'use strict';
/* =====================================================================
   SISTEMA DE SONS PERSONALIZADOS (audio.js)
   Carregado DEPOIS de game.js. Não altera o motor sintetizado (Au): apenas
   o "intercepta". Se existir um arquivo de áudio para o evento, toca o arquivo;
   se não existir, toca o som sintetizado de sempre.

   De onde vêm os sons (prioridade de cima para baixo):
     1. IMPORTADOS no jogo   (Configurações > Sons e músicas) — ficam salvos no aparelho
     2. PASTA  sons/         (ex.: sons/goal.mp3, sons/goal_2.mp3 = variação sorteada)
     3. SINTETIZADO          (o som original do jogo)

   Formatos: o que o navegador decodificar (mp3, wav, ogg, m4a/aac, flac, webm).
   ===================================================================== */

/* id, rótulo, grupo */
const SND_EVENTS = [
  ['music_menu', 'Música dos menus', 'Músicas'],
  ['music_game', 'Música durante a partida', 'Músicas'],
  ['crowd', 'Torcida de fundo (em loop)', 'Músicas'],
  ['goal', 'Gol', 'Lances'], ['net', 'Bola na rede', 'Lances'], ['post', 'Bola na trave', 'Lances'],
  ['save', 'Defesa do goleiro', 'Lances'], ['miss', 'Chute para fora', 'Lances'], ['ooh', '"Uuuh" da torcida', 'Lances'],
  ['whistle', 'Apito', 'Árbitro'], ['foul', 'Falta', 'Árbitro'], ['whistleEnd', 'Apito final', 'Árbitro'],
  ['corner', 'Escanteio', 'Árbitro'], ['horn', 'Buzina', 'Árbitro'],
  ['kick', 'Chute', 'Bola e jogadores'], ['pass', 'Passe', 'Bola e jogadores'], ['bounce', 'Quique da bola', 'Bola e jogadores'],
  ['tackle', 'Desarme', 'Bola e jogadores'], ['slide', 'Carrinho', 'Bola e jogadores'], ['dash', 'Arrancada', 'Bola e jogadores'],
  ['sprint', 'Corrida', 'Bola e jogadores'], ['swap', 'Troca de jogador', 'Bola e jogadores'],
  ['win', 'Vitória', 'Resultado'], ['lose', 'Derrota', 'Resultado'], ['count', 'Contagem regressiva', 'Resultado'], ['ach', 'Conquista', 'Resultado'],
  ['ui', 'Clique nos botões', 'Menus'], ['back', 'Voltar', 'Menus'], ['select', 'Selecionar', 'Menus'],
  ['confirm', 'Confirmar', 'Menus'], ['error', 'Erro', 'Menus']
];
const SND_LOOPS = new Set(['music_menu', 'music_game', 'crowd']);
const SND_ALIAS = { click: 'ui' };                       // nomes usados no jogo que compartilham o mesmo som
const SND_MINGAP = { ui: 70, back: 70, bounce: 90, sprint: 120, ooh: 400, miss: 400 };   // ms entre repetições
const SND_PITCH = new Set(['kick', 'pass', 'bounce', 'tackle', 'slide', 'save', 'post', 'net']); // leve variação de tom
const SND_PT = { // nomes de arquivo em português
  gol: 'goal', rede: 'net', trave: 'post', defesa: 'save', chute: 'kick', passe: 'pass', quique: 'bounce', desarme: 'tackle',
  carrinho: 'slide', arrancada: 'dash', corrida: 'sprint', apito: 'whistle', falta: 'foul', apito_final: 'whistleEnd', fim_de_jogo: 'whistleEnd',
  escanteio: 'corner', buzina: 'horn', vitoria: 'win', derrota: 'lose', torcida: 'crowd', musica: 'music_menu', musica_menu: 'music_menu',
  musica_jogo: 'music_game', musica_partida: 'music_game', clique: 'ui', voltar: 'back', confirmar: 'confirm', erro: 'error', conquista: 'ach'
};
const SND_MAX_BYTES = 12 * 1024 * 1024;
const SND_EXT = /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm|opus)$/i;

const SndPack = {
  user: {},     // id -> [{name,data:ArrayBuffer,buf:AudioBuffer}]   (importados)
  folder: {},   // id -> [{name,data,buf}]                           (pasta sons/)
  meta: {},     // id -> {vol: 0..1.5}
  db: null, dctx: null, ready: false, persistOK: true,
  last: {}, lastPick: {}, pv: null, slots: {}, voices: {},

  /* ---------- utilidades ---------- */
  idFromName(fileName) {
    let b = String(fileName).replace(/\.[^.]+$/, '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
      .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').replace(/_?\d+$/, '').replace(/_+$/, '');
    if (SND_PT[b]) return SND_PT[b];
    const hit = SND_EVENTS.find(e => e[0].toLowerCase() === b || e[0].toLowerCase() === b.replace(/_/g, ''));
    if (hit) return hit[0];
    // nomes "livres": música do menu / da partida / torcida
    const words = b.split('_'), has = (...ws) => ws.some(w => words.indexOf(w) >= 0);
    const mus = has('music', 'musica', 'musicas', 'trilha', 'tema', 'theme', 'bgm', 'soundtrack', 'song', 'som');
    if (mus || b === 'menu') {
      if (has('game', 'jogo', 'partida', 'match', 'gameplay', 'campo')) return 'music_game';
      if (b === 'menu' || has('menu', 'title', 'titulo', 'inicio', 'abertura', 'principal', 'main', 'lobby') || b === 'music' || b === 'musica') return 'music_menu';
    }
    if (has('torcida', 'crowd', 'arquibancada', 'estadio', 'stadium', 'ambiente', 'ambience')) return 'crowd';
    return null;
  },
  list(id) { return this.user[id] && this.user[id].length ? this.user[id] : (this.folder[id] || null); },
  source(id) { return this.user[id] && this.user[id].length ? 'user' : (this.folder[id] && this.folder[id].length ? 'folder' : 'synth'); },
  has(id) { const l = this.list(id); return !!(l && l.some(x => x.buf || x.data)); },
  vol(id) { const m = this.meta[id]; return m && typeof m.vol === 'number' ? m.vol : 1; },

  /* ---------- decodificação (não depende de gesto do usuário) ---------- */
  decode(ab) {
    if (!this.dctx) {
      const O = window.OfflineAudioContext || window.webkitOfflineAudioContext;
      if (!O) return Promise.reject(new Error('Sem suporte a áudio'));
      this.dctx = new O(1, 1, 44100);
    }
    const c = this.dctx, copy = ab.slice(0);
    return new Promise((res, rej) => {
      try { const p = c.decodeAudioData(copy, res, rej); if (p && p.catch) p.catch(rej); } catch (e) { rej(e); }
    });
  },
  async decodeItem(it) { try { it.buf = await this.decode(it.data); } catch (e) { it.buf = null; } return !!it.buf; },

  /* ---------- armazenamento (IndexedDB) ---------- */
  openDB() {
    return new Promise(res => {
      try {
        const r = indexedDB.open('fc3d_sons', 1);
        r.onupgradeneeded = () => r.result.createObjectStore('s');
        r.onsuccess = () => { this.db = r.result; res(); };
        r.onerror = () => { this.persistOK = false; res(); };
        r.onblocked = () => res();
      } catch (e) { this.persistOK = false; res(); }
    });
  },
  dbOp(mode, fn) {
    return new Promise(res => {
      if (!this.db) { res(null); return; }
      try {
        const tx = this.db.transaction('s', mode), st = tx.objectStore('s'), rq = fn(st);
        tx.oncomplete = () => res(rq && 'result' in rq ? rq.result : true);
        tx.onerror = tx.onabort = () => { this.persistOK = false; res(null); };
      } catch (e) { this.persistOK = false; res(null); }
    });
  },
  async dbLoadAll() {
    if (!this.db) return;
    await new Promise(res => {
      try {
        const rq = this.db.transaction('s', 'readonly').objectStore('s').openCursor();
        rq.onsuccess = () => {
          const cur = rq.result;
          if (!cur) { res(); return; }
          if (SND_EVENTS.some(e => e[0] === cur.key) && Array.isArray(cur.value)) this.user[cur.key] = cur.value.map(f => ({ name: f.name, data: f.data, buf: null }));
          cur.continue();
        };
        rq.onerror = () => res();
      } catch (e) { res(); }
    });
  },

  /* ---------- pasta sons/ ---------- */
  /* Descobre os arquivos da pasta sons/ em QUALQUER hospedagem:
     1) /api/sons (server.js)  2) sons/manifest.json  3) listagem de diretório  4) tentativa pelos nomes dos eventos */
  async listFiles() {
    const tryJson = async url => { try { const r = await fetch(url, { cache: 'no-store' }); if (r.ok) { const j = await r.json(); if (j && Array.isArray(j.files)) return j.files; } } catch (e) {} return null; };
    let f = await tryJson('api/sons'); if (f && f.length) return { via: 'servidor', files: f };
    const man = await tryJson('sons/manifest.json');
    if (man && man.length) {
      return { via: 'manifest', files: man }; // confia no manifest — sem probe extra
    }
    try {
      const r = await fetch('sons/', { cache: 'no-store' });
      if (r.ok) {
        const t = await r.text(), out = [];
        if (/<a\s/i.test(t)) t.replace(/href="([^"?#]+)"/gi, (m, h) => { try { h = decodeURIComponent(h.split('/').pop()); } catch (e) {} if (SND_EXT.test(h) && out.indexOf(h) < 0) out.push(h); return m; });
        if (out.length) return { via: 'listagem', files: out };
      }
    } catch (e) {}
    return { via: 'tentativa', files: await this.probe() };
  },
  async probe() {
    const exists = async n => { try { const r = await fetch('sons/' + encodeURIComponent(n), { method: 'HEAD', cache: 'no-store' }); return r.ok && (r.headers.get('content-type') || '').indexOf('text/html') < 0; } catch (e) { return false; } };
    const names = new Set(); SND_EVENTS.forEach(e => names.add(e[0])); ['gol', 'apito', 'torcida', 'musica', 'menu', 'musica_menu', 'musica_jogo', 'vitoria', 'derrota'].forEach(k => names.add(k));
    const cands = [];
    names.forEach(n => [n, n.charAt(0).toUpperCase() + n.slice(1)].forEach(c => ['mp3', 'wav', 'ogg'].forEach(x => cands.push(c + '.' + x))));
    const found = []; let i = 0;
    await Promise.all(Array.from({ length: 8 }, async () => { while (i < cands.length) { const n = cands[i++]; if (await exists(n)) found.push(n); } }));
    // variações _2 … _5 só para o que foi encontrado
    const vars = []; found.forEach(n => { const m = n.match(/^(.*)\.(\w+)$/); for (let k = 2; k <= 5; k++) vars.push(m[1] + '_' + k + '.' + m[2]); });
    await Promise.all(vars.map(async n => { if (await exists(n)) found.push(n); }));
    return found.sort();
  },
  scanInfo: { via: '', n: 0, ignored: [] },
  async scanFolder() {
    const { via, files } = await this.listFiles();
    const jobs = [], ignored = [];
    for (const name of files) {
      if (!SND_EXT.test(name)) continue;
      const id = this.idFromName(name);
      if (!id) { ignored.push(name); continue; }
      jobs.push((async () => {
        try {
          const r = await fetch('sons/' + encodeURIComponent(name), { cache: 'force-cache' });
          if (!r.ok) return;
          const it = { name, data: await r.arrayBuffer(), buf: null };
          // arquivos grandes / loops: só decodifica na 1ª vez que tocar (boot mais rápido)
          const big = SND_LOOPS.has(id) || (it.data && it.data.byteLength > 400000);
          if (big) (this.folder[id] = this.folder[id] || []).push(it);
          else if (await this.decodeItem(it)) (this.folder[id] = this.folder[id] || []).push(it);
        } catch (e) {}
      })());
    }
    await Promise.all(jobs);
    this.scanInfo = { via, ignored, n: Object.values(this.folder).reduce((a, l) => a + l.length, 0) };
  },

  async init() {
    try { this.meta = JSON.parse(localStorage.getItem('fc3d_snd_meta') || '{}') || {}; } catch (e) { this.meta = {}; }
    await this.openDB();
    await this.dbLoadAll();
    await Promise.all(Object.values(this.user).flat().map(it => this.decodeItem(it)));
    for (const id of Object.keys(this.user)) { this.user[id] = this.user[id].filter(x => x.buf); if (!this.user[id].length) delete this.user[id]; }
    await this.scanFolder();
    this.ready = true;
    this.tick();
  },
  saveMeta() { try { localStorage.setItem('fc3d_snd_meta', JSON.stringify(this.meta)); } catch (e) {} },

  /* ---------- importação ---------- */
  async readFiles(files) {
    const ok = [], bad = [];
    for (const f of Array.from(files || [])) {
      if (f.size > SND_MAX_BYTES) { bad.push(f.name + ' (maior que 12 MB)'); continue; }
      if (!(f.type && f.type.indexOf('audio') === 0) && !SND_EXT.test(f.name)) { bad.push(f.name + ' (não é áudio)'); continue; }
      try {
        const it = { name: f.name, data: await f.arrayBuffer(), buf: null };
        if (await this.decodeItem(it)) ok.push(it); else bad.push(f.name + ' (formato não suportado)');
      } catch (e) { bad.push(f.name + ' (erro ao ler)'); }
    }
    return { ok, bad };
  },
  async setUser(id, items) {
    this.user[id] = items;
    await this.dbOp('readwrite', st => st.put(items.map(i => ({ name: i.name, data: i.data })), id));
  },
  async importTo(id, files) {
    const { ok, bad } = await this.readFiles(files);
    if (ok.length) await this.setUser(id, SND_LOOPS.has(id) ? ok.slice(0, 1) : ok.slice(0, 8));
    return { ids: ok.length ? [id] : [], count: ok.length, bad };
  },
  async importBulk(files) {
    const { ok, bad } = await this.readFiles(files);
    const groups = {}, unknown = [];
    for (const it of ok) { const id = this.idFromName(it.name); if (id) (groups[id] = groups[id] || []).push(it); else unknown.push(it.name + ' (nome não corresponde a nenhum evento)'); }
    for (const id of Object.keys(groups)) await this.setUser(id, SND_LOOPS.has(id) ? groups[id].slice(0, 1) : groups[id].slice(0, 8));
    return { ids: Object.keys(groups), count: ok.length - unknown.length, bad: bad.concat(unknown) };
  },
  async removeUser(id) {
    delete this.user[id];
    await this.dbOp('readwrite', st => st.delete(id));
    if (this.slots.music && this.slots.music.id === id) this.stopSlot('music');
    if (this.slots.crowd && this.slots.crowd.id === id) this.stopSlot('crowd');
  },
  async removeAllUser() { for (const id of Object.keys(this.user)) await this.removeUser(id); },

  /* ---------- efeitos ---------- */
  pick(id) {
    const l = (this.list(id) || []).filter(x => x.buf || x.data);
    if (!l.length) return null;
    let it;
    if (l.length === 1) it = l[0];
    else {
      let i = Math.floor(Math.random() * l.length);
      if (i === this.lastPick[id]) i = (i + 1) % l.length;
      this.lastPick[id] = i;
      it = l[i];
    }
    // decode lazy (músicas/torcida grandes)
    if (!it.buf && it.data && !it._decoding) {
      it._decoding = this.decodeItem(it).then(ok => { if (!ok) it.data = null; delete it._decoding; });
    }
    return it.buf ? it : null;
  },
  playSfx(id, v) {
    const c = Au.ctx; if (!c || !Au.out) return null;
    const gap = SND_MINGAP[id];
    if (gap) { const t = performance.now(); if (t - (this.last[id] || 0) < gap) return null; this.last[id] = t; }
    const it = this.pick(id); if (!it) return null;
    // som longo (>= 0,8 s) que se repete: corta o anterior com fade, em vez de tocar um por cima do outro
    const long = it.buf.duration >= .8, old = this.voices[id];
    if (old) {
      if (long) this.fadeVoice(old, .12);
      else if (performance.now() - old.t0 < 45) return null;       // disparo duplo no mesmo instante
    }
    const s = c.createBufferSource(); s.buffer = it.buf;
    if (SND_PITCH.has(id)) s.playbackRate.value = .96 + Math.random() * .08;
    const g = c.createGain(); g.gain.value = Math.max(0, (S.volSfx == null ? 100 : S.volSfx) / 100 * this.vol(id) * (v || 1));
    s.connect(g); g.connect(Au.out); s.start();
    const vc = this.voices[id] = { src: s, gain: g, t0: performance.now() };
    s.onended = () => { if (this.voices[id] === vc) delete this.voices[id]; try { g.disconnect(); } catch (e) {} };
    return s;
  },
  fadeVoice(v, t) {
    try {
      const c = Au.ctx, now = c.currentTime;
      v.gain.gain.cancelScheduledValues(now); v.gain.gain.setValueAtTime(v.gain.gain.value, now);
      v.gain.gain.linearRampToValueAtTime(0, now + t); v.src.stop(now + t + .02);
    } catch (e) { try { v.src.stop(); } catch (e2) {} }
  },
  stopAllSfx() { for (const id of Object.keys(this.voices)) { this.fadeVoice(this.voices[id], .1); delete this.voices[id]; } },

  /* ---------- músicas e torcida em loop ---------- */
  setSlot(name, id, target) {
    const c = Au.ctx; if (!c || !Au.out) return;
    let sl = this.slots[name];
    if (sl && sl.id !== id) { this.stopSlot(name); sl = null; }
    if (!id) return;
    if (!sl) {
      const it = this.pick(id); if (!it) return;
      const s = c.createBufferSource(); s.buffer = it.buf; s.loop = true;
      const g = c.createGain(); g.gain.value = 0.0001;
      s.connect(g); g.connect(Au.out);
      s.start(0, name === 'crowd' ? Math.random() * Math.max(0, it.buf.duration - 1) : 0);
      sl = this.slots[name] = { id, src: s, gain: g };
    }
    sl.gain.gain.setTargetAtTime(Math.max(.0001, target), c.currentTime, .25);
  },
  stopSlot(name) {
    const sl = this.slots[name]; if (!sl) return;
    delete this.slots[name];
    try {
      const c = Au.ctx, t = c.currentTime;
      sl.gain.gain.cancelScheduledValues(t); sl.gain.gain.setTargetAtTime(.0001, t, .15);
      sl.src.stop(t + .8);
    } catch (e) { try { sl.src.stop(); } catch (e2) {} }
  },
  mode() {
    if (!S.sound) return null;
    if (document.body.classList.contains('playing')) return 'game';
    const cs = typeof curScreen !== 'undefined' ? curScreen : '', pv = typeof prevScreen !== 'undefined' ? prevScreen : '';
    return (cs === 'pause' || ((cs === 'set' || cs === 'sons') && pv === 'pause')) ? 'pause' : 'menu';
  },
  tick() {
    if (!this.ready || !Au.ctx) return;
    if (S.sound && Au.ctx.state === 'suspended') Au.resume();
    const m = this.mode();
    const mus = m === 'game' || m === 'pause' ? 'music_game' : m === 'menu' ? 'music_menu' : null;
    const crw = m === 'game' || m === 'pause' ? 'crowd' : null;
    const duck = m === 'pause' ? .3 : 1;
    this.setSlot('music', mus && this.has(mus) ? mus : null, (S.volMus == null ? 60 : S.volMus) / 100 * (mus ? this.vol(mus) : 1) * duck);
    this.setSlot('crowd', crw && this.has(crw) ? crw : null, (S.volCrowd == null ? 60 : S.volCrowd) / 100 * (crw ? this.vol(crw) : 1) * duck);
  },

  /* ---------- pré-escuta (tela de gerenciamento) ---------- */
  stopPreview() { if (this.pv) { try { this.pv.stop(); } catch (e) {} this.pv = null; } },
  preview(id) {
    if (!S.sound) return 'off';
    Au.init(); Au.resume();
    if (!Au.ctx) return 'off';
    if (this.pv) { this.stopPreview(); return 'stopped'; }
    if (this.has(id)) {
      const it = this.pick(id), c = Au.ctx, s = c.createBufferSource(), g = c.createGain();
      s.buffer = it.buf; g.gain.value = (SND_LOOPS.has(id) ? (S.volMus / 100) : (S.volSfx / 100)) * this.vol(id);
      s.connect(g); g.connect(Au.out); s.start();
      s.onended = () => { if (this.pv === s) this.pv = null; };
      this.pv = s; return 'file';
    }
    if (SND_LOOPS.has(id)) return 'none';
    SndPack._origPlay(id, 1); return 'synth';
  }
};

/* ---------- intercepta o motor de áudio original ---------- */
SndPack._origPlay = Au.play.bind(Au);
Au.play = function (n, v) {
  const id = SND_ALIAS[n] || n;
  if (SndPack.has(id)) {
    if (Net.fwd && NETSND.has(n)) Net.ev('s', n);     // multiplayer: avisa o outro aparelho, como antes
    if (!S.sound || !this.ctx) return;
    SndPack.playSfx(id, v || 1);
    return;
  }
  return SndPack._origPlay(n, v);
};
(function () {
  const origInit = Au.init.bind(Au);
  Au.init = function () { origInit(); if (SndPack.ready) SndPack.tick(); };
})();

setInterval(() => SndPack.tick(), 400);
/* Navegadores só liberam áudio depois de um gesto do usuário: qualquer toque, clique ou tecla libera. */
(function () {
  const unlock = () => {
    if (!S.sound) return;
    try { Au.init(); Au.resume(); } catch (e) {}
    SndPack.tick();
  };
  ['pointerdown', 'pointerup', 'touchend', 'mousedown', 'click', 'keydown'].forEach(ev => document.addEventListener(ev, unlock, true));
})();
document.addEventListener('visibilitychange', () => {
  if (!Au.ctx) return;
  if (document.hidden) { try { Au.ctx.suspend(); } catch (e) {} } else Au.resume();
});
addEventListener('load', () => { SndPack.init(); });

/* =====================================================================
   TELA "SONS E MÚSICAS"
   ===================================================================== */
const SndUI = {
  msg(t, bad) { const m = document.getElementById('sons-msg'); if (m) { m.textContent = t; m.classList.toggle('bad', !!bad); } },
  report(r, what) {
    let t = r.count ? (what || 'Importado') + ': ' + r.count + ' arquivo(s).' : 'Nada foi importado.';
    if (r.bad && r.bad.length) t += ' Ignorados: ' + r.bad.slice(0, 3).join('; ') + (r.bad.length > 3 ? '…' : '') + '.';
    if (r.count && !SndPack.persistOK) t += ' (Atenção: este navegador não permite salvar; valem só até fechar o jogo.)';
    this.msg(t, !r.count);
    Au.play(r.count ? 'confirm' : 'error');
  },
  pick(multiple, cb) {
    const i = document.createElement('input');
    i.type = 'file'; i.accept = 'audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac,.webm,.opus'; i.multiple = !!multiple;
    i.onchange = async () => { if (i.files && i.files.length) { this.msg('Lendo arquivos…'); await cb(i.files); } };
    i.click();
  },
  open() {
    this.build();
    const i = SndPack.scanInfo;
    const ig = (i.ignored || []).slice(0, 3).join(', ');
    this.msg((i.n ? 'Pasta sons/: ' + i.n + ' arquivo(s) detectado(s). ' : 'Pasta sons/: nenhum arquivo detectado. ')
      + (ig ? 'NÃO reconhecidos (renomeie, ex.: music_menu.mp3): ' + ig + '. ' : 'Importe um áudio por evento (⤒) ou vários de uma vez.'), !!ig);
    show('sons');
  },
  build() {
    const box = document.getElementById('sons-box'); if (!box) return;
    const keepScroll = box.scrollTop;
    box.innerHTML = '';
    let grp = '';
    SND_EVENTS.forEach(([id, label, g]) => {
      if (g !== grp) { grp = g; const h = document.createElement('div'); h.className = 'sec'; h.textContent = g; box.appendChild(h); }
      const src = SndPack.source(id), n = (SndPack.list(id) || []).length;
      const row = document.createElement('div'); row.className = 'row snd-row';
      const nm = document.createElement('span'); nm.className = 'snd-name';
      nm.innerHTML = '<b></b><small></small>';
      nm.firstChild.textContent = label;
      nm.lastChild.textContent = (src === 'user' ? 'Importado' : src === 'folder' ? 'Da pasta sons/' : (SND_LOOPS.has(id) ? 'Sem arquivo (silêncio)' : 'Som padrão')) + (n > 1 ? ' · ' + n + ' variações' : '') + (n === 1 && src !== 'synth' ? ' · ' + (SndPack.list(id)[0].name) : '');
      nm.lastChild.className = 'snd-' + src;
      const bPlay = document.createElement('button'); bPlay.className = 'snd-b'; bPlay.textContent = '▶'; bPlay.title = 'Ouvir';
      bPlay.onclick = () => { const r = SndPack.preview(id); if (r === 'off') this.msg('Ative o "Som" nas configurações para ouvir.', true); else if (r === 'none') this.msg('Ainda não há arquivo para esta faixa.', true); };
      const bImp = document.createElement('button'); bImp.className = 'snd-b'; bImp.textContent = '⤒'; bImp.title = 'Importar áudio';
      bImp.onclick = () => this.pick(!SND_LOOPS.has(id), async f => { const r = await SndPack.importTo(id, f); this.report(r, 'Importado para "' + label + '"'); this.build(); SndPack.tick(); });
      const bDel = document.createElement('button'); bDel.className = 'snd-b'; bDel.textContent = '✕'; bDel.title = 'Voltar ao padrão'; bDel.disabled = src !== 'user';
      bDel.onclick = async () => { await SndPack.removeUser(id); this.msg('"' + label + '" voltou ao padrão.'); Au.play('back'); this.build(); SndPack.tick(); };
      const vol = document.createElement('input'); vol.type = 'range'; vol.min = 0; vol.max = 150; vol.step = 5; vol.value = Math.round(SndPack.vol(id) * 100); vol.title = 'Volume deste som';
      vol.oninput = () => { SndPack.meta[id] = { vol: vol.value / 100 }; SndPack.saveMeta(); SndPack.tick(); };
      const ctr = document.createElement('span'); ctr.className = 'snd-ctr'; ctr.append(bPlay, bImp, bDel, vol);
      row.append(nm, ctr); box.appendChild(row);
    });
    box.scrollTop = keepScroll;
  }
};

document.getElementById('b-sons-bulk').onclick = () => SndUI.pick(true, async f => {
  const r = await SndPack.importBulk(f); SndUI.report(r, 'Distribuídos pelos eventos'); SndUI.build(); SndPack.tick();
});
document.getElementById('b-sons-back').onclick = () => { SndPack.stopPreview(); Au.play('back'); buildSettings(); show('set'); };
