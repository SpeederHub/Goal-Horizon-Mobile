/* ============================================================
   FC CARREIRA 3D — BANCO DE CLUBES (temporada 2026-27)
   Organizado por PAÍS → CAMPEONATO → CLUBE. IDs permanentes.
   Escudos: gerados por código (provisórios, originais). Para usar
   escudos reais, coloque PNGs em /crests/<id>.png e liste o id em
   CREST_FILES (veja LEIAME-CLUBES.txt).
   ============================================================ */
'use strict';
const CREST_FOLDERS={bra:'brazil',eng:'england',esp:'spain',ita:'italy',ger:'germany',fra:'france',por:'portugal'}; // demais paises -> other
const CREST_FILES={}; // id -> caminho (gerado automaticamente a partir do pais + slug; manifest.json pode sobrescrever)
 // coloque cada PNG em crests/<id>.png

// tokens de cor
const FC_COL={W:'#ffffff',K:'#141414',R:'#d4121f',M:'#7a1f3d',Q:'#a50044',N:'#0b2a5b',B:'#1d5fcf',L:'#6fc3f0',G:'#139a47',D:'#0b5a33',Y:'#f6d21a',O:'#f08a00',P:'#6b2a96',S:'#9aa3ad',A:'#c9a227',F:'#e86aa8',U:'#5a3a22'};

const FC_COUNTRIES=[
 {id:'BRA',code:'bra',name:'BRASIL',flag:'\u{1F1E7}\u{1F1F7}',promo:4,leagues:[{id:'BRA1',name:'Série A',tier:1},{id:'BRA2',name:'Série B',tier:2}]},
 {id:'ENG',code:'eng',name:'INGLATERRA',flag:'\u{1F3F4}\u{E0067}\u{E0062}\u{E0065}\u{E006E}\u{E0067}\u{E007F}',promo:3,leagues:[{id:'ENG1',name:'Premier League',tier:1},{id:'ENG2',name:'Championship',tier:2}]},
 {id:'ESP',code:'esp',name:'ESPANHA',flag:'\u{1F1EA}\u{1F1F8}',promo:3,leagues:[{id:'ESP1',name:'La Liga',tier:1},{id:'ESP2',name:'Segunda División',tier:2}]},
 {id:'ITA',code:'ita',name:'ITÁLIA',flag:'\u{1F1EE}\u{1F1F9}',promo:3,leagues:[{id:'ITA1',name:'Serie A',tier:1},{id:'ITA2',name:'Serie B',tier:2}]},
 {id:'GER',code:'ger',name:'ALEMANHA',flag:'\u{1F1E9}\u{1F1EA}',promo:2,leagues:[{id:'GER1',name:'Bundesliga',tier:1},{id:'GER2',name:'2. Bundesliga',tier:2}]},
 {id:'FRA',code:'fra',name:'FRANÇA',flag:'\u{1F1EB}\u{1F1F7}',promo:2,leagues:[{id:'FRA1',name:'Ligue 1',tier:1},{id:'FRA2',name:'Ligue 2',tier:2}]},
 {id:'POR',code:'por',name:'PORTUGAL',flag:'\u{1F1F5}\u{1F1F9}',promo:2,leagues:[{id:'POR1',name:'Primeira Liga',tier:1},{id:'POR2',name:'Liga Portugal 2',tier:2}]},
 {id:'NED',code:'ned',name:'HOLANDA',flag:'\u{1F1F3}\u{1F1F1}',promo:2,leagues:[{id:'NED1',name:'Eredivisie',tier:1},{id:'NED2',name:'Eerste Divisie',tier:2}]}
];

// slug|Nome curto|Nome oficial|SIGLA|força+estilo(A/D/M)|camisa|calção|meiões(opc)|r (time B/reserva)
const FC_RAW={
BRA1:`flamengo|Flamengo|Clube de Regatas do Flamengo|FLA|85A|R|K|R
palmeiras|Palmeiras|Sociedade Esportiva Palmeiras|PAL|90|G|W|G
corinthians|Corinthians|Sport Club Corinthians Paulista|COR|78|W|W|K
saopaulo|São Paulo|São Paulo Futebol Clube|SAO|78|W|W|R
santos|Santos|Santos Futebol Clube|SAN|73|W|W|K
vasco|Vasco da Gama|Club de Regatas Vasco da Gama|VAS|74|K|K|W
fluminense|Fluminense|Fluminense Football Club|FLU|77|M|W|D
botafogo|Botafogo|Botafogo de Futebol e Regatas|BOT|79|K|K|W
gremio|Grêmio|Grêmio Foot-Ball Porto Alegrense|GRM|77|#0d80bf|K|W
internacional|Internacional|Sport Club Internacional|SCI|77|R|W|R
cruzeiro|Cruzeiro|Cruzeiro Esporte Clube|CRU|79|#1a4fb5|W|#1a4fb5
atleticomg|Atlético Mineiro|Clube Atlético Mineiro|CAM|77|K|K|W
bahia|Bahia|Esporte Clube Bahia|BAH|75|B|W|R
bragantino|Red Bull Bragantino|Red Bull Bragantino|RBB|73|W|W|R
mirassol|Mirassol|Mirassol Futebol Clube|MIR|68|Y|B|Y
vitoria|Vitória|Esporte Clube Vitória|VIT|68|R|K|R
coritiba|Coritiba|Coritiba Foot Ball Club|CFC|67|D|W|D
athleticopr|Athletico Paranaense|Club Athletico Paranaense|CAP|73|R|K|R
chapecoense|Chapecoense|Associação Chapecoense de Futebol|CHP|62|G|W|G
remo|Remo|Clube do Remo|REM|62|N|W|N`,
BRA2:`ceara|Ceará|Ceará Sporting Club|CEA|66|K|W|K
fortaleza|Fortaleza|Fortaleza Esporte Clube|FOR|70|B|R|B
juventude|Juventude|Esporte Clube Juventude|JUE|60|G|W|G
sport|Sport Recife|Sport Club do Recife|SPO|65|R|K|R
pontepreta|Ponte Preta|Associação Atlética Ponte Preta|PON|60|K|K|W
londrina|Londrina|Londrina Esporte Clube|LON|55|B|W|B
nautico|Náutico|Clube Náutico Capibaribe|NAU|58|R|W|R
saobernardo|São Bernardo|São Bernardo Futebol Clube|SBE|55|Y|K|Y
criciuma|Criciúma|Criciúma Esporte Clube|CRI|62|Y|K|Y
goias|Goiás|Goiás Esporte Clube|GOI|63|G|W|G
novorizontino|Novorizontino|Grêmio Novorizontino|NVH|60|Y|K|Y
crb|CRB|Clube de Regatas Brasil|CRB|60|R|W|R
avai|Avaí|Avaí Futebol Clube|AVA|58|B|W|B
cuiaba|Cuiabá|Cuiabá Esporte Clube|CUI|60|D|Y|D
atleticogo|Atlético Goianiense|Atlético Clube Goianiense|ACG|58|R|K|R
operariopr|Operário Ferroviário|Operário Ferroviário Esporte Clube|OPE|56|K|W|K
vilanova|Vila Nova|Vila Nova Futebol Clube|VNO|58|R|W|R
americamg|América Mineiro|América Futebol Clube (MG)|AMM|58|G|W|G
athleticmg|Athletic Club (MG)|Athletic Club (São João del-Rei)|AMG|52|K|W|K
botafogosp|Botafogo-SP|Botafogo Futebol Clube (SP)|BSP|56|R|K|R`,
ENG1:`arsenal|Arsenal|Arsenal Football Club|ARS|90|R|W|R
astonvilla|Aston Villa|Aston Villa Football Club|AVL|80|M|W|L
bournemouth|Bournemouth|Association Football Club Bournemouth|BOU|74|R|K|R
brentford|Brentford|Brentford Football Club|BRE|74|R|W|R
brighton|Brighton & Hove Albion|Brighton & Hove Albion Football Club|BHA|75|B|W|B
chelsea|Chelsea|Chelsea Football Club|CHE|84|B|B|W
coventry|Coventry City|Coventry City Football Club|COV|68|L|L|L
crystalpalace|Crystal Palace|Crystal Palace Football Club|CRY|76|B|R|B
everton|Everton|Everton Football Club|EVE|74|B|W|B
fulham|Fulham|Fulham Football Club|FUL|74|W|K|K
hull|Hull City|Hull City Association Football Club|HUL|64|O|K|O
ipswich|Ipswich Town|Ipswich Town Football Club|IPS|66|B|W|B
leeds|Leeds United|Leeds United Football Club|LEE|74|W|W|B
liverpool|Liverpool|Liverpool Football Club|LIV|90A|R|R|R
mancity|Manchester City|Manchester City Football Club|MCI|91A|L|W|L
manutd|Manchester United|Manchester United Football Club|MUN|83|R|W|K
newcastle|Newcastle United|Newcastle United Football Club|NEW|80|K|K|W
nottmforest|Nottingham Forest|Nottingham Forest Football Club|NFO|74|R|W|R
sunderland|Sunderland|Sunderland Association Football Club|SUN|70|R|K|R
tottenham|Tottenham Hotspur|Tottenham Hotspur Football Club|TOT|82|W|N|W`,
ENG2:`birmingham|Birmingham City|Birmingham City Football Club|BIR|63|B|B|B
blackburn|Blackburn Rovers|Blackburn Rovers Football Club|BLB|62|B|W|B
bolton|Bolton Wanderers|Bolton Wanderers Football Club|BWF|58|W|N|W
bristolcity|Bristol City|Bristol City Football Club|BRC|63|R|W|R
burnley|Burnley|Burnley Football Club|BUR|68|M|W|L
cardiff|Cardiff City|Cardiff City Football Club|CAR|58|B|B|B
charlton|Charlton Athletic|Charlton Athletic Football Club|CHL|60|R|W|R
derby|Derby County|Derby County Football Club|DER|63|W|K|W
lincoln|Lincoln City|Lincoln City Football Club|LIN|58|R|W|R
middlesbrough|Middlesbrough|Middlesbrough Football Club|MID|68|R|W|R
millwall|Millwall|Millwall Football Club|MLW|62|N|W|N
norwich|Norwich City|Norwich City Football Club|NOR|64|Y|G|Y
portsmouth|Portsmouth|Portsmouth Football Club|POM|60|B|W|B
preston|Preston North End|Preston North End Football Club|PNE|60|W|N|W
qpr|Queens Park Rangers|Queens Park Rangers Football Club|QPR|58|B|W|B
sheffutd|Sheffield United|Sheffield United Football Club|SHU|66|R|K|R
southampton|Southampton|Southampton Football Club|SOU|66|R|K|R
stoke|Stoke City|Stoke City Football Club|STK|62|R|W|R
swansea|Swansea City|Swansea City Association Football Club|SWA|62|W|W|W
watford|Watford|Watford Football Club|WAT|64|Y|K|Y
westbrom|West Bromwich Albion|West Bromwich Albion Football Club|WBA|64|N|W|N
westham|West Ham United|West Ham United Football Club|WHU|71|M|W|L
wolves|Wolverhampton Wanderers|Wolverhampton Wanderers Football Club|WOL|70|O|K|O
wrexham|Wrexham|Wrexham Association Football Club|WRX|64|R|W|R`,
ESP1:`alaves|Alavés|Deportivo Alavés|ALA|70|B|W|B
athletic|Athletic Club|Athletic Club|ATB|79|R|K|R
atletico|Atlético de Madrid|Club Atlético de Madrid|ATM|86|R|N|R
barcelona|FC Barcelona|Futbol Club Barcelona|FCB|90A|Q|N|N
celta|Celta de Vigo|Real Club Celta de Vigo|CEL|72|L|L|L
deportivo|Deportivo La Coruña|Real Club Deportivo de La Coruña|DEP|64|B|W|B
elche|Elche|Elche Club de Fútbol|ELC|65|W|G|W
espanyol|Espanyol|Reial Club Deportiu Espanyol|ESY|68|B|W|B
getafe|Getafe|Getafe Club de Fútbol|GET|70|B|B|B
levante|Levante|Levante Unión Deportiva|LEV|66|M|N|M
malaga|Málaga|Málaga Club de Fútbol|MAL|62|L|W|L
osasuna|Osasuna|Club Atlético Osasuna|OSA|72|R|N|R
racing|Racing Santander|Real Racing Club de Santander|RAC|63|D|W|D
rayo|Rayo Vallecano|Rayo Vallecano de Madrid|RAY|72|W|W|R
betis|Real Betis|Real Betis Balompié|BET|77|G|W|G
realmadrid|Real Madrid|Real Madrid Club de Fútbol|RMA|92A|W|W|W
realsociedad|Real Sociedad|Real Sociedad de Fútbol|RSO|76|B|W|B
sevilla|Sevilla|Sevilla Fútbol Club|SEV|74|W|W|R
valencia|Valencia|Valencia Club de Fútbol|VAL|74|W|K|K
villarreal|Villarreal|Villarreal Club de Fútbol|VIL|77|Y|N|Y`,
ESP2:`albacete|Albacete|Albacete Balompié|ALB|58|W|W|W
almeria|Almería|Unión Deportiva Almería|ALM|62|R|W|R
andorra|Andorra|Futbol Club Andorra|AND|54|B|B|Y
burgos|Burgos|Burgos Club de Fútbol|BCF|56|W|K|W
cadiz|Cádiz|Cádiz Club de Fútbol|CAD|60|Y|B|Y
castellon|Castellón|Club Deportivo Castellón|CAS|58|K|W|K
celtafortuna|Celta Fortuna|Real Club Celta de Vigo "B"|CEF|52|L|W|L|r
ceuta|Ceuta|Asociación Deportiva Ceuta Fútbol Club|CEU|52|W|K|W
cordoba|Córdoba|Córdoba Club de Fútbol|COD|58|G|W|G
eibar|Eibar|Sociedad Deportiva Eibar|EIB|60|M|N|M
eldense|Eldense|Club Deportivo Eldense|ELD|52|B|W|B
girona|Girona|Girona Fútbol Club|GIR|68|R|W|R
granada|Granada|Granada Club de Fútbol|GRA|60|R|W|R
laspalmas|Las Palmas|Unión Deportiva Las Palmas|LPA|62|Y|B|Y
leganes|Leganés|Club Deportivo Leganés|LGN|58|B|W|B
mallorca|Mallorca|Real Club Deportivo Mallorca|MLL|68|R|K|R
oviedo|Real Oviedo|Real Oviedo|OVI|62|B|B|B
realsociedadb|Real Sociedad B|Real Sociedad de Fútbol "B"|RSB|56|B|W|B|r
sabadell|Sabadell|Centre d'Esports Sabadell|SAB|50|B|W|B
sportinggijon|Sporting de Gijón|Real Sporting de Gijón|SPG|60|R|W|R
tenerife|Tenerife|Club Deportivo Tenerife|TEN|58|W|B|W
valladolid|Valladolid|Real Valladolid Club de Fútbol|VLL|60|P|W|P`,
ITA1:`atalanta|Atalanta|Atalanta Bergamasca Calcio|ATA|82|K|K|B
bologna|Bologna|Bologna Football Club 1909|BFC|75|R|W|B
cagliari|Cagliari|Cagliari Calcio|CAG|66|R|N|R
como|Como|Como 1907|COM|72|B|B|B
fiorentina|Fiorentina|ACF Fiorentina|FIO|74|P|W|P
frosinone|Frosinone|Frosinone Calcio|FRO|58|Y|B|Y
genoa|Genoa|Genoa Cricket and Football Club|GEN|68|R|N|R
inter|Inter|Football Club Internazionale Milano|INT|89|B|K|B
juventus|Juventus|Juventus Football Club|JUV|86|W|K|W
lazio|Lazio|Società Sportiva Lazio|LAZ|76|L|W|L
lecce|Lecce|Unione Sportiva Lecce|LCE|62|Y|R|Y
milan|AC Milan|Associazione Calcio Milan|ACM|84|R|K|K
monza|Monza|Associazione Calcio Monza|MNZ|62|R|W|R
napoli|Napoli|Società Sportiva Calcio Napoli|NAP|84|L|W|L
parma|Parma|Parma Calcio 1913|PAR|68|W|B|W
roma|Roma|Associazione Sportiva Roma|ROM|80|M|W|M
sassuolo|Sassuolo|Unione Sportiva Sassuolo Calcio|SAS|66|G|K|G
torino|Torino|Torino Football Club|TOR|68|M|W|M
udinese|Udinese|Udinese Calcio|UDI|66|W|K|W
venezia|Venezia|Venezia Football Club|VEN|60|K|K|G`,
ITA2:`arezzo|Arezzo|Unione Sportiva Arezzo|ARE|52|M|W|M
ascoli|Ascoli|Ascoli Calcio 1898 Football Club|ASC|54|W|K|W
avellino|Avellino|Unione Sportiva Avellino 1912|AVE|56|G|W|G
benevento|Benevento|Benevento Calcio|BEN|56|R|W|R
carrarese|Carrarese|Carrarese Calcio 1908|CRR|54|Y|B|Y
catanzaro|Catanzaro|Unione Sportiva Catanzaro 1929|CTZ|60|Y|R|Y
cesena|Cesena|Cesena Football Club|CSN|58|W|K|W
cremonese|Cremonese|Unione Sportiva Cremonese|CRE|62|R|W|R
empoli|Empoli|Empoli Football Club|EMP|60|B|W|B
verona|Hellas Verona|Hellas Verona Football Club|HVR|62|Y|B|Y
jstabia|Juve Stabia|Società Sportiva Juve Stabia|JST|54|Y|B|Y
mantova|Mantova|Mantova Football Club|MNT|52|W|R|W
modena|Modena|Modena Football Club 2018|MOD|58|Y|B|Y
padova|Padova|Calcio Padova|PDV|56|W|R|W
palermo|Palermo|Palermo Football Club|PLM|66|F|K|F
pisa|Pisa|Pisa Sporting Club|PIS|60|N|K|N
sampdoria|Sampdoria|Unione Calcio Sampdoria|SAM|62|B|W|B
sudtirol|Südtirol|Football Club Südtirol|SUD|54|W|R|W
vicenza|Vicenza|Vicenza Calcio|VIC|56|R|W|R
entella|Virtus Entella|Virtus Entella|ENT|52|L|W|L`,
GER1:`bayern|Bayern München|Fußball-Club Bayern München|BAY|91A|R|W|R
dortmund|Borussia Dortmund|Ballspielverein Borussia 09 Dortmund|BVB|82|Y|K|Y
leipzig|RB Leipzig|RasenBallsport Leipzig|RBL|80|W|R|W
stuttgart|VfB Stuttgart|Verein für Bewegungsspiele Stuttgart 1893|VFB|78|W|R|W
hoffenheim|TSG Hoffenheim|TSG 1899 Hoffenheim|TSG|72|B|B|B
leverkusen|Bayer Leverkusen|Bayer 04 Leverkusen|B04|82|R|K|R
freiburg|SC Freiburg|Sport-Club Freiburg|SCF|72|R|K|R
frankfurt|Eintracht Frankfurt|Eintracht Frankfurt|SGE|74|K|K|R
augsburg|FC Augsburg|Fußball-Club Augsburg 1907|FCA|66|R|W|R
mainz|Mainz 05|1. FSV Mainz 05|M05|68|R|W|R
unionberlin|Union Berlin|1. FC Union Berlin|FCU|68|R|W|R
gladbach|Borussia M'gladbach|Borussia Verein für Leibesübungen 1900 Mönchengladbach|BMG|68|W|K|G
hsv|Hamburger SV|Hamburger Sport-Verein|HSV|70|W|B|W
koeln|1. FC Köln|1. Fußball-Club Köln 01/07|KOE|68|W|R|W
bremen|Werder Bremen|Sportverein Werder Bremen|SVW|70|G|W|G
schalke|Schalke 04|Fußball-Club Gelsenkirchen-Schalke 04|S04|66|B|W|B
elversberg|SV Elversberg|Sportvereinigung Elversberg 07|ELV|60|K|W|K
paderborn|SC Paderborn|Sport-Club Paderborn 07|P07|62|B|K|B`,
GER2:`hertha|Hertha BSC|Hertha, Berliner Sport-Club|BSC|66|W|B|W
bielefeld|Arminia Bielefeld|Deutscher Sportclub Arminia Bielefeld|DSC|62|B|W|B
bochum|VfL Bochum|Verein für Leibesübungen Bochum 1848|BOC|62|B|W|B
braunschweig|Eintracht Braunschweig|Braunschweiger Turn- und Sportverein Eintracht von 1895|EBS|58|Y|B|Y
cottbus|Energie Cottbus|Fußballclub Energie Cottbus|COT|56|R|W|R
darmstadt|Darmstadt 98|Sportverein Darmstadt 1898|SVD|60|B|W|B
dresden|Dynamo Dresden|Sportgemeinschaft Dynamo Dresden|SGD|60|Y|K|Y
fuerth|Greuther Fürth|Spielvereinigung Greuther Fürth|SPF|60|W|G|W
hannover|Hannover 96|Hannoverscher Sportverein von 1896|H96|64|R|K|R
heidenheim|1. FC Heidenheim|1. Fußball-Club Heidenheim 1846|HDH|64|R|B|R
kaiserslautern|1. FC Kaiserslautern|1. Fußball-Club Kaiserslautern|FCK|62|R|W|R
karlsruhe|Karlsruher SC|Karlsruher Sport-Club|KSC|60|B|W|B
kiel|Holstein Kiel|Kieler Sportvereinigung Holstein von 1900|KIE|58|B|W|B
magdeburg|1. FC Magdeburg|1. Fußball-Club Magdeburg|MAG|60|B|W|B
nuernberg|1. FC Nürnberg|1. Fußball-Club Nürnberg|NUE|62|R|K|R
osnabrueck|VfL Osnabrück|Verein für Leibesübungen Osnabrück|OSN|54|P|W|P
stpauli|FC St. Pauli|Fußball-Club St. Pauli von 1910|STP|68|U|W|U
wolfsburg|VfL Wolfsburg|Verein für Leibesübungen Wolfsburg|WOB|72|G|W|G`,
FRA1:`angers|Angers|Angers Sporting Club de l'Ouest|ANG|60|K|W|K
auxerre|Auxerre|Association de la Jeunesse Auxerroise|AUX|60|W|B|W
brest|Brest|Stade Brestois 29|BRS|64|R|W|R
lehavre|Le Havre|Le Havre Athletic Club|HAC|58|L|N|L
lemans|Le Mans|Le Mans Football Club|LMN|54|Y|R|Y
lens|Lens|Racing Club de Lens|RCL|74|Y|R|Y
lille|Lille|Lille Olympique Sporting Club|LOS|76|R|W|R
lorient|Lorient|Football Club Lorientais|FCL|58|O|K|O
lyon|Lyon|Olympique Lyonnais|OLY|78|W|B|R
marseille|Marseille|Olympique de Marseille|OLM|80|W|L|W
monaco|Monaco|Association Sportive de Monaco Football Club|ASM|77|R|W|R
nice|Nice|Olympique Gymnaste Club Nice Côte d'Azur|NIC|72|R|K|R
parisfc|Paris FC|Paris Football Club|PFC|66|B|W|B
psg|Paris Saint-Germain|Paris Saint-Germain Football Club|PSG|91A|N|N|R
rennes|Rennes|Stade Rennais Football Club|REN|74|R|K|R
strasbourg|Strasbourg|Racing Club de Strasbourg Alsace|RCS|70|B|W|B
toulouse|Toulouse|Toulouse Football Club|TFC|66|P|W|P
troyes|Troyes|Estac Troyes|TRO|56|B|W|B`,
FRA2:`annecy|Annecy|Football Club d'Annecy|ANN|52|R|W|R
boulogne|Boulogne|Union Sportive Boulogne Côte d'Opale|USB|50|R|W|R
clermont|Clermont|Clermont Foot 63|CLE|54|R|B|R
dijon|Dijon|Dijon Football Côte-d'Or|DIJ|52|R|W|R
dunkerque|Dunkerque|Union Sportive Dunkerque|DUN|50|B|R|B
grenoble|Grenoble|Grenoble Foot 38|GRE|50|B|W|B
guingamp|Guingamp|En Avant Guingamp|EAG|56|R|K|R
laval|Laval|Stade Lavallois Mayenne Football Club|LAV|52|O|K|O
metz|Metz|Football Club de Metz|MET|62|M|W|M
montpellier|Montpellier|Montpellier Hérault Sport Club|MHS|62|B|N|B
nancy|Nancy|Association Sportive Nancy-Lorraine|ASN|54|W|R|W
nantes|Nantes|Football Club de Nantes|NAN|66|Y|G|Y
paul|Paul|Paul Football Club|PAU|50|Y|B|Y
redstar|Red Star|Red Star Football Club|RED|52|G|W|G
reims|Reims|Stade de Reims|SDR|62|R|W|R
rodez|Rodez|Rodez Aveyron Football|ROD|50|R|W|R
saintetienne|Saint-Étienne|Association Sportive de Saint-Étienne|STE|66|G|W|G
sochaux|Sochaux|Football Club Sochaux-Montbéliard|SOC|56|Y|B|Y`,
POR1:`alverca|Alverca|Futebol Clube de Alverca|ALV|54|R|W|R
arouca|Arouca|Futebol Clube de Arouca|ARO|56|Y|B|Y
benfica|Benfica|Sport Lisboa e Benfica|SLB|86|R|W|R
braga|Braga|Sporting Clube de Braga|SCB|76|R|W|R
casapia|Casa Pia|Casa Pia Atlético Clube|CPI|60|W|K|W
estoril|Estoril Praia|Grupo Desportivo Estoril Praia|EST|62|Y|B|Y
estrela|Estrela da Amadora|Clube de Futebol Estrela da Amadora|ESA|56|R|G|R
famalicao|Famalicão|Futebol Clube de Famalicão|FAM|62|B|W|B
gilvicente|Gil Vicente|Gil Vicente Futebol Clube|GIL|60|R|B|R
maritimo|Marítimo|Club Sport Marítimo|MAR|58|G|R|G
moreirense|Moreirense|Moreirense Futebol Clube|MOR|56|D|W|D
nacional|Nacional|Clube Desportivo Nacional|NAB|58|K|W|K
porto|FC Porto|Futebol Clube do Porto|FCP|84|B|W|B
rioave|Rio Ave|Rio Ave Futebol Clube|RAV|58|G|W|G
santaclara|Santa Clara|Clube Desportivo Santa Clara|SCL|58|R|W|R
sporting|Sporting CP|Sporting Clube de Portugal|SCP|85|G|W|G
vitoriaguimaraes|Vitória de Guimarães|Vitória Sport Clube|VSC|68|W|K|W
viseu|Académico de Viseu|Académico de Viseu Futebol Clube|ACV|52|W|K|W`,
POR2:`academica|Académica|Associação Académica de Coimbra – OAF|ACA|54|K|W|K
avs|AVS|AVS Futebol SAD|AVS|54|W|R|W
amarante|Amarante|Amarante Futebol Clube|AMT|50|G|W|G
benficab|Benfica B|Sport Lisboa e Benfica "B"|BEB|58|R|W|R|r
chaves|Chaves|Grupo Desportivo de Chaves|CHV|54|R|W|R
farense|Farense|Sporting Clube Farense|FAR|58|W|K|W
feirense|Feirense|Clube Desportivo Feirense|FEI|52|W|B|W
felgueiras|Felgueiras|Futebol Clube de Felgueiras 1932|FEL|48|R|W|R
leixoes|Leixões|Leixões Sport Club|LEI|54|R|W|R
lourosa|Lusitânia Lourosa|Lusitânia Futebol Clube|LUS|46|B|W|B
penafiel|Penafiel|Futebol Clube de Penafiel|PEN|52|B|W|B
portimonense|Portimonense|Portimonense Sporting Clube|PTM|58|K|W|K
portob|FC Porto B|Futebol Clube do Porto "B"|POB|56|B|W|B|r
sportingb|Sporting CP B|Sporting Clube de Portugal "B"|SPB|54|G|W|G|r
tondela|Tondela|Clube Desportivo de Tondela|TON|56|G|Y|G
torreense|Torreense|Sport Clube União Torreense|TRR|52|R|W|R
leiria|União de Leiria|União Desportiva de Leiria|UDL|52|G|W|G
vizela|Vizela|Futebol Clube de Vizela|VIZ|52|B|W|B`,
NED1:`ado|ADO Den Haag|Alles Door Oefening Den Haag|ADO|58|G|Y|G
ajax|Ajax|Amsterdamsche Football Club Ajax|AJA|82|W|W|R
az|AZ Alkmaar|Alkmaar Zaanstreek|AZA|76|R|W|R
cambuur|Cambuur|Sportclub Cambuur|SCC|58|Y|B|Y
excelsior|Excelsior|Excelsior Rotterdam|EXC|62|R|K|R
feyenoord|Feyenoord|Feyenoord Rotterdam|FEY|80|R|K|K
fortuna|Fortuna Sittard|Fortuna Sittard|FOS|60|Y|G|Y
goahead|Go Ahead Eagles|Go Ahead Eagles|GAE|64|R|Y|R
groningen|Groningen|Football Club Groningen|GRO|64|G|W|G
heerenveen|Heerenveen|Sportclub Heerenveen|HEE|68|B|W|B
nec|NEC Nijmegen|Nijmegen Eendracht Combinatie|NEC|68|R|K|R
pec|PEC Zwolle|Prins Eendracht Combinatie Zwolle|PEC|60|B|W|B
psv|PSV Eindhoven|Philips Sport Vereniging|PSV|85A|R|W|R
sparta|Sparta Rotterdam|Sparta Rotterdam|SPA|64|R|W|R
telstar|Telstar|Telstar Velsen|TEL|58|W|K|W
twente|Twente|Football Club Twente|TWE|70|R|W|R
utrecht|Utrecht|Football Club Utrecht|UTR|70|R|W|R
willem2|Willem II|Willem II Tilburg|WIL|58|R|B|R`,
NED2:`heracles|Heracles Almelo|Heracles Almelo|HER|58|K|W|K
nac|NAC Breda|Nooit Opgeven Altijd Doorgaan Breda|NAD|60|Y|K|Y
volendam|Volendam|Football Club Volendam|VOL|52|O|W|O
degraafschap|De Graafschap|De Graafschap Doetinchem|DGS|56|B|W|B
almere|Almere City|Almere City Football Club|ALC|52|R|K|R
jongpsv|Jong PSV|Jong PSV|JPS|52|R|W|R|r
rkc|RKC Waalwijk|Rooms Katholieke Combinatie Waalwijk|RKC|54|Y|B|Y
roda|Roda JC Kerkrade|Roda Johannesburg Combinatie|RJC|54|Y|K|Y
denbosch|FC Den Bosch|Football Club Den Bosch|FDB|50|B|W|B
dordrecht|FC Dordrecht|Football Club Dordrecht|DOR|48|G|W|G
eindhoven|FC Eindhoven|Football Club Eindhoven|FCE|50|B|W|B
jongutrecht|Jong FC Utrecht|Jong FC Utrecht|JUT|48|R|W|R|r
vvv|VVV-Venlo|Voetbal Vereniging Venlo|VVV|50|Y|K|Y
emmen|FC Emmen|Football Club Emmen|EMM|50|R|W|R
mvv|MVV Maastricht|Maastrichtse Voetbal Vereniging|MVM|48|R|W|R
vitesse|Vitesse|Stichting Betaald Voetbal Vitesse|VTS|52|Y|K|Y
jongaz|Jong AZ|Jong AZ|JAZ|48|R|W|R|r
helmond|Helmond Sport|Helmondse Sport Vereniging|HEL|46|W|K|W
jongajax|Jong Ajax|Jong Ajax|JAJ|54|W|W|R|r
toposs|TOP Oss|Trots Op Oss|TOP|46|R|W|R`
};

/* ---------- utilitários de cor / hash ---------- */
function fcHex(c){c=FC_COL[c]||c||'#888888';if(/^#[0-9a-f]{3}$/i.test(c))c='#'+c[1]+c[1]+c[2]+c[2]+c[3]+c[3];return c.toLowerCase();}
function fcRgb(c){c=fcHex(c);return[parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)];}
function fcLum(c){const[r,g,b]=fcRgb(c);return(.299*r+.587*g+.114*b)/255;}
function fcDist(a,b){const x=fcRgb(a),y=fcRgb(b);return Math.hypot(x[0]-y[0],x[1]-y[1],x[2]-y[2]);}
function fcHash(s){let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;}

/* ---------- construção do banco ---------- */
const FC_CLUBS=[];            // todos os clubes
/* Uniformes exatos (cores reais): slug:camisa,calção,meiões|reserva camisa,calção,meiões (reserva opcional; sem ela o jogo gera automático) */
const FC_KITS_EXACT_RAW=`
flamengo:c8102e,111111,111111|f4f4f4,f4f4f4,f4f4f4
palmeiras:006437,ffffff,006437|ffffff,006437,ffffff
corinthians:ffffff,111111,ffffff|111111,111111,111111
saopaulo:ffffff,ffffff,ffffff|d7141a,ffffff,d7141a
santos:ffffff,ffffff,ffffff|111111,111111,111111
vasco:111111,111111,111111|ffffff,ffffff,ffffff
fluminense:8b1e3f,ffffff,ffffff|ffffff,ffffff,ffffff
botafogo:111111,111111,111111|ffffff,ffffff,ffffff
gremio:0d80bf,111111,ffffff|111111,111111,111111
internacional:e5050f,ffffff,e5050f|ffffff,ffffff,ffffff
cruzeiro:0033a0,ffffff,0033a0|ffffff,ffffff,ffffff
atleticomg:111111,111111,ffffff|ffffff,ffffff,ffffff
bahia:0b5cab,ffffff,d52b2b
bragantino:ffffff,ffffff,ffffff
mirassol:ffd400,00a650,ffd400
vitoria:d4121f,111111,111111
coritiba:00673c,ffffff,00673c
athleticopr:c8102e,111111,c8102e
chapecoense:00a859,ffffff,00a859
remo:0a2a6b,ffffff,0a2a6b
ceara:111111,ffffff,111111
fortaleza:0f4c9a,ffffff,0f4c9a
juventude:00a859,ffffff,00a859
sport:d4121f,111111,d4121f
pontepreta:111111,111111,ffffff
londrina:0a5cb8,ffffff,0a5cb8
nautico:d4121f,ffffff,d4121f
saobernardo:ffd200,111111,ffd200
criciuma:ffd200,111111,ffd200
goias:00a650,ffffff,00a650
novorizontino:ffd200,111111,ffd200
crb:d4121f,ffffff,d4121f
avai:0a5cb8,ffffff,0a5cb8
cuiaba:00693e,ffd200,00693e
atleticogo:d4121f,111111,d4121f
operariopr:111111,ffffff,111111
vilanova:d4121f,ffffff,d4121f
americamg:00a650,ffffff,00a650
athleticmg:111111,ffffff,111111
botafogosp:d4121f,111111,d4121f
arsenal:ef0107,ffffff,ef0107|f9e547,f9e547,f9e547
astonvilla:670e36,ffffff,95bfe5|ffffff,670e36,ffffff
bournemouth:e62333,111111,111111
brentford:e30613,111111,e30613
brighton:0057b8,ffffff,0057b8
chelsea:034694,034694,ffffff|ffffff,ffffff,ffffff
coventry:59cbe8,59cbe8,59cbe8
crystalpalace:1b458f,1b458f,1b458f|ffffff,ffffff,ffffff
everton:003399,ffffff,003399
fulham:ffffff,111111,ffffff
hull:f5a11a,111111,f5a11a
ipswich:3a64a3,ffffff,3a64a3
leeds:ffffff,ffffff,ffffff
liverpool:c8102e,c8102e,c8102e|ffffff,ffffff,ffffff
mancity:6cabdd,ffffff,6cabdd|111111,111111,111111
manutd:da291c,ffffff,111111|ffffff,ffffff,ffffff
newcastle:111111,111111,111111|ffffff,ffffff,ffffff
nottmforest:dd0000,ffffff,dd0000
sunderland:eb172b,111111,eb172b
tottenham:ffffff,132257,ffffff|132257,132257,132257
birmingham:0f3fb5,0f3fb5,0f3fb5
blackburn:1d4ea0,ffffff,1d4ea0
bolton:ffffff,132257,ffffff
bristolcity:e1001a,ffffff,e1001a
burnley:6c1d45,ffffff,6c1d45
cardiff:0070b5,ffffff,0070b5
charlton:d4021d,ffffff,d4021d
derby:ffffff,111111,ffffff
lincoln:d4121f,111111,d4121f
middlesbrough:e21a22,ffffff,e21a22
millwall:001d5e,ffffff,001d5e
norwich:ffe500,00a650,ffe500
portsmouth:001489,ffffff,001489
preston:ffffff,132257,ffffff
qpr:1d5ba4,ffffff,1d5ba4
sheffutd:ee2737,111111,ee2737
southampton:d71920,111111,d71920
stoke:e03a3e,ffffff,e03a3e
swansea:ffffff,ffffff,ffffff
watford:fbee23,111111,fbee23
westbrom:122f67,ffffff,122f67
westham:7a263a,ffffff,7a263a
wolves:fdb913,111111,fdb913
wrexham:d71920,ffffff,d71920
alaves:0057b8,ffffff,0057b8
athletic:ee2523,111111,ee2523
atletico:cb3524,1b2a6b,cb3524|1b2a6b,1b2a6b,1b2a6b
barcelona:a50044,004d98,004d98|f6c800,f6c800,f6c800
celta:8ac3ee,ffffff,8ac3ee
deportivo:0a4ea3,ffffff,0a4ea3
elche:ffffff,00743c,ffffff
espanyol:0a5aa8,ffffff,0a5aa8
getafe:005999,005999,005999
levante:a4123f,1b2a6b,a4123f
malaga:4fb0e5,ffffff,4fb0e5
osasuna:d91a21,0b2a6b,d91a21
racing:009f4d,ffffff,009f4d
rayo:ffffff,ffffff,ffffff
betis:00954f,ffffff,00954f
realmadrid:ffffff,ffffff,ffffff|1b1f3b,1b1f3b,1b1f3b
realsociedad:0067b1,ffffff,0067b1
sevilla:ffffff,ffffff,d4121f
valencia:ffffff,111111,111111
villarreal:fbe122,0b3d91,fbe122
albacete:ffffff,ffffff,ffffff
almeria:d4121f,ffffff,d4121f
andorra:0a3a8a,0a3a8a,ffd200
burgos:ffffff,111111,ffffff
cadiz:ffd200,0a3a8a,ffd200
castellon:111111,ffffff,111111
celtafortuna:8ac3ee,ffffff,8ac3ee
ceuta:ffffff,111111,ffffff
cordoba:00873c,ffffff,00873c
eibar:8a1538,0a3a8a,8a1538
eldense:0057b8,ffffff,0057b8
girona:d4121f,ffffff,d4121f
granada:d4121f,ffffff,d4121f
laspalmas:ffd200,0057b8,ffd200
leganes:0057b8,ffffff,0057b8
mallorca:d4121f,111111,d4121f
oviedo:0057b8,0057b8,0057b8
realsociedadb:0067b1,ffffff,0067b1
sabadell:0057b8,ffffff,0057b8
sportinggijon:d4121f,ffffff,d4121f
tenerife:ffffff,0057b8,ffffff
valladolid:5b2c83,ffffff,5b2c83
atalanta:111111,111111,1c4f9c
bologna:a6192e,ffffff,1a2f5a
cagliari:c8102e,0a2a6b,c8102e
como:0057b8,0057b8,0057b8
fiorentina:5b2b8c,ffffff,5b2b8c
frosinone:ffd200,0057b8,ffd200
genoa:c8102e,0a2a6b,c8102e
inter:0a4aa0,111111,0a4aa0|ffffff,ffffff,ffffff
juventus:ffffff,111111,ffffff|111111,111111,111111
lazio:87d8f7,ffffff,87d8f7
lecce:ffd200,c8102e,ffd200
milan:ee2523,111111,111111|ffffff,ffffff,ffffff
monza:d4121f,ffffff,d4121f
napoli:12a0d7,ffffff,12a0d7|ffffff,ffffff,ffffff
parma:ffffff,ffffff,ffffff
roma:8c1d2e,ffffff,8c1d2e
sassuolo:00a650,111111,00a650
torino:8a1538,ffffff,8a1538
udinese:ffffff,111111,ffffff
venezia:111111,111111,111111
arezzo:8a1538,ffffff,8a1538
ascoli:ffffff,111111,ffffff
avellino:00a650,ffffff,00a650
benevento:d4121f,ffffff,d4121f
carrarese:ffd200,0057b8,ffd200
catanzaro:ffd200,d4121f,ffd200
cesena:ffffff,111111,ffffff
cremonese:d4121f,ffffff,d4121f
empoli:0057b8,ffffff,0057b8
verona:ffd200,0a3a8a,ffd200
jstabia:ffd200,0057b8,ffd200
mantova:ffffff,d4121f,ffffff
modena:ffd200,0057b8,ffd200
padova:ffffff,d4121f,ffffff
palermo:f08fb8,111111,111111
pisa:0b2a5b,111111,0b2a5b
sampdoria:0057b8,ffffff,0057b8
sudtirol:ffffff,d4121f,ffffff
vicenza:d4121f,ffffff,d4121f
entella:7dc6e8,ffffff,7dc6e8
bayern:dc052d,ffffff,dc052d|1b1f3b,1b1f3b,1b1f3b
dortmund:fde100,111111,fde100|111111,111111,111111
leipzig:ffffff,ffffff,ffffff
stuttgart:ffffff,ffffff,ffffff
hoffenheim:1961b5,1961b5,1961b5
leverkusen:e32221,111111,e32221
freiburg:e2001a,111111,e2001a
frankfurt:111111,111111,111111
augsburg:ba3733,ffffff,ba3733
mainz:c3141e,ffffff,c3141e
unionberlin:eb1923,ffffff,eb1923
gladbach:ffffff,111111,ffffff
hsv:ffffff,0a3a8a,ffffff
koeln:ffffff,d4121f,ffffff
bremen:1d9053,ffffff,1d9053
schalke:004d9d,ffffff,004d9d
elversberg:111111,ffffff,111111
paderborn:0057b8,111111,0057b8
hertha:ffffff,0057b8,ffffff
bielefeld:0057b8,ffffff,0057b8
bochum:0057b8,ffffff,0057b8
braunschweig:ffd200,0057b8,ffd200
cottbus:d4121f,ffffff,d4121f
darmstadt:0057b8,ffffff,0057b8
dresden:ffd200,111111,ffd200
fuerth:ffffff,00873c,ffffff
hannover:d4121f,111111,d4121f
heidenheim:d4121f,0057b8,d4121f
kaiserslautern:d4121f,ffffff,d4121f
karlsruhe:0057b8,ffffff,0057b8
kiel:0057b8,ffffff,0057b8
magdeburg:0057b8,ffffff,0057b8
nuernberg:a6192e,111111,a6192e
osnabrueck:6a2c91,ffffff,6a2c91
stpauli:5a3825,ffffff,5a3825
wolfsburg:65b32e,ffffff,65b32e
angers:111111,ffffff,111111
auxerre:ffffff,0057b8,ffffff
brest:d4121f,ffffff,d4121f
lehavre:7dc6e8,0b2a5b,7dc6e8
lemans:ffd200,d4121f,ffd200
lens:ffd200,d4121f,ffd200
lille:d4121f,ffffff,d4121f
lorient:f77f00,111111,f77f00
lyon:ffffff,0057b8,ffffff
marseille:ffffff,ffffff,ffffff
monaco:d4121f,ffffff,d4121f
nice:d4121f,111111,d4121f
parisfc:0057b8,ffffff,0057b8
psg:004170,004170,004170|ffffff,ffffff,ffffff
rennes:d4121f,111111,d4121f
strasbourg:0057b8,ffffff,0057b8
toulouse:5b2c83,ffffff,5b2c83
troyes:0057b8,ffffff,0057b8
annecy:d4121f,ffffff,d4121f
boulogne:d4121f,ffffff,d4121f
clermont:d4121f,0057b8,d4121f
dijon:d4121f,ffffff,d4121f
dunkerque:0057b8,d4121f,0057b8
grenoble:0057b8,ffffff,0057b8
guingamp:d4121f,111111,d4121f
laval:f77f00,111111,f77f00
metz:8a1538,ffffff,8a1538
montpellier:0057b8,0b2a5b,0057b8
nancy:ffffff,d4121f,ffffff
nantes:ffd200,00873c,ffd200
paul:ffd200,0057b8,ffd200
redstar:00873c,ffffff,00873c
reims:d4121f,ffffff,d4121f
rodez:d4121f,ffffff,d4121f
saintetienne:00873c,ffffff,00873c
sochaux:ffd200,0057b8,ffd200
alverca:d4121f,ffffff,d4121f
arouca:ffd200,0057b8,ffd200
benfica:e30a17,ffffff,e30a17|111111,111111,111111
braga:d4121f,ffffff,d4121f
casapia:ffffff,111111,ffffff
estoril:ffd200,0057b8,ffd200
estrela:d4121f,00873c,d4121f
famalicao:0057b8,ffffff,0057b8
gilvicente:d4121f,0057b8,d4121f
maritimo:00873c,d4121f,00873c
moreirense:0a6b3a,ffffff,0a6b3a
nacional:111111,ffffff,111111
porto:0a4a9c,0a4a9c,0a4a9c|ffffff,ffffff,ffffff
rioave:00873c,ffffff,00873c
santaclara:d4121f,ffffff,d4121f
sporting:00873c,ffffff,00873c|ffffff,ffffff,ffffff
vitoriaguimaraes:ffffff,111111,ffffff
viseu:ffffff,111111,ffffff
academica:111111,ffffff,111111
avs:ffffff,d4121f,ffffff
amarante:00873c,ffffff,00873c
benficab:d4121f,ffffff,d4121f
chaves:d4121f,ffffff,d4121f
farense:ffffff,111111,ffffff
feirense:ffffff,0057b8,ffffff
felgueiras:d4121f,ffffff,d4121f
leixoes:d4121f,ffffff,d4121f
lourosa:0057b8,ffffff,0057b8
penafiel:0057b8,ffffff,0057b8
portimonense:111111,ffffff,111111
portob:0a4a9c,0a4a9c,0a4a9c
sportingb:00873c,ffffff,00873c
tondela:00873c,ffd200,00873c
torreense:d4121f,ffffff,d4121f
leiria:00873c,ffffff,00873c
vizela:0057b8,ffffff,0057b8
ado:00873c,ffd200,00873c
ajax:ffffff,ffffff,d4121f|0a2a6b,0a2a6b,0a2a6b
az:d4121f,ffffff,d4121f
cambuur:ffd200,0057b8,ffd200
excelsior:d4121f,111111,d4121f
feyenoord:d4121f,111111,111111
fortuna:ffd200,00873c,ffd200
goahead:d4121f,ffd200,d4121f
groningen:00873c,ffffff,00873c
heerenveen:0057b8,ffffff,0057b8
nec:d4121f,111111,d4121f
pec:0057b8,ffffff,0057b8
psv:d4121f,ffffff,d4121f
sparta:d4121f,ffffff,d4121f
telstar:ffffff,111111,ffffff
twente:d4121f,ffffff,d4121f
utrecht:d4121f,ffffff,d4121f
willem2:d4121f,0057b8,d4121f
heracles:ffffff,111111,ffffff
nac:ffd200,111111,ffd200
volendam:f77f00,ffffff,f77f00
degraafschap:0057b8,ffffff,0057b8
almere:d4121f,111111,d4121f
jongpsv:d4121f,ffffff,d4121f
rkc:ffd200,0057b8,ffd200
roda:ffd200,111111,ffd200
denbosch:0057b8,ffffff,0057b8
dordrecht:00873c,ffffff,00873c
eindhoven:0057b8,ffffff,0057b8
jongutrecht:d4121f,ffffff,d4121f
vvv:ffd200,111111,ffd200
emmen:d4121f,ffffff,d4121f
mvv:d4121f,ffffff,d4121f
vitesse:ffd200,111111,ffd200
jongaz:d4121f,ffffff,d4121f
helmond:ffffff,111111,ffffff
jongajax:ffffff,ffffff,ffffff
toposs:d4121f,ffffff,d4121f
`;
const FC_KITS_EXACT={};
FC_KITS_EXACT_RAW.trim().split('\n').forEach(l=>{
 const[s,v]=l.trim().split(':');const p=v.split('|').map(x=>x.split(',').map(h=>'#'+h));
 const k=a=>({shirt:a[0],shorts:a[1],socks:a[2]});
 FC_KITS_EXACT[s]={home:k(p[0]),away:p[1]?k(p[1]):null};
});

const FC_BY_ID={};            // id -> clube
const FC_LEAGUES={};          // id do campeonato -> {id,name,tier,country,clubs:[ids]}
(function build(){
 for(const C of FC_COUNTRIES){
  C.leagues.forEach(L=>{L.country=C.id;L.clubs=[];FC_LEAGUES[L.id]=L;});
  C.byTier=C.leagues;
  for(const L of C.leagues){
   FC_RAW[L.id].split('\n').forEach(line=>{
    const f=line.trim().split('|');if(f.length<8)return;
    const m=/^(\d+)([ADM]?)$/.exec(f[4]);const ovr=+m[1],st=m[2];
    const j=n=>(fcHash(f[0]+n)%3)-1; // -1..1 estável
    let att=ovr+j('a'),mid=ovr+j('m'),def=ovr+j('d');
    if(st==='A'){att+=3;def-=2;}else if(st==='D'){def+=3;att-=2;}else if(st==='M'){mid+=3;}
    const cl=v=>Math.max(30,Math.min(99,v));
    att=cl(att);mid=cl(mid);def=cl(def);
    const c1=fcHex(f[5]),c2=fcHex(f[6]),c3=fcHex(f[7]||f[6]);
    const club={id:C.code+'.'+f[0],slug:f[0],name:f[1],official:f[2],abbr:f[3],country:C.id,league0:L.id,
     ovr:Math.round((att*.36+mid*.34+def*.30)),att,mid,def,reserve:f[8]==='r',colors:[c1,c2,c3]};
    club.kits=fcKits(club);
    const ex=FC_KITS_EXACT[club.slug];
    if(ex){club.colors=[ex.home.shirt,ex.home.shorts,ex.home.socks];club.kits.home=ex.home;if(ex.away)club.kits.away=ex.away;else club.kits=fcKits(club);}
    FC_CLUBS.push(club);FC_BY_ID[club.id]=club;L.clubs.push(club.id);
   });
  }
 }
})();

function fcKits(c){
 const[c1,c2,c3]=c.colors;
 const home={shirt:c1,shorts:c2,socks:c3};
 let away;
 if(fcLum(c1)>.6){
  const dk=[c2,c3,c1].find(x=>fcLum(x)<.35)||'#14213d';
  away={shirt:dk,shorts:dk,socks:dk};
 }else{
  away={shirt:'#f4f4f4',shorts:fcLum(c2)<.35?c2:'#f4f4f4',socks:'#f4f4f4'};
  if(fcDist(c1,c2)>120&&fcLum(c2)>.7)away.shorts=c1;
 }
 return{home,away};
}
function fcClub(id){return FC_BY_ID[id]||null;}
function fcCountry(id){return FC_COUNTRIES.find(c=>c.id===id)||null;}
function fcLeagueOf(id){ // campeonato padrão do clube
 const c=FC_BY_ID[id];return c?FC_LEAGUES[c.league0]:null;}

/* Resolve o uniforme (home/away/auto + cores personalizadas) */
function fcKit(id,which,ov){
 const c=FC_BY_ID[id];if(!c)return null;
 const k=Object.assign({},c.kits[which==='away'?'away':'home']);
 if(ov){if(ov.shirt)k.shirt=ov.shirt;if(ov.shorts)k.shorts=ov.shorts;if(ov.socks)k.socks=ov.socks;}
 return k;
}
/* Escolhe uniformes dos dois times evitando cores iguais. a/b = {id,kit,ov} */
function fcPairKits(a,b){
 const pick=(t,w)=>fcKit(t.id,w,t.ov);
 let wa=a.kit==='away'?'away':'home',wb=b.kit==='away'?'away':'home';
 const clash=(x,y)=>fcDist(x.shirt,y.shirt)<110;
 let ka=pick(a,wa),kb=pick(b,wb);
 if(clash(ka,kb)&&!(b.ov&&b.ov.shirt)){wb=wb==='home'?'away':'home';kb=pick(b,wb);}
 if(clash(ka,kb)&&!(a.ov&&a.ov.shirt)){wa=wa==='home'?'away':'home';ka=pick(a,wa);}
 return[ka,kb,wa,wb];
}
/* cor de goleiro mais distinta das camisas */
function fcGkColor(k0,k1,not){
 const cand=['#f2a900','#2fbf6a','#3aa0ff','#e8e8e8','#ff5ab0','#7a3ad0'];
 let best=cand[0],bs=-1;
 for(const c of cand){if(c===not)continue;const s=Math.min(fcDist(c,k0.shirt),fcDist(c,k1.shirt));if(s>bs){bs=s;best=c;}}
 return best;
}

/* ---------- escudos provisórios (SVG original por clube) ---------- */
(function(){for(const c of FC_CLUBS){const code=c.id.split('.')[0];CREST_FILES[c.id]='crests/'+(CREST_FOLDERS[code]||'other')+'/'+c.slug+'.svg';}})();
(function(){ // manifest.json opcional (precisa de http; em file:// e ignorado sem erro)
 try{if(typeof fetch!=='function'||location.protocol==='file:')return;
  fetch('crests/manifest.json',{cache:'no-cache'}).then(r=>r.ok?r.json():null).then(m=>{
   if(!m||!m.clubs)return;for(const id in m.clubs){if(FC_BY_ID[id]&&m.clubs[id].file)CREST_FILES[id]=m.clubs[id].file;}
  }).catch(()=>{});}catch(e){}
})();
const FC_CREST_MISSING={}; // cache: ids cujo PNG não carregou (evita novas requisições)
function fcCrestErr(img){
 const id=img.getAttribute('data-id');
 if(/\.svg(\?.*)?$/i.test(img.src)&&!img.dataset.t){img.dataset.t=1;img.src=img.src.replace(/\.svg(\?.*)?$/i,'.png');return;} // tenta .png
 FC_CREST_MISSING[id]=1;
 const sz=+img.getAttribute('width')||40,c=FC_BY_ID[id];
 if(!c||!img.parentNode)return;
 const t=document.createElement('span');t.innerHTML=fcCrestSVG(c,sz);
 const n=t.firstChild;if(n)img.parentNode.replaceChild(n,img);
}
function fcCrest(club,size){
 size=size||40;
 if(typeof club==='string')club=FC_BY_ID[club];
 if(!club)return'';
 if(CREST_FILES[club.id]&&!FC_CREST_MISSING[club.id])return'<img class="crest" data-id="'+club.id+'" width="'+size+'" height="'+size+'" src="'+CREST_FILES[club.id]+'" alt="" loading="lazy" decoding="async" style="object-fit:contain" onerror="fcCrestErr(this)">';
 return fcCrestSVG(club,size);
}
function fcCrestSVG(club,size){
 size=size||40;
 const h=fcHash(club.id),[c1,c2,c3]=club.colors;
 let bg=c1,fg=fcLum(c1)>.82?(fcDist(c2,c1)>60?c2:(fcDist(c3,c1)>60?c3:'#c9a227')):(fcDist(c2,c1)>60?c2:(fcDist(c3,c1)>60?c3:(fcLum(c1)>.5?'#141414':'#ffffff')));
 if(fcLum(c1)>.82){bg=fg;fg=c1;}
 const shape=h%5,pat=(h>>3)%6,uid='c'+(h%99991);
 const paths=[
  'M8 6h44v26c0 14-12 22-22 26C20 54 8 46 8 32z',            // escudo clássico
  'M30 4a26 26 0 1 1 0 52a26 26 0 1 1 0-52z',                  // círculo
  'M6 8h48v24c0 12-10 20-24 26C16 52 6 44 6 32z',              // escudo largo
  'M30 3l24 12v18c0 12-10 20-24 24C16 53 6 45 6 33V15z',       // brasão
  'M10 6h40l6 14-6 28-20 10-20-10-6-28z'                       // hexágono
 ];
 const d=paths[shape];
 let ptn='';
 if(pat===0)ptn='<g clip-path="url(#'+uid+')"><rect x="20" y="0" width="10" height="60" fill="'+fg+'"/><rect x="40" y="0" width="10" height="60" fill="'+fg+'"/></g>';
 else if(pat===1)ptn='<g clip-path="url(#'+uid+')"><rect x="0" y="22" width="60" height="14" fill="'+fg+'"/></g>';
 else if(pat===2)ptn='<g clip-path="url(#'+uid+')"><polygon points="0,0 60,60 60,40 20,0" fill="'+fg+'"/></g>';
 else if(pat===3)ptn='<g clip-path="url(#'+uid+')"><rect x="0" y="0" width="60" height="18" fill="'+fg+'"/></g>';
 else if(pat===4)ptn='<g clip-path="url(#'+uid+')"><rect x="0" y="0" width="30" height="60" fill="'+fg+'"/></g>';
 else ptn='<g clip-path="url(#'+uid+')"><polygon points="0,38 30,18 60,38 60,48 30,28 0,48" fill="'+fg+'"/></g>';
 // cor do texto: contra o fundo predominante
 const tcol=(pat===1||pat===3)?'#ffffff':(fcLum(bg)>.55?'#101010':'#ffffff');
 const txt=club.abbr.slice(0,3);
 return'<svg class="crest" width="'+size+'" height="'+size+'" viewBox="0 0 60 60" aria-label="'+club.name.replace(/"/g,'')+'">'+
  '<defs><clipPath id="'+uid+'"><path d="'+d+'"/></clipPath></defs>'+
  '<path d="'+d+'" fill="'+bg+'"/>'+ptn+
  '<path d="'+d+'" fill="none" stroke="'+(fcLum(bg)>.5?'#222':'#fff')+'" stroke-width="2.5" stroke-opacity=".85"/>'+
  '<text x="30" y="36" text-anchor="middle" font-family="Arial Black,Arial,sans-serif" font-weight="900" font-size="'+(txt.length>2?15:18)+'" fill="'+tcol+'" stroke="'+(tcol==='#ffffff'?'#000':'#fff')+'" stroke-width=".6" paint-order="stroke">'+txt+'</text></svg>';
}
/* mini uniforme (camisa + calção) em SVG */
function fcKitSVG(k,size){
 size=size||34;
 return'<svg class="kitsv" width="'+size+'" height="'+size+'" viewBox="0 0 40 44">'+
  '<path d="M12 2l-10 6 4 8 5-3v14h18V13l5 3 4-8-10-6c-1 4-4 5-8 5s-7-1-8-5z" fill="'+k.shirt+'" stroke="#0006" stroke-width="1.2"/>'+
  '<rect x="11" y="28" width="18" height="9" rx="1.5" fill="'+k.shorts+'" stroke="#0006" stroke-width="1"/>'+
  '<rect x="12" y="37" width="6" height="6" fill="'+k.socks+'" stroke="#0006" stroke-width=".8"/><rect x="22" y="37" width="6" height="6" fill="'+k.socks+'" stroke="#0006" stroke-width=".8"/></svg>';
}
function fcSearch(q){
 q=(q||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').trim();
 if(!q)return[];
 const n=s=>s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
 return FC_CLUBS.filter(c=>n(c.name).includes(q)||n(c.official).includes(q)||n(c.abbr)===q||n(c.abbr).startsWith(q));
}
