/* ============================================================
   FC CARREIRA 3D — COMPETIÇÕES
   Copas nacionais, competições continentais e Mundial de Clubes.
   Usa SOMENTE os clubes já existentes em clubs.js (nada de clubes novos).

   Motor puro (sem DOM): dá para testar no Node.
   Tudo é guardado por ID de clube e é serializável em JSON.

   COMO ADICIONAR UM PAÍS NOVO NO FUTURO
   1) Cadastre o país/clubes em clubs.js (como já é feito).
   2) Em FCC.CUPS coloque o nome da copa nacional do país.
   3) Em QUOTA coloque as vagas do país (ex.: ARG:{LIB:6,SUL:6}).
   Os grupos, sorteios, calendário e qualificação se ajustam sozinhos.
   ============================================================ */
'use strict';
const FCC=(function(){
 const rng=FCL.rng,simScore=FCL.simScore,poisson=FCL.poisson,pickScorer=FCL.pickScorer;
 const club=id=>FC_BY_ID[id];

 /* ---------------- cadastro das competições ---------------- */
 const CUPS={BRA:'Copa do Brasil',ENG:'FA Cup',ESP:'Copa del Rey',ITA:'Coppa Italia',GER:'DFB-Pokal',FRA:'Coupe de France',POR:'Taça de Portugal',NED:'KNVB Beker'};
 const CUP_ICONS={BRA:'images/competitions/copa-brasil.svg',ENG:'images/competitions/fa-cup.svg',ESP:'images/competitions/copa-del-rey.svg',ITA:'images/competitions/coppa-italia.svg',GER:'images/competitions/dfb-pokal.svg',FRA:'images/competitions/coupe-france.svg',POR:'images/competitions/taca-portugal.svg',NED:'images/competitions/knvb-beker.svg'};
 /* n = nº de clubes · groups = nº de grupos (de 4) · adv = classificados por grupo · wild = melhores 3ºs */
 const CONT={
  UCL:{name:'UEFA Champions League',short:'Champions League',icon:'images/competitions/champions-league.svg',conf:'UEFA',n:24,groups:6,adv:2,wild:4,ord:20,gd:[.10,.18,.26,.34,.42,.50]},
  UEL:{name:'UEFA Europa League',short:'Europa League',icon:'images/competitions/europa-league.svg',conf:'UEFA',n:24,groups:6,adv:2,wild:4,ord:30,gd:[.11,.19,.27,.35,.43,.51]},
  LIB:{name:'CONMEBOL Libertadores',short:'Libertadores',icon:'images/competitions/libertadores.svg',conf:'CONMEBOL',n:8,groups:2,adv:2,wild:0,ord:40,gd:[.12,.20,.28,.36,.44,.52]},
  SUL:{name:'CONMEBOL Sul-Americana',short:'Sul-Americana',icon:'images/competitions/sul-americana.svg',conf:'CONMEBOL',n:8,groups:2,adv:2,wild:0,ord:50,gd:[.13,.21,.29,.37,.45,.53]}
 };
 const WCUP={name:'Mundial de Clubes',short:'Mundial',icon:'images/competitions/mundial-clubes.svg'};
 /* Vagas por país (1ª divisão). UEL inclui a vaga do campeão da copa nacional. Soma UCL=24, UEL=24, LIB=8, SUL=8 */
 const QUOTA={ENG:{UCL:4,UEL:4},ESP:{UCL:4,UEL:4},ITA:{UCL:4,UEL:3},GER:{UCL:4,UEL:3},FRA:{UCL:3,UEL:3},POR:{UCL:3,UEL:4},NED:{UCL:2,UEL:3},BRA:{LIB:8,SUL:8}};
 /* competição principal / secundária da confederação; cupSpot = onde cai o campeão da copa nacional */
 const CONFS=[{comps:['UCL','UEL'],cupSpot:'UEL'},{comps:['LIB','SUL'],cupSpot:'LIB'}];

 function info(id){
  if(id==='WC')return{id,name:WCUP.name,short:WCUP.short,icon:WCUP.icon,scope:'world'};
  if(CONT[id])return{id,name:CONT[id].name,short:CONT[id].short,icon:CONT[id].icon,scope:'cont'};
  if(id.indexOf('CUP-')===0){const cc=id.slice(4);return{id,name:CUPS[cc]||('Copa '+cc),short:CUPS[cc]||('Copa '+cc),icon:CUP_ICONS[cc]||'🏆',scope:'cup',country:cc};}
  return{id,name:id,short:id,icon:'',scope:'?'};
 }

 /* ---------------- utilitários ---------------- */
 function shuffle(a,r){const x=a.slice();for(let i=x.length-1;i>0;i--){const j=(r()*(i+1))|0;const t=x[i];x[i]=x[j];x[j]=t;}return x;}
 function lp2(n){let p=1;while(p*2<=n)p*=2;return p;}
 function koName(t){return({2:'Final',4:'Semifinais',8:'Quartas de final',16:'Oitavas de final',32:'16-avos de final',64:'32-avos de final'})[t]||('Fase de '+t);}
 function pairUp(list,r){const out=[];for(let i=0;i+1<list.length;i+=2){out.push(r()<.5?[list[i],list[i+1]]:[list[i+1],list[i]]);}return out;}
 function spread(a,b,m){const o=[];for(let i=0;i<m;i++)o.push(m===1?b:a+(b-a)*i/(m-1));return o;}
 function addSc(comp,c,n){const k=c+'|'+n,s=comp.scorers[k]||(comp.scorers[k]={c,n,g:0});s.g++;}
 function base(o){return Object.assign({rounds:[],champion:null,runnerUp:null,scorers:{},stage:'ko',koBase:0},o);}

 /* ---------------- pênaltis / prorrogação ---------------- */
 function shootout(h,a,r){
  const ph=Math.max(.6,Math.min(.88,.74+(club(h).ovr-70)*.002)),pa=Math.max(.6,Math.min(.88,.74+(club(a).ovr-70)*.002));
  let x=0,y=0;
  for(let i=0;i<5;i++){if(r()<ph)x++;if(r()<pa)y++;}
  let n=0;while(x===y&&n<30){if(r()<ph)x++;if(r()<pa)y++;n++;}
  if(x===y)x++;
  return[x,y];
 }
 /* placar empatado nos 90': prorrogação e, se preciso, pênaltis */
 function extra(h,a,gh,ga,r){
  const ex=poisson(.38,r),ey=poisson(.38,r);
  const o={gh:gh+ex,ga:ga+ey,et:1,pen:null,g90:[gh,ga]};
  if(o.gh===o.ga)o.pen=shootout(h,a,r);
  return o;
 }
 function simTie(h,a,r){
  const s=simScore(club(h),club(a),r);
  if(s[0]!==s[1])return{gh:s[0],ga:s[1],et:0,pen:null,g90:null};
  return extra(h,a,s[0],s[1],r);
 }
 /* Usado pelo jogo: o usuário empatou nos 90' de um jogo de mata-mata */
 function resolveDraw(h,a,gh,ga){return extra(h,a,gh,ga,Math.random);}

 /* ---------------- criação das competições ---------------- */
 function createCup(cc,ids,season){
  const teams=ids.filter(id=>club(id)&&!club(id).reserve);
  const n=teams.length,p=lp2(n),m=n-p,phases=[];
  if(m>0)phases.push('Fase preliminar');
  for(let t=p;t>=2;t/=2)phases.push(koName(t));
  return base({id:'CUP-'+cc,kind:'cup',cc,season,teams,phases,pool:teams.slice(),prelim:m});
 }
 function drawGroups(teams,G,r){
  const sorted=teams.slice().sort((a,b)=>club(b).ovr-club(a).ovr||(a<b?-1:1));
  const groups=Array.from({length:G},()=>[]);
  for(let i=0;i<sorted.length;i+=G){
   const pot=shuffle(sorted.slice(i,i+G),r),free=groups.map((_,k)=>k);
   for(const t of pot){
    const c=club(t).country;let best=-1,bs=1e9;
    for(const gi of shuffle(free,r)){
     const s=groups[gi].filter(x=>club(x).country===c).length;
     if(s<bs){bs=s;best=gi;}
    }
    groups[best].push(t);free.splice(free.indexOf(best),1);
   }
  }
  return groups;
 }
 function createGroupComp(key,teams,season){
  const cfg=CONT[key],G=cfg.groups,r=rng(fcHash(key+'|'+season+'|groups'));
  const gs=drawGroups(teams,G,r);
  const letter=i=>String.fromCharCode(65+i);
  const groups=gs.map((ids,i)=>FCL.create(key+'|S'+season+'|'+letter(i),ids,'double'));
  const gsRounds=FCL.rounds(groups[0]),phases=[];
  for(let i=1;i<=gsRounds;i++)phases.push('Fase de grupos · jogo '+i+'/'+gsRounds);
  const T=cfg.adv*G+cfg.wild;
  for(let t=T;t>=2;t/=2)phases.push(koName(t));
  return base({id:key,kind:'groups',key,season,teams:teams.slice(),groups,gsRounds,phases,koBase:gsRounds,stage:'groups',pool:[]});
 }
 function createWC(season){
  return base({id:'WC',kind:'ko',season,teams:[],phases:['Quartas de final','Semifinais','Final'],fixed:true,pool:[],firstPairs:null});
 }

 /* ---------------- qualificação ---------------- */
 function qualify(ranks,cupW){
  const out={UCL:[],UEL:[],LIB:[],SUL:[]};
  for(const cc in QUOTA){
   const q=QUOTA[cc],rk=ranks[cc]||[],cw=cupW&&cupW[cc];
   const conf=CONFS.find(c=>q[c.comps[0]]!=null),top=conf.comps[0],sec=conf.comps[1];
   const used=new Set(),mine={};mine[top]=[];mine[sec]=[];let ptr=0;
   const take=(name,n)=>{while(mine[name].length<n&&ptr<rk.length){const id=rk[ptr++];if(!used.has(id)){used.add(id);mine[name].push(id);}}};
   const reserve=(conf.cupSpot===top&&cw&&rk.slice(0,q[top]-1).indexOf(cw)<0)?1:0;
   take(top,q[top]-reserve);
   if(cw&&!used.has(cw)){used.add(cw);mine[conf.cupSpot].push(cw);}
   take(sec,q[sec]);
   out[top]=out[top].concat(mine[top]);out[sec]=out[sec].concat(mine[sec]);
  }
  return out;
 }
 /* 1ª temporada (sem histórico): ranking pela força dos clubes da 1ª divisão */
 function bootstrapQuali(members){
  const ranks={};
  FC_COUNTRIES.forEach(C=>{const l1=C.leagues[0].id;ranks[C.id]=(members[l1]||[]).slice().sort((a,b)=>club(b).ovr-club(a).ovr||(a<b?-1:1));});
  return qualify(ranks,null);
 }
 function createSeason(season,members,quali){
  const q=quali||bootstrapQuali(members),comps={};
  FC_COUNTRIES.forEach(C=>{if(!CUPS[C.id])return;comps['CUP-'+C.id]=createCup(C.id,C.leagues.reduce((a,l)=>a.concat(members[l.id]||[]),[]),season);});
  Object.keys(CONT).forEach(k=>{if(q[k]&&q[k].length>=CONT[k].groups*2)comps[k]=createGroupComp(k,q[k],season);});
  comps.WC=createWC(season);
  // sorteia já a 1ª fase das copas (determinístico): o jogador vê logo se joga a fase preliminar ou tem folga
  Object.keys(comps).forEach(id=>{if(comps[id].kind==='cup')prepare(comps,id,0);});
  return comps;
 }

 /* ---------------- calendário ---------------- */
 /* Eventos ficam "depois da rodada k" do campeonato do usuário (R rodadas). */
 function calendar(R,comps){
  const ev=[];
  for(let r=0;r<R;r++)ev.push({k:r,o:0,t:'L',r});
  const kOf=f=>Math.max(1,Math.min(R,Math.round(f*R)))-1;
  Object.keys(comps).forEach(id=>{
   const comp=comps[id],m=comp.phases.length;
   if(id==='WC'){for(let p=0;p<m;p++)ev.push({k:R-1,o:90+p,t:'C',c:id,p});return;}
   if(comp.kind==='cup'){
    const fr=m===6?[.06,.18,.31,.45,.66,.96]:spread(.06,.96,m);
    for(let p=0;p<m;p++)ev.push({k:kOf(fr[p]),o:10+p,t:'C',c:id,p});return;
   }
   const cfg=CONT[id],gs=comp.gsRounds,ko=m-gs;
   for(let p=0;p<gs;p++)ev.push({k:kOf(cfg.gd[p]),o:cfg.ord+p,t:'C',c:id,p});
   const st=ko>=4?.58:ko===3?.66:.78,fr=spread(st,.93,ko);
   for(let i=0;i<ko;i++)ev.push({k:kOf(fr[i]),o:cfg.ord+gs+i,t:'C',c:id,p:gs+i});
  });
  return ev.map((e,i)=>[e,i]).sort((a,b)=>a[0].k-b[0].k||a[0].o-b[0].o||a[1]-b[1]).map(x=>x[0]);
 }

 /* ---------------- sorteios do mata-mata ---------------- */
 function finishGroups(comp){
  const cfg=CONT[comp.key],gof={},W=[],Rn=[],rest=[];
  comp.groups.forEach((L,gi)=>{
   FCL.sorted(L).forEach((id,i)=>{
    gof[id]=gi;const t=L.table[id],row={id,pts:t.pts,gd:t.gf-t.ga,gf:t.gf};
    if(i===0)W.push(row);else if(i<cfg.adv)Rn.push(row);else if(i===cfg.adv)rest.push(row);
   });
  });
  const cmp=(a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||(a.id<b.id?-1:1);
  W.sort(cmp);Rn.sort(cmp);rest.sort(cmp);
  comp.gof=gof;comp.qual={W:W.map(x=>x.id),R:Rn.map(x=>x.id),X:rest.slice(0,cfg.wild).map(x=>x.id)};
  comp.stage='ko';
 }
 function drawFromGroups(comp,r){
  const q=comp.qual,all=q.W.concat(q.R,q.X),h=all.length/2;
  const seeded=all.slice(0,h),un=all.slice(h);let u=un;
  for(let a=0;a<300;a++){u=shuffle(un,r);if(seeded.every((s,i)=>comp.gof[s]!==comp.gof[u[i]]))break;}
  return seeded.map((s,i)=>r()<.5?[s,u[i]]:[u[i],s]);
 }
 function drawRound(comp){
  const ri=comp.rounds.length,r=rng(fcHash(comp.id+'|'+comp.season+'|d'+ri));let pairs;
  if(comp.kind==='cup'&&ri===0&&comp.prelim>0){
   const n=comp.teams.length,m=comp.prelim;
   const s=comp.teams.slice().sort((a,b)=>club(b).ovr-club(a).ovr||(a<b?-1:1));
   comp.wait=s.slice(0,n-2*m);
   pairs=pairUp(shuffle(s.slice(n-2*m),r),r);
  }else if(comp.fixed&&ri===0)pairs=comp.firstPairs;
  else if(comp.fixed){pairs=[];for(let i=0;i+1<comp.pool.length;i+=2)pairs.push([comp.pool[i],comp.pool[i+1]]);}
  else if(comp.kind==='groups'&&ri===0)pairs=drawFromGroups(comp,r);
  else pairs=pairUp(shuffle(comp.pool,r),r);
  const final=comp.koBase+ri===comp.phases.length-1;
  comp.rounds.push({name:comp.phases[comp.koBase+ri],ties:pairs.map(p=>({h:p[0],a:p[1],gh:null,ga:null,et:0,pen:null,g90:null,w:null,real:0,neu:final?1:0}))});
 }
 /* garante que a fase `ph` está sorteada (idempotente) */
 function prepare(comps,id,ph){
  const comp=comps[id];if(!comp)return;
  if(id==='WC'&&!comp.teams.length)fillWC(comps);
  if(comp.kind==='groups'&&ph<comp.gsRounds)return;
  const ri=ph-comp.koBase;
  while(comp.rounds.length<=ri)drawRound(comp);
 }
 function finishKO(comp){
  const rd=comp.rounds[comp.rounds.length-1],win=rd.ties.map(t=>t.w);
  if(comp.koBase+comp.rounds.length-1===comp.phases.length-1){const t=rd.ties[0];comp.champion=t.w;comp.runnerUp=t.w===t.h?t.a:t.h;comp.stage='done';comp.pool=[];}
  else{comp.pool=(comp.wait||[]).concat(win);comp.wait=null;}
 }

 /* ---------------- jogar uma fase ---------------- */
 function playKO(comp,um){
  const rd=comp.rounds[comp.rounds.length-1],rr=rng(fcHash(comp.id+'|'+comp.season+'|p'+comp.rounds.length));
  for(const t of rd.ties){
   if(t.w)continue;
   let res;
   if(um&&um.h===t.h&&um.a===t.a){
    res={gh:um.gh,ga:um.ga,et:um.et||0,pen:um.pen||null,g90:um.g90||null};t.real=1;
    if(res.gh===res.ga&&!res.pen){const x=extra(t.h,t.a,res.gh,res.ga,rr);res=x;}
    (um.scorers||[]).forEach(s=>addSc(comp,s.c,s.n));
   }else{
    res=simTie(t.h,t.a,rr);
    for(let i=0;i<res.gh;i++)addSc(comp,t.h,pickScorer(club(t.h),rr));
    for(let i=0;i<res.ga;i++)addSc(comp,t.a,pickScorer(club(t.a),rr));
   }
   t.gh=res.gh;t.ga=res.ga;t.et=res.et;t.pen=res.pen;t.g90=res.g90;
   t.w=res.gh>res.ga?t.h:res.ga>res.gh?t.a:(res.pen[0]>res.pen[1]?t.h:t.a);
  }
  finishKO(comp);
  return rd.ties;
 }
 function playGroupDay(comp,ph,um){
  const out=[];
  comp.groups.forEach((L,gi)=>{
   const res=FCL.playRound(L,um,comp.season)||[];
   res.forEach(x=>out.push([x[0],x[1],x[2],x[3],x[4],gi]));
  });
  if(ph===comp.gsRounds-1)finishGroups(comp);
  return out;
 }
 /* retorna lista de partidas da fase: grupos [h,a,gh,ga,real,grupo] | mata-mata = ties */
 function playPhase(comps,id,ph,um){
  prepare(comps,id,ph);const comp=comps[id];
  if(comp.kind==='groups'&&ph<comp.gsRounds)return playGroupDay(comp,ph,um);
  return playKO(comp,um);
 }
 function userFixture(comp,ph,me){
  if(!comp||!comp.teams.includes(me))return null;
  if(comp.kind==='groups'&&ph<comp.gsRounds){
   const L=comp.groups.find(g=>g.order.includes(me));if(!L||L.round!==ph)return null;
   const p=FCL.fixtures(L)[ph].find(x=>x[0]===me||x[1]===me);
   return p?{h:p[0],a:p[1],group:1}:null;
  }
  const rd=comp.rounds[ph-comp.koBase];if(!rd)return null;
  const t=rd.ties.find(x=>!x.w&&(x.h===me||x.a===me));
  return t?{h:t.h,a:t.a,neu:t.neu,group:0}:null;
 }

 /* ---------------- Mundial de Clubes ---------------- */
 function perf(comp,id){
  let pts=0,gd=0,gf=0;
  (comp.groups||[]).forEach(L=>{const t=L.table[id];if(t){pts+=t.pts;gd+=t.gf-t.ga;gf+=t.gf;}});
  comp.rounds.forEach(rd=>rd.ties.forEach(t=>{if(!t.w)return;
   if(t.h===id){gd+=t.gh-t.ga;gf+=t.gh;if(t.w===id)pts+=3;}
   else if(t.a===id){gd+=t.ga-t.gh;gf+=t.ga;if(t.w===id)pts+=3;}}));
  return{pts,gd,gf};
 }
 function semiLosers(comp){
  const rd=comp.rounds.find(x=>x.ties.length===2);if(!rd)return[];
  return rd.ties.map(t=>t.w===t.h?t.a:t.h).sort((a,b)=>{const x=perf(comp,a),y=perf(comp,b);return y.pts-x.pts||y.gd-x.gd||y.gf-x.gf||(a<b?-1:1);});
 }
 function fillWC(comps){
  const wc=comps.WC,list=[];
  const side=(a,b,c1,c2)=>{ // a=principal, b=secundária
   const out=[],add=id=>{if(id&&!out.includes(id)&&!list.includes(id)&&out.length<4)out.push(id);};
   const A=comps[a],B=comps[b];
   if(A){add(A.champion);add(A.runnerUp);}
   if(B)add(B.champion);
   if(A)semiLosers(A).forEach(add);
   if(B){add(B.runnerUp);semiLosers(B).forEach(add);}
   return out;
  };
  const U=side('UCL','UEL'),C=side('LIB','SUL');
  list.push(...U,...C);
  if(U.length<4||C.length<4){ // confederação incompleta: completa com os melhores restantes
   const all=[...U,...C];while(all.length<8){const x=FC_CLUBS.filter(c=>!all.includes(c.id)&&!c.reserve).sort((a,b)=>b.ovr-a.ovr)[0];if(!x)break;all.push(x.id);}
   wc.teams=all;
  }else wc.teams=[...U,...C];
  const u=U.length===4?U:wc.teams.slice(0,4),c=C.length===4?C:wc.teams.slice(4,8);
  wc.firstPairs=[[u[0],c[3]],[u[1],c[2]],[c[0],u[3]],[c[1],u[2]]];
 }

 /* ---------------- situação de um clube numa competição ---------------- */
 function status(comp,me){
  if(!comp||!comp.teams.includes(me))return null;
  if(comp.champion===me)return{k:'champ',t:'🏆 Campeão'};
  if(comp.runnerUp===me)return{k:'final',t:'🥈 Vice-campeão'};
  for(let i=comp.rounds.length-1;i>=0;i--){
   const t=comp.rounds[i].ties.find(x=>x.h===me||x.a===me);
   if(t){
    if(!t.w)return{k:'alive',t:'Jogando: '+comp.rounds[i].name};
    if(t.w!==me)return{k:'out',t:'Eliminado: '+comp.rounds[i].name};
    if(i===comp.rounds.length-1)return{k:'alive',t:'Classificado'};
   }
  }
  if(comp.kind==='groups'){
   const gi=comp.groups.findIndex(g=>g.order.includes(me)),L=comp.groups[gi],pos=FCL.sorted(L).indexOf(me)+1;
   const done=comp.stage!=='groups',q=comp.qual;
   if(done&&q&&!q.W.concat(q.R,q.X).includes(me))return{k:'out',t:'Eliminado na fase de grupos ('+pos+'º)'};
   if(done)return{k:'alive',t:'Classificado ao mata-mata'};
   return{k:'alive',t:'Grupo '+String.fromCharCode(65+gi)+' · '+pos+'º'};
  }
  if(comp.kind==='cup'&&!comp.rounds.length)return{k:'alive',t:'Aguardando sorteio'};
  if(comp.id==='WC')return{k:'alive',t:'Classificado'};
  return{k:'alive',t:'Na disputa (folga na 1ª fase)'};
 }
 function topScorers(comp,n){
  const m={};
  const add=s=>{const k=s.c+'|'+s.n,x=m[k]||(m[k]={c:s.c,n:s.n,g:0});x.g+=s.g;};
  Object.values(comp.scorers).forEach(add);
  (comp.groups||[]).forEach(L=>Object.values(L.scorers).forEach(add));
  return Object.values(m).sort((a,b)=>b.g-a.g||(a.n<b.n?-1:1)).slice(0,n||10);
 }
 function label(comp,ph){return comp.phases[ph]||'';}

 /* =====================================================================
    MUNDO: estado completo de uma carreira (todas as ligas + copas + continentais)
    W = {v,clubId,format,season,members,leagues,comps,cal,pos,quali,myLeague,history,honors}
    ===================================================================== */
 function detShuffle(ids,season,lid){return ids.slice().sort((a,b)=>fcHash(a+lid+season)-fcHash(b+lid+season)||(a<b?-1:1));}
 function buildLeagues(members,season,format){
  const lg={};
  FC_COUNTRIES.forEach(C=>C.leagues.forEach(l=>{lg[l.id]=FCL.create(l.id,detShuffle(members[l.id],season,l.id),format);}));
  return lg;
 }
 function myLeagueOf(W){
  const C=FC_COUNTRIES.find(c=>c.id===club(W.clubId).country);
  return C.leagues.find(l=>W.members[l.id].includes(W.clubId)).id;
 }
 function startSeason(W){
  W.leagues=buildLeagues(W.members,W.season,W.format);
  W.myLeague=myLeagueOf(W);
  W.comps=createSeason(W.season,W.members,W.quali);
  W.cal=calendar(FCL.rounds(W.leagues[W.myLeague]),W.comps);
  W.pos=0;W.banner=W.banner||'';
  advance(W);
 }
 function create(clubId,format){
  const members={};
  FC_COUNTRIES.forEach(C=>C.leagues.forEach(l=>members[l.id]=FC_LEAGUES[l.id].clubs.slice()));
  const W={v:4,clubId,format:format==='single'?'single':'double',season:1,members,quali:null,history:[],honors:[],banner:''};
  startSeason(W);return W;
 }
 /* roda os eventos em que o usuário não joga, até o próximo jogo dele (ou fim da temporada) */
 function advance(W){
  while(W.pos<W.cal.length){
   const ev=W.cal[W.pos];
   if(ev.t==='L')return;
   prepare(W.comps,ev.c,ev.p);
   if(userFixture(W.comps[ev.c],ev.p,W.clubId))return;
   playPhase(W.comps,ev.c,ev.p,null);W.pos++;
  }
 }
 function finished(W){return W.pos>=W.cal.length;}
 function pending(W){
  if(finished(W))return null;
  const ev=W.cal[W.pos];
  if(ev.t==='L'){
   const L=W.leagues[W.myLeague],pair=FCL.fixtures(L)[ev.r].find(p=>p[0]===W.clubId||p[1]===W.clubId),home=pair[0]===W.clubId;
   return{t:'L',ev,id:W.myLeague,name:FC_LEAGUES[W.myLeague].name,icon:'⚽',label:'Rodada '+(ev.r+1)+'/'+FCL.rounds(L),home,opp:home?pair[1]:pair[0],ko:false,neu:false};
  }
  prepare(W.comps,ev.c,ev.p);
  const comp=W.comps[ev.c],fx=userFixture(comp,ev.p,W.clubId),i=info(ev.c);
  if(!fx)return null;
  const home=fx.h===W.clubId;
  return{t:'C',ev,id:ev.c,name:i.name,icon:i.icon,label:label(comp,ev.p),home,opp:home?fx.a:fx.h,ko:!fx.group,neu:!!fx.neu};
 }
 /* o usuário jogou o evento pendente. um = {h,a,gh,ga,scorers,[et,pen,g90]}. Retorna os resultados da rodada. */
 function complete(W,um){
  const ev=W.cal[W.pos];let res;
  if(ev.t==='L'){
   const L=W.leagues[W.myLeague];res=FCL.playRound(L,um);
   const R=FCL.rounds(L),prog=(ev.r+1)/R;
   for(const id in W.leagues){if(id===W.myLeague)continue;const X=W.leagues[id];FCL.playUntil(X,Math.ceil(prog*FCL.rounds(X)-1e-9));}
  }else res=playPhase(W.comps,ev.c,ev.p,um);
  W.pos++;W.banner='';advance(W);
  return res;
 }
 /* classificação de todos os campeonatos do mundo */
 function endSeason(W){
  for(const id in W.leagues)FCL.playUntil(W.leagues[id],1e9);
  const ranks={},cupW={},members={},leagueChamps={},cupChamps={};
  FC_COUNTRIES.forEach(C=>{
   const l1=C.leagues[0].id,l2=C.leagues[1].id,L1=W.leagues[l1],L2=W.leagues[l2];
   ranks[C.id]=FCL.sorted(L1);
   const cup=W.comps['CUP-'+C.id];cupW[C.id]=cup?cup.champion:null;cupChamps[C.id]=cupW[C.id];
   leagueChamps[l1]=L1.champion;leagueChamps[l2]=L2.champion;
   const pr=FCL.promoRelegate(C,L1,L2);members[l1]=pr.tier1;members[l2]=pr.tier2;
  });
  const my=W.leagues[W.myLeague],pos=FCL.sorted(my).indexOf(W.clubId)+1;
  const comps=[];
  Object.keys(W.comps).forEach(id=>{
   const c=W.comps[id],st=status(c,W.clubId);
   if(st)comps.push({id,res:st.t.replace(/^[^A-Za-zÀ-ú]+/,''),champ:c.champion,k:st.k});
  });
  const cont={};['UCL','UEL','LIB','SUL','WC'].forEach(k=>{if(W.comps[k])cont[k]=W.comps[k].champion;});
  const entry={season:W.season,lid:W.myLeague,pos,champ:my.champion,clubId:W.clubId,comps};
  W.history.push(entry);
  W.honors.push({season:W.season,leagues:leagueChamps,cups:cupChamps,cont});
  const was=W.myLeague;
  W.quali=qualify(ranks,cupW);W.members=members;W.season++;W.banner='';
  startSeason(W);
  const C=FC_COUNTRIES.find(c=>c.id===club(W.clubId).country),l1=C.leagues[0].id,nm=FC_LEAGUES[W.myLeague].name;
  const trophies=comps.filter(c=>c.k==='champ').map(c=>info(c.id).short);
  let b='';
  if(was!==W.myLeague)b=W.myLeague===l1?'⬆ PROMOVIDO! Nova temporada na '+nm:'⬇ REBAIXADO. Nova temporada na '+nm;
  else if(pos===1&&was===l1)b='🏆 Campeão! Bora defender o título.';
  if(trophies.length&&!b)b='🏆 Títulos da temporada: '+trophies.join(', ');
  W.banner=b;
  return entry;
 }
 /* O que o clube do usuário vai disputar nesta temporada (para o painel) */
 function userComps(W){
  const out=[];
  Object.keys(W.comps).forEach(id=>{const st=status(W.comps[id],W.clubId);if(st)out.push(Object.assign({id},info(id),{st}));});
  return out;
 }
 /* valida um save */
 function valid(W){
  try{
   if(!W||W.v!==4||!club(W.clubId)||!W.leagues||!W.members||!W.comps||!Array.isArray(W.cal)||!W.leagues[W.myLeague])return false;
   for(const C of FC_COUNTRIES)for(const l of C.leagues){
    const L=W.leagues[l.id];if(!L||!Array.isArray(L.order)||!L.table||L.order.length%2)return false;
    for(const id of L.order)if(!club(id)||!L.table[id]||club(id).country!==C.id)return false;
   }
   if(!W.leagues[W.myLeague].order.includes(W.clubId))return false;
   return typeof W.pos==='number'&&W.pos>=0&&W.pos<=W.cal.length;
  }catch(e){return false;}
 }
 return{CUPS,CONT,QUOTA,info,prepare,create,startSeason,advance,pending,complete,finished,endSeason,userComps,valid,status,topScorers,qualify,bootstrapQuali,createSeason,calendar,resolveDraw,semiLosers,perf,label};
})();
