'use strict';
/* =====================================================================
   FC CARREIRA 3D — NÚCLEO (game.js)
   Regras, estado da partida, física da bola, IA, telas/menus e laço principal.
   Motor próprio (projeção 3D em Canvas 2D, sem bibliotecas externas).
   Arquivos:  game.js (este) · input.js (controles/HUD) · render.js (câmera/desenho)
   Todos compartilham o escopo global; ordem de carga: game → input → render (ver index.html).
   ===================================================================== */
const $=s=>document.querySelector(s);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const rnd=Math.random,PI=Math.PI,TAU=PI*2,sin=Math.sin,cos=Math.cos,hyp=Math.hypot,abs=Math.abs;
const dist2=(ax,az,bx,bz)=>(ax-bx)*(ax-bx)+(az-bz)*(az-bz);
const angd=(a,b)=>{const d=b-a;return Math.atan2(sin(d),cos(d));};

/* ---------------- Configurações ---------------- */
const DEF={diff:2,speed:1,len:4,aPass:70,aShot:50,aCross:60,pPow:1,aMove:50,sens:1,vib:true,radar:true,names:true,ind:true,autoSwitch:true,
 cam:0,camH:1,camD:1,camZ:1,camA:0,
 gfx:1,scale:1,shadow:1,tex:1,fps:2,showFps:false,
 hudO:85,hudS:100,stad3d:'arenahorizon',sound:true,volSfx:100,volMus:50,volCrowd:40,perfv:2};
const FPSV=[30,45,60];
let S=Object.assign({},DEF);
try{Object.assign(S,JSON.parse(localStorage.getItem('fc3d_cfg')||'{}'));}catch(e){}
S.stad3d='arenahorizon';delete S.stadTune; // estádio único: Arena Horizon
if((S.perfv|0)<2){S.perfv=2;S.fps=2;S.scale=Math.max(S.scale,.9);} // migração: 60 FPS e resolução alta (a adaptativa cuida do resto)
const saveCfg=()=>{try{localStorage.setItem('fc3d_cfg',JSON.stringify(S));}catch(e){}};
const PRE=[{scale:.9,shadow:0,tex:0,fps:0},{scale:1,shadow:1,tex:1,fps:0},{scale:1,shadow:2,tex:2,fps:2}];
const SCH=[
 {t:'sec',l:'Jogabilidade'},
 {k:'diff',l:'Dificuldade',t:'sel',o:['Iniciante','Amador','Profissional','Classe mundial','Lendário']},
 {k:'speed',l:'Velocidade da partida',t:'rng',min:.7,max:1.3,st:.05},
 {k:'len',l:'Duração da partida (min)',t:'rng',min:2,max:10,st:1},
 {k:'aPass',l:'Assistência de passe',t:'rng',min:0,max:100,st:5},
 {k:'aShot',l:'Assistência de chute',t:'rng',min:0,max:100,st:5},
 {k:'aCross',l:'Assistência de cruzamento',t:'rng',min:0,max:100,st:5},
 {k:'pPow',l:'Força do passe',t:'rng',min:.6,max:1.6,st:.05},
 {k:'aMove',l:'Assistência de movimentação',t:'rng',min:0,max:100,st:5},
 {k:'sens',l:'Sensibilidade dos controles',t:'rng',min:.6,max:1.6,st:.05},
 {k:'autoSwitch',l:'Troca automática de jogador',t:'tog'},
 {k:'vib',l:'Vibração',t:'tog'},
 {t:'sec',l:'Interface'},
 {k:'radar',l:'Exibir radar',t:'tog'},
 {k:'names',l:'Exibir nome dos jogadores',t:'tog'},
 {k:'ind',l:'Indicador do jogador controlado',t:'tog'},
 {k:'hudO',l:'Controles: opacidade (%)',t:'rng',min:30,max:100,st:5},
 {k:'hudS',l:'Controles: tamanho (%)',t:'rng',min:70,max:120,st:5},
 {t:'sec',l:'Câmera'},
 {k:'cam',l:'Tipo de câmera',t:'sel',o:['Transmissão','Lateral','Dinâmica','Próxima do jogador','Personalizada']},
 {k:'camH',l:'Altura',t:'rng',min:.5,max:2,st:.05},
 {k:'camD',l:'Distância',t:'rng',min:.5,max:2,st:.05},
 {k:'camZ',l:'Zoom',t:'rng',min:.6,max:1.8,st:.05},
 {k:'camA',l:'Ângulo (°)',t:'rng',min:-60,max:60,st:5},
 {t:'sec',l:'Gráficos'},
 {k:'gfx',l:'Qualidade geral',t:'sel',o:['Baixa','Média','Alta']},
 {k:'scale',l:'Resolução de renderização',t:'rng',min:.4,max:1,st:.05},
 {k:'shadow',l:'Qualidade das sombras',t:'sel',o:['Desativadas','Leves','Aprimoradas']},
 {k:'tex',l:'Qualidade das texturas',t:'sel',o:['Baixa','Média','Alta']},
 {k:'fps',l:'Limite de FPS',t:'sel',o:['30','45','60']},
 {k:'showFps',l:'Mostrar FPS',t:'tog'},
 {t:'sec',l:'Áudio'},
 {k:'sound',l:'Som',t:'tog'},
 {k:'volSfx',l:'Volume dos efeitos (%)',t:'rng',min:0,max:100,st:5},
 {k:'volMus',l:'Volume da música (%)',t:'rng',min:0,max:100,st:5},
 {k:'volCrowd',l:'Volume da torcida (%)',t:'rng',min:0,max:100,st:5},
 {k:'sndmgr',l:'Sons e músicas personalizados',t:'btn',b:'ABRIR'},
 {t:'glb'},
];

/* ---------------- Áudio (WebAudio, sem arquivos) ---------------- */
const Au={ctx:null,noise:null,out:null,lastUi:0,lastBounce:0,
 init(){ if(this.ctx||!S.sound)return;
  try{const A=window.AudioContext||window.webkitAudioContext;if(!A)return;const c=this.ctx=new A();const sr=c.sampleRate;
   const b=this.noise=c.createBuffer(1,sr*2,sr);const d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
   // saída com compressor suave: evita estalos e distorção quando vários sons tocam juntos
   const comp=c.createDynamicsCompressor();comp.threshold.value=-14;comp.knee.value=18;comp.ratio.value=5;comp.attack.value=.004;comp.release.value=.2;
   const m=this.out=c.createGain();m.gain.value=.8;m.connect(comp);comp.connect(c.destination);
  }catch(e){this.ctx=null;} },
 resume(){ if(this.ctx&&this.ctx.state==='suspended')this.ctx.resume(); },
 // ruído filtrado com ataque curto (sem estalo) e queda suave
 nz(dur,vol,freq,type,q,delay,fEnd){ if(!this.ctx||!S.sound)return;const c=this.ctx,t=c.currentTime+(delay||0);const s=c.createBufferSource();s.buffer=this.noise;
  const f=c.createBiquadFilter();f.type=type||'lowpass';f.frequency.setValueAtTime(freq,t);if(fEnd)f.frequency.exponentialRampToValueAtTime(fEnd,t+dur);f.Q.value=q||.7;
  const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(vol,t+.004);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  s.connect(f);f.connect(g);g.connect(this.out);s.start(t,Math.random()*1.5);s.stop(t+dur+.03); },
 tone(fr,dur,vol,type,fr2,delay){ if(!this.ctx||!S.sound)return;const c=this.ctx,t=c.currentTime+(delay||0);const o=c.createOscillator();o.type=type||'sine';o.frequency.setValueAtTime(fr,t);
  if(fr2)o.frequency.exponentialRampToValueAtTime(fr2,t+dur);const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(vol,t+.006);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  o.connect(g);g.connect(this.out);o.start(t);o.stop(t+dur+.03); },
 arp(notes,step,vol,type,dur){ notes.forEach((n,i)=>this.tone(n,dur||.22,vol,type||'triangle',0,i*step/1000)); },
 crowd(l){},
 cheer(vol,dur){ if(!this.ctx||!S.sound)return;const c=this.ctx,t=c.currentTime;const s=c.createBufferSource();s.buffer=this.noise;
  const f=c.createBiquadFilter();f.type='bandpass';f.Q.value=.9;f.frequency.setValueAtTime(450,t);f.frequency.linearRampToValueAtTime(1000,t+dur*.3);f.frequency.linearRampToValueAtTime(650,t+dur);
  const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(vol,t+.4);g.gain.linearRampToValueAtTime(vol*.7,t+dur*.6);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  s.connect(f);f.connect(g);g.connect(this.out);s.start(t,Math.random()*1.5);s.stop(t+dur+.05); },
 ooh(vol,dur){ // "uuuh" da torcida: ruído grave que sobe e cai
  if(!this.ctx||!S.sound)return;const c=this.ctx,t=c.currentTime;const s=c.createBufferSource();s.buffer=this.noise;
  const f=c.createBiquadFilter();f.type='bandpass';f.Q.value=1.4;f.frequency.setValueAtTime(380,t);f.frequency.linearRampToValueAtTime(620,t+dur*.4);f.frequency.linearRampToValueAtTime(300,t+dur);
  const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(vol,t+dur*.3);g.gain.exponentialRampToValueAtTime(.0001,t+dur);
  s.connect(f);f.connect(g);g.connect(this.out);s.start(t,Math.random()*1.5);s.stop(t+dur+.05); },
 whistle(dur,f0,delay){ // apito com trinado
  if(!this.ctx||!S.sound)return;const c=this.ctx,t=c.currentTime+(delay||0);
  const o=c.createOscillator();o.type='sine';o.frequency.setValueAtTime(f0,t);
  const lfo=c.createOscillator();lfo.frequency.value=32;const lg=c.createGain();lg.gain.value=55;lfo.connect(lg);lg.connect(o.frequency);
  const g=c.createGain();g.gain.setValueAtTime(.0001,t);g.gain.linearRampToValueAtTime(.16,t+.02);g.gain.setValueAtTime(.16,t+dur-.05);g.gain.linearRampToValueAtTime(.0001,t+dur);
  o.connect(g);g.connect(this.out);o.start(t);lfo.start(t);o.stop(t+dur+.02);lfo.stop(t+dur+.02);
  this.nz(dur,.03,5000,'highpass',.5,delay||0); },
 play(n,v){ if(Net.fwd&&NETSND.has(n))Net.ev('s',n); if(!S.sound||!this.ctx)return;v=v||1;const R=()=>.92+Math.random()*.16;
  switch(n){
   case 'kick':{ // chute realista: baque grave + estalo do couro + ar
    this.tone(150*R(),.13,.6*v,'sine',48);this.tone(90,.09,.3*v,'sine',45);
    this.nz(.045,.7*v,2300,'bandpass',1.1);this.nz(.16,.3*v,900,'lowpass',.7,0,300);this.nz(.09,.1*v,4500,'highpass',.6,.02);break;}
   case 'pass':this.tone(170*R(),.09,.34*v,'sine',70);this.nz(.04,.35*v,1900,'bandpass',1);this.nz(.07,.08,3500,'highpass');break;
   case 'bounce':{const t=performance.now();if(t-this.lastBounce<90)break;this.lastBounce=t;this.tone(120*R(),.11,.4*v,'sine',55);this.nz(.03,.22*v,1200,'bandpass',.9);break;}
   case 'tackle':this.tone(95,.14,.45,'sine',50);this.nz(.1,.5,1100,'lowpass',.8,0,350);this.nz(.03,.3,2500,'bandpass');break;
   case 'post':{[1180,1770,2530,3300].forEach((f,i)=>this.tone(f*R(),.45-i*.07,.2/(i+1)+.04,'sine'));this.nz(.04,.4,3000,'bandpass');this.tone(110,.1,.3,'sine',60);break;}
   case 'net':this.nz(.45,.32,3200,'bandpass',.5,0,900);this.nz(.3,.18,1500,'lowpass',.6,.05,400);break;
   case 'save':this.nz(.05,.55,1500,'bandpass',1);this.tone(110,.14,.45,'sine',55);this.nz(.12,.2,700,'lowpass',.7,.02);break;
   case 'miss':this.ooh(.16,1.1);break;
   case 'ooh':this.ooh(.2,1.3);break;
   case 'whistle':this.whistle(.5,2900);this.whistle(.35,3000,.55);break;
   case 'foul':this.whistle(.7,2850);break;
   case 'whistleEnd':this.whistle(.4,2850);this.whistle(.4,2850,.5);this.whistle(.9,2750,1);break;
   case 'goal':this.cheer(.26,4);break;
   case 'horn':this.tone(220,.9,.1,'sawtooth');this.tone(277,.9,.08,'sawtooth');this.tone(330,.9,.07,'sawtooth');break;
   case 'ui':case 'click':{const t=performance.now();if(t-this.lastUi<70)break;this.lastUi=t;this.tone(660,.07,.1,'sine',880);this.nz(.02,.08,3500,'highpass');break;}
   case 'back':{const t=performance.now();if(t-this.lastUi<70)break;this.lastUi=t;this.tone(520,.08,.1,'sine',360);break;}
   case 'select':this.arp([660,880],60,.07,'sine',.1);break;
   case 'confirm':this.arp([523,659,784],70,.09,'sine',.14);break;
   case 'error':this.tone(200,.15,.12,'square',140);break;
   case 'sprint':this.nz(.12,.08,2800,'highpass');break;
   case 'dash':this.nz(.25,.25,600,'bandpass',.8,0,2400);break;
   case 'slide':this.nz(.4,.3,900,'lowpass',.6,0,250);break;
   case 'swap':this.tone(500,.06,.07,'triangle',700);break;
   case 'corner':this.whistle(.3,3000);break;
   case 'ach':this.arp([784,988,1175,1568],90,.1,'triangle',.3);break;
   case 'win':this.arp([392,523,659,784,1047],140,.12,'triangle',.4);this.cheer(.2,3.5);break;
   case 'lose':this.arp([392,370,330,294],200,.1,'triangle',.4);break;
   case 'count':this.tone(880,.12,.1,'sine');break;
  } }
};

/* ---------------- Constantes do mundo ---------------- */
const HL=52.5,HW=34,GW=3.66,GH=2.44,GD=2.2,BR=.22;
const PLX=HL+2.2,PLZ=HW+1.6; // limite máximo de movimento dos jogadores (gramado + pequena margem)
const FORM=[ // papel, profundidade, lateral, ataque, número
 ['GK',.015,0,0,1],['LB',.20,-.82,.3,3],['CB',.17,-.28,0,4],['CB',.17,.28,0,5],['RB',.20,.82,.3,2],
 ['LM',.42,-.74,.7,11],['CM',.38,-.24,.5,8],['CM',.38,.24,.5,6],['RM',.42,.74,.7,7],
 ['ST',.62,-.2,1,9],['ST',.62,.22,1,10]];
const NAMES=['Silva','Costa','Rocha','Lima','Alves','Souza','Pinto','Dias','Nunes','Melo','Cruz','Reis','Moura','Neves','Ramos','Brito','Viana','Lopes','Castro','Freitas','Ribeiro','Teles'];
const KIT=[{sh:'#1f5fd6',sh2:'#ffffff',so:'#1f5fd6',num:'#fff'},{sh:'#d52b2b',sh2:'#1a1a1a',so:'#d52b2b',num:'#fff'}];
const GKK=[{sh:'#f2a900',sh2:'#222',so:'#222',num:'#000'},{sh:'#2fbf6a',sh2:'#222',so:'#222',num:'#000'}];
const SKIN=['#f1c9a5','#d9a47a','#b87a4e','#8a5a38','#5e3b24'],HAIR=['#161210','#3a2415','#6a4a2a','#c9a55a','#222'];
const TEAMN=['TIME 1','TIME 2'],TEAMA=['T1','T2'];
const DEF_CLUB_IDS=['bra.flamengo','bra.palmeiras']; // padrão do Amistoso/Editor (banco novo)
function cleanOv(o){const c=v=>(typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v))?v.toLowerCase():null;if(!o||typeof o!=='object')return null;const r={shirt:c(o.shirt),shorts:c(o.shorts),socks:c(o.socks)};return(r.shirt||r.shorts||r.socks)?r:null;}
function cleanTeamSpec(s,t){s=s||{};return fcClub(s.id)?{id:s.id,kit:(s.kit==='home'||s.kit==='away')?s.kit:'auto',ov:cleanOv(s.ov)}:{id:DEF_CLUB_IDS[t],kit:'auto',ov:null};}
const EDITOR_DEFAULT={teams:[cleanTeamSpec(null,0),cleanTeamSpec(null,1)],players:[Array.from({length:11},(_,i)=>({name:NAMES[i%NAMES.length],num:FORM[i][4],skin:SKIN[0],hair:HAIR[0],body:1})),Array.from({length:11},(_,i)=>({name:NAMES[(11+i)%NAMES.length],num:FORM[i][4],skin:SKIN[1],hair:HAIR[0],body:1}))]};
let CLUB=JSON.parse(JSON.stringify(EDITOR_DEFAULT));
try{const saved=JSON.parse(localStorage.getItem('fc3d_club_editor')||'null');
 if(saved&&saved.teams&&saved.players){
  // MIGRAÇÃO: clubes antigos/fictícios (sem ID válido do banco novo) são descartados
  saved.teams=[0,1].map(t=>cleanTeamSpec(saved.teams[t],t));
  CLUB=saved;
 }}catch(e){}
try{localStorage.removeItem('fc3d_career_v2');}catch(e){} // carreira antiga (clubes fictícios) removida
/* Aplica dois clubes do banco novo (nome, sigla, uniforme, goleiro) ao motor de jogo */
const MATCH_CLUBS=[null,null]; // ids dos clubes que vão jogar a partida (amistoso, carreira, pênaltis...)
function applyTeams(a,b){
 const[ka,kb,wa,wb]=fcPairKits(a,b),ca=fcClub(a.id),cb=fcClub(b.id);
 MATCH_CLUBS[0]=a.id;MATCH_CLUBS[1]=b.id;
 const set=(t,c,k)=>{TEAMN[t]=c.name.toUpperCase();TEAMA[t]=c.abbr;KIT[t].sh=k.shirt;KIT[t].sh2=k.shorts;KIT[t].so=k.socks;KIT[t].num=fcLum(k.shirt)>.6?'#111111':'#ffffff';};
 set(0,ca,ka);set(1,cb,kb);
 const g0=fcGkColor(ka,kb),g1=fcGkColor(ka,kb,g0);
 [g0,g1].forEach((g,t)=>{GKK[t].sh=g;GKK[t].num=fcLum(g)>.6?'#000000':'#ffffff';});
 return{k:[ka,kb],w:[wa,wb]};
}
function applyClub(){
 for(let t=0;t<2;t++)CLUB.teams[t]=cleanTeamSpec(CLUB.teams[t],t);
 applyTeams(CLUB.teams[0],CLUB.teams[1]);
 for(let t=0;t<2;t++){const c=fcClub(CLUB.teams[t].id);Object.assign(CLUB.teams[t],{name:c.name.toUpperCase(),abbr:c.abbr,shirt:KIT[t].sh,shirt2:KIT[t].sh2,shorts:KIT[t].so});}
}
function saveClub(){try{localStorage.setItem('fc3d_club_editor',JSON.stringify(CLUB));}catch(e){}applyClub();if(typeof applyEditorUI==='function')applyEditorUI();}
applyClub();
FCS.load(); // elencos por clube (players/*.json) — opcional; clubes sem elenco usam jogadores genéricos
const OPP=[.84,.92,.99,1.05,1.1],TKL=[.55,.75,.95,1.15,1.35],GKS=[.4,.6,.78,.9,.97];

/* ---------------- Estado do jogo ---------------- */
const G={state:'menu',paused:false,t:0,clock:0,half:1,score:[0,0],players:[],teamP:[[],[]],rk:[[],[]],off:[0,0],
 ball:null,user:null,possTeam:0,lastTouch:null,restart:null,restartT:0,clearR:0,stateT:0,charging:false,charge:0,
 autoSprint:false,press:[0,0],rush:[0,0],swT:0,rPrev:0,msg:'',msgUntil:0,stats:[{shots:0,passes:0,fouls:0,cards:0,poss:0},{shots:0,passes:0,fouls:0,cards:0,poss:0}],
 adapt:1,goalTeam:0,lastPassTgt:null,pass:null,shake:0,flash:0,net:null,msgT0:0,train:null,sp:null,wall:null,wallHold:0};
function msg(t,d,loc){G.msg=t;G.msgT0=G.t;G.msgUntil=G.t+(d||1.8);if(!loc&&Net.fwd)Net.ev('m',t,d||1.8);} // loc=true: mensagem só deste aparelho

/* ---------------- Controladores humanos ----------------
   LC = controle local (este aparelho; no anfitrião controla o time 0).
   RC = jogador remoto (só existe no anfitrião; controla o time 1 com os comandos recebidos pela rede).
   O MESMO código de controle (ctrlPlayer) serve aos dois: muda só a fonte de entrada (I) e o estado (carga do chute etc.). */
const LC={team:0,local:true,active:true,basis:null,cfg:null,
 get I(){return In;},
 get user(){return G.user;},set user(v){G.user=v;},
 get charging(){return G.charging;},set charging(v){G.charging=v;},
 get charge(){return G.charge;},set charge(v){G.charge=v;},
 get autoSprint(){return G.autoSprint;},set autoSprint(v){G.autoSprint=v;},
 get rPrev(){return G.rPrev;},set rPrev(v){G.rPrev=v;},
 get swT(){return G.swT;},set swT(v){G.swT=v;}};
const RC={team:1,local:false,active:false,basis:null,cfg:null,I:null,user:null,charging:false,charge:0,autoSprint:false,rPrev:0,swT:0};
RC.I=mkRemoteIn();
const CTL=[LC,RC];
let SC=S; // assistências em uso no momento (do controle que está sendo executado)
function ctlOf(p){return (LC.active&&LC.user===p)?LC:(RC.active&&RC.user===p)?RC:null;}
function vsAI(team){return team===1&&!Net.mp;} // bônus de dificuldade da IA só valem fora do multiplayer
function kcR(p){const c=ctlOf(p);return c?c.I.R.x:0;}
function resetUsers(){
 LC.user=G.teamP[0][9];
 if(Net.role==='host')RC.user=G.teamP[1][9];
 else if(Net.role==='guest')G.user=G.teamP[1][9];
}
function mkRemoteIn(){ // mesma interface de 'In', alimentada pelos pacotes da rede
 return {held:{},dn:{},up:{},L:{x:0,y:0},R:{x:0,y:0},kx:0,ky:0,
  press(id){if(this.held[id])return;this.held[id]=true;this.dn[id]=true;},
  release(id){if(!this.held[id])return;this.held[id]=false;this.up[id]=true;},
  pd(id){const v=this.dn[id];this.dn[id]=false;return !!v;},
  pu(id){const v=this.up[id];this.up[id]=false;return !!v;},
  clear(){this.dn={};this.up={};},
  releaseAll(){for(const k in this.held)if(this.held[k]){this.held[k]=false;this.up[k]=true;}this.L.x=this.L.y=this.R.x=this.R.y=0;}};
}
function cmsg(c,t,d){if(c.local)msg(t,d,true);else Net.sendMsg(t,d);}

/* Elenco resolvido das 11 vagas de cada time: titular do clube (squads.js) ou, sem elenco, o jogador genérico do Editor.
   ids = [clubIdTime0, clubIdTime1]. Retorna [[11],[11]] de {name,num,skin,hair,body,pid}. */
function buildRoster(ids){
 return[0,1].map(t=>Array.from({length:11},(_,i)=>{
  const E=(CLUB.players[t]&&CLUB.players[t][i])||{},d=(typeof FCS!=='undefined'&&ids&&ids[t])?FCS.slotData(ids[t],i):null;
  return d?{pid:d.id,name:d.name,num:d.num,skin:d.skin||E.skin,hair:d.hair||E.hair,body:E.body}:{pid:null,name:E.name,num:E.num,skin:E.skin,hair:E.hair,body:E.body};
 }));
}
/* Visual de jogador genérico (clube sem elenco): índice determinístico por time+vaga, para o mesmo jogador manter o mesmo personagem
   em partidas, menus e treinos (antes era Math.random a cada initMatch). */
function genIdx(team,i,salt){let h=(team*131+i*31+salt*17+(MATCH_CLUBS[team]?[...String(MATCH_CLUBS[team])].reduce((a,c)=>(a*31+c.charCodeAt(0))|0,7):0))>>>0;h=Math.imul(h^(h>>>15),2246822519)>>>0;h=Math.imul(h^(h>>>13),3266489917)>>>0;return (h^(h>>>16))%5;}
function mkPlayer(team,i){
 const f=FORM[i],R=(G.roster&&G.roster[team]&&G.roster[team][i])||(CLUB.players[team]&&CLUB.players[team][i])||{};
 return {team,i,role:f[0],u:f[1],v:f[2],att:f[3],pid:R.pid||null,name:R.name||NAMES[(team*11+i)%NAMES.length],num:+R.num||FORM[i][4],x:0,z:0,vx:0,vz:0,face:team?PI:0,phase:rnd()*6,speed:0,
  ctrlCd:0,kickT:0,slideT:0,slideHit:false,stun:0,tackleCd:0,immune:0,celeb:0,celebType:0,stumbleT:0,dustT:0,diveT:0,dvz:0,jumpT:0,skillCd:0,holdT:0,aiT:rnd()*.4,rank:9,d2b:0,
  sprint:false,out:false,shield:false,cards:0,skin:R.skin||SKIN[genIdx(team,i,5)],hair:R.hair||HAIR[genIdx(team,i,7)],body:+R.body||1,dz:0};
}
function initMatch(){
 if(!G.career)G.career=false;
 G.train=null;
 if(!G._penKeep)G.pen=null;
 G.roster=(Net.role==='guest')?null:buildRoster(MATCH_CLUBS);
 G.players=[];G.teamP=[[],[]];
 for(let t=0;t<2;t++)for(let i=0;i<11;i++){const p=mkPlayer(t,i);G.players.push(p);G.teamP[t].push(p);}
 G.ball={x:0,y:BR,z:0,px:0,pz:0,vx:0,vy:0,vz:0,spin:0,wx:0,wy:0,wz:0,q:[1,0,0,0],owner:null,rot:0,gkRolled:true,kicker:null,kickT:-9,postT:-9,hitT:-9,dz:0,isBall:true,tr:[]};
 G.score=[0,0];G.half=1;G.clock=0;G.stats=[{shots:0,passes:0,fouls:0,cards:0,poss:0},{shots:0,passes:0,fouls:0,cards:0,poss:0}];
 // Multi: anfitrião = time 0 (controle local) · visitante = time 1 (comandos chegam pela rede e rodam na simulação do anfitrião)
 const mpOn=!!(Net.mp&&Net.role);
 RC.user=null;RC.charging=false;RC.charge=0;RC.autoSprint=false;RC.rPrev=0;RC.swT=0;RC.I.releaseAll();RC.I.clear();
 RC.active=mpOn&&Net.role==='host'&&Net.connected;
 if(mpOn&&Net.role==='guest'){G.user=G.teamP[1][9];Net.other=G.teamP[0][9];}
 else{G.user=G.teamP[0][9];if(!mpOn)G.user.name='VOCÊ';else RC.user=G.teamP[1][9];}
 G.restart=null;G.sp=null;G.wall=null;G.wallHold=0;G.charging=false;G.autoSprint=false;G.press=[0,0];G.rush=[0,0];G.pass=null;
 G.t=0;G.paused=false;G.shake=0;G.flash=0;G.net=null;PT.length=0;
 kickoff(0);snapCamera();setL3Label('L3');
 msg('INÍCIO DE JOGO',2.2);
}
function halfLen(){return ((Net.role==='guest'&&Net.hostLen)?Net.hostLen:S.len)*30;}

function kickoff(team){
 spClearWall();G.sp=null;
 const b=G.ball;b.owner=null;b.vx=b.vy=b.vz=0;b.x=0;b.y=BR;b.z=0;ballResetSpin(b);
 for(const p of G.players){const dir=p.team?-1:1,own=-HL*dir;
  p.x=own+dir*Math.min(p.u*85,40);p.z=p.v*24;if(p.role==='GK'){p.x=own+dir*1.5;p.z=0;}
  p.vx=p.vz=0;p.face=dir>0?0:PI;p.ctrlCd=p.kickT=p.slideT=p.stun=p.tackleCd=p.immune=p.celeb=p.diveT=p.jumpT=p.stumbleT=0;p.holdT=0;}
 const dir=team?-1:1,tk=G.teamP[team][9],t2=G.teamP[team][10];
 tk.x=-dir*.6;tk.z=0;t2.x=-dir*3;t2.z=2.5;
 G.state='play';G.restart={kind:'kick',taker:tk,t:0};G.clearR=9.5;G.restartT=1.2;G.possTeam=team;
 setOwner(tk);tk.aiT=1.3;resetUsers();Au.play('whistle');
}
function setOwner(p){
 const b=G.ball;b.owner=p;G.possTeam=p.team;G.lastTouch=p;p.holdT=0;
 {const c=CTL[p.team];if(c.active&&p.role!=='GK')c.user=p;}
}

/* ---------------- Utilidades de movimento ---------------- */
function approach(p,tvx,tvz,a){
 let dx=tvx-p.vx,dz=tvz-p.vz;const v=hyp(p.vx,p.vz);
 if(v>3.2){ // inércia lateral: em velocidade alta a curva fechada custa mais (frear/acelerar continua rápido)
  const ux=p.vx/v,uz=p.vz/v,fw=dx*ux+dz*uz,lt=-dx*uz+dz*ux,k=1/(1+(v-3.2)*.055);
  dx=ux*fw-uz*lt*k;dz=uz*fw+ux*lt*k;
 }else if(a>0&&hyp(tvx,tvz)>v)a*=1+.35*(1-v/3.2); // arrancada explosiva saindo do parado
 const l=hyp(dx,dz);
 if(l>a){dx*=a/l;dz*=a/l;}
 p.vx+=dx;p.vz+=dz;
}
const HP={x:0,z:0};
function homePos(p){
 const dir=p.team?-1:1,own=-HL*dir,b=G.ball,has=G.possTeam===p.team;
 const progress=clamp((b.x-own)*dir/105,0,1),shift=(progress-.5)*(has?17:11);
 let tx=own+dir*clamp(p.u+(has?.055*p.att:-.035)+shift/105,.035,.965)*105;
 if(has&&['LB','RB'].includes(p.role))tx+=dir*3.5;
 if(!has&&['CB','LB','RB'].includes(p.role))tx-=dir*2.2;
 HP.x=clamp(tx,-HL+2,HL-2);
 let lane=p.v*(has?29:24)+b.z*(has?.12:.24);
 if(has&&['LM','RM'].includes(p.role))lane+=Math.sign(p.v||1)*3;
 if(has&&p.att>.45)lane+=clamp((b.z-p.z)*.12,-3.5,3.5);
 HP.z=clamp(lane,-31,31);return HP;
}
function steer(p,tx,tz,f,sprint,dt,spdF){
 const dx=tx-p.x,dz=tz-p.z,d=hyp(dx,dz);
 let sp=(sprint?7.5:5.1)*spdF*f;
 if(d<3)sp*=d/3;if(d<.25)sp=0;
 const nx=d>1e-3?dx/d:0,nz=d>1e-3?dz/d:0;
 approach(p,nx*sp,nz*sp,(sprint?10:13)*dt);p.sprint=sprint&&sp>0;
}
function nearestOf(team,x,z,noGK){
 let best=null,bd=1e9;
 for(const p of G.teamP[team]){if(p.out||(noGK&&p.role==='GK'))continue;const d=dist2(p.x,p.z,x,z);if(d<bd){bd=d;best=p;}}
 return best;
}
function nearestOppDist(m){
 let bd=1e9;for(const o of G.teamP[1-m.team]){const d=dist2(m.x,m.z,o.x,o.z);if(d<bd)bd=d;}return Math.sqrt(bd);
}

/* ---------------- Chutes, passes e bola ---------------- */
/* Efeito pedido pelo jogador (analógico direito, relativo à tela) somado ao chute: devolve a "razão de giro" lateral. */
function userCurl(p,ux,uz){
 const c=ctlOf(p);if(!c)return 0;const rx=c.I.R.x;if(abs(rx)<.3)return 0;
 const B=c.basis||C,sg=(-uz*B.grx+ux*B.grz)>=0?1:-1;
 return sg*Math.sign(rx)*clamp(abs(rx),0,1)*.14;
}
/* sp (opcional) = {side,top,roll}: side = curva lateral (razão de giro S, >0 vira p/ a esquerda do sentido do chute),
   top = topspin (+) / backspin (−), roll = bola sai rolando sem deslizar (passes e chutes rasteiros). */
function kickBall(p,vx,vy,vz,snd,sp){
 const b=G.ball;b.owner=null;b.pen=false;b.vx=vx;b.vy=vy;b.vz=vz;
 const vh=Math.max(.1,hyp(vx,vz)),ux=vx/vh,uz=vz/vh;
 if((sp&&sp.roll)||(!sp&&vy<2.5)){b.wx=vz/BR;b.wy=0;b.wz=-vx/BR;}      // rolamento puro (sentido correto)
 else spinInit(b,ux,uz,vh,vy,sp?sp.side||0:0,sp?sp.top||0:-.04);       // giro real do chute → Magnus no ar
 b.spin=clamp(b.wy*.1,-2.4,2.4);
 if(b.y<BR)b.y=BR;
 if(!b.q)b.q=[1,0,0,0];
 p.ctrlCd=.38;p.kickT=.3;p.holdT=0;G.lastTouch=p;G.possTeam=p.team;b.gkRolled=false;b.kicker=p;b.kickT=G.t;
 if(G.restart&&G.restart.taker===p){G.restart=null;G.clearR=0;G.restartT=0;}
 Au.play(snd||'kick');{const kc=ctlOf(p);if(kc)kc.charging=false;}
 fxKick(b,hyp(vx,vz),vy);
 if(p===G.user&&S.vib&&navigator.vibrate)try{navigator.vibrate(10);}catch(e){}
}
/* Passe rasteiro: calcula (andando de trás pra frente) a velocidade inicial que faz a bola chegar com
   velocidade de recepção va, já considerando o arrasto/atrito do gramado. Devolve também o tempo de voo. */
const PQ={v:0,t:0};
function groundPass(d,va){ // mesmo modelo de atrito/arrasto do núcleo físico: a bola chega com velocidade va
 let v=va,x=0,t=0;const h=.02;
 const dc=u=>MU_ROLL+C_ROLL*u+BM_K*ballCd(u)*u*u/(1+1/IK); // arrasto num corpo que rola vale 1/(1+⅔)=60% (parte vira giro)
 while(x<d&&t<6){const a0=dc(v),v1=v+a0*h;v+=.5*(a0+dc(v1))*h;x+=v*h;t+=h;} // integra de trás p/ frente (ponto médio)
 PQ.v=v;PQ.t=t;return PQ;
}
/* =====================================================================
   SISTEMA DE PASSES v2 (usa o mesmo núcleo físico da bola: physCore / groundPass / lobSpeed)
   - planPass: ponto de encontro bola×receptor (antecipa a corrida respeitando o que ele consegue alcançar)
   - bestTarget: escolha do receptor por CONE do analógico + espaço, marcação, risco por tempo de chegada e corrida
   - passTo: força progressiva com a distância, trajetória por tipo (curto / longo / enfiada / levantado / cruzamento)
   - G.pass + ballPath: o receptor corre até onde a bola REALMENTE vai passar e os adversários podem cortá-la
   ===================================================================== */
const SHOT_MIN=.3;                     // força mínima do chute (a barra de força começa aqui)
const PA={held:false};
/* Habilidade de passe (0..100) do jogador: usa o atributo "passing" do elenco quando existe (FCS), senão 66. Em cache no jogador. */
function passSkill(p){
 if(p._pk!==undefined)return p._pk;
 let v=66;try{if(p.pid&&typeof FCS!=='undefined'&&FCS.player){const sq=FCS.player(String(p.pid).split('.').slice(0,2).join('.'),p.pid);if(sq&&isFinite(sq.passing))v=sq.passing;}}catch(e){}
 return p._pk=clamp(v,30,99);
}                 // analógico esquerdo segurado no momento do passe (ctrlBody atualiza)
const V_OPP=6.9,R_OPP=.95;             // adversário: velocidade média de interceptação e alcance do pé (m/s, m)
const PP={tx:0,tz:0,d:0,T:0,va:0,vy:0,cross:false,open:9,race:0,risk:0};   // plano do passe (preenchido por planPass)
const AS={t:0};
/* Velocidade com que a bola deve CHEGAR ao receptor: cresce com a distância (curto = macio, longo = mais firme),
   fica mais firme com o corredor pressionado (urg 0..1) e supera a corrida de quem se afasta (away, m/s). */
function recvSpeed(d,type,urg,away){
 let v=7+.08*Math.min(d,32)+.04*Math.max(0,d-32);
 if(type===2)v+=1.2;
 v*=1+.12*clamp(urg,0,1);v+=Math.max(0,away)*.8;
 return clamp(v,6.5,13);
}
/* Elevação do passe levantado: lob curto mais baixo, lançamento longo mais alto, cruzamento tenso e rápido. */
function lobParams(d,cross){
 if(cross)return clamp(Math.sqrt(d)*1.2+.5,4.6,8);
 if(d<14)return clamp(Math.sqrt(d)*1.25+.3,3.6,6);
 return clamp(Math.sqrt(d)*1.45,4,d>38?9:11);
}
/* Tempo (s) para o adversário o chegar ao ponto (x,z): reação + corrida até o alcance do pé. */
function oppReach(o,x,z){
 const gk=o.role==='GK';
 return Math.max(0,hyp(o.x+o.vx*.25-x,o.z+o.vz*.25-z)-(gk?2:R_OPP))/(gk?6:V_OPP)+.18;
}
/* Risco do corredor do passe: para cada adversário, compara a hora em que a bola passa por pontos do trajeto com o
   tempo que ele leva para chegar lá (0 = livre, ~1+ = interceptado). No lançamento só o trecho final conta. */
function laneRisk(p,tx,tz,T,lob){
 const b=G.ball,ox=b.x,oz=b.z,dx=tx-ox,dz=tz-oz,d=hyp(dx,dz)||1;
 T=T||d/10;let risk=0;
 for(const o of G.teamP[1-p.team]){
  if(o.out)continue;
  const gk=o.role==='GK';let worst=0;
  for(let k=1;k<=6;k++){
   const s=k/6;if(lob&&s<.8)continue;
   const m=(T*Math.pow(s,.9)+.12-oppReach(o,ox+dx*s,oz+dz*s))/.55;
   if(m>worst)worst=m;
  }
  risk+=Math.min(1.2,worst)*(lob?.6:1)*(gk?.6:1);
 }
 return risk;
}
/* Velocidade horizontal inicial para a bola cruzar d metros ainda a va m/s, com a elevação vy (passe longo rasteiro/"driven"). */
function arriveSpeed(d,va,vy,roll,y0){
 let lo=Math.max(4,va*.8),hi=46;
 for(let k=0;k<10;k++){
  const vh=(lo+hi)/2,s=SIMB;s.x=0;s.y=y0;s.z=0;s.vx=vh;s.vy=vy;s.vz=0;
  if(roll){s.wx=0;s.wy=0;s.wz=-vh/BR;}else spinInit(s,1,0,vh,vy,0,-.04);
  let hs=0,t=0;
  for(let i=0;i<240;i++){physCore(s,.03);t+=.03;if(s.x>=d){hs=Math.hypot(s.vx,s.vz);break;}}
  AS.t=t;if(hs>va)hi=vh;else lo=vh;
 }
 return (lo+hi)/2;
}
/* Planeja o passe de p para o companheiro m (m = null: passe ao espaço na direção ax,az). Resultado em PP. */
function planPass(p,m,type,ax,az,ai){
 const b=G.ball,dir=p.team?-1:1,gx=HL*dir,ox=b.x,oz=b.z;
 const cross=type===1&&abs(p.z)>16&&p.x*dir>30;
 let tx,tz,T=.8,va=0,vy=0;
 if(!m||(cross&&!(abs(m.x-gx)<20&&abs(m.z)<14))){
  if(cross){tx=gx-dir*9;tz=-Math.sign(p.z||1)*3;}                                   // cruzamento sem ninguém na área: marca do pênalti, lado oposto
  else{const L=type===1?28:type===2?22:(ai?14:12),l=hyp(ax,az)||1;tx=ox+ax/l*L;tz=oz+az/l*L;}
  const dd=hyp(tx-ox,tz-oz);
  if(type===1){vy=lobParams(dd,cross);T=2*vy/G0*1.05;}else{va=recvSpeed(dd,type,0,0);T=groundPass(dd,va).t;}
 }else{
  const vR=m.role==='GK'?5.5:7.4,sp=hyp(m.vx,m.vz);
  tx=m.x;tz=m.z;
  for(let k=0;k<3;k++){
   const dd=hyp(tx-ox,tz-oz)||1,ux=(tx-ox)/dd,uz=(tz-oz)/dd;
   if(type===1){vy=lobParams(dd,cross);T=2*vy/G0*1.05;}
   else{va=recvSpeed(dd,type,0,m.vx*ux+m.vz*uz);T=groundPass(dd,va).t;}
   const lead=type===2?1:cross?.9:.8,te=Math.max(0,T-.12),lim=vR*Math.max(0,T-.1)*.92;
   let rx=m.x+m.vx*te*lead,rz=m.z+m.vz*te*lead,el=hyp(rx-m.x,rz-m.z);
   if(el>lim&&el>1e-3){rx=m.x+(rx-m.x)*lim/el;rz=m.z+(rz-m.z)*lim/el;el=lim;}     // nunca mira onde o receptor não chega a tempo
   if(type===2){                                                                    // enfiada: no espaço à frente do corredor
    const fwdRole=m.role==='ST'||m.role==='LM'||m.role==='RM'||m.role==='CM',ahead=(m.x-ox)*dir>3;
    const spe=(sp<4&&fwdRole&&ahead)?Math.max(sp,3.4):sp;                           // atacante à frente: assume que arranca em profundidade
    const rux=sp>1.5?m.vx/sp:dir,ruz=sp>1.5?m.vz/sp:0;
    const extra=Math.min(clamp(1.4+spe*.5,2.2,5.4),Math.max(0,lim-el));
    rx+=rux*extra;rz+=ruz*extra;
   }
   tx=rx;tz=rz;
  }
  if(cross){tx+=dir*.6;}                                                            // cruzamento: um passo à frente do atacante
  else if(type===1){const dd=hyp(tx-ox,tz-oz)||1,sh=clamp(dd*.05,.5,1.8);tx-=(tx-ox)/dd*sh;tz-=(tz-oz)/dd*sh;} // lançamento cai um pouco antes: quica e chega controlável
 }
 tx=clamp(tx,-HL+.5,HL-.5);tz=clamp(tz,-HW+.5,HW-.5);
 if(type===2)tx=dir>0?Math.min(tx,HL-3):Math.max(tx,-HL+3);                         // enfiada não vai pra linha de fundo
 const dd=hyp(tx-ox,tz-oz)||1;
 const T0=T,risk=m?laneRisk(p,tx,tz,T0,type===1):0;
 if(type!==1){                                                                       // marcado/corredor fechado: mais firme
  const ux=(tx-ox)/dd,uz=(tz-oz)/dd;
  va=recvSpeed(dd,type,risk,m?m.vx*ux+m.vz*uz:0);T=groundPass(dd,va).t;
 }else{vy=lobParams(dd,cross);T=2*vy/G0*1.05;}
 // espaço no ponto de chegada e disputa de corrida (>0: o receptor chega antes de qualquer adversário)
 let open=99,minTo=99;
 for(const o of G.teamP[1-p.team]){
  if(o.out)continue;
  const dq=hyp(o.x+o.vx*T*.5-tx,o.z+o.vz*T*.5-tz);if(dq<open)open=dq;
  const to=oppReach(o,tx,tz);if(to<minTo)minTo=to;
 }
 PP.tx=tx;PP.tz=tz;PP.d=dd;PP.T=T;PP.va=va;PP.vy=vy;PP.cross=cross;PP.open=open;
 PP.race=m?minTo-(Math.max(0,hyp(m.x-tx,m.z-tz)-.6)/(m.role==='GK'?5.5:7.4)+.12):0;
 PP.risk=risk;
 return PP;
}
/* Escolha do receptor. Humano: CONE em torno da direção do analógico (largura cresce com a assistência) → quem está na direção
   pedida vence; fora do cone ninguém é escolhido (o passe vai ao espaço naquela direção). Soma espaço, marcação, risco do
   corredor, corrida e (enfiada) disputa de corrida com a defesa. IA: avalia só contexto de jogo. */
function bestTarget(p,ax,az,type,assist,ai){
 const dir=p.team?-1:1,gx=HL*dir,b=G.ball,ox=b.x,oz=b.z;
 const held=!ai&&PA.held,cross=type===1&&abs(p.z)>16&&p.x*dir>30,aimA=Math.atan2(az,ax);
 const cone=held?(.45+.6*clamp(assist,0,1))*(cross?1.15:1):1.4;        // ≈26°–60° com o analógico; ≈80° sem ele
 let best=null,bs=-1e9;
 for(let ps=0;ps<2&&!best;ps++){
  if(ps&&(held||ai))break;
  const cn=ps?2.2:cone;                                                   // sem analógico e ninguém à frente: relaxa p/ ≈125° (recuo seguro)
  for(const m of G.teamP[p.team]){
   if(m===p||m.out)continue;
   const dx=m.x-ox,dz=m.z-oz,d0=hyp(dx,dz);if(d0<(ai?3:2.6))continue;
   if(!ai&&m.role==='GK'&&type!==0)continue;
   const pl=planPass(p,m,type,ax,az,ai),d=pl.d,open=pl.open,fwd=(pl.tx-ox)*dir,run=m.vx*dir,risk=pl.risk;
   let sc;
   if(ai){
    sc=fwd*.07+Math.min(open,8)*.5-d*.04+(m.role==='GK'?-6:0)+rnd()-risk*4.5+run*.25+clamp(pl.race,-1,1.2)*1.2;
    if(type===1&&d<14)sc-=5;if(type===0&&d>26)sc-=4;if(open<2)sc-=3;
   }else{
    const th=abs(angd(aimA,Math.atan2(dz,dx)))*.6+abs(angd(aimA,Math.atan2(pl.tz-oz,pl.tx-ox)))*.4;   // direção até o jogador e até o ponto de chegada
    if(th>cn*1.1)continue;
    sc=(1-Math.pow(Math.min(th/cn,1.3),1.6))*(held?8.5:5);
    if(type===0)sc+=-abs(d-13)*.05-(d>30?(d-30)*.08:0)+(m.role==='GK'?-2:0);                       // curto: companheiro próximo e seguro
    else if(type===1)sc+=Math.min(d,36)*.05-(d<12?2.2:0)+(cross?(abs(m.x-gx)<18&&abs(m.z)<14?1.6+Math.min(open,5)*.15:-1.5):(abs(m.z)>15&&m.x*dir>25?.8:0));
    else sc+=fwd*.05+run*.35+(fwd<2?-3:0)-(d<9?1.5:0)+clamp(pl.race,-1.5,1.5)*1.6;                  // enfiada: espaço, corrida e disputa
    sc+=-risk*3.4*(type===1?.6:1)+Math.min(open,7)*.2-(open<2.2?(2.2-open)*1:0);                   // evita jogador marcado e corredor fechado
    if(!held)sc+=fwd*.03;
    if(held){ // passe lateral / para trás: prioriza segurança (espaço livre, corredor limpo) e proximidade; lateral longo = inversão de jogo
     const fa=cos(aimA)*dir;
     if(fa<-.35&&type!==1)sc+=Math.min(open,8)*.25-risk*1.6-(d>24?(d-24)*.1:0);
     else if(fa<.35&&type===1&&d>=22)sc+=1.2;
    }
   }
   if(sc>bs){bs=sc;best=m;}
  }
 }
 return best;
}
function passTo(p,tgt,ax,az,type,assist,ai){
 const b=G.ball,dir=p.team?-1:1,ox=b.x,oz=b.z;
 const pl=planPass(p,tgt,type,ax,az,ai),cross=pl.cross,tx=pl.tx,tz=pl.tz;
 let vh,vy=0,sp=null,dx=tx-ox,dz=tz-oz,d=hyp(dx,dz);
 if(d<1){dx=cos(p.face);dz=sin(p.face);d=1;}
 // Erro de pontaria: cresce com distância, velocidade do passador, pressão e giro do corpo; diminui com a assistência
 let err=ai?(.07-S.diff*.012):.05*(1-assist*.75);
 if(cross&&!ai)err=.09*(1-SC.aCross/100*.7);
 if(type===0)err*=.8;if(type===1)err*=1.3;
 err*=.75+.018*Math.min(d,40);
 err*=clamp(1.32-.0062*passSkill(p),.78,1.2);                     // atributo de passe: craque erra menos, jogador fraco erra mais (erro natural preservado)
 err*=1+Math.min(p.speed,8)*.02;
 if(nearestOppDist(p)<2.5)err*=1.25;
 {const off=abs(angd(p.face,Math.atan2(dz,dx)));err*=1+.25*clamp(off/PI,0,1)*(p.speed>3?1:.6);}
 if(b.y>1)err*=1.6;if(p.stun>0)err*=1.5;
 const a=Math.atan2(dz,dx)+(rnd()+rnd()-1)*err,ux=cos(a),uz=sin(a);   // erro triangular: quase sempre perto da mira, raramente no limite
 if(type===1){
  vy=lobParams(d,cross);vh=clamp(lobSpeed(b.x,b.y,b.z,ux,uz,d,vy,-.12),7,40);sp={top:-.12};   // resolve o alcance exato com arrasto + backspin
 }else{
  const va=pl.va;
  if(d>26){                                                          // longo rasteiro: bola "viaja" rente ao chão (elevação baixa), força resolvida pela física
   vy=clamp(1.8+(d-26)*.045,1.8,3.2);const roll=vy<2.5;
   vh=clamp(arriveSpeed(d,va,vy,roll,b.y),12,40);sp=roll?{roll:true}:{top:-.04};
  }else{const g=groundPass(d,va);vh=clamp(g.v,type===2?11:7,34);}
 }
 if(!ai)vh*=SC.pPow;
 if(b.y>1){vh*=.8;vy=Math.min(vy,3);}
 kickBall(p,ux*vh,vy,uz*vh,'pass',sp);G.stats[p.team].passes++;if(!G.train&&p.team===0)achAdd('amistoso','passes',1);
 const rcv=tgt&&tgt.team===p.team;
 G.pass=rcv?{team:p.team,kicker:p,tgt:tgt,tx:tx,tz:tz,t0:G.t,T:pl.T,type:type,kt:b.kickT}:null;
 {const pc=ctlOf(p);if(pc&&tgt&&tgt.role!=='GK'&&tgt.team===p.team)pc.user=tgt;}
}
/* Passe "vivo": a bola ainda está a caminho do receptor pretendido (sem dono, sem outro chute/toque de adversário). */
function livePass(){
 const ps=G.pass,b=G.ball;
 if(!ps||b.owner||G.state!=='play'||b.kickT!==ps.kt||G.t>ps.t0+ps.T+1.6||b.hitT>ps.t0+.05)return null;
 return ps;
}
/* Trajetória prevista da bola livre (mesmo núcleo físico), amostrada a cada .05 s; calculada uma vez por passo. */
const BP={t:-1,n:0,x:new Float32Array(56),y:new Float32Array(56),z:new Float32Array(56)};
function ballPath(){
 if(BP.t===G.t)return;BP.t=G.t;
 const b=G.ball,s=SIMB;s.x=b.x;s.y=b.y;s.z=b.z;s.vx=b.vx;s.vy=b.vy;s.vz=b.vz;s.wx=b.wx;s.wy=b.wy;s.wz=b.wz;
 for(let n=0;n<56;n++){BP.x[n]=s.x;BP.y[n]=s.y;BP.z[n]=s.z;physCore(s,.025);physCore(s,.025);}
 BP.n=56;
}
/* Onde o receptor deve ir: entre os pontos em que a bola passa baixa (controlável) e que ele alcança a tempo, o mais perto do ponto
   planejado — e, se um adversário chegaria antes, o mais cedo possível (vem buscar a bola). Sem ponto alcançável: o menos longe. */
const RT={x:0,z:0,t:0,ok:true};
function receiveTarget(p,ps,vmax,react){
 ballPath();
 let bi=-1,bc=1e9,fi=-1,fd=1e9;
 const opp=G.teamP[1-p.team];
 for(let i=1;i<BP.n;i++){
  if(BP.y[i]>1.15)continue;
  const t=i*.05,x=clamp(BP.x[i],-HL+.5,HL-.5),z=clamp(BP.z[i],-HW+.5,HW-.5);
  const tr=react+Math.max(0,hyp(x-p.x,z-p.z)-.6)/vmax,def=tr-t;
  if(def<fd){fd=def;fi=i;}
  if(def>.04)continue;
  let c=hyp(x-ps.tx,z-ps.tz)*.3;
  for(const o of opp){if(!o.out&&oppReach(o,x,z)<t-.02){c+=4+t*1.5;break;}}
  if(c<bc){bc=c;bi=i;}
 }
 const i=bi>=0?bi:fi;
 if(i<0){RT.x=ps.tx;RT.z=ps.tz;RT.t=0;RT.ok=false;return RT;}
 RT.x=clamp(BP.x[i],-HL+.5,HL-.5);RT.z=clamp(BP.z[i],-HW+.5,HW-.5);RT.t=i*.05;RT.ok=bi>=0;return RT;
}
/* IA do receptor: depois de uma reação curta corre ao ponto de encontro com a trajetória REAL da bola (corrige passe torto/curto). */
function passReceive(p,ps,dt,spdF){
 if(G.t<ps.t0+.12)return false;
 const vm=7.4*spdF,rt=receiveTarget(p,ps,vm,0);
 receiveVel(p,rt,vm);
 approach(p,RV.x,RV.z,(RV.sp>5.2?10:13)*dt);p.sprint=RV.sp>5.2;return true;
}
/* Velocidade desejada do receptor: chega ao ponto na hora em que a bola chega (não antes) e, se já vem correndo, segue em frente
   "correndo na bola" em vez de frear e esperar. */
const RV={x:0,z:0,sp:0};
function receiveVel(p,rt,vm){
 const dx=rt.x-p.x,dz=rt.z-p.z,d=hyp(dx,dz),ux=d>1e-3?dx/d:0,uz=d>1e-3?dz/d:0;
 let sp=d>.3?Math.min(vm,(d-.3)/Math.max(.15,rt.t)):0;
 if(p.speed>2.5&&(p.vx*ux+p.vz*uz)>0)sp=Math.max(sp,Math.min(p.speed,6.5));
 if(d<.6&&p.speed>2.5){RV.x=p.vx*.97;RV.z=p.vz*.97;RV.sp=p.speed;return RV;}
 if(d<2&&sp>0)sp=Math.max(sp,Math.min(vm,d*3));
 RV.x=ux*sp;RV.z=uz*sp;RV.sp=sp;return RV;
}
/* IA do adversário: se consegue chegar a um ponto do trajeto antes da bola (com reação que melhora na dificuldade), vai cortar o passe. */
function passIntercept(p,ps,dt,spdF){
 const react=.42-.06*S.diff;
 if(G.t<ps.t0+react||p.role==='GK')return false;
 const b=G.ball;
 {const sx=ps.tx-b.x,sz=ps.tz-b.z,l2=sx*sx+sz*sz||1,t=clamp(((p.x-b.x)*sx+(p.z-b.z)*sz)/l2,0,1);
  if(hyp(p.x-(b.x+sx*t),p.z-(b.z+sz*t))>14)return false;}   // longe demais do corredor
 ballPath();
 const vo=V_OPP*spdF/.97;
 for(let i=2;i<BP.n;i++){
  if(BP.y[i]>1.15)continue;
  const t=i*.05,x=clamp(BP.x[i],-HL+.5,HL-.5),z=clamp(BP.z[i],-HW+.5,HW-.5);
  if(Math.max(0,hyp(x-p.x,z-p.z)-.7)/vo<=t-.05){steer(p,x,z,1.05,true,dt,spdF);return true;}
 }
 return false;
}
/* Cobrança de falta (Treino de Falta): usa o mesmo disparo do chute (mira pelo analógico, força pela carga do botão X, curva pelo mesmo userCurl),
   mas escolhe uma trajetória em arco que PASSA POR CIMA da barreira (9,15 m) e cai no gol. Carga baixa = bola mais alta/lenta, alta = mais rasa/rápida. */
function freeKick(p,power,aimz){
 const b=G.ball,gx=HL,D=hyp(gx-b.x,aimz-b.z),a0=Math.atan2(aimz-b.z,gx-b.x),wd=Math.min(9.15,D-3);
 const ty=clamp(1.9-1.45*Math.min(power,1),.45,1.9),side=userCurl(p,cos(a0),sin(a0)),top=power>.8?.05:0;
 let vy=4,vh=16,phi=0;
 for(let t=0;t<12;t++){
  vy=4+t*.5;let lo=8,hi=34;
  for(let i=0;i<9;i++){const m=(lo+hi)/2;flightAt(b.x,b.y,b.z,a0+phi,a0,D,m,vy,side,top);if(FQ.y>ty)hi=m;else lo=m;}
  vh=(lo+hi)/2;flightAt(b.x,b.y,b.z,a0+phi,a0,wd,vh,vy,side,top);
  if(FQ.y>=2.3)break; // altura sobre a barreira (jogador 1,8 m + folga)
 }
 for(let i=0;i<3;i++){flightAt(b.x,b.y,b.z,a0+phi,a0,D,vh,vy,side,top);phi-=FQ.lat/D;} // compensa a curva
 let err=(.03+.09*power*power)*(1-SC.aShot/100*.55)+D*.0012;if(p.stun>0)err*=1.5;if(power>1)err*=1+(power-1)*10;
 const a=a0+phi+(rnd()+rnd()-1)*err;vy=Math.max(0,vy+(rnd()+rnd()-1)*err*5+(power>1?(power-1)*rnd()*20:0));
 kickBall(p,cos(a)*vh,vy,sin(a)*vh,'kick',{side:side,top:top,roll:false});G.stats[p.team].shots++;
 if(vh>27)G.shake=Math.max(G.shake,.2);
}
/* Erro angular do chute (rad) pela força: mínimo na zona ideal (70–90%), pior fraco demais ou "na bola" (mesma curva do pênalti: penErr). */
function shotErr(pw){return pw<.7?.035+.07*(.7-pw)/.7:(pw<=.9?.035:.035+.08*(pw-.9)/.1);}
function shoot(p,power,aimz,ai,clear){
 const b=G.ball,dir=p.team?-1:1,gx=HL*dir;
 if(clear){const a=p.face;kickBall(p,cos(a)*22,3.5,sin(a)*22,'kick',{top:-.06});return;}
 if(!ai&&G.train&&G.train.type==='foul'&&p.team===0){freeKick(p,power,aimz);return;}
 power=clamp(power,.1,1);   // a força vai de 0 a 100%: acima disso não existe mais "exagero" aleatório (a barra mostra o limite)
 const gk=G.teamP[1-p.team][0],d0=hyp(gx-p.x,aimz-p.z),a0=Math.atan2(aimz-p.z,gx-p.x);
 const D=hyp(gx-b.x,aimz-b.z),gkOut=gk&&!gk.out&&abs(gk.x-gx)>4.2&&d0>8&&d0<30; // goleiro adiantado
 let ty,side=0,top=0,cap=13,roll=false,kind;
 const v0=14+16*power;                                    // MESMA escala de força do pênalti: 30%→18,8 · 70%→25,2 · 100%→30 m/s
 let v=v0;
 const cdir=abs(aimz)>.8?-Math.sign(aimz):(rnd()<.5?-1:1); // curva "para dentro" do gol
 if(power<.8&&gkOut&&(ai?rnd()<.3:power<.62)){kind='chip';v=14;ty=1.2;top=-.16;cap=11;}   // cobertura: sobe, cai atrás do goleiro
 else if(power<.5&&D<=20){kind='low';ty=.4;cap=.6;roll=true;}                                  // rasteiro colocado (só de perto: de longe a bola rolando morre antes do gol)
 else if(power<.8){kind='curl';ty=(power<.5?.6+rnd()*.4:1.1+rnd()*.6);side=power<.5?0:cdir*(.2+.1*(power-.5)/.3);cap=power<.5?12:9;}  // colocado (com curva)
 else{kind='power';ty=.6+rnd()*1.1;top=.05+(d0>22?.08:0);side=(rnd()-.5)*.04;}                  // forte (de longe a bola "cai": topspin)
 if(!ai&&kind!=='low'&&kind!=='chip')side+=userCurl(p,cos(a0),sin(a0));
 let err=ai?(.075-S.diff*.012):shotErr(power)*(1-SC.aShot/100*.55);
 err+=d0*.0016;if(p.stun>0)err*=1.5;if(b.y>1)err*=1.8;
 { // Realismo do chute: corpo fora de posição, corrida, marcador colado e ângulo fechado pioram a pontaria
  const fa=abs(angd(p.face,a0)),ga=abs(angd(p.team?PI:0,a0));
  err*=1.35*(1+Math.min(p.speed,8)*.05+fa*(p.speed>3?.35:.2)+clamp(ga-.5,0,1)*.8);
  if(nearestOppDist(p)<2.2)err*=1.3;
 }
 if(b.y>1){v*=.85;cap=Math.min(cap,2);roll=false;}
 if(kind==='chip'&&b.y<=1){ // sobe alto o bastante para passar por cima do goleiro e desce (backspin) antes do gol: a velocidade é resolvida p/ cair a ty na linha
  AQ.vy=clamp(6.8+d0*.06,7,8.6);AQ.a=a0;let lo=6,hi=26;
  for(let i=0;i<8;i++){const m=(lo+hi)/2;flightAt(b.x,b.y,b.z,a0,a0,D,m,AQ.vy,0,top);if(FQ.y>ty)hi=m;else lo=m;}
  v=(lo+hi)/2;
 }else solveAim(b.x,b.y,b.z,a0,D,ty,v,side,top,cap);   // elevação e azimute que compensam arrasto, Magnus e curva
 const a=AQ.a+(rnd()+rnd()-1)*err;   // erro triangular: quase sempre perto da mira, às vezes bem fora
 const vy=clamp(AQ.vy+(kind==='low'?0:(rnd()+rnd()-1)*err*8),0,Math.max(cap,0)+(power>.9?1.5:0));
 kickBall(p,cos(a)*v,vy,sin(a)*v,'kick',{side:side,top:top,roll:roll});G.stats[p.team].shots++;if(G.train&&G.train.type==='shoot'&&p.team===0)achAdd('chute','attempts',1);if(!G.train&&p.team===0)achAdd('amistoso','shots',1);
 if(v>27)G.shake=Math.max(G.shake,.2);
}
function aiPass(p,long){
 const tgt=bestTarget(p,0,0,long?1:0,.5,true),dir=p.team?-1:1;
 if(!tgt){const a=p.team?PI:0;passTo(p,null,cos(a),sin(a),1,.5,true);return;}
 const d=hyp(tgt.x-p.x,tgt.z-p.z);let type=(long||d>24)?1:0;
 if(!long&&tgt.att>.9&&rnd()<.3&&(tgt.x-p.x)*dir>6)type=2;
 passTo(p,tgt,0,0,type,.5,true);
}
function aiShoot(p){
 const gk=G.teamP[1-p.team][0];
 shoot(p,.55+rnd()*.4,-Math.sign(gk.z||rnd()-.5)*2.6+(rnd()-.5)*1.5,true,false);
}

/* ---------------- Desarmes e faltas ---------------- */
function tackleAttempt(tk,o,kind){
 if(G.restartT>0||o.immune>0||o.out)return false;
 let pc=kind?.6:.45;if(vsAI(tk.team))pc*=TKL[S.diff];if(o.shield)pc-=.2;if(o.sprint)pc-=.05;
 if(vsAI(o.team))pc*=(1.0-(S.diff*.04));
 if(rnd()<pc){
  const b=G.ball;b.owner=null;const a=tk.face+(rnd()-.5)*1.2,sp=3+rnd()*3;
  b.vx=cos(a)*sp+tk.vx*.3;b.vy=0;b.vz=sin(a)*sp+tk.vz*.3;b.gkRolled=true;
  o.ctrlCd=.55;G.lastTouch=tk;G.possTeam=tk.team;Au.play('tackle');tk.tackleCd=.5;
  o.stumbleT=.55;fxBurst(o.x,o.z,9);return true;
 }
 if(kind===1&&rnd()<.4){foul(tk,o);return false;}
 if(kind===0&&rnd()<.07){foul(tk,o);return false;}
 tk.stun=.5;return false;
}
function foul(tk,o){
 G.stats[tk.team].fouls++;Au.play('foul');
 let t='FALTA';
 if(rnd()<.25){tk.cards++;G.stats[tk.team].cards++;t='FALTA · CARTÃO AMARELO';}
 const dir=o.team?-1:1,gx=HL*dir;
 const inBox=(HL-abs(o.x))<16.5&&abs(o.z)<20.15&&o.x*dir>0;
 if(inBox){setRestart('pen',o.team,gx-dir*11,0,o,dir>0?0:PI);msg('PÊNALTI',2.2);}
 else{setRestart('free',o.team,o.x,o.z,o,dir>0?0:PI);msg(t,2.2);}
}
function setRestart(kind,team,x,z,taker,face){
 const b=G.ball;b.owner=null;b.x=x;b.z=z;b.y=BR;b.vx=b.vy=b.vz=0;ballResetSpin(b);
 for(const p of G.players){p.slideT=0;p.diveT=0;}
 taker.x=x-cos(face)*.6;taker.z=z-sin(face)*.6;taker.vx=taker.vz=0;taker.face=face;taker.ctrlCd=0;
 spClearWall();G.sp=null;
 G.restart={kind,taker,t:0};G.restartT=1.1;G.charging=false;RC.charging=false;
 G.clearR={free:8,corner:6,throw:2.5,goalkick:0,pen:14,kick:9.5}[kind]||0;
 setOwner(taker);taker.aiT=.9+rnd()*.8;
 if(!Net.mp&&!G.train&&!G.pen){
  const dir=taker.team?-1:1,gx=HL*dir;
  if(kind==='pen'){ // goleiro na linha, como na disputa de pênaltis
   const gk=G.teamP[1-taker.team][0];gk.x=gx-dir*1.2;gk.z=0;gk.vx=gk.vz=0;gk.face=dir>0?PI:0;gk.diveT=gk.slideT=gk.jumpT=0;gk.holdT=0;
  }
  if(kind==='free'&&freeKickInRange(taker,dir)){ // falta perigosa: barreira + chute com mira
   G.restart.shot=true;spBuildWall(x,z,taker.team);
   if(ctlOf(taker)===LC)spBegin('free',taker);else taker.aiT+=1.5; // IA espera a barreira se formar
  }else if(kind==='pen'){if(ctlOf(taker)===LC)spBegin('pen',taker);else taker.aiT+=.8;}
 }
}
function restartAct(p){
 const k=G.restart?G.restart.kind:'free',dir=p.team?-1:1,gx=HL*dir;
 if(k==='pen'){if(Net.mp||G.pen)shoot(p,.8,(rnd()<.5?-1:1)*2.8,true,false);else spAI(p,'pen');return;}
 if(k==='free'&&G.restart&&G.restart.shot&&rnd()<.75){spAI(p,'free');return;}
 if(k==='corner'){
  const c=[];for(const m of G.teamP[p.team])if(m!==p&&m.role!=='GK'&&abs(m.x-gx)<18&&abs(m.z)<14)c.push(m);
  const t=c.length?c[(rnd()*c.length)|0]:null;passTo(p,t,0,0,1,.5,true);return;
 }
 aiPass(p,k==='goalkick'||k==='free'&&abs(p.x-gx)>50);
}


function ballResetSpin(b){
 b.spin=0;b.wx=0;b.wy=0;b.wz=0;b.rot=0;b.q=[1,0,0,0];
}
function quatNormalize(q){
 const n=Math.hypot(q[0],q[1],q[2],q[3])||1;
 q[0]/=n;q[1]/=n;q[2]/=n;q[3]/=n;
}
function quatIntegrate(q,wx,wy,wz,dt){
 // dq = 0.5 * Ω ⊗ q * dt,  q=[w,x,y,z], Ω=[0,ωx,ωy,ωz]
 const qw=q[0],qx=q[1],qy=q[2],qz=q[3];
 const dw = -0.5*(wx*qx + wy*qy + wz*qz)*dt;
 const dx =  0.5*(wx*qw + wy*qz - wz*qy)*dt;
 const dy =  0.5*(wy*qw + wz*qx - wx*qz)*dt;
 const dz =  0.5*(wz*qw + wx*qy - wy*qx)*dt;
 q[0]+=dw; q[1]+=dx; q[2]+=dy; q[3]+=dz;
 quatNormalize(q);
}

/* ---------------- Física da bola (v3) ----------------
   Núcleo único e "puro" (physCore) usado tanto pela bola real quanto pelos previsores de chute/passe,
   então a bola SEMPRE faz o que o jogo previu. Convenção: sistema destro (x=comprimento, y=altura, z=largura),
   ω em rad/s; ponto de contato com o chão: u = v + ω×(0,−R,0); rolar sem deslizar ⇒ ωx=vz/R, ωz=−vx/R.
   - Ar: gravidade, arrasto quadrático ½ρCdAv² (Cd cai com a velocidade: regime "super-crítico"), Magnus
     a = ½ρ·CL(S)·A·v² · (ω×v)/|ω×v|, com S = R·ω⊥/v (razão de giro); o giro decai devagar.
   - Chão/traves/jogadores: impulso com restituição + atrito de Coulomb (impulso limitado a μ·Jn, ou o necessário
     para travar o deslizamento) e momento de inércia de casca esférica (I = ⅔mR²): o quique converte giro em
     velocidade e vice-versa.
   - Grama: deslizamento (μ≈0,42) até a bola "pegar" o rolamento; depois resistência de rolamento
     constante + viscosa. Quiques < 0,9 m/s viram rolamento (sem "tremedeira" no chão). */
const G0=9.81,BM_K=.053;           // BM_K = ½·ρ·A/m (ρ=1,2 kg/m³, raio real 11 cm, 430 g)
const MU_ROLL=.62,C_ROLL=.07;      // resistência de rolamento na grama: a = MU_ROLL + C_ROLL·v (m/s²)
const MU_TURF=.42,IK=1.5;          // atrito de deslizamento bola×grama · m·R²/I (casca esférica)
function ballCd(v){return v>=12?.22:v<=4?.42:.42-.2*(v-4)/8;}
function aero(s,dt,gr){ // atualiza só as velocidades (gravidade + arrasto + Magnus) e o giro
 const vx=s.vx,vy=s.vy,vz=s.vz,v2=vx*vx+vy*vy+vz*vz,v=Math.sqrt(v2);
 if(v>.3){
  const kd=BM_K*ballCd(v)*v*dt;                      // fração perdida por arrasto neste passo
  if(!gr){
   const cx=s.wy*vz-s.wz*vy,cy=s.wz*vx-s.wx*vz,cz=s.wx*vy-s.wy*vx,cm=Math.sqrt(cx*cx+cy*cy+cz*cz);
   if(cm>1e-3){const S=BR*cm/v2,a=BM_K*.30*(1-Math.exp(-S/.13))*v2/cm*dt;s.vx+=cx*a;s.vy+=cy*a;s.vz+=cz*a;}
  }
  const f=Math.max(0,1-kd);s.vx*=f;s.vy*=f;s.vz*=f;
 }
 s.vy-=G0*dt;
 if(!gr){const d=Math.exp(-.15*dt);s.wx*=d;s.wy*=d;s.wz*=d;}
}
function ballContact(s,nx,ny,nz,e,mu,sx,sz){ // colisão bola×superfície (n aponta da superfície para a bola); devolve a velocidade normal de impacto
 const rx=s.vx-sx,rz=s.vz-sz,vn=rx*nx+s.vy*ny+rz*nz;if(vn>=0)return 0;
 const Jn=-(1+e)*vn,tx=rx-vn*nx,ty=s.vy-vn*ny,tz=rz-vn*nz;
 const cx=s.wy*nz-s.wz*ny,cy=s.wz*nx-s.wx*nz,cz=s.wx*ny-s.wy*nx;       // ω×n
 const ux=tx-BR*cx,uy=ty-BR*cy,uz=tz-BR*cz,us=Math.sqrt(ux*ux+uy*uy+uz*uz);   // deslizamento no ponto de contato
 s.vx+=Jn*nx;s.vy+=Jn*ny;s.vz+=Jn*nz;
 if(us>1e-5){
  const jt=Math.min(mu*Jn,us/(1+IK)),fx=-ux/us*jt,fy=-uy/us*jt,fz=-uz/us*jt;
  s.vx+=fx;s.vy+=fy;s.vz+=fz;
  s.wx-=IK*(ny*fz-nz*fy)/BR;s.wy-=IK*(nz*fx-nx*fz)/BR;s.wz-=IK*(nx*fy-ny*fx)/BR;
 }
 return -vn;
}
function physCore(s,dt){ // um passo livre da bola (sem dono). Devolve a velocidade do quique (0 = sem quique)
 aero(s,dt,s.y<=BR+.004&&s.vy<=.5);
 s.x+=s.vx*dt;s.y+=s.vy*dt;s.z+=s.vz*dt;
 let imp=0;
 if(s.y<BR){
  s.y=BR;const vn=-s.vy;
  if(vn>.9){ // quique: restituição cai com a força do impacto (grama amortece)
   imp=ballContact(s,0,1,0,.62-.17*clamp((vn-4)/8,0,1),MU_TURF,0,0);
  }else{ // contato contínuo: deslizamento → rolamento → resistência da grama
   ballContact(s,0,1,0,0,MU_TURF,0,0);s.vy=0;
   const sp=Math.sqrt(s.vx*s.vx+s.vz*s.vz),ux=s.vx+BR*s.wz,uz=s.vz-BR*s.wx;
   if(ux*ux+uz*uz<.02){ // rolando sem deslizar
    const dec=(MU_ROLL+C_ROLL*sp)*dt;
    if(sp<=dec||sp<.04){s.vx=s.vz=0;s.wx=s.wz=0;}
    else{const k=(sp-dec)/sp;s.vx*=k;s.vz*=k;s.wx=s.vz/BR;s.wz=-s.vx/BR;}
    s.wy*=Math.exp(-2.5*dt);
   }else s.wy*=Math.exp(-1.2*dt);
  }
 }
 return imp;
}
/* ---- Previsores (usam o MESMO núcleo; não mexem na bola real) ---- */
const SIMB={x:0,y:0,z:0,vx:0,vy:0,vz:0,wx:0,wy:0,wz:0},FQ={y:0,lat:0,t:0,L:0};
function spinInit(s,ux,uz,vh,vy,side,top){ // side>0 curva para a esquerda do sentido do chute (vira +90°); top>0 topspin, <0 backspin
 const k=Math.hypot(vh,vy)/BR;s.wx=top*k*uz;s.wy=-side*k;s.wz=-top*k*ux;
}
function flightAt(x0,y0,z0,aL,a0,D,vh,vy,side,top){ // altura e desvio lateral ao cruzar a distância D (medida na direção a0)
 const s=SIMB,ux=cos(aL),uz=sin(aL),c0=cos(a0),s0=sin(a0);
 s.x=x0;s.y=y0;s.z=z0;s.vx=ux*vh;s.vy=vy;s.vz=uz*vh;spinInit(s,ux,uz,vh,vy,side,top);
 let t=0,pa=0,py=y0,pl=0,pt=0;
 for(let i=0;i<90;i++){
  physCore(s,.03);t+=.03;
  const al=(s.x-x0)*c0+(s.z-z0)*s0,lt=-(s.x-x0)*s0+(s.z-z0)*c0;
  if(al>=D){const f=(D-pa)/Math.max(1e-6,al-pa);FQ.y=py+(s.y-py)*f;FQ.lat=pl+(lt-pl)*f;FQ.t=pt+(t-pt)*f;return FQ;}
  pa=al;py=s.y;pl=lt;pt=t;
 }
 FQ.y=s.y;FQ.lat=0;FQ.t=t;return FQ;
}
const AQ={vy:0,a:0};
function solveAim(x0,y0,z0,a0,D,ty,vh,side,top,vyMax){ // acha a elevação e o azimute que levam a bola ao ponto (D, altura ty, desvio 0)
 const T0=D/(vh*.85);let vy=clamp((ty-y0)/T0+4.9*T0,0,vyMax),phi=0;
 for(let i=0;i<4;i++){
  flightAt(x0,y0,z0,a0+phi,a0,D,vh,vy,side,top);
  vy=clamp(vy+(ty-FQ.y)/Math.max(.25,FQ.t*.9),0,vyMax);
  phi-=FQ.lat/D;
 }
 AQ.vy=vy;AQ.a=a0+phi;
}
function lobSpeed(x0,y0,z0,ux,uz,d,vy,top){ // velocidade horizontal que faz o lançamento pousar a d metros (bissecção; deixa o tempo de voo em FQ.t)
 let lo=5,hi=42,t=0;
 for(let k=0;k<9;k++){
  const vh=(lo+hi)/2,s=SIMB;s.x=x0;s.y=y0;s.z=z0;s.vx=ux*vh;s.vy=vy;s.vz=uz*vh;spinInit(s,ux,uz,vh,vy,0,top);
  let L=0,air=false;t=0;
  for(let i=0;i<140;i++){physCore(s,.03);t+=.03;L=(s.x-x0)*ux+(s.z-z0)*uz;if(s.y>BR+.03)air=true;else if(air)break;} // 1º toque no chão
  if(L<d)lo=vh;else hi=vh;
 }
 FQ.t=t;return (lo+hi)/2;
}
/* ---------------- Física da bola ---------------- */
function stepBall(dt,noTr){
 const b=G.ball;
 if(b.owner){
  if(b.tr.length)b.tr.length=0;
  const o=b.owner,f=o.face,amp=Math.min(o.speed/6,1);
  if(o.role==='GK'&&o.holdT>=0&&G.restart==null&&!o.dribbles){
   b.x+=(o.x+cos(f)*.35-b.x)*Math.min(1,20*dt);b.z+=(o.z+sin(f)*.35-b.z)*Math.min(1,20*dt);b.y=1.05;
  }else{
   const a2=Math.min(o.speed/8,1),pulse=Math.pow(abs(sin(o.phase)),2)*.2*a2;
   let stride=.46+.3*a2+pulse,sideTouch=sin(o.phase)*.12*amp;
   if(o.shield){
    const op=nearestOf(1-o.team,o.x,o.z,true);stride=.42+pulse*.4;
    if(op){const ang=angd(f,Math.atan2(op.z-o.z,op.x-o.x));sideTouch=-Math.sign(ang||1)*.3;}
   }
   const kfb=o.recvT>0?.5:1;
   const tx=o.x+cos(f)*stride-sin(f)*sideTouch,tz=o.z+sin(f)*stride+cos(f)*sideTouch,kf=1-Math.exp(-(13+o.speed*.9)*dt*kfb);
   b.x+=(tx-b.x)*kf;b.z+=(tz-b.z)*kf;b.y=BR+abs(sin(o.phase))*(.035+.055*amp);if(o.recvT>0)o.recvT-=dt;
  }
  if(o.role==='GK')b.x=clamp(b.x,-(HL-.3),HL-.3);
  b.vx=o.vx;b.vz=o.vz;b.vy=0;
  // a bola dominada rola junto com o jogador: giro de rolamento puro (sentido correto), sem efeito lateral
  const k=1-Math.exp(-10*dt);
  b.wx+=(o.vz/BR-b.wx)*k;b.wz+=(-o.vx/BR-b.wz)*k;b.wy*=Math.exp(-4*dt);
  b.spin=clamp(b.wy*.1,-2.4,2.4);
  b.rot+=(o.speed||0)*dt/BR*.8;
  if(b.q)quatIntegrate(b.q,b.wx,b.wy,b.wz,dt);
  return;
 }
 if(!noTr){if(hyp(b.vx,b.vz)>15){b.tr.push(b.x,b.y,b.z);if(b.tr.length>24)b.tr.splice(0,3);}else if(b.tr.length)b.tr.splice(0,3);}

 const imp=physCore(b,dt);
 if(imp>3.2){Au.play('bounce');if(imp>5)fxPuff(b.x,b.z,2,.5);}
 b.spin=clamp(b.wy*.1,-2.4,2.4); // escalar legado (rede/visual): sentido do giro vertical

 // (sem "parede invisível" na lateral: a bola sai de verdade e checkBounds marca o lateral)

 // rotação visual legada + quaternão
 b.rot+=hyp(b.vx,b.vz)*dt/BR*.8;
 if(b.q)quatIntegrate(b.q,b.wx,b.wy,b.wz,dt);

 // rede do gol
 if(abs(b.x)>HL && abs(b.z)<GW+.25 && b.y<GH+.35){
  const sg=Math.sign(b.x)||1;
  if(abs(b.x)>HL+GD-.25){b.x=sg*(HL+GD-.25);b.vx*=-.28;b.vz*=.55;b.wx*=.5;b.wy*=.5;b.wz*=.5;}
  if(abs(b.z)>GW-.12){b.z=Math.sign(b.z)*(GW-.12);b.vz*=-.35;}
  if(b.y>GH-.08){b.y=GH-.08;b.vy=-abs(b.vy)*.35;}
 }
}
/* ---------------- Colisões da bola ----------------
   Traves e travessão (cilindros finos), corpo dos jogadores (cilindros) e sub-passos para a bola
   rápida não "atravessar" nada. O goleiro continua usando o sistema de defesas (gkSaves). */
const PR=.06,POSTR=BR+PR,BODY=.34; // raio da trave, distância de contato bola×trave, raio do corpo do jogador
function ballSeg(b,ax,ay,az,bx,by,bz,e){ // esfera × segmento; devolve a velocidade do impacto (0 = sem contato)
 const dx=bx-ax,dy=by-ay,dz=bz-az,l2=dx*dx+dy*dy+dz*dz;
 const t=clamp(((b.x-ax)*dx+(b.y-ay)*dy+(b.z-az)*dz)/l2,0,1),cx=ax+dx*t,cy=ay+dy*t,cz=az+dz*t;
 let nx=b.x-cx,ny=b.y-cy,nz=b.z-cz;const d=hyp(nx,ny,nz);
 if(d>=POSTR)return 0;
 if(d<1e-4){nx=0;ny=1;nz=0;}else{nx/=d;ny/=d;nz/=d;}
 b.x=cx+nx*POSTR;b.y=cy+ny*POSTR;b.z=cz+nz*POSTR;
 return ballContact(b,nx,ny,nz,e,.28,0,0); // metal pintado: quica forte e ainda gera/rouba giro pelo atrito
}
function ballFrame(b){ // gol: duas traves + travessão
 const x=(b.x<0?-1:1)*HL;let hp=0;
 for(const z of [-GW,GW])hp=Math.max(hp,ballSeg(b,x,0,z,x,GH,z,.7));
 const hc=ballSeg(b,x,GH,-GW,x,GH,GW,.7),h=Math.max(hp,hc);
 if(h>2.5&&G.t-b.postT>.3){
  b.postT=G.t;b.gkRolled=true;Au.play('post');Au.play('ooh');
  if(h>8){msg(hc>hp?'NO TRAVESSÃO!':'NA TRAVE!',1.2);G.shake=Math.max(G.shake,h>14?.3:.15);}
  if(navigator.vibrate&&S.vib&&h>8)try{navigator.vibrate(18);}catch(e){}
 }
}
function ballBody(b){ // bola × corpo dos jogadores (goleiros ficam de fora)
 const bsp=hyp(b.vx,b.vz),R=BODY+BR;
 for(const p of G.players){
  if(p.out||p.role==='GK')continue;
  if(p===b.kicker&&G.t-b.kickT<.45)continue; // quem acabou de chutar não bate na própria bola
  if(b.y-BR>(p.slideT>0?.45:1.8))continue;    // por cima da cabeça (ou do jogador no carrinho)
  const dx=b.x-p.x,dz=b.z-p.z,d2=dx*dx+dz*dz;if(d2>=R*R)continue;
  if(p.ctrlCd<=0&&p.slideT<=0&&b.y<=1.15&&bsp<=22)continue; // bola baixa e mansa: o domínio é feito em checkPickup
  let nx=1,nz=0;const d=Math.sqrt(d2);
  const qx=b.px-p.x,qz=b.pz-p.z,mx=dx-qx,mz=dz-qz,A=mx*mx+mz*mz;
  if(qx*qx+qz*qz>=R*R&&A>1e-8){ // bola rápida: acha o instante exato em que tocou o corpo (colisão "varrida") → normal correta, não atravessa
   const B=qx*mx+qz*mz,disc=B*B-A*(qx*qx+qz*qz-R*R);
   if(disc>=0){const t=clamp((-B-Math.sqrt(disc))/A,0,1);nx=(qx+mx*t)/R;nz=(qz+mz*t)/R;}
   else if(d>1e-3){nx=dx/d;nz=dz/d;}
  }else if(d>1e-3){nx=dx/d;nz=dz/d;}
  b.x=p.x+nx*R;b.z=p.z+nz*R;
  const hh=b.y-BR,e=hh<.5?.3:hh<1.3?.38:.48,mu=hh<.5?.7:.5; // pé absorve, tronco/cabeça devolvem mais
  const imp=ballContact(b,nx,0,nz,e,mu,p.vx,p.vz);if(imp<=0)continue;
  if(b.y>1)b.vy=Math.max(b.vy,Math.min(imp*.3,4)); // peito/cabeça: a bola sobe um pouco
  G.lastTouch=p;b.gkRolled=true;b.hitT=G.t;
  if(imp>6){p.ctrlCd=Math.max(p.ctrlCd,.3);Au.play('tackle');}
 }
}
function ballCollide(){const b=G.ball;if(G.state!=='play')return;ballBody(b);if(abs(b.x)>HL-1.2&&b.y<GH+1)ballFrame(b);}
function stepBallSub(dt){ // sub-passos: no máximo ~20 cm de deslocamento por passo
 const b=G.ball;if(b.owner){stepBall(dt);return;}
 const n=clamp(Math.ceil(hyp(b.vx,b.vy,b.vz)*dt/.2),1,8),h=dt/n;
 for(let i=0;i<n;i++){b.px=b.x;b.pz=b.z;stepBall(h,i>0);ballCollide();}
}
function checkPickup(){
 const b=G.ball;if(b.owner||G.state!=='play')return;
 if(G.sp&&G.sp.phase!=='flight')return; // bola parada esperando a cobrança com mira
 let best=null,bd=1e9;const bsp=hyp(b.vx,b.vz);
 for(const p of G.players){
  if(p.out||p.ctrlCd>0||p.slideT>0)continue;
  const gk=p.role==='GK';if(b.y>(gk?2.2:1.15))continue;
  const pcc=ctlOf(p),r=gk?1.1:(.78+(pcc?.35*(pcc.cfg||S).aMove/100:.1));
  const d=dist2(p.x,p.z,b.x,b.z);if(d<r*r&&d<bd){best=p;bd=d;}
 }
 if(!best)return;
 if(best.role==='GK'&&bsp>12)return; // goleiro: defesas tratadas em gkSaves
 if(bsp>22){ // forte demais p/ dominar: o jogador amortece e a bola escapa à frente (sem inverter nem sortear a direção)
  const ox=b.x-best.x,oz=b.z-best.z,off=(-ox*b.vz+oz*b.vx)/bsp,px=-b.vz/bsp,pz=b.vx/bsp,dv=clamp(off*5,-3,3); // desvio p/ o lado em que a bola bateu
  b.vx=b.vx*.3+best.vx*.5+px*dv;b.vz=b.vz*.3+best.vz*.5+pz*dv;b.vy=Math.min(2,.6+bsp*.04);
  b.wx*=.5;b.wy*=.5;b.wz*=.5;best.ctrlCd=.4;G.lastTouch=best;b.gkRolled=true;Au.play('tackle');return;
 }
 if(!G.train&&best.role!=='GK'&&bsp>8&&b.y<.6){ // domínio difícil: bola rápida (ou vinda de trás, ou com marcador colado) pode escapar do pé
  const pcc2=ctlOf(best),aid=pcc2?(pcc2.cfg||S).aMove/100:.4;
  const mv=hyp(best.vx-b.vx,best.vz-b.vz); // velocidade relativa bola×jogador
  const back=clamp(-(-b.vx*cos(best.face)-b.vz*sin(best.face))/bsp,0,1),pr=nearestOppDist(best)<2?1.25:1; // back: 1 = bola chega pelas costas
  if(rnd()<clamp((mv-9.5)*.03,0,.3)*(1.15-aid*.6)*(1+.5*back)*pr){
   b.vx=b.vx*.38+best.vx*.4;b.vz=b.vz*.38+best.vz*.4;b.vy=.9;best.ctrlCd=.2;G.lastTouch=best;b.gkRolled=true;G.possTeam=best.team;return;
  }
 }
 setOwner(best);best.recvT=.3;
}
function gkSaves(){
 const b=G.ball;if(b.owner||G.state!=='play'||b.gkRolled)return;
 for(const p of G.teamP[0].concat(G.teamP[1]).filter(q=>q.role==='GK'&&!q.out)){
  if(p.team===(b.kicker?b.kicker.team:-1))continue;
  const dir=p.team?-1:1;if(b.vx*dir>-2)continue; // indo contra o gol dele
  const reach=p.diveT>0?2.2:1.5;
  if(b.y<2.8&&dist2(p.x,p.z,b.x,b.z)<reach*reach){
   b.gkRolled=true;const sp=hyp(b.vx,b.vz),sk=vsAI(p.team)?GKS[S.diff]:.7;
   const ch=(b.pen&&vsAI(p.team))?clamp(.35+PEN_DIFF[spDiff()].gk*.35-(sp>22?.15:0),.12,.9):clamp(sk-(sp-14)*.02,.15,.97);
   if(rnd()<ch){
    if(sp<15&&b.y<1.9){setOwner(p);p.holdT=0;Au.play('tackle');msg('DEFESA!',1.2);Au.play('save');Au.play('ooh',.6);}
    else{b.owner=null;const side=Math.sign(b.z-p.z)||(rnd()<.5?-1:1);b.vx=-b.vx*.32;b.vz=b.vz*.3+side*(3+rnd()*3);b.vy=1.6+rnd()*2.4;b.wx*=.5;b.wy*=.5;b.wz*=.5;p.ctrlCd=.5;G.lastTouch=p;G.possTeam=p.team;msg('DEFESAÇA!',1.4);Au.play('save');}
    if(p.diveT<=0)p.diveT=.5;
   }
  }
 }
}
function checkBounds(){
 const b=G.ball;if(b.owner||G.state!=='play')return;
 if(abs(b.x)>HL){
  const s=Math.sign(b.x);
  if(abs(b.z)<GW&&b.y<GH+.15){if(G.train&&(!isShootTr(G.train)||s<0))trainOut();else goalScored(s);return;}
  if(G.train){trainOut();return;}
  const atk=s>0?0:1;
  if(G.lastTouch&&G.lastTouch.team===atk){
   const team=1-atk,gk=G.teamP[team][0],dirT=team?-1:1;
   setRestart('goalkick',team,s*(HL-5.5),0,gk,dirT>0?0:PI);msg('TIRO DE META',1.6);Au.play('miss');
  }else{
   const sz=Math.sign(b.z||1),tk=nearestOf(atk,s*HL,sz*HW,true);
   setRestart('corner',atk,s*(HL-.4),sz*(HW-.4),tk,Math.atan2(-sz,-s));msg('ESCANTEIO',1.8);Au.play('miss');
  }
  return;
 }
 if(abs(b.z)>HW+.1){
  if(G.train){trainOut();return;}
  const team=G.lastTouch&&G.lastTouch.team===0?1:0,sz=Math.sign(b.z),x=clamp(b.x,-HL+3,HL-3);
  const tk=nearestOf(team,x,sz*HW,true);
  setRestart('throw',team,x,sz*(HW-.1),tk,Math.atan2(-sz,0));msg('LATERAL',1.4);
 }
}
function goalScored(s){
 const team=s>0?0:1;G.score[team]++;if(!G.train&&team===0)achAdd('amistoso','goals',1);if(G.train&&G.train.type==='shoot'&&team===0)achAdd('chute','goals',1);G.state='goal';G.stateT=3.6;G.goalTeam=team;
 const sc=G.lastTouch;if(sc&&sc.team===team){sc.celeb=3.4;sc.celebType=(rnd()*3)|0;}else msg('GOL CONTRA',2);
 if(G.career)(G.careerGoals||(G.careerGoals=[])).push({t:team,n:(sc&&sc.team===team&&sc.name)?sc.name:null});
 fxGoal(s);if(Net.fwd)Net.ev('g',s);
 msg('GOOOL!  '+TEAMA[0]+' '+G.score[0]+' x '+G.score[1]+' '+TEAMA[1],3.4);Au.play('goal');if(G.train)trainGoal();
 if(navigator.vibrate&&S.vib)try{navigator.vibrate([40,60,40]);}catch(e){}
 G.charging=false;
}

/* ---------------- Controle do usuário ---------------- */
function switchPlayer(p,c){
 c=c||LC;const I=c.I,B=c.basis||C,b=G.ball,ix=I.L.x||I.kx,iy=I.L.y||I.ky,m=hyp(ix,iy);let best=null,bd=1e9;
 let wx=0,wz=0;if(m>.4){const nx=ix/m,ny=iy/m;wx=B.grx*nx+B.gfx*(-ny);wz=B.grz*nx+B.gfz*(-ny);}
 for(const q of G.teamP[p.team]){
  if(q===p||q.role==='GK'||q.out)continue;
  let d=dist2(q.x,q.z,b.x,b.z);
  if(m>.4){const dx=q.x-p.x,dz=q.z-p.z,dd=hyp(dx,dz)||1;if((dx*wx+dz*wz)/dd<.3||dd>30)continue;d=dd*dd;}
  if(d<bd){bd=d;best=q;}
 }
 if(best){c.user=best;c.swT=.8;if(c.local)Au.play('swap');}
}
const DASH_CD=1.1,DASH_VMAX=10.5; // recarga (s) e velocidade máxima após a arrancada
function dash(p,dx,dz,k){
 const l=hyp(dx,dz)||1;p.vx+=dx/l*k;p.vz+=dz/l*k;
 const v=hyp(p.vx,p.vz);if(v>DASH_VMAX){p.vx*=DASH_VMAX/v;p.vz*=DASH_VMAX/v;} // nunca acumula velocidade
 p.immune=.45;p.skillCd=DASH_CD;Au.play('dash');
}
/* Finta: ao driblar com a bola, adversários próximos e à frente são pegos no contrapé (perdem tração e o desarme demora) */
function dribbleBeat(p,fx,fz){
 const l=hyp(fx,fz)||1,ux=fx/l,uz=fz/l,sd=abs(-sin(p.face)*ux+cos(p.face)*uz); // 1 = corte lateral, 0 = frente
 for(const o of G.teamP[1-p.team]){
  if(o.out||o.role==='GK'||o.slideT>0)continue;
  const ox=o.x-p.x,oz=o.z-p.z,d=hyp(ox,oz);if(d>2.4||d<.1)continue;
  if((ox*cos(p.face)+oz*sin(p.face))/d<.1)continue; // só quem está na frente
  const k=.35+.4*sd;o.vx*=1-k;o.vz*=1-k;o.tackleCd=Math.max(o.tackleCd,.35+.45*sd);
 }
}
function userControl(p,dt){ctrlPlayer(p,dt,LC);} // compatibilidade
/* Direção do chute do usuário: o ponto no gol é onde a LINHA do analógico (a partir do jogador) cruza a linha de fundo.
   Antes usava só a componente Z do analógico como se fosse a posição no gol (errava o lado em chutes de ângulo/ala).
   Com o analógico solto: mira o canto oposto ao goleiro (assistência de chute). */
function shotAimZ(p,stick,ax,az,dir,gk,cf){
 const gx=HL*dir,lim=GW+2.6;
 if(stick){
  const ex=ax*dir;
  if(ex>.12){const t=(gx-p.x)/ax;return clamp(p.z+az*t,-lim,lim);}      // a linha do analógico cruza a linha do gol
  return (az>=0?1:-1)*(GW-.5);                                            // analógico quase paralelo à linha de fundo: mira a trave daquele lado
 }
 return (-Math.sign(gk.z||(rnd()-.5))*2.7)*(cf.aShot/100)+(rnd()-.5)*3.6*(1-cf.aShot/100);
}
/* Controle de UM jogador humano (local ou remoto). c = controlador (LC/RC). */
function ctrlPlayer(p,dt,c){
 SC=c.cfg||S;
 try{ctrlBody(p,dt,c);}finally{SC=S;}
}
function ctrlBody(p,dt,c){
 if(G.sp&&G.sp.taker===p&&G.sp.phase!=='flight'&&c===LC)return; // cobrança com mira: spStep controla o cobrador
 const b=G.ball,I=c.I,held=I.held,cf=SC,B=c.basis||C,tm=p.team,dir=tm?-1:1;
 let ix=I.L.x,iy=I.L.y;if(I.kx||I.ky){ix=I.kx;iy=I.ky;}
 const m=hyp(ix,iy);let mag=m<.14?0:clamp((m-.14)/.8,0,1);mag=clamp(mag*cf.sens,0,1);
 let wx=0,wz=0;if(m>.001){const nx=ix/m,ny=iy/m;wx=B.grx*nx+B.gfx*(-ny);wz=B.grz*nx+B.gfz*(-ny);} // relativo à câmera de QUEM joga
 const has=b.owner===p,sprint=!!(held.RT||c.autoSprint),shield=!!(held.LT&&has);
 p.shield=shield;
 if(p.stun>0)mag*=.4;
 let maxSp=(sprint?8.3:5.7)*(has?.94:1)*(shield?.55:1);
 if(!has&&(held.LT||held.RB))maxSp*=.72;
 let tvx=wx*mag*maxSp,tvz=wz*mag*maxSp,rcvAs=false;
 if(mag===0&&!has&&!b.owner){ // receptor de um passe sem tocar no analógico: ajusta a corrida (suave; qualquer movimento seu assume o controle)
  const ps=livePass();
  if(ps&&ps.tgt===p){const rt=receiveTarget(p,ps,7.4,.12),dx=rt.x-p.x,dz=rt.z-p.z,dd=hyp(dx,dz);
   if(dd>.35||p.speed>2.5){const vm=7.2*(.75+.25*cf.aMove/100);receiveVel(p,rt,vm);tvx=RV.x;tvz=RV.z;rcvAs=true;}}
 }
 approach(p,tvx,tvz,((mag>0||rcvAs)?(sprint?12:15):19)*(1+cf.aMove/200)*dt);
 p.sprint=sprint&&mag>.3;
 // Analógico direito: drible em direção rápida
 const rm=hyp(I.R.x,I.R.y);
 if(rm>.75&&c.rPrev<.45&&p.skillCd<=0){
  const nx=I.R.x/rm,ny=I.R.y/rm,fx=B.grx*nx+B.gfx*(-ny),fz=B.grz*nx+B.gfz*(-ny);dash(p,fx,fz,4.6);
  if(has)dribbleBeat(p,fx,fz);
 }
 c.rPrev=rm;
 const near=!has&&!b.owner&&dist2(p.x,p.z,b.x,b.z)<2.25&&b.y<1.0;
 const air=!has&&!b.owner&&b.y>=1&&b.y<2.7&&dist2(p.x,p.z,b.x,b.z)<4;
 const canKick=has||near||air;
 const ax=mag>.25?wx:cos(p.face),az=mag>.25?wz:sin(p.face);
 PA.held=mag>.25; // o passe respeita a direção do analógico (cone) quando ele está segurado
 if(air&&(I.dn.A||I.dn.B||I.dn.X))p.jumpT=.55;
 if(I.pd('A')){
  if(canKick)passTo(p,bestTarget(p,ax,az,0,cf.aPass/100,false),ax,az,0,cf.aPass/100,false);
  else{G.press[tm]=G.t+3.2;cmsg(c,'PRESSÃO',.9);}
 }
 if(I.pd('B')){
  if(canKick){const cz=abs(p.z)>16&&p.x*dir>30,as=(cz?cf.aCross:cf.aPass)/100;passTo(p,bestTarget(p,ax,az,1,as,false),ax,az,1,as,false);}
  else if(b.owner&&b.owner.team!==tm&&dist2(p.x,p.z,b.owner.x,b.owner.z)<5&&p.tackleCd<=0){p.tackleCd=.8;tackleAttempt(p,b.owner,0);}
 }
 if(I.pd('Y')){
  if(canKick)passTo(p,bestTarget(p,ax,az,2,cf.aPass/100,false),ax,az,2,cf.aPass/100,false);
  else{G.rush[tm]=G.t+2.5;cmsg(c,'GOLEIRO SAI',.9);}
 }
 if(I.pd('X')){
  if(canKick){c.charging=true;c.charge=SHOT_MIN;}   // a barra já começa na força mínima real do chute (barra = força usada)
  else if(!has&&p.slideT<=0&&p.tackleCd<=0){
   Au.play('slide');p.slideT=.55;p.slideHit=false;p.tackleCd=1.3;
   const l=hyp(ax,az)||1;p.vx=ax/l*9.5;p.vz=az/l*9.5;p.face=Math.atan2(az,ax);Au.play('pass');
  }
 }
 if(c.charging){
  if(!canKick&&!has){c.charging=false;}
  else if(held.X){c.charge=Math.min(1,c.charge+dt*(1-SHOT_MIN)/.8);}   // ≈0,8 s da força mínima até 100%
  else{
   const gk=G.teamP[1-tm][0],gx=HL*dir;
   const ang=abs(angd(Math.atan2(az,ax),Math.atan2(-p.z,gx-p.x)));
   if(ang>1.4&&mag>.25)shoot(p,.6,0,false,true);
   else{
    shoot(p,Math.max(SHOT_MIN,c.charge),shotAimZ(p,mag>.3,ax,az,dir,gk,cf),false,false);
   }
   c.charging=false;
  }
 }
 if(I.pd('RB')&&has&&p.skillCd<=0&&p.slideT<=0)dash(p,ax,az,5.2); // respeita a recarga: sem dash infinito
 if(I.pd('R3')){
  if(has&&p.skillCd<=0){dash(p,-az,ax,4.4);}
  else if(!has){G.press[tm]=G.t+4;cmsg(c,'PRESSÃO DO TIME',1);}
 }
 if(I.pd('L3')&&G.train&&G.train.type==='foul'&&c.local){c.charging=false;trainPlace();msg('NOVA COBRANÇA',1);}
 else if(I.pd('L3')){c.autoSprint=!c.autoSprint;cmsg(c,c.autoSprint?'CORRIDA AUTOMÁTICA: LIGADA':'CORRIDA AUTOMÁTICA: DESLIGADA',1.2);}
 if(I.pd('LB'))switchPlayer(p,c);
}

/* ---------------- IA ---------------- */
function aiWithBall(p,dt,spdF){
 const b=G.ball,dir=p.team?-1:1,gx=HL*dir;
 p.holdT+=dt;p.aiT-=dt;
 if(G.restart&&G.restart.taker===p){
  p.vx*=.9;p.vz*=.9;if(p.aiT<=0)restartAct(p);return;
 }
 const dg=hyp(gx-p.x,0); // distância ao gol no eixo X
 let no=null,nd=1e9;for(const o of G.teamP[1-p.team]){const d=dist2(p.x,p.z,o.x,o.z);if(d<nd){nd=d;no=o;}}
 const nr=Math.sqrt(nd);
 // dribla afastando do marcador mais próximo
 let tz=p.z*.55;
 if(no&&nr<7){
  const side=((p.z-no.z)>=0?1:-1);
  tz=p.z+side*(6+rnd()*4);
  // se muito pressionado, corta para dentro ou fora
  if(nr<3.2)tz=p.z+side*9;
 }
 // avança em direção ao gol com leve variação
 const targetX=gx-dir*(p.role==='ST'?4:8);
 steer(p,targetX,clamp(tz,-HW+2,HW-2),.95,nr>5.5||dg>30,dt,spdF);
 if(p.aiT<=0){
  p.aiT=.22+rnd()*.28-S.diff*.025;
  const ang=abs(angd(p.face,Math.atan2(-p.z,gx-p.x)));
  // finalização mais inteligente: só chuta com ângulo e espaço
  if(p.role!=='GK'&&dg<28&&ang<1.05&&(dg<15||(dg<22&&nr>3.5)||rnd()<.38)){aiShoot(p);return;}
  // passa sob pressão, se goleiro, ou se segura demais
  if(p.role==='GK'||(nr<3.5&&rnd()<.8)||p.holdT>2.6+rnd()|| (nr<5&&rnd()<.35)){aiPass(p,p.role==='GK');return;}
  // arrancada ocasional se espaço à frente
  if(p.skillCd<=0&&nr>6&&dg>20&&rnd()<.18){dash(p,cos(p.face),sin(p.face),4.8);p.aiT=.5;}
 }
}
function gkAI(p,dt){
 const b=G.ball,dir=p.team?-1:1,own=-HL*dir,sk=vsAI(p.team)?GKS[S.diff]:.72;
 if(b.owner===p){
  p.vx*=.82;p.vz*=.82;p.holdT+=dt;
  if(G.restart&&G.restart.taker===p){p.aiT-=dt;if(p.aiT<=0)restartAct(p);return;}
  // segura um pouco e distribui com mais critério
  if(p.holdT>0.9+rnd()*.6)aiPass(p,true);return;
 }
 if(p.diveT>0){p.vx*=.97;p.vz*=.97;return;}
 const bd=(b.x-own)*dir,bsp=hyp(b.vx,b.vz);
 let tx,tz,f=1,sp=false;
 const rush=G.rush[p.team]>G.t&&bd<22;
 const loose=!b.owner&&bd<16&&abs(b.z)<20&&bsp<9&&b.y<2.2;
 if(rush||loose){tx=b.x;tz=b.z;sp=true;f=1.15;}
 else{
  // posicionamento: acompanha a bola no eixo Z e ajusta profundidade
  const depth=clamp(bd*.08,.6,5.2);
  tx=own+dir*depth;
  // fica centralizado no gol (cobre o ângulo), com leve balanço para nunca ficar parado
  tz=clamp(b.z*.3,-GW*.5,GW*.5)+Math.sin(G.t*2.3+p.team*1.7)*.7;
  // antecipa chute / cruzamento
  if(!b.owner&&b.vx*dir<-2.5){
   const gl=own+dir*.4,t=(gl-b.x)/Math.max(abs(b.vx),.01)*(b.vx<0===dir<0?1:-1);
   // tempo até cruzar a linha do gol
   const tArrive=b.vx!==0?(gl-b.x)/b.vx:99;
   if(tArrive>0&&tArrive<1.8){
    const zp=b.z+b.vz*tArrive,yp=b.y+b.vy*tArrive-4.9*tArrive*tArrive;
    if(abs(zp)<GW+2&&yp<GH+.8&&yp>-.2){
     tz=clamp(zp,-GW-.3,GW+.3);tx=own+dir*.5;sp=true;f=1.7;
     // mergulho se necessário
     if(tArrive<.8&&p.diveT<=0&&abs(zp-p.z)>.5){
      p.diveT=.65+sk*.12;p.dvz=Math.sign(zp-p.z)||(rnd()>.5?1:-1);
      p.vz=clamp((zp-p.z)/Math.max(tArrive,.12),-(7.5+5.5*sk),7.5+5.5*sk);
      p.vx*=.3;p.face=Math.atan2(p.dvz,dir*0.2);return;
     }
    }
   }
  }
  // bola alta na área: sobe para interceptar
  if(!b.owner&&bd<12&&b.y>1.4&&bsp<12&&abs(b.z-p.z)<6){
   tx=b.x;tz=b.z;sp=true;f=1.2;
   if(hyp(b.x-p.x,b.z-p.z)<2.8&&b.y<2.6)p.jumpT=.5;
  }
 }
 // não sai demais da pequena área
 tx=clamp(tx,own-dir*0.2,own+dir*8);
 tz=clamp(tz,-GW-2.5,GW+2.5);
 steer(p,tx,tz,f,sp,dt,(1.15+sk*.4));
}
function aiPlayer(p,dt){
 const b=G.ball,dir=p.team?-1:1,own=-HL*dir,spdF=vsAI(p.team)?(OPP[S.diff]*(G.career&&G.careerOppStr?G.careerOppStr:1)):.97;
 if(p.role==='GK'){gkAI(p,dt);return;}
 if(p.wallSpot){ // barreira: fica no ponto marcado olhando a bola
  const s=p.wallSpot;if(dist2(p.x,p.z,s[0],s[1])>.09)steer(p,s[0],s[1],.9,dist2(p.x,p.z,s[0],s[1])>9,dt,1.45);else{approach(p,0,0,14*dt);p.face=Math.atan2(b.z-p.z,b.x-p.x);}
  if(!G.restart&&!p.jumped){p.jumped=true;if(rnd()<.8)p.jumpT=.55;}
  return;
 }
 if(G.sp&&G.sp.phase!=='flight'&&!b.owner){const h=homePos(p);steer(p,h.x,h.z,.8,false,dt,spdF);return;} // bola parada esperando o cobrador: ninguém corre pra ela
 if(b.owner===p){aiWithBall(p,dt,spdF);return;}
 if(!b.owner){const ps=livePass();if(ps){ // passe a caminho: o receptor corre ao encontro da bola e os adversários podem cortá-la
  if(p===ps.tgt){if(passReceive(p,ps,dt,spdF))return;}
  else if(p.team!==ps.team&&passIntercept(p,ps,dt,spdF))return;}}
 const owner=b.owner;let tx,tz,f=.9,sp=false;
 if(owner&&owner.team!==p.team){ // defendendo
  const pressOn=G.press[p.team]>G.t;
  if(p.rank===0||(pressOn&&p.rank===1)){
   // antecipa a trajetória do portador
   tx=owner.x+owner.vx*.32;tz=owner.z+owner.vz*.32;sp=true;f=1.05;
   const d=dist2(p.x,p.z,owner.x,owner.z);
   if(d<2.2&&p.tackleCd<=0&&p.stun<=0&&p.slideT<=0&&G.restartT<=0){
    p.tackleCd=.75+rnd()*.45;
    // carrinho só quando o adversário está rápido e há ângulo
    if(d<6&&owner.speed>5.5&&rnd()<.16){
     p.slideT=.52;p.slideHit=false;
     const a=Math.atan2(owner.z-p.z,owner.x-p.x);p.vx=cos(a)*9.2;p.vz=sin(a)*9.2;p.face=a;
    }else tackleAttempt(p,owner,0);
   }
  }else if(p.rank===1){
   const h=homePos(p);
   // Segundo defensor protege o corredor entre portador e gol, pronto para interceptar.
   tx=owner.x+(own-owner.x)*.24;tz=owner.z*.62+h.z*.38;
   f=.95;sp=dist2(p.x,p.z,tx,tz)>64;
  }else{
   const h=homePos(p),opp=G.teamP[1-p.team][p.i];
   // Linha defensiva acompanha os atacantes sem abandonar totalmente a formação.
   tx=opp.x*.42+h.x*.58+(own-opp.x)*.06;
   tz=opp.z*.38+h.z*.62;
   if(p.role==='CB')tx=clamp(tx,Math.min(owner.x,own)-8,Math.max(owner.x,own)+8);
   f=.85;sp=dist2(p.x,p.z,tx,tz)>100;
  }
 }else if(!owner){ // bola solta
  if(p.rank<=1){const k=clamp(hyp(b.x-p.x,b.z-p.z)/7,0,1.2);tx=b.x+b.vx*k;tz=b.z+b.vz*k;sp=true;f=1;}
  else{const h=homePos(p);tx=h.x;tz=h.z;}
 }else{ // posse: criar linhas de passe, largura e corridas em profundidade
  const h=homePos(p);tx=h.x;tz=h.z;
  const toGoal=(HL*dir-owner.x*dir),nearBall=hyp(owner.x-p.x,owner.z-p.z);
  if(p.att>.72){
   // Atacantes atacam espaço atrás da defesa; variam a corrida para não ficarem alinhados.
   tx+=dir*(5+7*p.att+3*sin(G.t*.85+p.i*1.7));
   tz+=clamp((owner.z-p.z)*.22,-4,4)+sin(G.t*.7+p.i)*1.8;
  }else if(p.att>.35){
   // Meias oferecem apoio diagonal; laterais mantêm largura.
   tx+=dir*(2+3*sin(G.t*.55+p.i));
   if(!['LM','RM','LB','RB'].includes(p.role))tz+=Math.sign(p.z-owner.z||1)*3.2;
  }
  if(nearBall<10&&p.att<.8){tx-=dir*2.5;tz+=Math.sign(p.z-owner.z||1)*2.5;}
  // Evita ultrapassar a linha defensiva e mantém os jogadores dentro do campo.
  const lim=Math.max(G.off[p.team]*dir,b.x*dir)-.6;if(tx*dir>lim)tx=lim*dir;
  f=.9;sp=dist2(p.x,p.z,tx,tz)>64;
 }
 tx=clamp(tx,-HL-.5,HL+.5);tz=clamp(tz,-HW-.5,HW+.5);
 steer(p,tx,tz,f,sp,dt,spdF);
}
function computeRanks(){
 const b=G.ball,o=b.owner,rx=o?o.x:b.x,rz=o?o.z:b.z;
 for(let t=0;t<2;t++){
  const arr=G.rk[t];arr.length=0;
  for(const p of G.teamP[t]){p.rank=9;if(p.role==='GK'||p.out||ctlOf(p))continue;p.d2b=dist2(p.x,p.z,rx,rz);arr.push(p);}
  arr.sort(cmpD);for(let i=0;i<arr.length;i++)arr[i].rank=i;
 }
 for(let t=0;t<2;t++){
  const dir=t?-1:1;let m1=-1e9,m2=-1e9;
  for(const o of G.teamP[1-t]){const v=o.x*dir;if(v>m1){m2=m1;m1=v;}else if(v>m2)m2=v;}
  G.off[t]=m2*dir;
 }
}
function cmpD(a,b){return a.d2b-b.d2b;}
function autoSwitch(dt){
 for(const c of CTL){
  if(!c.active||!c.user||!(c.cfg||S).autoSwitch)continue;
  c.swT-=dt;if(c.swT>0)continue;c.swT=.35;
  const b=G.ball,u=c.user;if(b.owner&&b.owner.team===c.team)continue;
  {const lp=livePass();if(lp&&lp.tgt===u)continue;} // passe a caminho: fica com o receptor
  let best=null,bd=1e9;
  for(const p of G.teamP[c.team]){if(p.role==='GK'||p.out)continue;const d=dist2(p.x,p.z,b.x,b.z);if(d<bd){bd=d;best=p;}}
  if(best&&best!==u&&bd<dist2(u.x,u.z,b.x,b.z)-30)c.user=best;
 }
}

/* ---------------- Atualização dos jogadores ---------------- */
function updatePlayer(p,dt){
 if(p.out)return;
 p.ctrlCd=Math.max(0,p.ctrlCd-dt);p.kickT=Math.max(0,p.kickT-dt);p.stun=Math.max(0,p.stun-dt);p.tackleCd=Math.max(0,p.tackleCd-dt);
 p.immune=Math.max(0,p.immune-dt);p.celeb=Math.max(0,p.celeb-dt);p.jumpT=Math.max(0,p.jumpT-dt);p.skillCd=Math.max(0,p.skillCd-dt);
 p.diveT=Math.max(0,p.diveT-dt);p.stumbleT=Math.max(0,p.stumbleT-dt);p.dustT-=dt;
 const b=G.ball,pc=ctlOf(p);
 if(p.slideT>0){
  if(p.dustT<=0){p.dustT=.045;fxBurst(p.x-cos(p.face)*.4,p.z-sin(p.face)*.4,2);fxPuff(p.x,p.z,1,.9);}
  p.slideT-=dt;p.vx*=Math.exp(-2.2*dt);p.vz*=Math.exp(-2.2*dt);
  if(!p.slideHit&&b.owner&&b.owner.team!==p.team&&dist2(p.x,p.z,b.owner.x,b.owner.z)<1.3){p.slideHit=true;tackleAttempt(p,b.owner,1);}
  else if(!p.slideHit&&!b.owner&&dist2(p.x,p.z,b.x,b.z)<1.2&&b.y<.8){p.slideHit=true;const a=p.face;b.vx=cos(a)*6;b.vz=sin(a)*6;G.lastTouch=p;b.gkRolled=true;Au.play('tackle');}
  if(p.slideT<=0)p.stun=.45;
 }else if(G.state==='play'){
  if(G.train&&G.train.wait>0){approach(p,0,0,14*dt);p.sprint=false;} // entre tentativas o treino vai reposicionar tudo: ninguém corre/chuta nesse intervalo (antes dava "teleporte" no meio da jogada)
  else if(pc)ctrlPlayer(p,dt,pc);
  else if(G.train&&p.role!=='GK')trainAI(p,dt);
  else aiPlayer(p,dt);
 }else{ // gol / intervalo: parar (no gol, o time comemora)
  if(G.state==='goal'&&!G.train)celebMove(p,dt);else approach(p,0,0,14*dt);
 }
 if(p.dustT<=0){ // poeira da corrida, rastro da arrancada e deslize da comemoração
  if(G.state==='play'&&p.skillCd>DASH_CD-.3){p.dustT=.04;fxGhost(p);}
  else if(G.state==='play'&&p.speed>6.3&&p.sprint){p.dustT=.14;fxPuff(p.x-cos(p.face)*.3,p.z-sin(p.face)*.3,1,.35);}
  else if(p.celeb>0&&p.celebType===1&&p.speed>2.2){p.dustT=.05;fxBurst(p.x,p.z,2);}
 }
 p.x=clamp(p.x+p.vx*dt,-PLX,PLX);p.z=clamp(p.z+p.vz*dt,-PLZ,PLZ);
 if(p.x*p.x>=PLX*PLX||p.z*p.z>=PLZ*PLZ){if(abs(p.x)>=PLX)p.vx=0;if(abs(p.z)>=PLZ)p.vz=0;}
 p.speed=hyp(p.vx,p.vz);
 if(p.diveT>0){p.face=p.face;}
 else if(p.slideT>0){/* mantém direção */}
 else if(p.role==='GK'&&b.owner===p){
  // goleiro com a bola nas mãos: orientação fixa (sem giro automático). Em reposição mantém a face definida; senão, voltado ao campo.
  if(!(G.restart&&G.restart.taker===p))p.face=p.team?PI:0;
 }
 else if(p.speed>.7){
  const tr=((pc?9+(pc.cfg||S).aMove/25:8)*(1+clamp(1-p.speed/6,0,1)*.9)+(b.owner===p?5:0))*dt;p.face+=clamp(angd(p.face,Math.atan2(p.vz,p.vx)),-tr,tr);
 }else{
  const tr=4*dt,tgx=(b.owner||b).x,tgz=(b.owner||b).z;p.face+=clamp(angd(p.face,Math.atan2(tgz-p.z,tgx-p.x)),-tr,tr);
 }
 p.phase+=p.speed*1.45*dt;
 if(p.speed>2){ // taxa de giro da trajetória: curva fechada em sprint com a bola = toque pesado
  const hd=Math.atan2(p.vz,p.vx);
  if(b.owner===p&&p.speed>6.2&&G.state==='play'&&p.hdPrev!==undefined&&!G.train){
   const dh=abs(angd(p.hdPrev,hd))/Math.max(dt,.001);
   if(dh>4.4&&!p.shield&&rnd()<dt*(dh-4.4)*(p.speed-5.5)*.22*(pc?1:.6)){
    const ux=p.vx,uz=p.vz;b.owner=null;b.vx=ux*1.05-uz*.12;b.vz=uz*1.05+ux*.12;b.vy=.5;p.ctrlCd=.22;G.lastTouch=p;b.gkRolled=true;
   }
  }
  p.hdPrev=hd;
 }else p.hdPrev=undefined;
}
/* Comemoração: artilheiro corre para a bandeira (3 estilos), time vai abraçar, adversários ficam cabisbaixos */
function celebMove(p,dt){
 const gt=G.goalTeam,sc=G.lastTouch&&G.lastTouch.team===gt?G.lastTouch:null;
 if(p.team!==gt||!sc||p.role==='GK'){approach(p,0,0,12*dt);return;}
 if(p===sc){
  const el=3.4-p.celeb; // tempo desde o gol
  if(p.celebType>0&&el<1.7)steer(p,(gt?-1:1)*(HL-3.5),(p.z>=0?1:-1)*(HW-4),1,true,dt,1);
  else approach(p,0,0,12*dt);
  return;
 }
 const d=hyp(sc.x-p.x,sc.z-p.z);
 if(d>3.2)steer(p,sc.x,sc.z,1,true,dt,1);
 else{approach(p,0,0,14*dt);p.celeb=Math.max(p.celeb,.5);}
}
function separation(dt){
 const P=G.players;
 for(let i=0;i<22;i++){const a=P[i];if(a.out)continue;
  for(let j=i+1;j<22;j++){const c=P[j];if(c.out)continue;
   const dx=c.x-a.x,dz=c.z-a.z,d2=dx*dx+dz*dz;
   if(d2<.64&&d2>1e-6){const d=Math.sqrt(d2),k=(.8-d)*.5/d;a.x-=dx*k;a.z-=dz*k;c.x+=dx*k;c.z+=dz*k;}
  }
 }
 if(G.clearR>0&&G.restart){
  const tk=G.restart.taker,b=G.ball;
  for(const p of P){
   if(p===tk||p.out)continue;
   if(p.team===tk.team&&G.restart.kind!=='pen'&&G.restart.kind!=='kick')continue;
   if(p.role==='GK'&&(G.restart.kind==='pen'||G.restart.kind==='goalkick'))continue;
   const dx=p.x-b.x,dz=p.z-b.z,d=hyp(dx,dz);
   if(d<G.clearR&&d>.01){const k=(G.clearR-d)*Math.min(1,6*dt)/d;p.x+=dx*k;p.z+=dz*k;}
  }
 }
 for(const p of P){ // jogadores não atravessam as traves
  if(p.out)continue;
  for(const s of [-1,1])for(const z of [-GW,GW]){
   const dx=p.x-s*HL,dz=p.z-z,d2=dx*dx+dz*dz,R=BODY+PR;
   if(d2<R*R&&d2>1e-6){const d=Math.sqrt(d2),k=(R-d)/d;p.x+=dx*k;p.z+=dz*k;}
  }
 }
 for(const p of P){p.x=clamp(p.x,-PLX,PLX);p.z=clamp(p.z,-PLZ,PLZ);} // empurrões também respeitam o limite do campo
}

/* ---------------- Passo da simulação ---------------- */
function simStep(dt){
 G.t+=dt;
 const st=G.state;
 stepFX(dt);
 if(G.pen){penStep(dt);return;}
 if(st==='play'){
  G.clock+=dt;
  if(G.restart){G.restart.t+=dt;
   const tk=G.restart.taker;
   if(ctlOf(tk)&&!G.sp&&G.restart.t>7&&G.ball.owner===tk){const t=bestTarget(tk,cos(tk.face),sin(tk.face),0,.7,true);passTo(tk,t,cos(tk.face),sin(tk.face),0,.7,true);}
  }
  G.restartT=Math.max(0,G.restartT-dt);
  if(G.wall&&!G.restart){if(G.wallHold>50)G.wallHold=1.3;G.wallHold-=dt;if(G.wallHold<=0)spClearWall();}
  if(G.sp)spStep(dt);
  computeRanks();autoSwitch(dt);
  for(const p of G.players)updatePlayer(p,dt);
  separation(dt);stepBallSub(dt);checkPickup();gkSaves();checkBounds();
  if(G.train&&G.state==='play')trainUpdate(dt);
  if(G.ball.owner)G.stats[G.ball.owner.team].poss+=dt;
  if(G.state==='play'&&!G.train&&G.clock>=halfLen())endHalf();
 }else{
  for(const p of G.players)updatePlayer(p,dt);
  separation(dt);stepBall(dt);
  G.stateT-=dt;
  if(G.stateT<=0){
   if(st==='goal'){if(G.train){G.state='play';trainNext();}else kickoff(1-G.goalTeam);}
   else if(st==='half'){G.half=2;G.clock=0;kickoff(1);msg('2º TEMPO',2);}
   else if(st==='end'){/* mantém */}
  }
 }
 if(((G.t*2)|0)!==(((G.t-dt)*2)|0)){ // ambiente da torcida
  const b=G.ball,dn=(1-abs(b.x)/HL);Au.crowd(.045+.05*(1-dn)+(G.state==='goal'?.2:0));
 }
}
function endHalf(){
 Au.play('whistleEnd');
 if(G.half===1){G.state='half';G.stateT=3;msg('INTERVALO',2.8);G.charging=false;}
 else{
  G.state='end';G.stateT=9e9;
  if(G.career){
   msg('FIM DE JOGO',3);
   setTimeout(finishCareerMatch,2600);
  }else{
   achAdd('amistoso','matches',1);if(G.score[0]>G.score[1])achAdd('amistoso','wins',1);achAdd('amistoso','possession',Math.round(G.stats[0].poss));
   msg('FIM DE JOGO',3);setTimeout(()=>Au.play(G.score[0]>G.score[1]?'win':(G.score[0]<G.score[1]?'lose':'confirm')),1600);setTimeout(showResult,2600);
  }
 }
}

/* ---------------- Conquistas (sem recompensas) ---------------- */
const ACH_KEY='fc3d_achievements_v1';
const ACH_MODES={
 amistoso:{title:'AMISTOSO',items:[['Primeiro apito','Jogue 1 partida','matches',1],['Rotina de jogo','Jogue 3 partidas','matches',3],['Veterano','Jogue 10 partidas','matches',10],['Primeira vitória','Vença 1 partida','wins',1],['Três vitórias','Vença 3 partidas','wins',3],['Invicto','Vença 5 partidas','wins',5],['Artilheiro','Marque 3 gols','goals',3],['Chuteira afiada','Finalize 10 vezes','shots',10],['Bom companheiro','Faça 20 passes','passes',20],['Domínio de bola','Acumule 5 minutos de posse','possession',300]]},
 chute:{title:'TREINO DE CHUTE',items:[['Primeiro disparo','Tente 1 chute','attempts',1],['Aquecimento','Tente 5 chutes','attempts',5],['Metralhadora','Tente 10 chutes','attempts',10],['Na mira','Marque 1 gol','goals',1],['Abrindo o placar','Marque 3 gols','goals',3],['Artilheiro do treino','Marque 5 gols','goals',5],['Precisão','Marque 7 gols','goals',7],['Canhão','Marque 10 gols','goals',10],['Persistência','Tente 15 chutes','attempts',15],['Especialista','Tente 20 chutes','attempts',20]]},
 passe:{title:'TREINO DE PASSE',items:[['Passe inicial','Complete 1 passe','passes',1],['Troca de bola','Complete 5 passes','passes',5],['Conexão','Complete 10 passes','passes',10],['Ritmo','Complete 20 passes','passes',20],['Maestro','Complete 30 passes','passes',30],['Sequência 3','Faça sequência de 3','streak',3],['Sequência 5','Faça sequência de 5','streak',5],['Sequência 8','Faça sequência de 8','streak',8],['Sequência 10','Faça sequência de 10','streak',10],['Passe total','Complete 50 passes','passes',50]]},
 posse:{title:'CONTROLE DE POSSE',items:[['Primeiros segundos','Segure a bola por 5 s','best',5],['Controle','Segure por 10 s','best',10],['Calma','Segure por 15 s','best',15],['Persistente','Segure por 20 s','best',20],['Dono da bola','Segure por 30 s','best',30],['Resistência','Segure por 45 s','best',45],['Domínio','Segure por 60 s','best',60],['Muralha','Segure por 75 s','best',75],['Imparável','Segure por 90 s','best',90],['Lenda da posse','Segure por 120 s','best',120]]}
};
let ACH={};
try{ACH=JSON.parse(localStorage.getItem(ACH_KEY)||'{}')||{};}catch(e){ACH={};}
function achData(mode){if(!ACH[mode])ACH[mode]={};return ACH[mode];}
function achAdd(mode,key,n=1){if(Net.mp)return;const d=achData(mode);d[key]=(d[key]||0)+n;checkAchievements(mode);try{localStorage.setItem(ACH_KEY,JSON.stringify(ACH));}catch(e){}}
function achMax(mode,key,n){if(Net.mp)return;const d=achData(mode);d[key]=Math.max(d[key]||0,n);checkAchievements(mode);try{localStorage.setItem(ACH_KEY,JSON.stringify(ACH));}catch(e){}}
function checkAchievements(mode){const d=achData(mode);let changed=false;for(const [name,desc,key,target] of ACH_MODES[mode].items){if((d[key]||0)>=target&&!d['unlocked:'+name]){d['unlocked:'+name]=Date.now();changed=true;Au.play('ach');}}
 if(changed){try{localStorage.setItem(ACH_KEY,JSON.stringify(ACH));}catch(e){} }
}
function achievementCount(){let n=0;Object.keys(ACH_MODES).forEach(m=>ACH_MODES[m].items.forEach(a=>{if(achData(m)['unlocked:'+a[0]])n++;}));return n;}

/* ===================== SELETOR DE CLUBES: PAÍS → CAMPEONATO → CLUBE =====================
   Usado por Carreira, Amistoso, Pênaltis e Editor. Inclui pesquisa por nome/sigla.
   ======================================================================================== */
function escH(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
const CP={step:1,country:null,league:null,opts:null,q:''};
function openClubPicker(opts){
 CP.opts=opts;CP.step=1;CP.country=null;CP.league=null;CP.q='';
 $('#cp-search').value='';$('#cp-title').textContent=opts.title||'ESCOLHA O CLUBE';
 const cur=opts.current&&fcClub(opts.current);
 if(cur){CP.country=cur.country;CP.league=cur.league0;CP.step=3;}
 cpRender();show('club-pick');
}
function cpBars(c){
 const bar=(l,v)=>`<div class="cp-bar"><span>${l}</span><i><u style="width:${Math.max(4,(v-30)/70*100)}%"></u></i><b>${v}</b></div>`;
 return bar('GERAL',c.ovr)+bar('ATAQUE',c.att)+bar('MEIO',c.mid)+bar('DEFESA',c.def);
}
function cpClubRow(c,showLeague){
 const L=FC_LEAGUES[c.league0],C=fcCountry(c.country);
 return`<button class="cp-club" data-id="${c.id}"><span class="cp-cr">${fcCrest(c,36)}</span>
  <span class="cp-nm"><b>${escH(c.name)}</b><small>${showLeague?C.flag+' '+escH(L.name):escH(c.official)}</small></span>
  <span class="cp-ab">${c.abbr}</span><span class="cp-mini"><em>ATA ${c.att}</em><em>MEI ${c.mid}</em><em>DEF ${c.def}</em></span><span class="cp-ov">${c.ovr}</span></button>`;
}
function cpRender(){
 const body=$('#cp-body'),crumb=$('#cp-crumb'),q=CP.q.trim();
 $('#cp-prev').classList.remove('show');
 let h='',cr='';
 if(q){
  const list=fcSearch(q).sort((a,b)=>b.ovr-a.ovr);
  cr='<span class="on">PESQUISA</span>';
  h=list.length?list.map(c=>cpClubRow(c,true)).join(''):'<div class="cp-empty">Nenhum clube encontrado.</div>';
 }else if(CP.step===1){
  cr='<span class="on">ESCOLHA O PAÍS</span>';
  h='<div class="cp-grid">'+FC_COUNTRIES.map(C=>{const n=C.leagues.reduce((s,l)=>s+FC_LEAGUES[l.id].clubs.length,0);
   return`<button class="cp-card" data-c="${C.id}"><em>${C.flag}</em><b>${C.name}</b><small>${C.leagues.map(l=>l.name).join(' · ')}</small><small>${n} clubes</small></button>`;}).join('')+'</div>';
 }else if(CP.step===2){
  const C=fcCountry(CP.country);
  cr=`<button data-s="1">PAÍSES</button> › <span class="on">${C.flag} ${C.name}</span>`;
  h='<div class="cp-grid cp-lg">'+C.leagues.map(l=>`<button class="cp-card" data-l="${l.id}"><em>${l.tier===1?'🏆':'⚽'}</em><b>${l.name}</b><small>${C.name} · ${l.tier}ª divisão</small><small>${FC_LEAGUES[l.id].clubs.length} clubes</small></button>`).join('')+'</div>';
 }else{
  const C=fcCountry(CP.country),L=FC_LEAGUES[CP.league];
  cr=`<button data-s="1">PAÍSES</button> › <button data-s="2">${C.flag} ${C.name}</button> › <span class="on">${L.name}</span>`;
  h=L.clubs.map(fcClub).sort((a,b)=>b.ovr-a.ovr).map(c=>cpClubRow(c,false)).join('');
 }
 crumb.innerHTML=cr;body.innerHTML=h;body.scrollTop=0;
 crumb.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{CP.step=+b.dataset.s;cpRender();});
 body.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{Au.play('ui');CP.country=b.dataset.c;CP.step=2;cpRender();});
 body.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{Au.play('ui');CP.league=b.dataset.l;CP.step=3;cpRender();});
 body.querySelectorAll('[data-id]').forEach(b=>b.onclick=()=>{Au.play('ui');cpPreview(b.dataset.id);});
}
function cpPreview(id){
 const c=fcClub(id),L=FC_LEAGUES[c.league0],C=fcCountry(c.country),o=CP.opts||{};
 const kit=(k,l)=>`<div class="cp-kit">${fcKitSVG(k,44)}<small>${l}</small></div>`;
 $('#cp-prev').innerHTML=`<div class="cp-pcard">
  <div class="cp-ptop">${fcCrest(c,84)}<div><h3>${escH(c.name)}</h3><div class="cp-off">${escH(c.official)}</div><div class="cp-lg">${C.flag} ${C.name} · ${L.name} · <b>${c.abbr}</b></div></div></div>
  <div class="cp-pmid"><div class="cp-bars">${cpBars(c)}</div><div class="cp-kits">${kit(c.kits.home,'PRINCIPAL')}${kit(c.kits.away,'RESERVA')}</div></div>
  ${o.career?`<label class="cp-fmt">Formato da temporada <select id="cp-format"><option value="double">Completa (ida e volta)</option><option value="single">Turno único (mais rápida)</option></select></label>`:''}
  <div class="cp-pbtn"><button class="btn" id="cp-ok">${o.career?'INICIAR CARREIRA':'ESCOLHER ESTE CLUBE'}</button><button class="btn sec2" id="cp-no">Cancelar</button></div></div>`;
 $('#cp-prev').classList.add('show');
 $('#cp-no').onclick=()=>{Au.play('back');$('#cp-prev').classList.remove('show');};
 $('#cp-ok').onclick=()=>{Au.play('confirm');const f=$('#cp-format');const fn=o.onPick;const from=o.from||'title';show(from);if(fn)fn(id,{format:f?f.value:'double'});};
}
$('#cp-search').oninput=e=>{CP.q=e.target.value;cpRender();};
$('#cp-back').onclick=()=>{
 Au.play('back');
 if(CP.q.trim()){CP.q='';$('#cp-search').value='';cpRender();return;}
 if($('#cp-prev').classList.contains('show')){$('#cp-prev').classList.remove('show');return;}
 if(CP.step>1){CP.step--;cpRender();return;}
 show((CP.opts&&CP.opts.from)||'title');
};

/* ===================== AMISTOSO: escolha dos dois clubes ===================== */
function frRender(){
 applyClub();
 [0,1].forEach(t=>{
  const s=CLUB.teams[t],c=fcClub(s.id),L=FC_LEAGUES[c.league0],C=fcCountry(c.country);
  const k={shirt:KIT[t].sh,shorts:KIT[t].sh2,socks:KIT[t].so};
  const kl={auto:'AUTOMÁTICO',home:'PRINCIPAL',away:'RESERVA'}[s.kit];
  $('#fr-c'+t).innerHTML=`<div class="fr-tag">${t?'ADVERSÁRIO':'SEU TIME'}</div>${fcCrest(c,76)}<b class="fr-nm">${escH(c.name)}</b><small>${C.flag} ${escH(L.name)}</small>
   <div class="fr-ovr">GERAL <b>${c.ovr}</b> · ATA ${c.att} · MEI ${c.mid} · DEF ${c.def}</div>
   <div class="fr-kit">${fcKitSVG(k,40)}<button class="btn sec2 mp-mini" data-kit="${t}">UNIFORME: ${kl}</button></div>
   <button class="btn mp-mini" data-pick="${t}">TROCAR CLUBE</button>`;
 });
 document.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>{const t=+b.dataset.pick;Au.play('ui');
  openClubPicker({title:t?'ESCOLHA O ADVERSÁRIO':'ESCOLHA O SEU TIME',from:'friendly',current:CLUB.teams[t].id,onPick:id=>{CLUB.teams[t]={id,kit:'auto',ov:null};saveClub();frRender();}});});
 document.querySelectorAll('[data-kit]').forEach(b=>b.onclick=()=>{const t=+b.dataset.kit,s=CLUB.teams[t];Au.play('ui');s.kit=s.kit==='auto'?'home':s.kit==='home'?'away':'auto';saveClub();frRender();});
}
function openFriendly(){prevScreen='title';frRender();show('friendly');}

/* ===================== MODO CARREIRA — campeonatos, copas, continentais e mundial =====================
   O estado inteiro da carreira (CAR) é gerado e avançado por competitions.js (FCC):
   16 ligas de 8 países + 8 copas nacionais + Champions/Europa/Libertadores/Sul-Americana + Mundial.
   O save guarda apenas IDs permanentes de clubes.
   ================================================================================ */
const CAREER_KEY='fc3d_career_v4',CAREER_OLD='fc3d_career_v3';
let CAR=null,carTab='table',carViewL=null,carCty=null,carComp=null,carSub='main';
function carCreate(clubId,format){
 CAR=FCC.create(clubId,format);carViewL=CAR.myLeague;carTab='table';carCty=null;carComp=null;carSub='main';saveCareer();
}
/* carreira antiga (v3, só ligas): mantém clube, formato, temporada e histórico; reinicia a temporada atual com as novas competições */
function carMigrate(){
 try{
  const o=JSON.parse(localStorage.getItem(CAREER_OLD)||'null');
  if(!o||o.v!==3||!fcClub(o.clubId))return null;
  const W=FCC.create(o.clubId,o.format),C=fcCountry(fcClub(o.clubId).country);
  C.leagues.forEach(l=>{const m=o.members&&o.members[l.id];if(Array.isArray(m)&&m.length===FC_LEAGUES[l.id].clubs.length&&m.every(id=>fcClub(id)&&fcClub(id).country===C.id))W.members[l.id]=m.slice();});
  W.season=o.season||1;W.history=Array.isArray(o.history)?o.history.filter(h=>h&&FC_LEAGUES[h.lid]&&fcClub(h.champ)):[];
  FCC.startSeason(W);
  return W;
 }catch(e){return null;}
}
function loadCareer(){
 if(FCC.valid(CAR))return CAR;
 try{CAR=JSON.parse(localStorage.getItem(CAREER_KEY)||'null');}catch(e){CAR=null;}
 if(!FCC.valid(CAR)){CAR=carMigrate();if(CAR)saveCareer();}
 if(!FCC.valid(CAR))CAR=null;
 return CAR;
}
function saveCareer(){try{localStorage.setItem(CAREER_KEY,JSON.stringify(CAR));}catch(e){}}
function carCountry(){return fcCountry(fcClub(CAR.clubId).country);}
function carPickClub(){
 openClubPicker({title:'ESCOLHA O CLUBE DA SUA CARREIRA',from:FCC.valid(CAR)?'career':'title',career:true,onPick:(id,o)=>{carCreate(id,o.format);openCareer();}});
}
function openCareer(){
 if(!loadCareer()){carPickClub();return;}
 prevScreen='title';if(!CAR.leagues[carViewL])carViewL=CAR.myLeague;carRender();show('career');
}
function carResRow(r){
 const h=fcClub(r[0]),a=fcClub(r[1]),me=r[0]===CAR.clubId||r[1]===CAR.clubId;
 return`<div class="car-res${me?' me':''}"><span class="h">${escH(h.name)} ${fcCrest(h,16)}</span><b>${r[2]} - ${r[3]}</b><span class="a">${fcCrest(a,16)} ${escH(a.name)}</span></div>`;
}
function carScoreTxt(t){
 if(!t.w)return'×';
 let s=t.gh+' - '+t.ga;
 if(t.pen)s+=' <small>('+t.pen[0]+'-'+t.pen[1]+' pên.)</small>';else if(t.et)s+=' <small>(pror.)</small>';
 return s;
}
function carTieRow(t){
 const h=fcClub(t.h),a=fcClub(t.a),me=t.h===CAR.clubId||t.a===CAR.clubId;
 return`<div class="car-res${me?' me':''}${t.w?'':' fx'}"><span class="h${t.w===t.h?' win':''}">${escH(h.name)} ${fcCrest(h,16)}</span><b>${carScoreTxt(t)}</b><span class="a${t.w===t.a?' win':''}">${fcCrest(a,16)} ${escH(a.name)}</span></div>`;
}
/* zonas de vaga continental na tabela da 1ª divisão */
function carZones(cc){
 const q=FCC.QUOTA[cc];if(!q)return null;
 if(q.UCL!=null)return{top:q.UCL,sec:q.UEL-1,tn:'Champions League',sn:'Europa League (+ campeão da copa)'};
 return{top:q.LIB-1,sec:q.SUL,tn:'Libertadores (+ campeão da copa)',sn:'Sul-Americana'};
}
function carTableHTML(lid){
 const L=CAR.leagues[lid],Lg=FC_LEAGUES[lid],C=fcCountry(Lg.country),n=L.order.length,ids=FCL.sorted(L),pr=C.promo,z=carZones(C.id);
 let h=`<table class="car-table"><thead><tr><th class="pos">#</th><th>Clube</th><th class="c">J</th><th class="c">V</th><th class="c">E</th><th class="c">D</th><th class="c">GP</th><th class="c">GC</th><th class="c">SG</th><th class="pts">Pts</th></tr></thead><tbody>`;
 ids.forEach((id,i)=>{
  const t=L.table[id],c=fcClub(id),sg=t.gf-t.ga;let zc='';
  if(Lg.tier===1){if(i===0)zc='zone-gold';else if(z&&i<=z.top)zc='zone-top';else if(z&&i<=z.top+z.sec)zc='zone-sec';else if(i>=n-pr)zc='zone-bot';}
  else if(i<pr)zc=i===0?'zone-gold':'zone-up';
  h+=`<tr class="${id===CAR.clubId?'you':''} ${zc}"><td class="pos">${i+1}</td><td class="club">${fcCrest(c,18)}<span>${escH(c.name)}</span></td><td class="c">${t.p}</td><td class="c">${t.w}</td><td class="c">${t.d}</td><td class="c">${t.l}</td><td class="c">${t.gf}</td><td class="c">${t.ga}</td><td class="gd">${sg>0?'+':''}${sg}</td><td class="pts">${t.pts}</td></tr>`;
 });
 h+='</tbody></table><div class="car-legend">'+(Lg.tier===1?`<span class="lg-gold">Líder / campeão</span>${z?`<span class="lg-top">${z.tn}</span><span class="lg-sec">${z.sn}</span>`:''}<span class="lg-bot">Rebaixamento (${pr})</span>`:`<span class="lg-gold">Campeão</span><span class="lg-up">Acesso (${pr} primeiros)</span>`)+'</div>';
 return h;
}
function carScorerRows(list,empty){
 if(!list.length)return'<div class="cp-empty">'+empty+'</div>';
 return'<table class="car-table"><thead><tr><th class="pos">#</th><th>Jogador</th><th>Clube</th><th class="pts">Gols</th></tr></thead><tbody>'+
  list.map((s,i)=>{const c=fcClub(s.c);return`<tr class="${s.c===CAR.clubId?'you':''}"><td class="pos">${i+1}</td><td>${escH(s.n)}</td><td class="club">${fcCrest(c,16)}<span>${escH(c.name)}</span></td><td class="pts">${s.g}</td></tr>`;}).join('')+'</tbody></table>';
}
function carScorersHTML(lid){return carScorerRows(FCL.topScorers(CAR.leagues[lid],12),'Ainda não há gols nesta temporada.');}
/* Ícones das competições: aceita caminhos de imagem e mantém emojis antigos. */
function fcCompIcon(icon,size){
 const v=String(icon||'🏆');
 if(/^images\/[a-zA-Z0-9_./-]+\.(?:png|svg|webp)$/i.test(v))return `<img class="fc-comp-icon" src="${v}" alt="" width="${size||22}" height="${size||22}" style="width:${size||22}px;height:${size||22}px;object-fit:contain;vertical-align:middle" onerror="this.replaceWith(document.createTextNode('🏆'))">`;
 return escH(v);
}
/* próximos jogos do usuário (liga + competições em que ele ainda está vivo) */
function carUpcoming(){
 const out=[],alive={},seenKO={},me=CAR.clubId;
 FCC.userComps(CAR).forEach(c=>{if(c.st.k==='alive')alive[c.id]=1;});
 for(let i=CAR.pos;i<CAR.cal.length&&out.length<9;i++){
  const ev=CAR.cal[i];
  if(ev.t==='L'){
   const L=CAR.leagues[CAR.myLeague],p=FCL.fixtures(L)[ev.r].find(x=>x[0]===me||x[1]===me),home=p[0]===me;
   out.push({icon:'⚽',name:FC_LEAGUES[CAR.myLeague].name,lab:'Rodada '+(ev.r+1),home,opp:home?p[1]:p[0]});
  }else{
   const comp=CAR.comps[ev.c];if(!alive[ev.c])continue;
   const inf=FCC.info(ev.c);
   if(comp.kind==='groups'&&ev.p<comp.gsRounds){
    const L=comp.groups.find(g=>g.order.includes(me));if(!L)continue;
    const p=FCL.fixtures(L)[ev.p].find(x=>x[0]===me||x[1]===me),home=p[0]===me;
    out.push({icon:inf.icon,name:inf.short,lab:'Grupos · jogo '+(ev.p+1),home,opp:home?p[1]:p[0]});
   }else{
    if(seenKO[ev.c])continue;seenKO[ev.c]=1;
    const rd=comp.rounds[ev.p-comp.koBase],t=rd&&rd.ties.find(x=>!x.w&&(x.h===me||x.a===me));
    if(rd&&!t)continue; // fase já sorteada e o clube não joga (folga)
    out.push({icon:inf.icon,name:inf.short,lab:comp.phases[ev.p],home:t?t.h===me:null,opp:t?(t.h===me?t.a:t.h):null});
   }
  }
 }
 return out;
}
function carRoundHTML(){
 const L=CAR.leagues[CAR.myLeague];let h='';
 if(L.last)h+=`<div class="car-sec">RODADA ${L.lastRound+1} · RESULTADOS DA LIGA</div>`+L.last.map(carResRow).join('');
 h+='<div class="car-sec">SEU CALENDÁRIO</div>';
 const up=carUpcoming();
 up.forEach(u=>{
  const o=u.opp?fcClub(u.opp):null;
  h+=`<div class="car-res fx"><span class="h">${fcCompIcon(u.icon,20)} ${escH(u.name)} · ${escH(u.lab)}</span><b>${u.home===null?'—':u.home?'CASA':'FORA'}</b><span class="a">${o?fcCrest(o,16)+' '+escH(o.name):'<i>adversário a definir</i>'}</span></div>`;
 });
 if(!up.length)h+='<div class="cp-empty">Calendário concluído.</div>';
 return h;
}
function carHistHTML(){
 if(!CAR.history.length)return'<div class="cp-empty">Nenhuma temporada concluída ainda.</div>';
 return CAR.history.slice().reverse().map(x=>{
  const cs=(x.comps||[]).map(c=>{const i=FCC.info(c.id);return`<div class="car-res hist sub"><span class="h">${fcCompIcon(i.icon,20)} ${escH(i.short)}</span><b class="${c.k==='champ'?'gold':''}">${escH(c.res)}</b><span class="a">${c.champ?'🏆 '+fcCrest(fcClub(c.champ),16)+' '+escH(fcClub(c.champ).name):''}</span></div>`;}).join('');
  return`<div class="car-res hist"><span class="h">Temporada ${x.season} · ${escH(FC_LEAGUES[x.lid].name)}</span><b>${x.pos}º</b><span class="a">🏆 ${fcCrest(fcClub(x.champ),16)} ${escH(fcClub(x.champ).name)}</span></div>${cs}`;
 }).join('');
}
/* ---------- aba COMPETIÇÕES (todas as ligas, copas, continentais e o Mundial) ---------- */
function carCompKey(){ // normaliza seleção atual
 const C=fcCountry(carCty||fcClub(CAR.clubId).country);
 const ok=['L1','L2','CUP'].concat(['UCL','UEL','LIB','SUL','WC'].filter(k=>CAR.comps[k]));
 if(!carComp||ok.indexOf(carComp)<0)carComp='CUP';
 return{C,key:carComp};
}
function carMiniTable(L,adv,wild){
 const ids=FCL.sorted(L);
 return`<table class="car-table"><thead><tr><th class="pos">#</th><th>Clube</th><th class="c">J</th><th class="c">V</th><th class="c">E</th><th class="c">D</th><th class="c">SG</th><th class="pts">Pts</th></tr></thead><tbody>`+
 ids.map((id,i)=>{const t=L.table[id],c=fcClub(id),sg=t.gf-t.ga,z=i<adv?'zone-top':(i===adv&&wild?'zone-sec':'');
  return`<tr class="${id===CAR.clubId?'you':''} ${z}"><td class="pos">${i+1}</td><td class="club">${fcCrest(c,16)}<span>${escH(c.name)}</span></td><td class="c">${t.p}</td><td class="c">${t.w}</td><td class="c">${t.d}</td><td class="c">${t.l}</td><td class="gd">${sg>0?'+':''}${sg}</td><td class="pts">${t.pts}</td></tr>`;}).join('')+'</tbody></table>';
}
function carCompBody(id){
 const comp=CAR.comps[id],inf=FCC.info(id);
 let h=`<div class="car-ch"><span class="ci">${fcCompIcon(inf.icon,42)}</span><div><b>${escH(inf.name)}</b><small>Temporada ${CAR.season}</small></div></div>`;
 const st=FCC.status(comp,CAR.clubId);
 if(st)h+=`<div class="car-mystat k-${st.k}">Seu clube: ${escH(st.t)}</div>`;
 else if(id!=='WC')h+=`<div class="car-mystat">Seu clube não participa desta competição.</div>`;
 if(comp.champion){const c=fcClub(comp.champion);h+=`<div class="car-champ-line">🏆 Campeão: ${fcCrest(c,18)} <b>${escH(c.name)}</b></div>`;}
 if(carSub==='sc')return h+carScorerRows(FCC.topScorers(comp,15),'Ainda não há gols nesta competição.');
 if(id==='WC'&&!comp.teams.length)return h+'<div class="cp-empty">Os 8 classificados (campeões e finalistas da Champions League, Europa League, Libertadores e Sul-Americana) serão definidos depois das finais continentais, no fim da temporada.</div>';
 if(comp.kind==='cup')h+=`<div class="car-note">${comp.teams.length} clubes inscritos (1ª e 2ª divisões, sem times B). Sorteio livre a cada fase; os clubes mais fortes têm folga na fase preliminar.</div>`;
 for(let i=comp.rounds.length-1;i>=0;i--)h+=`<div class="car-sec">${escH(comp.rounds[i].name.toUpperCase())}</div>`+comp.rounds[i].ties.map(carTieRow).join('');
 if(comp.kind==='groups'){
  const cfg=FCC.CONT[id];
  h+=`<div class="car-sec">FASE DE GRUPOS</div>`+comp.groups.map((L,i)=>`<div class="car-grp"><b>GRUPO ${String.fromCharCode(65+i)}</b>${carMiniTable(L,cfg.adv,cfg.wild)}</div>`).join('');
  h+=`<div class="car-legend"><span class="lg-top">Classificado${cfg.wild?'':'s'} (${cfg.adv} por grupo)</span>${cfg.wild?`<span class="lg-sec">3º colocado: ${cfg.wild} melhores avançam</span>`:''}</div>`;
 }
 if(id==='WC'&&comp.teams.length)h+=`<div class="car-sec">CLASSIFICADOS</div><div class="car-wcl">`+comp.teams.map(t=>`<span>${fcCrest(fcClub(t),16)} ${escH(fcClub(t).abbr)}</span>`).join('')+'</div>';
 return h;
}
function carCompHTML(){
 const{C,key}=carCompKey();let h='';
 const sub=`<div class="car-sub"><button data-s="main" class="${carSub==='main'?'on':''}">${key==='L1'||key==='L2'?'TABELA':key==='CUP'||CAR.comps[key]?'JOGOS':'TABELA'}</button><button data-s="sc" class="${carSub==='sc'?'on':''}">ARTILHARIA</button></div>`;
 if(key==='L1'||key==='L2'){
  const lid=C.leagues[key==='L1'?0:1].id,last=CAR.honors[CAR.honors.length-1];
  h+=`<div class="car-ch"><span class="ci">${C.flag}</span><div><b>${escH(FC_LEAGUES[lid].name)}</b><small>${escH(C.name)} · Temporada ${CAR.season}</small></div></div>`;
  if(last&&last.leagues[lid]){const c=fcClub(last.leagues[lid]);h+=`<div class="car-champ-line">Campeão da temporada ${last.season}: ${fcCrest(c,18)} <b>${escH(c.name)}</b></div>`;}
  h+=sub+(carSub==='sc'?carScorersHTML(lid):carTableHTML(lid));
 }else{
  const id=key==='CUP'?'CUP-'+C.id:key,last=CAR.honors[CAR.honors.length-1];
  let prev='';
  if(last){const w=key==='CUP'?last.cups[C.id]:last.cont[key];if(w){const c=fcClub(w);prev=`<div class="car-champ-line">Campeão da temporada ${last.season}: ${fcCrest(c,18)} <b>${escH(c.name)}</b></div>`;}}
  h+=sub+prev+carCompBody(id);
 }
 return h;
}
function carRender(){
 const me=fcClub(CAR.clubId),L=CAR.leagues[CAR.myLeague],Lg=FC_LEAGUES[CAR.myLeague],C=carCountry(),tot=FCL.rounds(L);
 const pos=FCL.sorted(L).indexOf(CAR.clubId)+1,fin=FCC.finished(CAR);
 $('#car-season').innerHTML=`${C.flag} ${C.name} · ${Lg.name} · Temporada ${CAR.season}`+(fin?' · ENCERRADA':` · Rodada ${Math.min(L.round+1,tot)}/${tot}`);
 const box=$('#car-next'),uc=FCC.userComps(CAR);
 const chips=uc.length?'<div class="car-chips">'+uc.map(c=>`<span class="cchip k-${c.st.k}" title="${escH(c.name)}">${fcCompIcon(c.icon,18)} ${escH(c.short)} · ${escH(c.st.t)}</span>`).join('')+'</div>':'';
 if(fin){
  const champ=fcClub(L.champion),won=L.champion===CAR.clubId,up=Lg.tier===2&&pos<=C.promo,down=Lg.tier===1&&pos>L.order.length-C.promo;
  box.innerHTML=`<div class="car-vs">TEMPORADA ${CAR.season} ENCERRADA</div><div class="car-kits">${fcCrest(me,54)}</div>
   <div class="car-match">${won?'🏆 CAMPEÃO DA '+escH(Lg.name.toUpperCase())+'!':'Posição final: '+pos+'º lugar'}</div>
   <div class="car-champ-line">Campeão: ${escH(champ.name)} · ${L.table[L.champion].pts} pts</div>
   <div class="car-diff">${up?'⬆ Seu clube conquistou o ACESSO!':down?'⬇ Seu clube foi REBAIXADO.':''}</div>${chips}
   <button class="btn car-play-btn" id="b-car-play">NOVA TEMPORADA</button>`;
  $('#b-car-play').onclick=()=>carEndSeason();
 }else{
  const nx=FCC.pending(CAR),opp=fcClub(nx.opp),pk=fcPairKits({id:me.id,kit:nx.home?'home':'away'},{id:opp.id,kit:nx.home?'away':'home'});
  const st=Math.min(5,Math.max(1,Math.round((FCL.aiStrength(opp,me)-.7)*8)));
  const venue=nx.neu?'CAMPO NEUTRO':nx.home?'EM CASA':'FORA DE CASA';
  box.innerHTML=`${CAR.banner?`<div class="car-banner">${CAR.banner}</div>`:''}
   <div class="car-comp">${fcCompIcon(nx.icon,24)} ${escH(nx.name)}</div>
   <div class="car-vs">${escH(nx.label.toUpperCase())} · ${venue}${nx.t==='L'?' · VOCÊ: '+pos+'º':''}</div>
   ${nx.ko?'<div class="car-ko">MATA-MATA · empate vai para prorrogação e pênaltis</div>':''}
   <div class="car-kits"><div class="car-kit">${fcCrest(me,50)}<b>${escH(me.name)}</b>${fcKitSVG(pk[0],26)}</div><div class="car-x">×</div><div class="car-kit">${fcCrest(opp,50)}<b>${escH(opp.name)}</b>${fcKitSVG(pk[1],26)}</div></div>
   <div class="car-diff">Rival · GERAL ${opp.ovr} · ${'★'.repeat(st)}${'☆'.repeat(5-st)}</div>
   <button class="btn car-play-btn" id="b-car-play">JOGAR PARTIDA</button>${chips}`;
  $('#b-car-play').onclick=()=>startCareerMatch();
 }
 const sib=C.leagues.find(l=>l.id!==CAR.myLeague).id,tabs=$('#car-tabs');
 tabs.innerHTML=[['table','TABELA'],['scorers','ARTILHARIA'],['round','CALENDÁRIO'],['comp','COMPETIÇÕES'],['hist','HISTÓRICO']].map(([k,l])=>`<button class="editor-tab${carTab===k?' active':''}" data-t="${k}">${l}</button>`).join('');
 if(carTab==='table'||carTab==='scorers')tabs.innerHTML+=[CAR.myLeague,sib].map(id=>`<button class="editor-tab chip${carViewL===id?' active':''}" data-l="${id}">${escH(FC_LEAGUES[id].name)}</button>`).join('');
 if(carTab==='comp'){
  const{C:cc,key}=carCompKey();
  tabs.innerHTML+=`<select id="car-cty" class="car-sel">`+FC_COUNTRIES.map(x=>`<option value="${x.id}"${x.id===cc.id?' selected':''}>${x.flag} ${x.name}</option>`).join('')+`</select>`+
   [['L1',cc.leagues[0].name],['L2',cc.leagues[1].name],['CUP',FCC.CUPS[cc.id]||'Copa']].concat(['UCL','UEL','LIB','SUL','WC'].filter(k=>CAR.comps[k]).map(k=>[k,FCC.info(k).short])).map(([k,l])=>`<button class="editor-tab chip${key===k?' active':''}" data-c="${k}">${escH(l)}</button>`).join('');
 }
 tabs.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{carTab=b.dataset.t;carSub='main';carRender();});
 tabs.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{carViewL=b.dataset.l;carRender();});
 tabs.querySelectorAll('[data-c]').forEach(b=>b.onclick=()=>{carComp=b.dataset.c;carSub='main';carRender();});
 const sel=$('#car-cty');if(sel)sel.onchange=()=>{carCty=sel.value;carRender();};
 $('#car-table').innerHTML=carTab==='table'?carTableHTML(carViewL):carTab==='scorers'?carScorersHTML(carViewL):carTab==='round'?carRoundHTML():carTab==='comp'?carCompHTML():carHistHTML();
 $('#car-table').querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>{carSub=b.dataset.s;carRender();});
}
function carEndSeason(){
 const seasonEntry=FCC.endSeason(CAR);
 // Registra somente títulos realmente vencidos pelo clube do jogador.
 if(seasonEntry){
  if(!Array.isArray(CAR.trophyHistory))CAR.trophyHistory=[];
  const won=(seasonEntry.comps||[]).filter(x=>x&&x.k==='champ'&&x.champ===CAR.clubId);
  if(seasonEntry.champ===CAR.clubId){
   const leagueName=FC_LEAGUES[seasonEntry.lid]?FC_LEAGUES[seasonEntry.lid].name:'Campeonato';
   won.unshift({id:'LEAGUE-'+seasonEntry.lid,name:leagueName});
  }
  won.forEach(x=>{
   const inf=x.id.indexOf('LEAGUE-')===0?{name:x.name,icon:'🏆'}:FCC.info(x.id);
   const key=seasonEntry.season+'|'+x.id+'|'+CAR.clubId;
   if(!CAR.trophyHistory.some(t=>t.key===key))CAR.trophyHistory.push({key,competition:inf.name,icon:inf.icon||'🏆',season:seasonEntry.season,clubId:CAR.clubId});
  });
 }
 carViewL=CAR.myLeague;carTab='table';carCty=null;carComp=null;carSub='main';saveCareer();carRender();
}
function startCareerMatch(){
 if(!loadCareer()||FCC.finished(CAR)){openCareer();return;}
 const nx=FCC.pending(CAR);if(!nx){carRender();return;}
 const me=fcClub(CAR.clubId),opp=fcClub(nx.opp);
 applyTeams({id:me.id,kit:nx.home?'home':'away',ov:null},{id:opp.id,kit:nx.home?'away':'home',ov:null});
 G.careerOppStr=FCL.aiStrength(opp,me);
 G.careerInfo={home:nx.home,opp:opp.id,pos:CAR.pos,ko:nx.ko,name:nx.name,label:nx.label,icon:nx.icon};G.careerGoals=[];
 G.career=true;G.train=null;Net.reset();
 Au.init();Au.resume();Au.play('ui');
 startMatch();
}
function finishCareerMatch(){
 if(!G.career)return;
 if(!loadCareer()){G.career=false;show('title');return;}
 const info=G.careerInfo||{},gf=G.score[0],ga=G.score[1],me=CAR.clubId,opp=info.opp;
 if(info.pos!==CAR.pos||FCC.finished(CAR)){G.career=false;openCareer();return;}
 const home=!!info.home,sq=FCL.squad(fcClub(opp)),sc=[];
 (G.careerGoals||[]).forEach(g=>{
  if(g.t===0&&g.n)sc.push({c:me,n:String(g.n)});
  else if(g.t===1&&g.n)sc.push({c:opp,n:sq[(Math.random()*3)|0]});
 });
 const um={h:home?me:opp,a:home?opp:me,gh:home?gf:ga,ga:home?ga:gf,scorers:sc};
 if(info.ko&&gf===ga)Object.assign(um,FCC.resolveDraw(um.h,um.a,um.gh,um.ga));
 const evd=CAR.cal[CAR.pos],res=FCC.complete(CAR,um);
 CAR.banner='';saveCareer();
 if(gf>ga)achAdd('amistoso','wins',1);
 achAdd('amistoso','matches',1);achAdd('amistoso','goals',gf);
 // resultado do ponto de vista do usuário (considera prorrogação/pênaltis)
 const mf=home?um.gh:um.ga,mo=home?um.ga:um.gh,mp=um.pen?(home?um.pen:[um.pen[1],um.pen[0]]):null;
 let title=mf>mo?'VITÓRIA!':mf<mo?'DERROTA':'EMPATE',adv='';
 if(info.ko){
  if(mp){title=mp[0]>mp[1]?'CLASSIFICADO NOS PÊNALTIS!':'ELIMINADO NOS PÊNALTIS';}
  else if(um.et)title=mf>mo?'VITÓRIA NA PRORROGAÇÃO!':'DERROTA NA PRORROGAÇÃO';
  const won=mp?mp[0]>mp[1]:mf>mo,stt=FCC.status(CAR.comps[evd.c],me);
  adv=won?(stt&&stt.k==='champ'?'🏆 VOCÊ É CAMPEÃO: '+escH(info.name)+'!':'✅ Você avançou de fase.'):'❌ Seu clube foi eliminado de '+escH(info.name)+'.';
 }
 $('#car-r-title').textContent=title;
 $('#car-r-score').textContent=mf+' - '+mo;
 $('#car-r-stat').textContent=fcClub(me).name+' × '+fcClub(opp).name+(um.et&&!mp?' (após prorrogação)':'')+(mp?' · pênaltis '+mp[0]+' x '+mp[1]:'');
 let body;
 if(evd&&evd.t==='L'){
  const L=CAR.leagues[CAR.myLeague],pos=FCL.sorted(L).indexOf(me)+1,tot=FCL.rounds(L);
  body=(L.round>=tot?`Liga encerrada · Você terminou em ${pos}º lugar`:`${fcCompIcon(info.icon,20)} ${escH(info.name)} · Você está em ${pos}º · Próxima rodada ${L.round+1}/${tot}`)+'<div class="car-rl">'+res.map(carResRow).join('')+'</div>';
 }else{
  const comp=CAR.comps[evd.c],stt=FCC.status(comp,me);
  const rows=Array.isArray(res)&&res.length&&Array.isArray(res[0])?res.map(carResRow).join(''):(res||[]).map(carTieRow).join('');
  body=`${fcCompIcon(info.icon,20)} ${escH(info.name)} · ${escH(info.label)}`+(adv?`<div class="car-adv">${adv}</div>`:(stt?`<div class="car-adv">${escH(stt.t)}</div>`:''))+'<div class="car-rl">'+rows+'</div>';
 }
 $('#car-r-table').innerHTML=body;
 show('car-result');
 G.career=false;
}
function renderAchievements(){const box=$('#ach-list');if(!box)return;box.innerHTML='';Object.keys(ACH_MODES).forEach(mode=>{const cfg=ACH_MODES[mode],d=achData(mode);const h=document.createElement('h3');h.className='ach-heading';h.textContent=cfg.title;box.appendChild(h);cfg.items.forEach(([name,desc,key,target])=>{const done=!!d['unlocked:'+name],v=Math.min(target,d[key]||0);const card=document.createElement('div');card.className='ach-item'+(done?' done':'');const top=document.createElement('div');top.className='ach-top';const title=document.createElement('b');title.textContent=(done?'✓ ':'')+name;const state=document.createElement('span');state.textContent=done?'CONCLUÍDA':'BLOQUEADA';top.append(title,state);const detail=document.createElement('small');detail.textContent=desc;const prog=document.createElement('div');prog.className='ach-progress';const fill=document.createElement('i');fill.style.width=(v/target*100)+'%';prog.appendChild(fill);const count=document.createElement('small');count.className='ach-count';count.textContent=v+' / '+target;card.append(top,detail,prog,count);box.appendChild(card);});});$('#ach-total').textContent=achievementCount()+' / 40 conquistas';}
$('#b-achievements').onclick=()=>{renderAchievements();prevScreen='title';show('achievements');};
function renderTrophyHistory(){
 const list=$('#trophy-list'),total=$('#trophy-total');if(!list||!total)return;
 let trophies=[];
 if(loadCareer()&&Array.isArray(CAR.trophyHistory))trophies=CAR.trophyHistory.slice().sort((a,b)=>(b.season||0)-(a.season||0)||String(a.competition).localeCompare(String(b.competition)));
 total.textContent=trophies.length+' '+(trophies.length===1?'título conquistado':'títulos conquistados');
 if(!trophies.length){list.innerHTML='<div class="trophy-empty"><span>🏆</span><b>NENHUM TROFÉU CONQUISTADO</b><small>Quando seu clube vencer uma competição no Modo Carreira, o título aparecerá aqui.</small></div>';return;}
 list.innerHTML=trophies.map(t=>{const c=fcClub(t.clubId);return '<article class="trophy-card"><div class="trophy-icon">'+escH(t.icon||'🏆')+'</div><div class="trophy-info"><b>'+escH(t.competition||'Competição')+'</b><small>Temporada '+escH(String(t.season))+'</small><span>Clube: '+escH(c?c.name:(t.clubId||'—'))+'</span></div><div class="trophy-medal">🏆</div></article>';}).join('');
}
$('#b-trophy-history').onclick=()=>{renderTrophyHistory();prevScreen='title';show('trophy-history');};

/* ---------------- Telas ---------------- */
let curScreen='title',prevScreen='title';
function show(name){
 document.querySelectorAll('.screen').forEach(e=>e.classList.remove('show'));
 curScreen=name;if(name)In.releaseAll();
 if(name==='title'&&(Net.role||Net.mp))Net.reset(); // voltar ao menu sempre encerra o multiplayer
 if(name){const e=$('#s-'+name);if(e)e.classList.add('show');}
 document.body.classList.toggle('playing',!name);
}
function buildSettings(){
 const box=$('#setbox');box.innerHTML='';
 SCH.forEach(it=>{
  const row=document.createElement('div');
  if(it.t==='glb'){if(typeof GLBSys!=='undefined')GLBSys.buildUI(box,buildSettings);return;}
  if(it.t==='sec'){row.className='sec';row.textContent=it.l;box.appendChild(row);return;}
  row.className='row';const lab=document.createElement('span');lab.textContent=it.l;row.appendChild(lab);
  let inp;
  if(it.t==='btn'){inp=document.createElement('button');inp.className='btn mp-mini';inp.textContent=it.b||'ABRIR';inp.onclick=()=>{if(typeof SndUI!=='undefined')SndUI.open();};row.appendChild(inp);}
  else if(it.t==='sel'){inp=document.createElement('select');it.o.forEach((o,i)=>{const op=document.createElement('option');op.value=i;op.textContent=o;inp.appendChild(op);});inp.value=S[it.k];
   inp.onchange=()=>{S[it.k]=+inp.value;onCfg(it.k);};row.appendChild(inp);}
  else if(it.t==='tog'){inp=document.createElement('input');inp.type='checkbox';inp.checked=!!S[it.k];inp.onchange=()=>{S[it.k]=inp.checked;onCfg(it.k);};row.appendChild(inp);}
  else{inp=document.createElement('input');inp.type='range';inp.min=it.min;inp.max=it.max;inp.step=it.st;inp.value=S[it.k];
   const val=document.createElement('span');val.className='val';val.textContent=(+S[it.k]).toFixed(it.st<1?2:0);
   inp.oninput=()=>{S[it.k]=+inp.value;val.textContent=(+inp.value).toFixed(it.st<1?2:0);onCfg(it.k,true);};
   row.appendChild(inp);row.appendChild(val);}
  box.appendChild(row);
 });
}
function onCfg(k,live){
 if(k==='gfx'){Object.assign(S,PRE[S.gfx]);buildCrowd();buildSettings();resize();}
 if(k==='scale')resize();
 if(k==='hudO'||k==='hudS')layoutHUD();
 if(k==='sound'&&!S.sound)Au.crowd(0);
 if(k==='sound'&&S.sound){Au.init();Au.resume();}
 if((k==='sound'||k==='volMus'||k==='volCrowd')&&typeof SndPack!=='undefined')SndPack.tick();
 if(k==='vib'&&S.vib&&navigator.vibrate)try{navigator.vibrate(30);}catch(e){}
 if(!live)Au.play('ui');
 saveCfg();
}
function openSettings(from){prevScreen=from;buildSettings();show('set');}
let editorTeam=0,editorPlayer=0,editorTab='club';
function buildEditor(){
 const box=$('#editorbox');if(!box)return;box.innerHTML='';
 const tabs=document.createElement('div');tabs.className='editor-tabs';
 [['club','CLUBE'],['players','JOGADORES'],['visual','VISUAL']].forEach(([id,label])=>{const b=document.createElement('button');b.className='editor-tab'+(editorTab===id?' active':'');b.textContent=label;b.onclick=()=>{editorTab=id;buildEditor();};tabs.appendChild(b);});box.appendChild(tabs);
 const addField=(parent,label,value,type,change,opts)=>{const w=document.createElement('label');w.className='editor-field';const l=document.createElement('span');l.textContent=label;let inp=document.createElement(type==='select'?'select':'input');if(type!=='select')inp.type=type; if(type==='select')opts.forEach(v=>{let o=document.createElement('option');o.value=v.value;o.textContent=v.label;inp.appendChild(o);});inp.value=value;inp.oninput=()=>change(inp.value);w.append(l,inp);parent.appendChild(w);return inp;};
 const section=(title)=>{const h=document.createElement('div');h.className='editor-section';h.textContent=title;box.appendChild(h);};
 const team=CLUB.teams[editorTeam];
 const teamTabs=document.createElement('div');teamTabs.className='editor-tabs';[0,1].forEach(t=>{let b=document.createElement('button');b.className='editor-tab'+(editorTeam===t?' active':'');b.textContent=CLUB.teams[t].name||'CLUBE '+(t+1);b.onclick=()=>{editorTeam=t;editorPlayer=0;buildEditor();};teamTabs.appendChild(b);});if(editorTab!=='import')box.appendChild(teamTabs);
 if(editorTab==='club'){
  section('CLUBE (BANCO OFICIAL)');
  const cc=fcClub(team.id),LL=FC_LEAGUES[cc.league0],CC=fcCountry(cc.country);
  const card=document.createElement('div');card.className='editor-clubcard';
  card.innerHTML=fcCrest(cc,54)+'<div><b>'+escH(cc.name)+'</b><small>'+CC.flag+' '+escH(CC.name)+' · '+escH(LL.name)+' · '+cc.abbr+'</small><small>'+escH(cc.official)+'</small></div>';
  const pb=document.createElement('button');pb.className='btn mp-mini';pb.textContent='ESCOLHER CLUBE';
  pb.onclick=()=>{Au.play('ui');const t=editorTeam;openClubPicker({title:'EDITOR · CLUBE '+(t+1),from:'editor',current:CLUB.teams[t].id,onPick:id=>{CLUB.teams[t]={id,kit:'auto',ov:null};saveClub();buildEditor();}});};
  card.appendChild(pb);box.appendChild(card);
  section('UNIFORME');
  addField(box,'Uniforme usado',team.kit||'auto','select',v=>{team.kit=v;saveClub();buildEditor();},[{value:'auto',label:'Automático'},{value:'home',label:'Principal'},{value:'away',label:'Reserva'}]);
  [['Camisa','shirt',KIT[editorTeam].sh],['Calção','shorts',KIT[editorTeam].sh2],['Meiões','socks',KIT[editorTeam].so]].forEach(([l,k,cur])=>addField(box,l+' (personalizar)',cur,'color',v=>{team.ov=team.ov||{};team.ov[k]=v;saveClub();}));
  const rb=document.createElement('button');rb.className='btn sec2 mp-mini';rb.textContent='RESTAURAR CORES OFICIAIS';rb.onclick=()=>{team.ov=null;saveClub();buildEditor();};box.appendChild(rb);
 }else if(editorTab==='players'){
  const hasSq=FCS.has(team.id),ld=hasSq?FCS.lineup(team.id):null;
  if(hasSq){ // clube com elenco cadastrado (players/*.json): escolha dos 11 titulares, sem repetir jogador e respeitando posições
   section('ESCALAÇÃO · 11 TITULARES');
   const used={};ld.forEach(p=>{if(p)used[p.id]=1;});
   const all=FCS.squad(team.id);
   ld.forEach((cur,slot)=>{
    const opts=[{value:'',label:'(jogador genérico)'}].concat(FCS.eligible(all,slot).filter(p=>!used[p.id]||(cur&&p.id===cur.id)).sort((a,b)=>b.overall-a.overall).map(p=>({value:p.id,label:p.number+' · '+p.displayName+' ('+p.position+' '+p.overall+')'})));
    addField(box,FCS.SLOT_NAME[slot],cur?cur.id:'','select',v=>{if(FCS.setSlot(team.id,slot,v||null)){saveClub();}buildEditor();},opts);
   });
  }
  if(!hasSq){const n=document.createElement('div');n.className='editor-note';n.textContent='Este clube ainda não tem elenco cadastrado (usa jogadores genéricos).';box.appendChild(n);}
  section('ESCOLHA O JOGADOR');
  const sel=document.createElement('div');sel.className='editor-player-select';
  CLUB.players[editorTeam].forEach((pl,i)=>{let b=document.createElement('button');b.className='editor-tab'+(editorPlayer===i?' active':'');b.textContent=(i+1)+'. '+((ld&&ld[i]?ld[i].displayName:pl.name)||'Jogador');b.onclick=()=>{editorPlayer=i;buildEditor();};sel.appendChild(b);});box.appendChild(sel);
  const pl=CLUB.players[editorTeam][editorPlayer]||(CLUB.players[editorTeam][editorPlayer]={});
  section('DADOS DO JOGADOR');
  if(ld&&ld[editorPlayer]){const q=ld[editorPlayer],n=document.createElement('div');n.className='editor-note';n.textContent=q.fullName+' · camisa '+q.number+' · '+(FCS.POS[q.position]||q.position)+' · OVR '+q.overall;box.appendChild(n);}
  else{
   addField(box,'Nome',pl.name||'','text',v=>{pl.name=v;saveClub();});
   addField(box,'Número da camisa',pl.num||editorPlayer+1,'number',v=>{pl.num=clamp(parseInt(v)||editorPlayer+1,1,99);saveClub();});
  }
  section('APARÊNCIA DO BONECO');
  addField(box,'Tom de pele',pl.skin||SKIN[0],'color',v=>{pl.skin=v;saveClub();});
  addField(box,'Cor do cabelo',pl.hair||HAIR[0],'color',v=>{pl.hair=v;saveClub();});
  addField(box,'Proporção do boneco',pl.body||1,'select',v=>{pl.body=+v;saveClub();},[{value:'0.85',label:'Mais baixo / compacto'},{value:'1',label:'Padrão'},{value:'1.15',label:'Mais alto / robusto'}]);
 }else if(editorTab==='import'){
  buildImportTab(box,section);
 }else{
  section('QUALIDADE VISUAL DO JOGO');
  addField(box,'Qualidade dos bonecos',S.gfx,'select',v=>{S.gfx=+v;saveCfg();},[{value:'0',label:'Econômica'},{value:'1',label:'Alta'},{value:'2',label:'Máxima'}]);
  addField(box,'Resolução visual',S.scale,'select',v=>{S.scale=+v;saveCfg();},[{value:'.6',label:'Economia de desempenho'},{value:'.8',label:'Equilibrada'},{value:'1',label:'Máxima'}]);
  addField(box,'Sombras',S.shadow,'select',v=>{S.shadow=+v;saveCfg();},[{value:'0',label:'Desativadas'},{value:'1',label:'Leves'},{value:'2',label:'Aprimoradas'}]);
  section('MENU E INTERFACE');
  const root=document.documentElement;
  const ui=CLUB.ui||(CLUB.ui={accent:'#176b42',panel:'#0b1724',title:'FC CARREIRA 3D'});
  addField(box,'Cor principal do menu',ui.accent,'color',v=>{ui.accent=v;applyEditorUI();saveClub();});
 }
}
/* ---------- IMPORTAR ELENCO (dentro do jogo, sem Node/terminal/servidor) ---------- */
let IMPV=[],impMsg='';   // análises pendentes dos arquivos escolhidos · mensagem do último resultado
function readFileText(f){return(f&&typeof f.text==='function')?f.text():new Promise((ok,no)=>{const r=new FileReader();r.onload=()=>ok(String(r.result));r.onerror=()=>no(r.error);r.readAsText(f);});}
function downloadJSON(obj,name){
 try{const b=new Blob([JSON.stringify(obj,null,1)],{type:'application/json'}),u=URL.createObjectURL(b),a=document.createElement('a');
  a.href=u;a.download=name;a.style.display='none';document.body.appendChild(a);a.click();setTimeout(()=>{try{URL.revokeObjectURL(u);a.remove();}catch(e){}},5000);return true;}catch(e){return false;}
}
function buildImportTab(box,section){
 const mk=(tag,cls,txt)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(txt!=null)e.textContent=txt;return e;};
 const cname=id=>{const c=fcClub(id);return c?c.name:'(clube não identificado)';};
 const inf=FCS.info();
 section('IMPORTAR ELENCO');
 box.appendChild(mk('div','editor-note','Escolha um ou mais arquivos .json (um clube por arquivo) ou uma cópia de segurança. Nada sai do aparelho: os dados ficam salvos neste navegador. Clubes com elenco: '+inf.clubs+' ('+inf.imported+' importados aqui).'));
 if(impMsg){const m=mk('div','imp-msg',impMsg);box.appendChild(m);}
 const lab=mk('label','btn mp-mini imp-pick','ESCOLHER ARQUIVO(S) JSON');
 const inp=document.createElement('input');inp.type='file';inp.multiple=true;inp.accept='.json,application/json,text/plain,application/octet-stream';inp.style.display='none';
 inp.onchange=async()=>{
  const fs=Array.from(inp.files||[]).slice(0,60);if(!fs.length)return;
  const batch={ids:{},clubs:{},persons:{}};IMPV=[];impMsg='';
  for(const f of fs){
   let pv;
   try{pv=(f.size>FCS.MAX_FILE_BYTES)?{fileName:f.name,kind:'invalid',items:[],error:'arquivo grande demais (máx. 2 MB)'}:FCS.preview(await readFileText(f),f.name,batch);}
   catch(e){pv={fileName:f.name,kind:'invalid',items:[],error:'não foi possível ler o arquivo'};}
   IMPV.push(pv);
  }
  buildEditor();
 };
 lab.appendChild(inp);box.appendChild(lab);
 // ---- análise dos arquivos escolhidos ----
 let ready=0,repl=[];
 IMPV.forEach(pv=>{
  const card=mk('div','imp-card');card.appendChild(mk('div','imp-file','📄 '+pv.fileName+(pv.kind==='backup'?' · cópia de segurança':'')));
  if(pv.error)card.appendChild(mk('div','imp-err','✗ '+pv.error));
  pv.items.forEach(it=>{
   const row=mk('div','imp-item'+(it.ok?' ok':' bad')),c=fcClub(it.clubId);
   const head=mk('div','imp-head');if(c){const sp=document.createElement('span');sp.innerHTML=fcCrest(c,26);head.appendChild(sp);}
   const t=mk('div','imp-title');t.appendChild(mk('b',null,cname(it.clubId)));t.appendChild(mk('small',null,it.players.length+' jogador(es) válido(s) · '+(it.ok?'PRONTO PARA IMPORTAR':'COM ERROS — não será importado')));
   head.appendChild(t);row.appendChild(head);
   if(it.replaces){row.appendChild(mk('div','imp-warn','⚠ Substituirá o elenco '+it.replaces+' deste clube.'));if(it.ok)repl.push(cname(it.clubId));}
   if(it.players.length)row.appendChild(mk('div','imp-names',it.players.map(p=>p.number+' '+p.displayName+' ('+p.position+')').join(' · ')));
   it.errors.slice(0,8).forEach(e=>row.appendChild(mk('div','imp-err','✗ '+e)));if(it.errors.length>8)row.appendChild(mk('div','imp-err','… e mais '+(it.errors.length-8)+' erro(s)'));
   it.warnings.slice(0,8).forEach(e=>row.appendChild(mk('div','imp-warn','⚠ '+e)));if(it.warnings.length>8)row.appendChild(mk('div','imp-warn','… e mais '+(it.warnings.length-8)+' aviso(s)'));
   if(it.ok)ready++;card.appendChild(row);
  });
  box.appendChild(card);
 });
 const ib=mk('button','btn mp-mini','IMPORTAR ELENCO'+(ready?' ('+ready+')':''));
 if(!ready){ib.disabled=true;ib.style.opacity='.45';}
 ib.onclick=()=>{
  if(!ready)return;
  if(repl.length&&!confirm('Substituir o elenco atual de: '+repl.join(', ')+'?\n(Dica: exporte uma cópia de segurança antes.)'))return;
  Au.play('confirm');
  const r=FCS.importItems(IMPV);
  impMsg=r.storageFull?'✗ Sem espaço no armazenamento do navegador. Nada foi alterado.':
   (r.saved.length?'✓ '+r.saved.length+' elenco(s) importado(s) e salvo(s): '+r.saved.map(cname).join(', ')+'.':'Nada foi importado.')+(r.failed.length?' '+r.failed.length+' com erro.':'');
  IMPV=[];saveClub();buildEditor();
 };
 box.appendChild(ib);
 // ---- elencos salvos neste aparelho ----
 section('ELENCOS IMPORTADOS NESTE APARELHO');
 const list=FCS.importedList().sort((a,b)=>cname(a.clubId).localeCompare(cname(b.clubId)));
 if(!list.length)box.appendChild(mk('div','editor-note','Nenhum elenco importado ainda.'));
 list.forEach(x=>{
  const c=fcClub(x.clubId),row=mk('div','editor-clubcard');
  if(c){const sp=document.createElement('span');sp.innerHTML=fcCrest(c,34);row.appendChild(sp);}
  const d=mk('div');d.appendChild(mk('b',null,cname(x.clubId)));d.appendChild(mk('small',null,x.count+' jogadores · '+(x.importedAt?new Date(x.importedAt).toLocaleDateString():'')));row.appendChild(d);
  const e=mk('button','btn sec2 mp-mini','EXPORTAR');e.onclick=()=>{Au.play('ui');impMsg=downloadJSON(FCS.exportBackup(x.clubId),'goalhorizon-'+x.clubId+'.json')?'✓ Arquivo do clube gerado (veja Downloads).':'✗ Não foi possível gerar o arquivo.';buildEditor();};
  const r=mk('button','btn sec2 mp-mini','EXCLUIR');r.onclick=()=>{if(!confirm('Excluir o elenco importado de '+cname(x.clubId)+'? O clube volta ao elenco do projeto (se houver) ou a jogadores genéricos.'))return;Au.play('back');impMsg=FCS.removeImported(x.clubId)?'Elenco de '+cname(x.clubId)+' excluído.':'✗ Não foi possível excluir.';saveClub();buildEditor();};
  row.append(e,r);box.appendChild(row);
 });
 const bk=mk('button','btn mp-mini','EXPORTAR CÓPIA DE SEGURANÇA'+(list.length?' ('+list.length+')':''));
 if(!list.length){bk.disabled=true;bk.style.opacity='.45';}
 bk.onclick=()=>{if(!list.length)return;Au.play('ui');const d=new Date(),p=n=>String(n).padStart(2,'0');
  impMsg=downloadJSON(FCS.exportBackup(),'goalhorizon-elencos-'+d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate())+'.json')?'✓ Cópia de segurança gerada (veja Downloads). Para restaurar, escolha esse arquivo em ESCOLHER ARQUIVO(S).':'✗ Não foi possível gerar a cópia.';buildEditor();};
 box.appendChild(bk);
}
function applyEditorUI(){
 const ui=CLUB.ui||{};
 document.documentElement.style.setProperty('--editor-accent',ui.accent||'#176b42');
 document.documentElement.style.setProperty('--editor-panel',ui.panel||'#0b1724');
}
applyEditorUI();
function openEditor(){prevScreen='title';IMPV=[];impMsg='';editorTeam=0;editorPlayer=0;editorTab='club';buildEditor();show('editor');}
$('#b-editor').onclick=openEditor;
$('#b-editor-save').onclick=()=>{saveClub();Au.play('ui');msg('CLUBES SALVOS!',1.5);};

function showResult(){
 if(G.state!=='end')return;
 const s0=G.stats[0],s1=G.stats[1],tp=s0.poss+s1.poss||1;
 const me=Net.role==='guest'?1:0,ba=$('#b-again');
 if(ba){ba.textContent=Net.role==='guest'?'Aguardando anfitrião…':'Jogar de novo';ba.style.opacity=Net.role==='guest'?.5:1;}
 $('#r-title').textContent=G.score[me]>G.score[1-me]?'VITÓRIA!':G.score[me]<G.score[1-me]?'DERROTA':'EMPATE';
 $('#r-score').textContent=TEAMA[0]+' '+G.score[0]+' - '+G.score[1]+' '+TEAMA[1];
 const rows=[['Finalizações',s0.shots,s1.shots],['Passes',s0.passes,s1.passes],['Posse de bola',Math.round(s0.poss/tp*100)+'%',Math.round(s1.poss/tp*100)+'%'],['Faltas',s0.fouls,s1.fouls],['Cartões amarelos',s0.cards,s1.cards]];
 $('#r-stat').innerHTML=rows.map(r=>'<b>'+r[1]+'</b><span>'+r[0]+'</span><b>'+r[2]+'</b>').join('');
 show('result');
}
function startMatch(){
 if(!G.career)applyClub(); // clubes do banco novo (Amistoso/Editor)
 initMatch();In.clear();show(null);resize();lastTs=0;
}
$('#b-play').onclick=()=>{Au.init();Au.resume();Au.play('ui');Net.reset();openFriendly();};
$('#b-fr-start').onclick=()=>{Au.init();Au.resume();Au.play('ui');Net.reset();startMatch();};
$('#b-multi').onclick=()=>{Au.play('ui');prevScreen='title';lobbyOpen();};
$('#b-career').onclick=()=>{Au.play('ui');openCareer();};
$('#b-car-continue').onclick=()=>{Au.play('ui');openCareer();};
$('#b-car-menu').onclick=()=>{G.career=false;Au.play('ui');show('title');};
$('#b-car-new').onclick=()=>{if(!loadCareer())return;if(!confirm('Reiniciar esta temporada? Ligas, copas e competições continentais da temporada atual serão zeradas.'))return;CAR.banner='';FCC.startSeason(CAR);carViewL=CAR.myLeague;carTab='table';carComp=null;saveCareer();carRender();};
$('#b-car-club').onclick=()=>{if(!confirm('Trocar de clube inicia uma NOVA carreira e apaga o progresso atual. Continuar?'))return;carPickClub();};
$('#b-how').onclick=()=>{prevScreen='title';show('how');};
$('#b-set1').onclick=()=>openSettings('title');
$('#b-set2').onclick=()=>openSettings('pause');
$('#b-fs').onclick=()=>{try{const e=document.documentElement;(e.requestFullscreen||e.webkitRequestFullscreen).call(e);if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{});}catch(e){}};
document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>{Au.play('back');show(prevScreen);});
$('#b-resume').onclick=()=>{G.paused=false;In.clear();show(null);if(Net.mp&&Net.role==='host')Net.sendPause(false);};
$('#b-quit').onclick=()=>{G.paused=false;G.train=null;G.pen=null;G.career=false;G.state='menu';Net.reset();show('title');};
$('#b-again').onclick=()=>{if(G.pen){startPenalties(G.pen.cfg);return;}if(Net.mp){if(Net.role==='host')Net.rematch();return;}startMatch();};
$('#b-menu').onclick=()=>{G.train=null;G.pen=null;G.career=false;G.state='menu';show('title');};
function pauseGame(){if(G.state==='menu'||G.paused)return;
 if(Net.mp&&Net.role==='guest'){In.releaseAll();show('pause');return;} // visitante: a partida continua no anfitrião
 G.paused=true;if(Net.mp&&Net.role==='host')Net.sendPause(true);G.charging=false;In.releaseAll();const tb=$('#b-trrst');if(tb)tb.style.display=G.train?'block':'none';show('pause');}

/* ---------------- Modo treinamento (chute · passe · controle de posse) ----------------
   Reaproveita a mesma física/controles da partida. Jogadores que não participam do treino ficam com out=true.
   G.train = null (partida normal) ou objeto do treino ativo. */
const TR_INFO={
 shoot:{n:'TREINO DE CHUTE',max:10},
 foul:{n:'TREINO DE FALTA',max:10},
 pass:{n:'TREINO DE PASSE',time:90},
 poss:{n:'CONTROLE DE POSSE',time:120}
};
const isShootTr=tr=>!!tr&&(tr.type==='shoot'||tr.type==='foul'); // treinos de finalização (mesma contagem de tentativas/gols)
const TR_SPOTS=[[-9,-7],[9,-7],[9,7],[-9,7]];
function hudL(i){return G.pen?TEAMA[i]:(G.train?G.train.lab[i]:TEAMA[i]);}
function hudS(i){return G.pen?G.pen.scores[i]:(G.train?G.train.val[i]:G.score[i]);}
function setL3Label(t){try{const d=(typeof HD!=='undefined')&&HD.find(x=>x.id==='L3');if(d&&d.el)d.el.textContent=t;}catch(e){}} // no treino de falta o botão L3 reinicia a cobrança
function startTraining(type){
 Net.reset();initMatch();
 G.train={type,lab:['',''],val:[0,0],clk:'',spots:null,def:[],wall:[],fk:null,ok:0,fail:0,streak:0,best:0,cur:0,t:0,att:0,goals:0,live:false,liveT:0,wait:0,lastOwner:null,looseT:0,shots0:0};
 const tr=G.train,T0=G.teamP[0],T1=G.teamP[1],u=T0[9];
 let keep;
 if(type==='shoot')keep=[u,T1[0]];
 else if(type==='foul'){tr.wall=[T1[2],T1[3],T1[4],T1[5],T1[6]];keep=[u,T1[0]].concat(tr.wall);}
 else if(type==='pass'){keep=[u,T0[5],T0[6],T0[8]];tr.spots=TR_SPOTS;keep.forEach((p,i)=>{p.spot=TR_SPOTS[i];});}
 else{tr.def=[T1[5],T1[6],T1[9]];keep=[u].concat(tr.def);}
 for(const p of G.players)p.out=!keep.includes(p);
 G.restart=null;G.clearR=0;G.restartT=0;G.state='play';G.user=u;
 trainPlace();trainHud();snapCamera();
 In.clear();show(null);resize();lastTs=0;
 setL3Label(type==='foul'?'NOVA':'L3');
 msg(type==='foul'?'TREINO DE FALTA · L3/C: NOVA COBRANÇA':TR_INFO[type].n,2.6);
}
function trainPlace(){
 const tr=G.train,b=G.ball,T0=G.teamP[0],T1=G.teamP[1],u=T0[9];
 const reset=(p,x,z,f)=>{p.x=x;p.z=z;p.vx=p.vz=0;p.face=f;p.ctrlCd=p.kickT=p.slideT=p.stun=p.immune=p.celeb=p.diveT=p.jumpT=p.stumbleT=0;p.tackleCd=1.2;p.holdT=0;p.sprint=false;p.shield=false;p.skillCd=0;};
 G.state='play';tr.live=false;tr.wait=0;tr.looseT=0;tr.lastOwner=null;G.charging=false;
 b.vx=b.vy=b.vz=0;ballResetSpin(b);b.kicker=null;b.gkRolled=true;b.tr.length=0;
 if(tr.type==='foul'){
  // Cobrança de falta: bola parada a 17–27 m do gol (+x), barreira a 9,15 m da bola, goleiro na linha, cobrador 1,4 m atrás da bola
  const bx=HL-(17+rnd()*10),bz=(rnd()<.5?-1:1)*(2+rnd()*13),ang=Math.atan2(-bz,HL-bx),ux=cos(ang),uz=sin(ang),n=(HL-bx)<21?5:4,dist=hyp(HL-bx,bz);
  tr.fk={x:bx,z:bz,ang:ang,dist:dist};
  const g=T1[0],gz=clamp(bz*.12,-2.4,2.4);reset(g,HL-1.2,gz,PI);g.tackleCd=0;
  const side=Math.sign(bz)||1,off=-side*.0; // barreira centrada na linha bola→gol (o goleiro cobre o lado oposto)
  tr.wall.forEach((p,i)=>{
   const active=i<n;p.out=!active;
   if(!active)return;
   const k=(i-(n-1)/2)*.82,wx=bx+ux*9.15-uz*k,wz=bz+uz*9.15+ux*k+off;
   reset(p,wx,wz,ang+PI);p.spot=[wx,wz];p.jumped=false;
  });
  reset(u,bx-ux*1.4,bz-uz*1.4,ang);
  b.x=bx;b.z=bz;b.y=BR;b.owner=null;G.lastTouch=u;G.possTeam=0;G.pass=null;G.restartT=0;
  const c=CTL[0];if(c.active)c.user=u;
  G.sp=null;spBegin('free',u,true);
  snapCamera();return;
 }
 if(tr.type==='shoot'){
  const x=HL-(17+rnd()*19),z=(rnd()-.5)*34;
  reset(u,x,z,Math.atan2(-z,HL-x));reset(T1[0],HL-1.5,0,PI);T1[0].tackleCd=0;
 }else if(tr.type==='pass'){
  [u,T0[5],T0[6],T0[8]].forEach((p,i)=>reset(p,TR_SPOTS[i][0],TR_SPOTS[i][1],Math.atan2(-TR_SPOTS[i][1],-TR_SPOTS[i][0])));
 }else{
  reset(u,0,0,0);const a0=rnd()*TAU;
  tr.def.forEach((p,i)=>{const a=a0+i*2.09;reset(p,cos(a)*14,sin(a)*14,a+PI);});
  G.restartT=1;
 }
 b.x=u.x+cos(u.face)*.5;b.z=u.z+sin(u.face)*.5;b.y=BR;
 G.pass=null;setOwner(u);
 snapCamera(); // a câmera acompanha o novo posicionamento na hora (sem varredura que parecia teleporte)
}
function trainHud(){
 const tr=G.train;if(!tr)return;
 if(isShootTr(tr)){tr.lab=['GOL','TENT'];tr.val=[tr.goals,tr.att];}
 else if(tr.type==='pass'){tr.lab=['PAS','SEQ'];tr.val=[tr.ok,tr.streak];}
 else{tr.lab=['REC','ATU'];tr.val=[tr.best|0,tr.cur|0];}
}
function trainAI(p,dt){
 const tr=G.train,b=G.ball,o=b.owner;
 if(p.team===1&&tr.type==='foul'){ // barreira: fica parada no ponto marcado, olhando a bola; pula quando o cobrador chuta
  const s=p.spot;if(s&&dist2(p.x,p.z,s[0],s[1])>.09)steer(p,s[0],s[1],.8,false,dt,1);else approach(p,0,0,14*dt);
  if(tr.live&&!p.jumped){p.jumped=true;if(rnd()<.8)p.jumpT=.55;}
  return;
 }
 if(p.team===1){ // marcadores do treino de posse: um vai na bola, os outros cercam
  const tg=(o&&o.team===0)?o:b,k=Math.max(0,tr.def.indexOf(p)),a=G.t*.7+k*2.09,rad=k?3.2:0;
  steer(p,tg.x+(tg.vx||0)*.3+cos(a)*rad,tg.z+(tg.vz||0)*.3+sin(a)*rad,1,true,dt,OPP[S.diff]*.92);
  if(o&&o.team===0&&p.tackleCd<=0&&p.stun<=0&&p.slideT<=0&&G.restartT<=0&&dist2(p.x,p.z,o.x,o.z)<1.96){
   p.tackleCd=1+rnd()*.6;tackleAttempt(p,o,0);
  }
  return;
 }
 {const ps=livePass();if(ps&&ps.tgt===p&&passReceive(p,ps,dt,1))return;} // receptor do passe corre ao encontro da bola
 const s=p.spot; // companheiros do treino de passe: voltam ao ponto marcado
 if(s)steer(p,s[0],s[1],.9,dist2(p.x,p.z,s[0],s[1])>40,dt,1);else approach(p,0,0,14*dt);
}
function trainUpdate(dt){
 const tr=G.train,b=G.ball,o=b.owner,info=TR_INFO[tr.type];
 if(tr.wait>0){tr.wait-=dt;if(tr.wait<=0)trainNext();trainHud();return;}
 if(info.time){
  tr.t+=dt;const rem=Math.max(0,info.time-tr.t),m=(rem/60)|0,s=(rem%60)|0;
  tr.clk=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
  if(rem<=0){trainEnd();trainHud();return;}
 }else tr.clk=Math.min(tr.att,info.max)+'/'+info.max;
 if(isShootTr(tr)){
  if(!tr.live){if(G.stats[0].shots>tr.shots0){tr.shots0=G.stats[0].shots;tr.live=true;tr.liveT=0;tr.att++;}}
  else{
   tr.liveT+=dt;
   if(o||tr.liveT>6||(tr.liveT>.8&&hyp(b.vx,b.vz)<.8&&b.y<BR+.1))trainShotEnd(false);
  }
 }else if(tr.type==='pass'){
  if(o){
   tr.looseT=0;
   if(tr.lastOwner&&o!==tr.lastOwner){
    tr.ok++;tr.streak++;tr.best=Math.max(tr.best,tr.streak);achAdd('passe','passes',1);achMax('passe','streak',tr.streak);Au.play('confirm');
    if(tr.streak%5===0)msg('SEQUÊNCIA '+tr.streak+'!',1);
   }
   tr.lastOwner=o;
  }else{
   tr.looseT+=dt;
   if(tr.looseT>5||(tr.looseT>1.2&&hyp(b.vx,b.vz)<1.5))trainLoss('PASSE PERDIDO!');
  }
 }else{
  tr.cur+=dt;tr.best=Math.max(tr.best,tr.cur);achMax('posse','best',tr.cur);
  if(o){tr.looseT=0;if(o.team===1)trainLoss('BOLA PERDIDA!');}
  else{tr.looseT+=dt;if(tr.looseT>1.8)trainLoss('BOLA PERDIDA!');}
 }
 trainHud();
}
function trainShotEnd(out){
 const tr=G.train;if(!tr.live)return;
 tr.live=false;tr.wait=1.1;const o=G.ball.owner;
 msg(out?'PARA FORA!':(o&&o.team===1?(o.role==='GK'?'DEFENDEU!':'BARREIRA!'):'ERROU!'),1);
}
function trainGoal(){ // chamado por goalScored()
 const tr=G.train;if(tr.live)tr.goals++;
 tr.live=false;G.stateT=2.4;trainHud();msg('GOOOL!',2);
}
function trainLoss(txt){tr_loss(txt);}
function tr_loss(txt){const tr=G.train;tr.fail++;tr.streak=0;tr.cur=0;tr.wait=.9;msg(txt,1);trainHud();}
function trainOut(){ // bola saiu do campo (no treino não há reposição)
 const tr=G.train;if(!tr||tr.wait>0)return;
 if(isShootTr(tr)){if(tr.live)trainShotEnd(true);else tr.wait=.6;}
 else trainLoss('BOLA FORA!');
}
function trainEnd(){
 const tr=G.train;
 msg(tr.type==='pass'?'FIM · '+tr.ok+' PASSES · SEQUÊNCIA '+tr.best:'FIM · MELHOR '+(tr.best|0)+'s · PERDAS '+tr.fail,3.4);
 tr.t=0;tr.ok=0;tr.fail=0;tr.streak=0;tr.best=0;tr.cur=0;tr.wait=3.4;
}
function trainNext(){
 const tr=G.train;
 if(isShootTr(tr)&&tr.att>=TR_INFO[tr.type].max){msg('FIM · '+tr.goals+'/'+tr.att+' GOLS',3.4);tr.att=0;tr.goals=0;tr.wait=3.4;return;}
 trainPlace();
}
$('#b-train').onclick=()=>{Au.play('ui');prevScreen='title';show('train');};
$('#b-tr-shoot').onclick=()=>{Au.init();Au.resume();Au.play('ui');startTraining('shoot');};
$('#b-tr-foul').onclick=()=>{Au.init();Au.resume();Au.play('ui');startTraining('foul');};
$('#b-tr-pass').onclick=()=>{Au.init();Au.resume();Au.play('ui');startTraining('pass');};
$('#b-tr-poss').onclick=()=>{Au.init();Au.resume();Au.play('ui');startTraining('poss');};
$('#b-trrst').onclick=()=>{if(G.train)startTraining(G.train.type);};

/* =====================================================================
   DISPUTA DE PÊNALTIS
   Alternância de 5 cobranças + morte súbita. Reaproveita física, animações
   de chute/mergulho/comemoração e controles por toque do motor principal.
   ===================================================================== */
const PEN_DIFF=[ // reação goleiro, precisão IA, erro usuário
 {gk:.38,aiAim:.55,userErr:1.15,label:'Fácil'},
 {gk:.58,aiAim:.72,userErr:1.0,label:'Normal'},
 {gk:.82,aiAim:.88,userErr:.85,label:'Difícil'}
];
let PEN_SEL=null; // [id0,id1] — clubes do banco novo
function penFillSelects(){
 if(!PEN_SEL||!fcClub(PEN_SEL[0])||!fcClub(PEN_SEL[1]))PEN_SEL=[CLUB.teams[0].id,CLUB.teams[1].id];
 [0,1].forEach(t=>{const c=fcClub(PEN_SEL[t]),b=$('#pen-team'+t);if(!b)return;
  b.innerHTML=fcCrest(c,22)+'<span>'+escH(c.name)+'</span>';
  b.onclick=()=>{Au.play('ui');openClubPicker({title:t?'ADVERSÁRIO':'SEU TIME',from:'pen-setup',current:PEN_SEL[t],onPick:id=>{PEN_SEL[t]=id;penFillSelects();}});};});
}
function openPenSetup(){
 prevScreen='title';penFillSelects();show('pen-setup');
}
function startPenalties(cfg){
 Net.reset();Au.init();Au.resume();Au.play('ui');
 if(!PEN_SEL)penFillSelects();
 const c0=cfg&&fcClub(cfg.c0)?cfg.c0:PEN_SEL[0],c1=cfg&&fcClub(cfg.c1)?cfg.c1:PEN_SEL[1];
 const diff=cfg?cfg.diff:+($('#pen-diff')&&$('#pen-diff').value)||1;
 const stad=0; // estádio único (Arena Horizon)
 applyTeams({id:c0,kit:'auto',ov:null},{id:c1,kit:'auto',ov:null});
 G._penKeep=true;
 initMatch();
 G._penKeep=false;
 G.train=null;G.career=false;
 // só cobrador + goleiro de cada lado
 const taker0=G.teamP[0][9],taker1=G.teamP[1][9],gk0=G.teamP[0][0],gk1=G.teamP[1][0];
 for(const p of G.players)p.out=!(p===taker0||p===taker1||p===gk0||p===gk1);
 G.pen={
  phase:'intro',timer:1.6,round:0,sudden:false,kickTeam:0,
  scores:[0,0],taken:[0,0],history:[],
  taker:taker0,gk:gk1,atkDir:1,
  aimZ:0,aimY:.45,power:0,charging:false,
  diff:clamp(diff,0,2),stad:stad,
  cfg:{c0,c1,diff,stad},
  result:null,waitMsg:'',userDive:0,gkDecided:false,flightT:0
 };
 G.state='play';G.user=taker0;G.score=[0,0];G.restart=null;G.charging=false;
 penPlaceKick();
 In.clear();show(null);resize();lastTs=0;snapCamera();
 msg('DISPUTA DE PÊNALTIS',2.2);Au.play('whistle');
}
function penPlaceKick(){
 const pen=G.pen;if(!pen)return;
 const dir=1;pen.atkDir=dir; // todas as cobranças no MESMO gol (trave direita)
 const gx=HL*dir,spotX=gx-dir*11; // marca dos 11 metros
 const taker=G.teamP[pen.kickTeam][9],gk=G.teamP[1-pen.kickTeam][0];
 pen.taker=taker;pen.gk=gk;G.user=pen.kickTeam===0?taker:gk;
 // posiciona
 const reset=(p,x,z,f)=>{p.x=x;p.z=z;p.vx=p.vz=0;p.face=f;p.ctrlCd=p.kickT=p.slideT=p.stun=p.immune=p.celeb=p.diveT=p.jumpT=p.stumbleT=0;p.holdT=0;p.out=false;};
 reset(taker,spotX-dir*4.2,0,dir>0?0:PI);
 reset(gk,gx-dir*1.2,0,dir>0?PI:0);
 // outros fora de cena
 for(const p of G.players)if(p!==taker&&p!==gk){p.out=true;p.x=0;p.z=(p.team?1:-1)*40;}
 const b=G.ball;
 b.x=spotX;b.z=0;b.y=BR;b.vx=b.vy=b.vz=0;ballResetSpin(b);b.owner=null;b.kicker=null;b.gkRolled=true;b.tr.length=0;
 pen.aimZ=0;pen.aimY=.45;pen.power=0;pen.charging=false;pen.result=null;pen.gkDecided=false;pen.userDive=0;pen.flightT=0;
 pen.phase='walk';pen.timer=0;
 msg((pen.sudden?'MORTE SÚBITA · ':'')+TEAMA[pen.kickTeam]+' COBRA',1.8);
}
function penStep(dt){
 const pen=G.pen;if(!pen)return;
 // atualiza animação de todos (para dive/kick/celeb)
 for(const p of G.players){
  if(p.out){p.vx*=.9;p.vz*=.9;continue;}
  // timers de animação
  if(p.kickT>0)p.kickT=Math.max(0,p.kickT-dt);
  if(p.diveT>0)p.diveT=Math.max(0,p.diveT-dt);
  if(p.celeb>0)p.celeb=Math.max(0,p.celeb-dt);
  if(p.jumpT>0)p.jumpT=Math.max(0,p.jumpT-dt);
  if(p.stumbleT>0)p.stumbleT=Math.max(0,p.stumbleT-dt);
  p.x+=p.vx*dt;p.z+=p.vz*dt;p.vx*=Math.exp(-3*dt);p.vz*=Math.exp(-3*dt);
  p.speed=hyp(p.vx,p.vz);p.phase+=dt*(4+p.speed*1.2);
 }
 const b=G.ball;
 if(pen.phase==='flight'||pen.phase==='resolve'){
  stepBallSub(dt);
  // contato com goleiro
  const gk=pen.gk;
  if(!b.gkRolled&&gk.diveT>0){
   const reach=2.0+(pen.diff===2?.15:0);
   if(b.y<2.9&&dist2(gk.x,gk.z,b.x,b.z)<reach*reach){
    b.gkRolled=true;
    const sp=hyp(b.vx,b.vz);
    const catchP=.35+PEN_DIFF[pen.diff].gk*.35-(sp>22?.15:0);
    if(rnd()<catchP){ // agarrou
     b.vx=b.vz=0;b.vy=0;b.owner=gk;gk.holdT=.2;
     pen.result='save';pen.phase='resolve';pen.timer=2.2;
     msg('DEFENDEU!',1.8);Au.play('save');
     if(navigator.vibrate&&S.vib)try{navigator.vibrate(40);}catch(e){}
    }else{ // espalmou
     b.vx*=-.15+(rnd()-.5)*.4;b.vz+=(rnd()-.5)*8;b.vy=Math.abs(b.vy)*.4+1.5;
     pen.result='save';pen.phase='resolve';pen.timer=2.2;
     msg('ESPALMOU!',1.8);Au.play('save');
    }
   }
  }
  // gol / fora / trave
  if(pen.phase==='flight'){
   pen.flightT+=dt;
   if(abs(b.x)>HL){
    const s=Math.sign(b.x),dir=pen.atkDir;
    if(s===dir&&abs(b.z)<GW&&b.y<GH+.12){
     // GOL
     pen.result='goal';pen.phase='resolve';pen.timer=2.8;
     pen.scores[pen.kickTeam]++;G.score[pen.kickTeam]=pen.scores[pen.kickTeam];
     pen.taker.celeb=3.2;pen.taker.celebType=(rnd()*3)|0;
     msg('GOOOL!',2.4);Au.play('goal');fxGoal(dir);
     if(navigator.vibrate&&S.vib)try{navigator.vibrate([40,50,40]);}catch(e){}
    }else{
     // trave?
     if(s===dir&&abs(b.z)<GW+.35&&b.y<GH+.5){
      pen.result='post';pen.phase='resolve';pen.timer=2.2;
      msg('TRAVESSA / TRAVE!',1.8);Au.play('post');Au.play('ooh');
      b.vx*=-.3;b.vz+=(rnd()-.5)*4;
     }else{
      pen.result='miss';pen.phase='resolve';pen.timer=2.2;
      msg('PARA FORA!',1.8);Au.play('miss');
      pen.taker.stumbleT=.8;
     }
    }
   }else if(pen.flightT>4.5||(pen.flightT>1.2&&hyp(b.vx,b.vz)<.6&&b.y<=BR+.05)){
    pen.result='miss';pen.phase='resolve';pen.timer=2.0;
    msg('PARA FORA!',1.6);
   }
  }
 }
 // fases de controle
 if(pen.phase==='intro'){
  pen.timer-=dt;if(pen.timer<=0){pen.phase='walk';pen.timer=0;}
 }else if(pen.phase==='walk'){
  // cobrador caminha até a bola
  const t=pen.taker,bx=b.x,bz=b.z,dx=bx-t.x,dz=bz-t.z,d=hyp(dx,dz);
  if(d>1.15){
   const sp=2.4;t.vx=dx/d*sp;t.vz=dz/d*sp;t.face=Math.atan2(dz,dx);
  }else{
   t.vx=t.vz=0;t.face=pen.atkDir>0?0:PI;
   pen.phase=pen.kickTeam===0?'aim':'ai_prep';pen.timer=pen.kickTeam===0?0:.6+rnd()*.5;
   if(pen.kickTeam===0)msg('MIRE (analógico) · SEGURE X: SOLTE NA ZONA VERDE',2.8);
  }
 }else if(pen.phase==='aim'){
  // mira com analógico: X = lateralidade no gol, Y = altura
  let ix=In.L.x,iy=In.L.y;if(In.kx||In.ky){ix=In.kx;iy=In.ky;}
  if(hyp(ix,iy)>.12){
   pen.aimZ=clamp(pen.aimZ+ix*dt*1.8,-1,1);
   pen.aimY=clamp(pen.aimY-iy*dt*1.2,.08,.95);
  }
  // força
  if(In.pd('X')){pen.charging=true;pen.power=0;}
  if(pen.charging){
   if(In.held.X){pen.power=Math.min(1,pen.power+dt/.9);G.charging=true;G.charge=pen.power;}
   else{
    G.charging=false;pen.charging=false;
    pen.phase='runup';pen.timer=.55;pen.power=Math.max(.28,pen.power);
   }
  }
  // dica de mira: leve rotação do jogador
  pen.taker.face=Math.atan2(pen.aimZ*.9,pen.atkDir*2.5);
 }else if(pen.phase==='runup'){
  pen.timer-=dt;
  const t=pen.taker,dir=pen.atkDir;
  // corrida curta de aproximação
  t.vx=dir*6.5;t.vz=pen.aimZ*1.2;t.face=Math.atan2(pen.aimZ*.4,dir);
  if(pen.timer<=0){
   // CHUTE
   penDoKick(false);
   pen.phase='flight';pen.flightT=0;b.gkRolled=false;
   penGkReact();
  }
 }else if(pen.phase==='ai_prep'){
  pen.timer-=dt;
  if(pen.timer<=0){
   // IA escolhe mira
   const d=PEN_DIFF[pen.diff];
   // tende a mirar cantos
   const side=rnd()<.5?-1:1;
   pen.aimZ=side*(.55+rnd()*.4)*d.aiAim+(rnd()-.5)*(1-d.aiAim)*1.2;
   pen.aimY=.25+rnd()*.55;
   pen.power=.55+rnd()*.4;
   pen.phase='runup';pen.timer=.5;
  }
 }else if(pen.phase==='flight'){
  // usuário controlando goleiro: pode iniciar mergulho
  if(pen.kickTeam===1&&!pen.gkDecided){
   let ix=In.L.x,iy=In.L.y;if(In.kx||In.ky){ix=In.kx;iy=In.ky;}
   if(In.pd('X')||In.pd('A')||In.pd('B')||hyp(ix,iy)>.55){
    pen.userDive=ix||(rnd()-.5);
    penGkReact(true);
   }
  }
 }else if(pen.phase==='resolve'){
  pen.timer-=dt;
  if(pen.timer<=0){
   // registra histórico
   pen.history.push({team:pen.kickTeam,result:pen.result||'miss',n:pen.taken[pen.kickTeam]+1});
   pen.taken[pen.kickTeam]++;
   // próxima cobrança / fim
   if(penCheckEnd()){penEnd();return;}
   // alterna time
   pen.kickTeam=1-pen.kickTeam;
   // após 5 cada, morte súbita
   if(!pen.sudden&&pen.taken[0]>=5&&pen.taken[1]>=5){
    if(pen.scores[0]!==pen.scores[1]){penEnd();return;}
    pen.sudden=true;msg('MORTE SÚBITA!',2.2);
   }
   penPlaceKick();
  }
 }
 // crowd leve
 if(((G.t*2)|0)!==(((G.t-dt)*2)|0))Au.crowd(.06+(pen.phase==='resolve'&&pen.result==='goal'?.25:0));
}
/* erro de pontaria (fração do gol) conforme a força: mínimo na zona ideal (70–90%), pior fraco demais ou "na bola" */
function penErr(p){return p<.7?.05+.1*(.7-p)/.7:(p<=.9?.05:.05+.08*(p-.9)/.1);}

/* =====================================================================
   COBRANÇAS DE FALTA E PÊNALTI (partida e Treino de falta) — MESMO sistema da disputa de pênaltis
   Mira no gol com o analógico (lateral + altura), força segurando X e soltando na ZONA VERDE (70–90%),
   corrida curta e chute. Falta perigosa (≤ 33 m, de frente): barreira a 9,15 m que pula; a bola sobe para passar por cima dela.
   Analógico direito = efeito (curva). Na falta da partida, A/B/Y cancela a mira e passa a bola.
   ===================================================================== */
const SP_RANGE=33;
function spDiff(){return clamp(S.diff|0,0,2);}
function spDisp(sp,pw){return penErr(pw)*PEN_DIFF[sp.diff].userErr*(sp.kind==='free'?1+Math.max(0,sp.D-11)/22:1);} // dispersão (fração do gol): anel da mira
function freeKickInRange(o,dir){const D=hyp(HL*dir-o.x,o.z);return D<=SP_RANGE&&D>=15&&abs(o.z)<=22&&o.x*dir>0;}
function spClearWall(){if(G.wall){for(const p of G.wall)p.wallSpot=null;}G.wall=null;G.wallHold=0;}
function spBuildWall(bx,bz,team){
 spClearWall();
 const dir=team?-1:1,gx=HL*dir,D=hyp(gx-bx,bz),ux=(gx-bx)/D,uz=-bz/D,n=D<22?5:4;
 const c=G.teamP[1-team].filter(q=>q.role!=='GK'&&!q.out&&!ctlOf(q));
 c.sort((a,b)=>dist2(a.x,a.z,bx,bz)-dist2(b.x,b.z,bx,bz));
 const w=c.slice(0,n);G.wall=w;G.wallHold=99;
 w.forEach((p,i)=>{const k=(i-(w.length-1)/2)*.82;p.wallSpot=[bx+ux*9.15-uz*k,bz+uz*9.15+ux*k];p.jumped=false;});
}
function spBegin(kind,taker,train){
 const b=G.ball,dir=taker.team?-1:1,gx=HL*dir,D=hyp(gx-b.x,b.z);
 G.sp={kind,taker,D,aimZ:0,aimY:.45,power:0,charging:false,phase:'aim',timer:0,t:0,wait:0,train:!!train,canPass:kind==='free'&&!train,diff:spDiff()};
 b.owner=null;b.vx=b.vy=b.vz=0;b.y=BR;ballResetSpin(b);
 if(!train){const ux=(gx-b.x)/D,uz=-b.z/D,back=kind==='pen'?3.2:1.7;taker.x=b.x-ux*back;taker.z=b.z-uz*back;taker.face=Math.atan2(uz,ux);}
 taker.vx=taker.vz=0;taker.ctrlCd=0;G.charging=false;
}
function spCancel(){ // volta ao controle normal (passe na falta)
 const sp=G.sp;if(!sp)return;const t=sp.taker,b=G.ball;G.sp=null;G.charging=false;
 t.x=b.x-cos(t.face)*.6;t.z=b.z-sin(t.face)*.6;t.vx=t.vz=0;setOwner(t);
}
function spStep(dt){
 const sp=G.sp;if(!sp)return;
 const b=G.ball,t=sp.taker,I=In;
 if(sp.phase==='flight'){
  sp.t+=dt;
  if(G.state!=='play'||b.owner||sp.t>4.5||(sp.t>1.2&&hyp(b.vx,b.vz)<.8&&b.y<=BR+.05))G.sp=null;
  return;
 }
 if(G.state!=='play'||(!sp.train&&!G.restart)||t.out){G.sp=null;G.charging=false;return;}
 if(!sp.train&&ctlOf(t)!==LC){G.sp=null;G.charging=false;return;} // o controle saiu do cobrador (troca de jogador)
 if(sp.train&&I.pd('L3')){trainPlace();msg('NOVA COBRANÇA',1);return;} // Treino de falta: L3/C reinicia a cobrança
 const dir=t.team?-1:1,gx=HL*dir;
 if(sp.phase==='aim'){
  let ix=I.L.x,iy=I.L.y;if(I.kx||I.ky){ix=I.kx;iy=I.ky;}
  if(hyp(ix,iy)>.12){sp.aimZ=clamp(sp.aimZ+ix*dt*1.8,-1,1);sp.aimY=clamp(sp.aimY-iy*dt*1.2,.08,.95);}
  if(sp.canPass&&!sp.charging&&(I.dn.A||I.dn.B||I.dn.Y)){spCancel();return;}
  if(I.pd('X')){sp.charging=true;sp.power=0;}
  if(sp.charging){
   if(I.held.X){sp.power=Math.min(1,sp.power+dt/.9);G.charging=true;G.charge=sp.power;}
   else{G.charging=false;sp.charging=false;sp.phase='runup';sp.timer=sp.kind==='pen'?.55:.42;sp.power=Math.max(.28,sp.power);}
  }
  t.vx=t.vz=0;t.face=Math.atan2(sp.aimZ*GW*.92-t.z,gx-t.x);
 }else if(sp.phase==='runup'){
  if(G.wall&&sp.wait<3&&G.wall.some(q=>q.wallSpot&&dist2(q.x,q.z,q.wallSpot[0],q.wallSpot[1])>1.4)){sp.wait+=dt;t.vx=t.vz=0;return;} // espera a barreira se formar (no máx. 3 s)
  sp.timer-=dt;
  const dx=b.x-t.x,dz=b.z-t.z,d=hyp(dx,dz)||1,sv=Math.min(7,d/Math.max(sp.timer,.08));
  t.vx=dx/d*sv;t.vz=dz/d*sv;t.face=Math.atan2(dz,dx);
  if(sp.timer<=0){
   t.vx=t.vz=0;
   spKick(t,sp.kind,sp.aimZ,sp.aimY,sp.power,false);
   sp.phase='flight';sp.t=0;
  }
 }
}
/* Chute da cobrança. Alvo = retículo (aimZ,aimY) + erro da curva de força (penErr), igual ao pênalti. Vale para usuário e IA. */
function spKick(p,kind,aimZ,aimY,power,ai){
 const b=G.ball,dir=p.team?-1:1,gx=HL*dir,d=PEN_DIFF[spDiff()],free=kind==='free',D0=hyp(gx-b.x,b.z);
 let tz=aimZ*GW*.92,ty=.25+aimY*(GH-.35);
 let err=(ai?penErr(power)*(1.25-d.aiAim*.4):penErr(power)*d.userErr)*(free?1+Math.max(0,D0-11)/22:1);
 if(p.stun>0)err*=1.5;
 tz+=(rnd()-.5)*2*err*GW;ty+=(rnd()-.5)*err*1.4;ty=clamp(ty,.15,GH+.4);
 const dist=hyp(gx-b.x,tz-b.z),a0=Math.atan2(tz-b.z,gx-b.x);
 if(!free){ // pênalti: velocidade pela força, elevação exata p/ a altura escolhida (idêntico a penDoKick)
  const v=14+16*power;
  solveAim(b.x,b.y,b.z,a0,dist,ty,v,0,0,power<.4?.9:12);
  const vy=AQ.vy;
  kickBall(p,cos(a0)*v,vy,sin(a0)*v,'kick',power<.4?{roll:true}:{top:.03});
  b.pen=true;G.shake=Math.max(G.shake,.15+power*.2);
  if(!G.train){const gk=G.teamP[1-p.team][0];if(gk&&!gk.out&&vsAI(gk.team))penGkReact(false,{gk,diff:spDiff(),kickTeam:p.team,aimZ:clamp(tz/(GW*.92),-1,1),aimY:aimY,atkDir:dir,gkDecided:false});}
 }else{ // falta: trajetória em arco que passa por cima da barreira (9,15 m) e cai no ponto mirado; força alta = mais rasa/rápida, baixa = mais alta/lenta
  const side=ai?0:userCurl(p,cos(a0),sin(a0)),top=power>.8?.05:0,wd=Math.min(9.15,dist-3),vy0=3.2+3.2*(1-Math.min(power,1));
  let vy=vy0,vh=16,phi=0;
  for(let k=0;k<14;k++){
   vy=vy0+k*.5;let lo=8,hi=36;
   for(let i=0;i<9;i++){const m=(lo+hi)/2;flightAt(b.x,b.y,b.z,a0+phi,a0,dist,m,vy,side,top);if(FQ.y>ty)hi=m;else lo=m;}
   vh=(lo+hi)/2;flightAt(b.x,b.y,b.z,a0+phi,a0,wd,vh,vy,side,top);
   if(FQ.y>=2.3)break; // altura sobre a barreira (jogador 1,8 m + folga)
  }
  for(let i=0;i<3;i++){flightAt(b.x,b.y,b.z,a0+phi,a0,dist,vh,vy,side,top);phi-=FQ.lat/dist;} // compensa a curva
  const a=a0+phi;
  kickBall(p,cos(a)*vh,vy,sin(a)*vh,'kick',{side:side,top:top,roll:false});
  if(vh>27)G.shake=Math.max(G.shake,.2);
 }
 G.stats[p.team].shots++;if(!G.train&&p.team===0)achAdd('amistoso','shots',1);
}
function spAI(p,kind){ // IA cobra: canto/ângulo aleatório, força na faixa boa
 const d=PEN_DIFF[spDiff()],side=rnd()<.5?-1:1;
 const aimZ=clamp(side*(.5+rnd()*.4)*(.6+d.aiAim*.4)+(rnd()-.5)*(1-d.aiAim)*.8,-1,1);
 spKick(p,kind,aimZ,kind==='pen'?.25+rnd()*.55:.3+rnd()*.55,kind==='pen'?.55+rnd()*.4:.6+rnd()*.3,true);
}
function penDoKick(ai){
 const pen=G.pen,t=pen.taker,b=G.ball,dir=pen.atkDir,d=PEN_DIFF[pen.diff];
 const gx=HL*dir;
 // alvo no gol
 let tz=pen.aimZ*GW*.92;
 let ty=.25+pen.aimY*(GH-.35);
 // erro
 let err=(ai?(.12-d.aiAim*.08):penErr(pen.power)) * d.userErr;
 tz+=(rnd()-.5)*2*err*GW;
 ty+=(rnd()-.5)*err*1.4;
 ty=clamp(ty,.15,GH+.4);
 // velocidade
 const power=pen.power;
 let v=14+16*power;
 const dx=gx-b.x,dz=tz-b.z,dist=hyp(dx,dz);
 const a=Math.atan2(dz,dx);
 solveAim(b.x,b.y,b.z,a,dist,ty,v,0,0,power<.4?.9:12); // elevação exata p/ a altura escolhida
 const vy=AQ.vy;
 t.kickT=.32;t.face=a;
 kickBall(t,cos(a)*v,vy,sin(a)*v,'kick',power<.4?{roll:true}:{top:.03});
 b.owner=null;b.gkRolled=false;
 G.shake=Math.max(G.shake,.15+power*.2);
}
function penGkReact(userForced,pen0){
 const pen=pen0||G.pen;if(!pen||pen.gkDecided)return;
 const gk=pen.gk,b=G.ball,d=PEN_DIFF[pen.diff];
 pen.gkDecided=true;
 // decide lado do mergulho
 let side;
 if(userForced&&pen.kickTeam===1){
  side=Math.sign(pen.userDive)||(rnd()>.5?1:-1);
 }else{
  // IA: chance de ir no lado certo proporcional à dificuldade
  const trueSide=Math.sign(pen.aimZ)||(rnd()>.5?1:-1);
  if(rnd()<d.gk)side=trueSide;else side=-trueSide*(rnd()>.3?1:0);
 }
 const high=pen.aimY>.55;
 gk.diveT=.7+d.gk*.15;
 gk.dvz=side||(rnd()>.5?1:-1);
 gk.vz=gk.dvz*(6.2+3.5*d.gk);
 gk.vx*=.25;
 gk.face=Math.atan2(gk.dvz,pen.atkDir*-.3);
 if(high)gk.jumpT=.45;
}
function penCheckEnd(){
 const pen=G.pen;
 // morte súbita: quem errou / acertou decide
 if(pen.sudden){
  if(pen.taken[0]===pen.taken[1]&&pen.taken[0]>0){
   if(pen.scores[0]!==pen.scores[1])return true;
  }
  return false;
 }
 // após ambos terem o mesmo nº de cobranças (até 5), verifica se já decidiu
 const a=pen.taken[0],b=pen.taken[1];
 if(a<5||b<5){
  // ainda há cobranças: pode já estar decidido matematicamente
  const leftA=5-a,leftB=5-b;
  if(pen.scores[0]+leftA<pen.scores[1])return true;
  if(pen.scores[1]+leftB<pen.scores[0])return true;
  return false;
 }
 return pen.scores[0]!==pen.scores[1];
}
function penEnd(){
 const pen=G.pen;if(!pen)return;
 pen.phase='end';
 G.state='end';G.stateT=9e9;
 const w=pen.scores[0]>pen.scores[1]?0:1;
 msg((w===0?'VITÓRIA!':'DERROTA!')+'  '+TEAMA[0]+' '+pen.scores[0]+' x '+pen.scores[1]+' '+TEAMA[1],3.5);
 setTimeout(showPenResult,2200);
}
function showPenResult(){
 const pen=G.pen;if(!pen)return;
 const w=pen.scores[0]>pen.scores[1]?0:1;
 $('#pen-r-title').textContent=w===0?'VITÓRIA!':'DERROTA';
 $('#pen-r-score').textContent=TEAMA[0]+' '+pen.scores[0]+' - '+pen.scores[1]+' '+TEAMA[1];
 $('#pen-r-winner').textContent=TEAMN[w]+' venceu a disputa'+(pen.sudden?' (morte súbita)':'');
 const lab={goal:'GOL',save:'DEFESA',miss:'FORA',post:'TRAVE'};
 const cls={goal:'ph-ok',save:'ph-save',miss:'ph-no',post:'ph-no'};
 let h='';
 pen.history.forEach((k,i)=>{
  h+='<div class="ph-row"><span>'+(i+1)+'. '+TEAMA[k.team]+' · cobrança '+k.n+'</span><span class="'+(cls[k.result]||'')+'">'+(lab[k.result]||k.result)+'</span></div>';
 });
 $('#pen-r-hist').innerHTML=h||'<div class="ph-row">Sem cobranças registradas</div>';
 show('pen-result');
}
// botões do modo pênaltis
$('#b-pen').onclick=()=>{Au.play('ui');openPenSetup();};
$('#b-pen-start').onclick=()=>startPenalties();
$('#b-pen-again').onclick=()=>{const cfg=G.pen&&G.pen.cfg;G.pen=null;startPenalties(cfg);};
$('#b-pen-menu').onclick=()=>{G.pen=null;G.state='menu';Au.play('ui');show('title');};

/* ---------------- Loop principal ---------------- */
let lastTs=0,fpsShow=60,fAcc=0,fN=0,adaptT=0,msAvg=16;
function globalInput(dt){
 if(In.pd('MENU'))pauseGame();
 if(In.pd('NEXT')){S.cam=(S.cam+1)%5;msg('CÂMERA: '+['TRANSMISSÃO','LATERAL','DINÂMICA','PRÓXIMA','PERSONALIZADA'][S.cam],1.2,true);saveCfg();}
 if(In.pd('PREV')){S.cam=(S.cam+4)%5;msg('CÂMERA: '+['TRANSMISSÃO','LATERAL','DINÂMICA','PRÓXIMA','PERSONALIZADA'][S.cam],1.2,true);saveCfg();}
 const rbEl=$('#hb-RB');if(rbEl&&G.user)rbEl.classList.toggle('cd',G.user.skillCd>0&&G.ball.owner===G.user);
 let ch=false;
 if(In.held.DU){S.camZ=clamp(S.camZ+.7*dt,.6,1.8);ch=true;}
 if(In.held.DD){S.camZ=clamp(S.camZ-.7*dt,.6,1.8);ch=true;}
 if(In.held.DL){S.camA=clamp(S.camA-45*dt,-60,60);ch=true;}
 if(In.held.DR){S.camA=clamp(S.camA+45*dt,-60,60);ch=true;}
 if(!ch&&(In.up.DU||In.up.DD||In.up.DL||In.up.DR)){saveCfg();In.up.DU=In.up.DD=In.up.DL=In.up.DR=false;}
}
/* ===================== MULTIPLAYER · 2 JOGADORES (LAN / ONLINE) =====================
   Arquitetura: o ANFITRIÃO roda a simulação inteira e é a autoridade da partida.
   O VISITANTE só envia seus comandos (analógicos + botões) e desenha o estado recebido, com interpolação.
   • Transporte LAN    : WebSocket até o servidor local (server.js, Node) — sem internet, só a mesma Wi-Fi.
   • Transporte ONLINE : WebRTC via PeerJS. ATENÇÃO: usa servidor de sinalização na internet (NÃO é LAN offline).
   Mensagens (JSON):  hello · start · i (comandos) · s (snapshot) · m (mensagem) · p (pausa) · ping/pong · bye
   ==================================================================================== */
const NET_V=3,NET_KEYS=['A','B','X','Y','RB','LB','LT','RT','L3','R3'];
const NETSND=new Set(['kick','pass','bounce','tackle','post','net','save','miss','ooh','whistle','foul','whistleEnd','goal','dash','slide','corner']);
const NET_SNAP_MS=40,NET_IN_MS=25,NET_PORT=3000;
const NET_ERR={'no-room':'Sala não encontrada. Confira o código.','room-full':'A sala já tem 2 jogadores.','bad-code':'Código inválido.','in-use':'Código já em uso.','busy':'Servidor ocupado.'};
const r2=v=>Math.round(v*100)/100;
const isNum=v=>typeof v==='number'&&isFinite(v);
const nclamp=(v,a,b,d)=>isNum(v)?clamp(v,a,b):d;
function cleanCfg(c){ // assistências do visitante (validadas)
 c=c||{};return{sens:nclamp(c.sens,.6,1.6,1),aPass:nclamp(c.aPass,0,100,70),aShot:nclamp(c.aShot,0,100,50),aCross:nclamp(c.aCross,0,100,60),
  aMove:nclamp(c.aMove,0,100,50),pPow:nclamp(c.pPow,.6,1.6,1),autoSwitch:c.autoSwitch!==false};
}
function netClub(){ // CLUB com os 11 titulares já resolvidos (o visitante não precisa dos arquivos de elenco)
 const ids=CLUB.teams.map(t=>t.id),R=buildRoster(ids);
 return Object.assign({},CLUB,{players:R.map(r=>r.map(x=>({pid:x.pid||null,name:x.name,num:x.num,skin:x.skin,hair:x.hair,body:x.body})))});
}
function cleanClub(c){ // clube recebido do anfitrião (validado)
 try{
  if(!c||!Array.isArray(c.teams)||!Array.isArray(c.players)||c.teams.length<2||c.players.length<2)return null;
  const s=(v,d)=>typeof v==='string'&&v?v.slice(0,24):d,col=(v,d)=>(typeof v==='string'&&/^#[0-9a-fA-F]{6}$/.test(v))?v:d;
  const out={teams:[],players:[[],[]],ui:CLUB.ui};
  for(let t=0;t<2;t++){
   const T=c.teams[t]||{};
   out.teams.push(cleanTeamSpec(T,t));
   for(let i=0;i<11;i++){
    const P=(c.players[t]||[])[i]||{},DP=EDITOR_DEFAULT.players[t][i];
    out.players[t].push({pid:(typeof P.pid==='string'&&/^[a-z0-9._-]{3,60}$/i.test(P.pid))?P.pid:null,name:s(P.name,DP.name),num:clamp(parseInt(P.num)||DP.num,1,99),skin:col(P.skin,DP.skin),hair:col(P.hair,DP.hair),body:nclamp(+P.body,.8,1.2,1)});
   }
  }
  return out;
 }catch(e){return null;}
}

const Net={
 role:null,           // 'host' | 'guest'
 mode:'lan',          // 'lan' (WebSocket + server.js) | 'online' (PeerJS)
 mp:false,            // partida multiplayer montada (host ou visitante)
 connected:false,     // o outro jogador está ligado agora
 ready:false,state:'idle',code:'',ips:[],port:NET_PORT,srvHost:'',
 ws:null,peer:null,conn:null,_gen:0,_timer:0,_reconT:0,_recon:false,_retry:0,_bye:false,_exitT:0,_bannerT:0,
 buf:[],evq:[],evOut:[],off:null,jit:0,delay:110,sq:0,qi:0,
 lastRx:0,lastSnap:0,lastIn:0,lastInSent:0,rtt:0,hostLen:0,other:null,_clubBackup:null,_sig:'',_stale:false,
 statusText:'',statusKind:'idle',_hold:0,_forceNew:false,
 get fwd(){return this.role==='host'&&this.mp&&this.connected;},

 /* ---------- interface (status, faixa de aviso, indicador de ping) ---------- */
 setStatus(t,kind){
  this.statusText=t;this.statusKind=kind||'idle';
  const el=document.getElementById('multi-status');
  if(el){el.className='mp-status st-'+this.statusKind;const sp=el.querySelector('span');if(sp)sp.textContent=t;}
  try{console.log('[Net]',t);}catch(e){}
 },
 banner(t,kind,ms){
  const el=document.getElementById('net-banner');if(!el)return;
  clearTimeout(this._bannerT);
  if(!t){el.className='';el.textContent='';return;}
  el.textContent=t;el.className='on '+(kind||'');
  if(ms)this._bannerT=setTimeout(()=>{el.className='';el.textContent='';},ms);
 },
 hud(){
  const el=document.getElementById('net-hud');if(!el)return;
  if(!this.mp||!this.role){el.className='';return;}
  let q,txt;
  if(!this.connected){q='bad';txt=(this.role==='host'?'ANFITRIÃO · sem jogador 2':'SEM CONEXÃO');}
  else if(this.role==='guest'){q=this.rtt<60?'ok':this.rtt<130?'mid':'bad';txt='VISITANTE · '+Math.round(this.rtt)+' ms';}
  else{q='ok';txt='ANFITRIÃO · J2 conectado';}
  el.className='on '+q;el.textContent='● '+txt;
 },

 /* ---------- servidor LAN ---------- */
 parseServer(s){
  s=(s||'').trim().replace(/^(https?|wss?):\/\//i,'').replace(/[\/?#].*$/,'');
  if(!s||!/^[A-Za-z0-9.\-]+(:\d{1,5})?$/.test(s))return null;
  if(!/:\d+$/.test(s))s+=':'+NET_PORT;
  return s;
 },
 serverHost(){
  const inp=document.getElementById('mp-server');
  let h=this.parseServer(inp?inp.value:'');
  if(!h&&/^https?:$/.test(location.protocol)&&location.host)h=location.host;
  return h;
 },
 httpBase(){const h=this.serverHost();return h?'http://'+h:'';},
 genCode12(){const c='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';let r='';for(let i=0;i<12;i++)r+=c[Math.floor(Math.random()*c.length)];return r;},
 loadPeerLib(){
  return new Promise(res=>{
   if(typeof Peer!=='undefined')return res(true);
   const s=document.createElement('script');s.src='https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
   s.onload=()=>res(typeof Peer!=='undefined');s.onerror=()=>res(false);
   setTimeout(()=>res(typeof Peer!=='undefined'),9000);
   document.head.appendChild(s);
  });
 },

 /* ---------- ciclo de vida ---------- */
 reset(){ // encerra tudo (idempotente): conexões, timers, estado do multiplayer
  this._gen++;clearInterval(this._timer);this._timer=0;clearTimeout(this._reconT);clearTimeout(this._exitT);clearTimeout(this._bannerT);
  try{if(this.role&&this.ws&&this.ws.readyState===1)this.ws.send(JSON.stringify({t:'bye'}));}catch(e){}
  try{if(this.role&&this.conn&&this.conn.open)this.conn.send({t:'bye'});}catch(e){}
  try{if(this.ws)this.ws.close();}catch(e){}
  try{if(this.conn)this.conn.close();}catch(e){}
  try{if(this.peer)this.peer.destroy();}catch(e){}
  this.ws=this.conn=this.peer=null;
  if(this._clubBackup){CLUB=this._clubBackup;this._clubBackup=null;applyClub();}
  this.role=null;this.mp=false;this.connected=false;this.ready=false;this.state='idle';this.code='';this.hostLen=0;this._recon=false;this._retry=0;this._bye=false;
  RC.active=false;RC.user=null;RC.cfg=null;RC.basis=null;RC.charging=false;RC.charge=0;RC.autoSprint=false;RC.I.releaseAll();RC.I.clear();
  this.buf.length=0;this.evq.length=0;this.evOut.length=0;this.off=null;this.jit=0;this.other=null;this.rtt=0;
  this.banner('');this.hud();
 },
 _start(){ // timers de batimento (ping, timeout, indicador)
  if(this._timer)return;
  this._timer=setInterval(()=>this._beat(),1000);
 },
 _beat(){
  const now=performance.now();
  if(this.role==='guest'&&this.connected)this.send({t:'ping',ts:now});
  if(this.connected&&this.lastRx&&now-this.lastRx>(this.role==='host'?7000:6000)){
   if(this.role==='host')this._peerDown('timeout');else this._linkLost();
  }
  this.hud();
 },

 /* ---------- criar sala (anfitrião) ---------- */
 async createHost(mode){
  this.reset();this.mode=mode;this.role='host';this.state='creating';this.lastRx=0;
  if(mode==='online'){
   this.setStatus('Carregando PeerJS (precisa de internet)…','search');
   if(!await this.loadPeerLib()){this.fail('Sem internet: não foi possível carregar o PeerJS. Use o modo LAN.');return;}
   if(!this.role)return;
   this.code=this.genCode12();
   const peer=this.peer=new Peer('fc3d'+this.code.toLowerCase());
   peer.on('open',()=>{this.state='waiting';this.setStatus('Sala criada. Envie o código e aguarde o outro jogador.','wait');lobbyHostInfo();this._start();});
   peer.on('connection',conn=>{if(this.conn&&this.conn.open){try{conn.close();}catch(e){}return;}this._bindConn(conn);});
   peer.on('error',e=>{this.fail('Erro: '+(e&&e.type||e));});
   peer.on('disconnected',()=>{try{peer.reconnect();}catch(e){}});
   return;
  }
  const host=this.serverHost();
  if(!host){this.fail('Informe o endereço do servidor LAN (IP:porta).');return;}
  this.srvHost=host;
  this.setStatus('Conectando ao servidor da rede local…','search');
  this._openWS(host,()=>{this.ws.send(JSON.stringify({c:'create',name:'Anfitrião'}));});
 },
 /* ---------- entrar na sala (visitante) ---------- */
 async createGuest(mode,code){
  code=(code||'').trim().toUpperCase().replace(/[^A-Z0-9]/g,'');
  this.reset();this.mode=mode;this.role='guest';this.state='connecting';this.lastRx=0;
  if(mode==='online'){
   if(code.length!==12){this.fail('O código online tem 12 caracteres.');return;}
   this.code=code;this.setStatus('Carregando PeerJS (precisa de internet)…','search');
   if(!await this.loadPeerLib()){this.fail('Sem internet: não foi possível carregar o PeerJS. Use o modo LAN.');return;}
   if(!this.role)return;
   this.setStatus('Conectando…','conn');
   const peer=this.peer=new Peer();
   peer.on('open',()=>{this._bindConn(peer.connect('fc3d'+code.toLowerCase(),{reliable:true,serialization:'json'}));});
   peer.on('error',e=>{this.fail(e&&e.type==='peer-unavailable'?'Código não encontrado.':'Erro: '+(e&&e.type||e));});
   setTimeout(()=>{if(this.role==='guest'&&!this.connected&&this.state==='connecting')this.fail('Tempo esgotado. Confira o código e a internet.');},15000);
   return;
  }
  if(code.length!==4){this.fail('O código da sala LAN tem 4 caracteres.');return;}
  const host=this.serverHost();
  if(!host){this.fail('Informe o endereço do servidor LAN (IP:porta).');return;}
  this.code=code;this.srvHost=host;
  this.setStatus('Conectando…','conn');
  this._openWS(host,()=>{this.ws.send(JSON.stringify({c:'join',code}));});
 },
 fail(t){
  this.setStatus(t,'err');this.state='error';this._hold=performance.now()+7000;
  try{if(this.ws)this.ws.close();}catch(e){}try{if(this.peer)this.peer.destroy();}catch(e){}
  this._gen++;this.ws=this.peer=this.conn=null;clearInterval(this._timer);this._timer=0;
  if(!this.mp)this.role=null;
  lobbyHostInfo();
 },

 /* ---------- transporte ---------- */
 _openWS(host,onopen){
  if(location.protocol==='https:'){this.fail('Esta página usa HTTPS e o navegador bloqueia o servidor LAN (HTTP). Abra o jogo por http://'+host+'/');return;}
  const gen=this._gen;let ws;
  try{ws=new WebSocket('ws://'+host+'/ws');}catch(e){this._connFail(host);return;}
  this.ws=ws;let opened=false;
  const to=setTimeout(()=>{if(gen===this._gen&&!opened){try{ws.close();}catch(e){}this._connFail(host);}},6000);
  ws.onopen=()=>{if(gen!==this._gen)return;opened=true;clearTimeout(to);this.lastRx=performance.now();this._start();onopen();};
  ws.onmessage=ev=>{if(gen!==this._gen)return;this._rx(ev.data);};
  ws.onclose=()=>{clearTimeout(to);if(gen!==this._gen)return;if(!opened)this._connFail(host);else this._onLinkClose();};
  ws.onerror=()=>{};
 },
 _connFail(host){
  if(this._recon){this._reconT=setTimeout(()=>this._tryReconnect(),1800);return;}
  this.fail('Não foi possível conectar ao servidor '+host+'. Confira o IP, a Wi-Fi e se o servidor (node server.js) está rodando.');
 },
 _bindConn(conn){ // PeerJS
  this.conn=conn;
  conn.on('open',()=>{this.lastRx=performance.now();if(this.role==='host')this._peerUp();else this._sendHello();});
  conn.on('data',d=>this._rx(d));
  conn.on('close',()=>{if(this.conn!==conn)return;this.conn=null;if(this.role==='host')this._peerDown('closed');else this._hostGone('Conexão encerrada.');});
  conn.on('error',()=>{});
 },
 send(o){
  try{
   if(this.mode==='lan'){const w=this.ws;if(w&&w.readyState===1)w.send(JSON.stringify(o));}
   else{const c=this.conn;if(c&&c.open)c.send(o);}
  }catch(e){}
 },
 _canSend(){return this.mode!=='lan'||!this.ws||this.ws.bufferedAmount<200000;},
 _rx(raw){
  let m=raw;
  if(typeof raw==='string'){if(raw.length>200000)return;try{m=JSON.parse(raw);}catch(e){return;}}
  if(!m||typeof m!=='object')return;
  this.lastRx=performance.now();
  if(typeof m.s==='string')this._onServer(m);else this._onApp(m);
 },
 _onServer(m){
  switch(m.s){
   case 'created':
    this.code=String(m.code||'');this.ips=Array.isArray(m.ips)?m.ips.slice(0,6):[];this.port=+m.port||NET_PORT;
    if(this._recon){this._recon=false;this.banner(this.mp?'Servidor reconectado. Aguardando o outro jogador…':'','warn',this.mp?4000:0);}
    this.state='waiting';this.setStatus('Aguardando jogador…','wait');lobbyHostInfo();break;
   case 'joined':
    if(this._recon){this._recon=false;this.banner('Reconectado!','ok',2500);}
    this.state='connecting';this.setStatus('Conectado à sala '+this.code+'. Aguardando o anfitrião…','conn');this._sendHello();break;
   case 'peer':this._peerUp();break;
   case 'peer-left':this._peerDown('left');break;
   case 'closed':
    if(this._bye)this._hostGone('O anfitrião encerrou a partida.');
    else if(this.mp)this._startReconnect();else this._hostGone('O anfitrião encerrou a sala.');break;
   case 'error':
    if(this._recon){try{this.ws.close();}catch(e){}this._gen++;this.ws=null;this._reconT=setTimeout(()=>this._tryReconnect(),1800);return;}
    this.fail(NET_ERR[m.e]||('Erro do servidor: '+m.e));break;
   case 'pong':break;
  }
 },
 _onLinkClose(){ // o WebSocket caiu depois de aberto
  if(!this.role)return;
  this.ws=null;
  if(this._bye){this._hostGone('O anfitrião encerrou a partida.');return;}
  if(!this.mp){this.fail('A conexão com o servidor foi perdida.');return;}
  this._startReconnect();
 },
 _linkLost(){ // visitante sem receber nada (Wi-Fi caiu sem fechar a conexão)
  if(this.mode==='lan'&&this.role==='guest')this._startReconnect();else this._hostGone('Conexão perdida.');
 },
 _startReconnect(){
  if(this._recon||!this.role||this.mode!=='lan')return;
  this._recon=true;this._retry=0;this.connected=false;this.state='reconnecting';
  if(this.role==='host'){RC.active=false;RC.I.releaseAll();}
  this.banner('Reconectando…','warn',0);this.hud();this._tryReconnect();
 },
 _tryReconnect(){
  if(!this._recon||!this.role)return;
  if(++this._retry>14){this._recon=false;this._giveUp(this.role==='host'?'Sem conexão com o servidor. Seguindo contra a IA.':'Não foi possível reconectar.');return;}
  this.setStatus('Reconectando… ('+this._retry+')','search');
  this.banner('Reconectando… ('+this._retry+')','warn',0);
  this._gen++;try{if(this.ws)this.ws.close();}catch(e){}this.ws=null;
  const host=this.srvHost;
  this._openWS(host,()=>{this.ws.send(JSON.stringify(this.role==='host'?{c:'create',code:this.code,name:'Anfitrião'}:{c:'join',code:this.code}));});
 },
 _giveUp(t){
  this.banner(t,'err',0);this.state='error';
  if(this.role==='host'){this.connected=false;RC.active=false;return;} // anfitrião continua jogando contra a IA
  clearTimeout(this._exitT);
  this._exitT=setTimeout(()=>this._leaveToMenu(),2800);
 },
 _leaveToMenu(){G.paused=false;G.train=null;G.pen=null;G.career=false;G.state='menu';this.reset();show('title');},

 /* ---------- aperto de mão ---------- */
 _cfgOut(){return{sens:S.sens,aPass:S.aPass,aShot:S.aShot,aCross:S.aCross,aMove:S.aMove,pPow:S.pPow,autoSwitch:!!S.autoSwitch};},
 _sendHello(){this.send({t:'hello',v:NET_V,cfg:this._cfgOut()});},
 _peerUp(){ // anfitrião: o visitante apareceu; espera o 'hello' (traz as configurações dele)
  this.lastRx=performance.now();
  this.setStatus('Jogador 2 conectado! Iniciando…','ok');
  if(this.mp)this.banner('Jogador 2 voltou! Retomando…','ok',2500);
 },
 _peerDown(reason){ // anfitrião: o visitante saiu / caiu
  if(this.role!=='host')return;
  const was=this.connected||RC.active;
  this.connected=false;RC.active=false;RC.I.releaseAll();RC.I.clear();this.buf.length=0;
  if(!this.mp){this.state='waiting';this.setStatus('Jogador 2 saiu. Aguardando outro jogador…','wait');lobbyHostInfo();return;}
  if(was){
   msg('JOGADOR 2 DESCONECTOU',2.6,true);
   this.banner('Jogador 2 desconectou · o time dele passou para a IA · para voltar ele entra com o código '+this.code,'warn',9000);
  }
  this.state='peer-lost';this.hud();
 },
 _hostGone(t){ // visitante: a partida acabou do lado do anfitrião
  if(this.role!=='guest')return;
  this.connected=false;this.state='closed';this.hud();
  if(!this.mp){this.fail(t);return;}
  this.banner(t+' Voltando ao menu…','err',0);
  clearTimeout(this._exitT);this._exitT=setTimeout(()=>this._leaveToMenu(),2800);
 },
 _onHello(m){ // anfitrião
  if(this.role!=='host')return;
  if(m.v!==NET_V){this.send({t:'start',v:NET_V,bad:1});this.setStatus('Versão do jogo diferente no outro aparelho. Atualize os arquivos.','err');return;}
  RC.cfg=cleanCfg(m.cfg);
  this._startHost();
 },
 _startHost(){
  const resume=this.mp&&G.state!=='menu'&&G.players.length>0&&!this._forceNew;
  this._forceNew=false;
  this.mp=true;this.connected=true;this.ready=true;this.state='playing';this._stale=false;this.lastIn=performance.now();
  RC.I.releaseAll();RC.I.clear();RC.charging=false;
  this.send({t:'start',v:NET_V,resume:resume?1:0,club:netClub(),len:S.len});
  if(resume){
   RC.active=true;if(!RC.user)RC.user=G.teamP[1][9];
   this.lastSnap=0;this.banner('Jogador 2 reconectado!','ok',2500);msg('JOGADOR 2 RECONECTOU',2,true);
  }else{
   Au.init();Au.resume();G.career=false;G.train=null;G.pen=null;G._penKeep=false;
   startMatch();
  }
  this.setStatus('Partida iniciada','ok');this.hud();
 },
 rematch(){if(this.role==='host'&&this.connected){this._forceNew=true;this._startHost();}else startMatch();},
 _onStart(m){ // visitante
  if(this.role!=='guest')return;
  if(m.bad||m.v!==NET_V){this.fail('Versão do jogo diferente do anfitrião. Atualize os arquivos nos dois aparelhos.');return;}
  this.connected=true;this.state='playing';this.hostLen=nclamp(+m.len,2,10,4);
  if(m.resume&&G.players.length&&G.state!=='menu'){this.buf.length=0;this.evq.length=0;this.off=null;this.ready=true;this.setStatus('Partida iniciada','ok');this.hud();return;}
  const club=cleanClub(m.club);
  if(club){if(!this._clubBackup)this._clubBackup=CLUB;CLUB=club;}
  this.mp=true;this.ready=false;this.buf.length=0;this.evq.length=0;this.evOut.length=0;this.off=null;this.jit=0;
  G.career=false;G.train=null;G.pen=null;G._penKeep=false;
  Au.init();Au.resume();
  startMatch();
  this.ready=true;this.setStatus('Partida iniciada','ok');this.hud();
 },

 /* ---------- mensagens do aplicativo ---------- */
 _onApp(m){
  switch(m.t){
   case 'hello':this._onHello(m);break;
   case 'start':this._onStart(m);break;
   case 'i':this._onInput(m);break;
   case 's':this._onSnap(m);break;
   case 'm':if(this.role==='guest'&&typeof m.x==='string')msg(m.x.slice(0,60),nclamp(+m.d,.5,6,1.5),true);break;
   case 'p':if(this.role==='guest')this.banner(m.on?'PARTIDA PAUSADA PELO ANFITRIÃO':'','warn',0);break;
   case 'ping':this.send({t:'pong',ts:m.ts});break;
   case 'pong':if(isNum(m.ts)){const r=performance.now()-m.ts;this.rtt=this.rtt?this.rtt*.7+r*.3:r;}break;
   case 'bye':this._bye=true;if(this.role==='guest')this._hostGone('O anfitrião encerrou a partida.');else this._peerDown('left');break;
  }
 },
 ev(k,a,b){if(this.evq.length<200)this.evq.push([k,a,b]);},
 sendMsg(t,d){if(this.fwd)this.send({t:'m',x:t,d:d});},
 sendPause(on){if(this.role==='host'&&this.connected)this.send({t:'p',on:on?1:0});},

 /* ============ ANFITRIÃO: snapshots e comandos remotos ============ */
 tick(){
  if(!this.connected)return;
  const now=performance.now();
  if(RC.active&&!this._stale&&now-this.lastIn>600){RC.I.releaseAll();this._stale=true;} // sem comandos há 0,6 s: solta tudo (evita botão preso)
  if(now-this.lastSnap>=NET_SNAP_MS&&this._canSend()){this.lastSnap=now;this.send(this.packSnap());}
 },
 packSnap(){
  const b=G.ball,P=G.players,pl=new Array(P.length);
  for(let i=0;i<P.length;i++){
   const p=P[i];
   pl[i]=[r2(p.x),r2(p.z),r2(p.vx),r2(p.vz),r2(p.face),(p.sprint?1:0)|(p.out?2:0)|(p.shield?4:0),
    r2(p.slideT),r2(p.stun),r2(p.stumbleT),r2(p.celeb),p.celebType|0,r2(p.diveT),Math.sign(p.dvz)|0,r2(p.jumpT),r2(p.kickT),r2(p.skillCd)];
  }
  const idx=q=>q?q.team*11+q.i:-1;
  const st=G.stats;
  return{t:'s',q:++this.sq,ts:performance.now(),c:r2(G.clock),h:G.half,sc:G.score.slice(),st:G.state,sT:Math.min(r2(G.stateT),9999),
   gt:G.goalTeam|0,lt:idx(G.lastTouch),pt:G.possTeam|0,
   b:[r2(b.x),r2(b.y),r2(b.z),r2(b.vx),r2(b.vy),r2(b.vz),r2(b.spin||0),idx(b.owner)],
   p:pl,gu:idx(RC.user),hu:idx(G.user),ch:[RC.charging?1:0,Math.round(clamp(RC.charge,0,1.1)*100)],
   ss:[[st[0].shots,st[0].passes,st[0].fouls,st[0].cards,r2(st[0].poss)],[st[1].shots,st[1].passes,st[1].fouls,st[1].cards,r2(st[1].poss)]],
   ev:this.evq.splice(0)};
 },
 _onInput(m){ // validação + aplicação dos comandos do visitante na MESMA estrutura de entrada do controle local
  if(this.role!=='host'||!RC.active)return;
  const I=RC.I;
  if(Array.isArray(m.L)&&isNum(m.L[0])&&isNum(m.L[1])){let x=clamp(m.L[0],-1,1),y=clamp(m.L[1],-1,1);const h=hyp(x,y);if(h>1){x/=h;y/=h;}I.L.x=x;I.L.y=y;}
  if(Array.isArray(m.R)&&isNum(m.R[0])&&isNum(m.R[1])){let x=clamp(m.R[0],-1,1),y=clamp(m.R[1],-1,1);const h=hyp(x,y);if(h>1){x/=h;y/=h;}I.R.x=x;I.R.y=y;}
  const cb=m.cb;
  if(Array.isArray(cb)&&cb.length>=4&&cb.every(isNum)){const a=hyp(cb[0],cb[1]),g=hyp(cb[2],cb[3]);
   if(a>.5&&a<1.5&&g>.5&&g<1.5)RC.basis={grx:cb[0]/a,grz:cb[1]/a,gfx:cb[2]/g,gfz:cb[3]/g};}
  if(Array.isArray(m.e)){for(let i=0;i<m.e.length&&i<24;i++){const e=m.e[i];if(!Array.isArray(e)||NET_KEYS.indexOf(e[0])<0)continue;if(e[1])I.press(e[0]);else I.release(e[0]);}}
  if(Array.isArray(m.h)){
   const hs={};for(const k of m.h)if(NET_KEYS.indexOf(k)>=0)hs[k]=1;
   for(const k of NET_KEYS){if(hs[k]&&!I.held[k])I.press(k);else if(!hs[k]&&I.held[k])I.release(k);}
  }
  this.lastIn=performance.now();this._stale=false;
 },

 /* ============ VISITANTE: receber, interpolar, enviar comandos ============ */
 _onSnap(m){
  if(this.role!=='guest'||!this.ready||!G.players.length)return;
  if(!isNum(m.ts)||!Array.isArray(m.p)||m.p.length!==G.players.length||!Array.isArray(m.b)||m.b.length<8||!Array.isArray(m.sc))return;
  for(const a of m.p)if(!Array.isArray(a)||a.length<16)return;
  const at=performance.now(),o=at-m.ts;
  if(this.off===null){this.off=o;this.jit=0;}
  else{const d=o-this.off;if(d<0)this.off=o;else{this.off+=d*.01;this.jit+=(d-this.jit)*.1;}}
  this.delay=clamp(NET_SNAP_MS*1.6+this.jit*2,70,260);
  this.buf.push({ts:m.ts,m});
  if(Array.isArray(m.ev))for(const e of m.ev)if(Array.isArray(e))this.evq.push({ts:m.ts,e});
  if(this.buf.length>80)this.buf.splice(0,this.buf.length-80);
  if(!this.connected){this.connected=true;this.hud();}
 },
 _runEv(e){
  switch(e[0]){
   case 's':if(typeof e[1]==='string'&&NETSND.has(e[1]))Au.play(e[1]);break;
   case 'm':if(typeof e[1]==='string')msg(e[1].slice(0,60),nclamp(+e[2],.5,6,1.5),true);break;
   case 'g':fxGoal(e[1]>0?1:-1);if(navigator.vibrate&&S.vib)try{navigator.vibrate([40,60,40]);}catch(x){}break;
  }
 },
 guestFrame(dt){
  const now=performance.now();
  G.t+=dt;
  this._interp(now,dt);
  stepFX(dt);
  this._sendInput(now);
 },
 _interp(now,dt){
  const buf=this.buf;if(!buf.length||this.off===null||!G.players.length)return;
  const rt=now-this.off-this.delay;
  while(buf.length>=2&&buf[1].ts<=rt)buf.shift();
  const a=buf[0],b=buf.length>1?buf[1]:null,A=a.m,B=b?b.m:null;
  let k=0,ex=0;
  if(B)k=clamp((rt-a.ts)/Math.max(1,b.ts-a.ts),0,1);else ex=clamp((rt-a.ts)/1000,0,.12);
  const since=Math.max(0,(rt-a.ts)/1000);
  // eventos agendados (sons, mensagens, efeito de gol) no instante certo da reprodução
  while(this.evq.length&&this.evq[0].ts<=rt){const q=this.evq.shift();if(rt-q.ts<600)this._runEv(q.e);}
  // estado da partida
  const st=A.st;
  G.half=A.h|0;G.score[0]=A.sc[0]|0;G.score[1]=A.sc[1]|0;G.goalTeam=A.gt|0;G.possTeam=A.pt|0;
  G.clock=A.c+(st==='play'?clamp(since,0,.2):0);G.stateT=Math.max(0,A.sT-since);
  G.lastTouch=A.lt>=0?G.players[A.lt]||null:null;
  for(let t=0;t<2;t++){const s=A.ss&&A.ss[t];if(s){const o=G.stats[t];o.shots=s[0];o.passes=s[1];o.fouls=s[2];o.cards=s[3];o.poss=s[4];}}
  if(G.state!==st){
   const prev=G.state;G.state=st;
   if(st==='end'&&prev!=='end'){
    const me=1;setTimeout(()=>{if(Net.role==='guest'&&G.state==='end')Au.play(G.score[me]>G.score[1-me]?'win':(G.score[me]<G.score[1-me]?'lose':'confirm'));},1600);
    setTimeout(()=>{if(Net.role==='guest')showResult();},2600);
   }
  }
  if(A.gu>=0&&A.gu<G.players.length)G.user=G.players[A.gu];
  this.other=(A.hu>=0&&A.hu<G.players.length)?G.players[A.hu]:null;
  G.charging=!!(A.ch&&A.ch[0]);G.charge=A.ch?A.ch[1]/100:0;
  // jogadores
  for(let i=0;i<G.players.length;i++){
   const p=G.players[i],pa=A.p[i],pb=B?B.p[i]:null;
   let x,z,vx,vz,f;
   if(pb&&hyp(pb[0]-pa[0],pb[1]-pa[1])<6){
    x=pa[0]+(pb[0]-pa[0])*k;z=pa[1]+(pb[1]-pa[1])*k;vx=pa[2]+(pb[2]-pa[2])*k;vz=pa[3]+(pb[3]-pa[3])*k;f=pa[4]+angd(pa[4],pb[4])*k;
   }else if(pb){x=pb[0];z=pb[1];vx=pb[2];vz=pb[3];f=pb[4];} // teletransporte (reinício): sem interpolar
   else{x=pa[0]+pa[2]*ex;z=pa[1]+pa[3]*ex;vx=pa[2];vz=pa[3];f=pa[4];}
   p.x=x;p.z=z;p.vx=vx;p.vz=vz;p.face=f;p.speed=hyp(vx,vz);p.phase+=p.speed*1.45*dt;
   const fl=pa[5]|0;p.sprint=!!(fl&1);p.out=!!(fl&2);p.shield=!!(fl&4);
   p.slideT=Math.max(0,pa[6]-since);p.stun=Math.max(0,pa[7]-since);p.stumbleT=Math.max(0,pa[8]-since);p.celeb=Math.max(0,pa[9]-since);
   p.celebType=pa[10]|0;p.diveT=Math.max(0,pa[11]-since);p.dvz=pa[12]|0;p.jumpT=Math.max(0,pa[13]-since);p.kickT=Math.max(0,pa[14]-since);p.skillCd=Math.max(0,pa[15]-since);
   if(!p.out){ // poeira, arrancada e deslize (só visual)
    p.dustT-=dt;
    if(p.dustT<=0){
     if(p.slideT>0){p.dustT=.045;fxBurst(p.x-cos(p.face)*.4,p.z-sin(p.face)*.4,2);fxPuff(p.x,p.z,1,.9);}
     else if(p.skillCd>DASH_CD-.3){p.dustT=.04;fxGhost(p);}
     else if(p.speed>6.3&&p.sprint){p.dustT=.14;fxPuff(p.x-cos(p.face)*.3,p.z-sin(p.face)*.3,1,.35);}
     else if(p.celeb>0&&p.celebType===1&&p.speed>2.2){p.dustT=.05;fxBurst(p.x,p.z,2);}
    }
   }
  }
  // bola
  const bl=G.ball,ba=A.b,bn=B?B.b:null;
  if(bn&&hyp(bn[0]-ba[0],bn[2]-ba[2])<14){
   bl.x=ba[0]+(bn[0]-ba[0])*k;bl.y=ba[1]+(bn[1]-ba[1])*k;bl.z=ba[2]+(bn[2]-ba[2])*k;
   bl.vx=ba[3]+(bn[3]-ba[3])*k;bl.vy=ba[4]+(bn[4]-ba[4])*k;bl.vz=ba[5]+(bn[5]-ba[5])*k;
  }else if(bn){bl.x=bn[0];bl.y=bn[1];bl.z=bn[2];bl.vx=bn[3];bl.vy=bn[4];bl.vz=bn[5];}
  else{bl.x=ba[0]+ba[3]*ex;bl.y=Math.max(BR,ba[1]+ba[4]*ex-4.9*ex*ex);bl.z=ba[2]+ba[5]*ex;bl.vx=ba[3];bl.vy=ba[4];bl.vz=ba[5];}
  bl.spin=ba[6];bl.owner=ba[7]>=0?G.players[ba[7]]||null:null;
  if(bl.owner){bl.rot+=bl.owner.speed*dt/BR*.8;if(bl.tr.length)bl.tr.length=0;}
  else{
   bl.rot+=hyp(bl.vx,bl.vz)*dt/BR*.8;
   if(hyp(bl.vx,bl.vz)>15){bl.tr.push(bl.x,bl.y,bl.z);if(bl.tr.length>24)bl.tr.splice(0,3);}else if(bl.tr.length)bl.tr.splice(0,3);
  }
 },
 _sendInput(now){
  if(!this.connected)return;
  const I=In;let ix=I.L.x,iy=I.L.y;if(I.kx||I.ky){ix=I.kx;iy=I.ky;}
  if(G.state!=='menu'&&curScreen!==null){ix=iy=0;} // com menu aberto o jogador fica parado
  const ev=this.evOut;
  for(const k of NET_KEYS){ // pressionar/soltar são EVENTOS: nunca se perdem entre dois envios
   const d=I.pd(k),u=I.pu(k);
   if(d&&u)ev.push([k,1],[k,0]);else if(d)ev.push([k,1]);else if(u)ev.push([k,0]);
  }
  const held=[];for(const k of NET_KEYS)if(I.held[k])held.push(k);
  const rx=I.R.x,ry=I.R.y;
  const sig=r2(ix)+','+r2(iy)+','+r2(rx)+','+r2(ry)+','+held.join('+');
  const due=ev.length>0||(sig!==this._sig&&now-this.lastInSent>=NET_IN_MS)||now-this.lastInSent>=120;
  if(!due)return;
  this._sig=sig;this.lastInSent=now;
  const msgI={t:'i',q:++this.qi,L:[r2(ix),r2(iy)],R:[r2(rx),r2(ry)],h:held,cb:[r2(C.grx*1000)/1000,r2(C.grz*1000)/1000,r2(C.gfx*1000)/1000,r2(C.gfz*1000)/1000]};
  if(ev.length)msgI.e=ev.splice(0);
  this.send(msgI);
 }
};


/* ---------------- Tela LAN LOCAL(lobby) ---------------- */
let lobbyMode='lan',lobbyPoll=0;
const $id=id=>document.getElementById(id);
function lobbySetMode(m){
 lobbyMode=m;Net.reset();Net.mode=m;
 $id('mp-tab-lan').classList.toggle('active',m==='lan');$id('mp-tab-online').classList.toggle('active',m==='online');
 $id('mp-srv-row').style.display=m==='lan'?'flex':'none';
 $id('mp-note').textContent=m==='lan'
  ?'LAN real, sem internet: um aparelho roda "node server.js" e os dois abrem o endereço dele na mesma Wi-Fi.'
  :'ATENÇÃO: o modo ONLINE usa a internet (sinalização PeerJS). Não é LAN offline.';
 $id('mp-list-lbl').textContent=m==='lan'?'PARTIDAS ENCONTRADAS NA REDE':'ENTRE COM O CÓDIGO DE 12 CARACTERES';
 $id('mp-list').style.display=m==='lan'?'block':'none';
 $id('b-mp-refresh').style.display=m==='lan'?'block':'none';
 const ci=$id('mp-code-in');ci.maxLength=m==='lan'?4:12;ci.placeholder=m==='lan'?'CÓDIGO (4)':'CÓDIGO (12)';ci.value='';
 lobbyHostInfo();Net.setStatus('Escolha: criar sala ou entrar','idle');
 if(m==='lan')lobbyRefresh(true);
}
function lobbyHostInfo(){
 const box=$id('mp-hostinfo');if(!box)return;
 const on=Net.role==='host'&&Net.code&&(Net.state==='waiting'||Net.state==='playing');
 $id('b-host').textContent=(Net.role==='host'&&Net.state==='waiting')?'CANCELAR SALA':'CRIAR SALA';
 box.style.display=on?'block':'none';
 if(!on)return;
 $id('mp-code').textContent=Net.code;
 const lan=Net.mode==='lan';
 $id('mp-addr-lbl').style.display=lan?'block':'none';
 $id('mp-addr').textContent=lan?(Net.ips.length?Net.ips.map(ip=>'http://'+ip+':'+Net.port).join('   '):'(IP não detectado)'):'';
}
function lobbyUpdate(){lobbyHostInfo();}
function lobbyRender(rooms){
 const box=$id('mp-list');box.innerHTML='';
 if(!rooms.length){const d=document.createElement('div');d.className='mp-empty';d.textContent='Nenhuma partida criada ainda.';box.appendChild(d);return;}
 for(const r of rooms){
  const row=document.createElement('div');row.className='mp-room';
  const t=document.createElement('span');t.textContent=r.code+' · '+r.name+(r.full?' (cheia)':'');
  const b=document.createElement('button');b.className='btn mp-mini';b.textContent='ENTRAR';b.disabled=!!r.full;
  b.onclick=()=>{Au.play('ui');Net.createGuest('lan',r.code);};
  row.append(t,b);box.appendChild(row);
 }
}
async function lobbyRefresh(manual){
 if(lobbyMode!=='lan'||Net.role)return;
 const base=Net.httpBase(),box=$id('mp-list');
 if(!base){box.innerHTML='<div class="mp-empty">Informe o endereço do servidor (IP:porta).</div>';if(manual)Net.setStatus('Informe o endereço do servidor LAN','idle');return;}
 const quiet=!manual&&performance.now()<Net._hold;
 try{
  const ac=new AbortController(),to=setTimeout(()=>ac.abort(),2500);
  const r=await fetch(base+'/api/rooms',{signal:ac.signal,cache:'no-store'});clearTimeout(to);
  const j=await r.json();if(Net.role)return;
  const rooms=Array.isArray(j.rooms)?j.rooms:[];lobbyRender(rooms);
  try{localStorage.setItem('fc3d_lan_server',Net.serverHost());}catch(e){}
  if(!quiet)Net.setStatus('Servidor LAN encontrado · '+(rooms.length?rooms.length+' partida(s) na rede':'nenhuma partida criada ainda'),'ok');
 }catch(e){
  if(Net.role)return;
  box.innerHTML='<div class="mp-empty">Servidor não encontrado.</div>';
  if(!quiet)Net.setStatus('Servidor LAN não encontrado em '+Net.serverHost()+'. Rode "node server.js" e confira o IP.','err');
 }
}
async function lobbyOpen(){
 Net.reset();
 const inp=$id('mp-server');let v='';
 try{v=localStorage.getItem('fc3d_lan_server')||'';}catch(e){}
 inp.value=v;
 if(/^https?:$/.test(location.protocol)&&location.host){ // página aberta pelo próprio servidor LAN: endereço certo automaticamente
  try{const r=await fetch(location.origin+'/api/info',{cache:'no-store'});const j=await r.json();if(j&&j.game==='fc3d')inp.value=location.host;}catch(e){}
 }
 lobbySetMode(lobbyMode);show('multi');
 clearInterval(lobbyPoll);lobbyPoll=setInterval(()=>{if(curScreen==='multi')lobbyRefresh(false);else if(curScreen!=='multi')clearInterval(lobbyPoll);},2500);
}
$id('mp-tab-lan').onclick=()=>{Au.play('ui');lobbySetMode('lan');};
$id('mp-tab-online').onclick=()=>{Au.play('ui');lobbySetMode('online');};
$id('b-mp-test').onclick=()=>{Au.play('ui');lobbyRefresh(true);};
$id('b-mp-refresh').onclick=()=>{Au.play('ui');lobbyRefresh(true);};
$id('mp-server').onchange=()=>lobbyRefresh(true);
$id('b-host').onclick=()=>{
 Au.play('ui');
 if(Net.role==='host'&&Net.state==='waiting'){Net.reset();lobbyHostInfo();Net.setStatus('Sala cancelada','idle');return;}
 Net.createHost(lobbyMode);
};
$id('b-join').onclick=()=>{
 Au.play('ui');
 const code=$id('mp-code-in').value.trim();
 if(!code){Net.setStatus(lobbyMode==='lan'?'Digite o código ou toque numa partida da lista.':'Digite o código de 12 caracteres.','err');return;}
 Net.createGuest(lobbyMode,code);
};
$id('mp-code-in').oninput=e=>{e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,'');};
$id('b-copy-sdp').onclick=()=>{
 const t=Net.code+(Net.mode==='lan'&&Net.ips.length?'  http://'+Net.ips[0]+':'+Net.port:'');
 try{navigator.clipboard.writeText(t);}catch(e){}
 Net.setStatus('Código copiado: '+Net.code,'ok');
};
$id('b-multi-back').onclick=()=>{Net.reset();clearInterval(lobbyPoll);Au.play('back');show('title');};


function frame(ts){
 requestAnimationFrame(frame);
 const minDt=1000/FPSV[S.fps]-2;
 if(lastTs&&ts-lastTs<minDt)return;
 let dt=lastTs?Math.min((ts-lastTs)/1000,.1):1/60;lastTs=ts;
 // FPS e resolução adaptativa
 fAcc+=dt;fN++;if(fAcc>=.5){fpsShow=fN/fAcc;msAvg=fAcc/fN*1000;fAcc=0;fN=0;}
 adaptT+=dt;
 if(adaptT>1.8&&G.state!=='menu'){
  adaptT=0;const target=1000/FPSV[S.fps];
  if(msAvg>target*1.3&&G.adapt>.8){G.adapt=Math.max(.8,G.adapt-.05);resize();}
  else if(msAvg<target*1.08&&G.adapt<1&&FPSV[S.fps]<=45){G.adapt=Math.min(1,G.adapt+.04);resize();}
 }
 if(G.state!=='menu'){
  if(Net.mp&&Net.role==='guest'){
   // visitante: não simula; interpola o estado do anfitrião e envia os próprios comandos
   if(curScreen===null)globalInput(dt);
   Net.guestFrame(dt);
   In.clear();
  }else if(!G.paused&&curScreen===null){
   globalInput(dt);
   const sd=dt*S.speed,n=Math.min(3,Math.ceil(sd/(1/60))),h=sd/n;
   for(let i=0;i<n;i++)simStep(h);
   if(Net.role==='host'&&Net.mp)Net.tick();
   if(G.state!=='play'||!G.charging)In.up.X=false;
   if(G.state!=='play'||!RC.charging)RC.I.up.X=false;
   In.clear();RC.I.clear();
  }
  updateCamera(dt,false);
  render();
 }else{
  // fundo animado leve no menu
  ctx.fillStyle='#050a10';ctx.fillRect(0,0,CW,CH);
 }
}
addEventListener('resize',()=>{if(booted)resize();});
addEventListener('orientationchange',()=>setTimeout(()=>{if(booted)resize();},200));
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseGame();});



/* ---------------- Início ---------------- */
let booted=false; // true depois que os 3 arquivos carregaram (evita eventos antes da hora)
function boot(){
 booted=true;
 Object.assign(S,{gfx:clamp(S.gfx|0,0,2),fps:clamp(S.fps|0,0,2),cam:clamp(S.cam|0,0,4),hudS:clamp(S.hudS||100,70,120)});
 buildHUD();buildCrowd();resize();requestAnimationFrame(frame);
 window.__FC={G,S,C,In,HD,simStep,render,initMatch,updateCamera,userControl,resize,buildCrowd,startMatch}; // depuração
}
/* 'load' dispara depois que game.js, input.js e render.js foram todos executados */
addEventListener('load',boot);

/* som de clique em qualquer botão do jogo */
document.addEventListener('pointerdown',e=>{const t=e.target.closest&&e.target.closest('button,.btn,.mm-item,.mm-card,.mm-ic,[data-back]');if(!t)return;Au.init();Au.resume();Au.play(t.hasAttribute('data-back')?'back':'click');},true);
