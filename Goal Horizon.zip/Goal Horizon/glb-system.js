'use strict';
/* =====================================================================
   GOAL HORIZON — SISTEMA GLB (glb-system.js)
   1) ESTÁDIOS .glb  -> models/stadiums/*.glb  (ajuste automático ao campo 105x68, gols/rede/gramado do jogo)
   2) ANIMAÇÕES .glb -> models/animations/*.glb (retarget por nome de osso, ex.: Mixamo) + clipes embutidos em player.glb
   3) IMPORTAR pelo próprio jogo (Configurações) -> guarda no IndexedDB do aparelho
   Depende de: THREE (r147), THREE.GLTFLoader, globals do jogo (G, S, HL, HW, GW, GH, GD, BR, clamp).
   Usado por render.js (GLBSys.init, ensureStadium, animate, cloneModel...).
   ===================================================================== */
const GLBSys=(function(){
 const BASE='models/',D2R=Math.PI/180;
 const man={ready:false,stadiums:[],animations:[],animMap:{},player:{}};
 const MAIN_STADIUM='arenahorizon'; // estádio único do jogo
 const STAD_TUNE={k:1.23,y:0,rot:0}; // tamanho/altura/rotação fixos da Arena Horizon
 let T=null;
 const norm=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
 const bonekey=s=>norm(s).replace(/^(mixamorig|armature|bip001|bip01)+/,'');
 const say=(t,s)=>{try{if(typeof msg==='function')msg(t,s||2,true);}catch(e){}};

 /* ---------------- Manifesto ---------------- */
 async function fetchJSON(u){const r=await fetch(u,{cache:'no-cache'});if(!r.ok)throw new Error(u+' '+r.status);return r.json();}
 function prettify(f){return f.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());}
 async function loadManifest(){
  let m=null;
  try{m=await fetchJSON('api/modelos');}catch(e){}
  if(!m||!Array.isArray(m.stadiums)){try{m=await fetchJSON(BASE+'manifest.json');}catch(e){m=null;}}
  m=m||{};
  man.stadiums=(m.stadiums||[]).map(e=>({id:e.id||norm(e.file),name:e.name||prettify(e.file||e.id),url:/^(blob:|https?:|\/)/.test(e.file)?e.file:BASE+e.file,cfg:e.cfg||{}}))
   .filter(e=>norm(e.id)===MAIN_STADIUM||norm(e.name)===MAIN_STADIUM);
  if(!man.stadiums.length)man.stadiums=[{id:MAIN_STADIUM,name:'Arena Horizon',url:BASE+'stadiums/arena-horizon.glb',cfg:{}}];
  man.stadiums[0].id=MAIN_STADIUM;
  man.animations=(m.animations||[]).map(f=>/^(blob:|https?:|\/)/.test(f)?f:BASE+f);
  man.animMap=m.animMap||{};man.player=m.player||{};
  man.ready=true;
 }

 /* =====================================================================
    ESTÁDIO
    ===================================================================== */
 const SD={want:null,status:'none',err:'',group:null,tune:null,model:null,field:null,fx:null,goals:[],mixer:null,info:null,token:0,url:null,active:false};
 const PITCH_RE='pitch|grass|field|turf|campo|gramado|relva|cesped|césped|rasen|pelouse|lawn';
 const GOAL_RE=/(^|[^a-z])(goal|goalpost|goalposts|net|nets|gol|trave|rede)([^a-z]|$)|goalpost/i;

 function loadGLTF(src){return new Promise((res,rej)=>{
  let url=src.url,tmp=null;if(src.blob){tmp=url=URL.createObjectURL(src.blob);}
  T.loader.load(url,g=>{if(tmp)URL.revokeObjectURL(tmp);res(g);},undefined,e=>{if(tmp)URL.revokeObjectURL(tmp);rej(e||new Error('falha ao carregar'));});});}

 function disposeTree(o){
  o.traverse(c=>{
   if(c.geometry)c.geometry.dispose();
   const ms=c.material?(Array.isArray(c.material)?c.material:[c.material]):[];
   for(const m of ms){for(const k in m){const v=m[k];if(v&&v.isTexture)v.dispose();}m.dispose();}
  });
 }
 function unloadStadium(){
  SD.token++;
  if(SD.group){T.scene.remove(SD.group);disposeTree(SD.group);}
  if(SD.mixer)SD.mixer.stopAllAction();
  Object.assign(SD,{group:null,tune:null,model:null,field:null,fx:null,goals:[],mixer:null,info:null,active:false,status:'none',err:''});
  FXS.shadows=[];FXS.spots=[];
  if(T.lights)T.lights.restore();
 }

 function fitModel(model,cfg){
  const wrap=new THREE.Group();wrap.add(model);
  const info={pitch:false,scale:1,auto:false};
  const reP=new RegExp(cfg.pitchMesh||PITCH_RE,'i');
  wrap.updateMatrixWorld(true);
  let best=null,bestA=0;
  model.traverse(o=>{if(!o.isMesh)return;
   const b=new THREE.Box3().setFromObject(o),s=new THREE.Vector3();b.getSize(s);
   const hit=reP.test(o.name||'')||(o.material&&!Array.isArray(o.material)&&reP.test(o.material.name||''));
   if(hit&&s.y<=Math.max(s.x,s.z)*.08&&s.x*s.z>bestA){best=o;bestA=s.x*s.z;}});
  const box=o=>{wrap.updateMatrixWorld(true);return new THREE.Box3().setFromObject(o);};
  const sz=b=>{const v=new THREE.Vector3();b.getSize(v);return v;};
  if(typeof cfg.rotY==='number')model.rotation.y=cfg.rotY*D2R;
  else if(best){const s=sz(box(best));if(s.z>s.x*1.1)model.rotation.y=Math.PI/2;}
  let ref=best?box(best):box(model),s0=sz(ref);
  let k;
  if(typeof cfg.scale==='number')k=cfg.scale;
  else if(best)k=(2*HL+(cfg.pitchPad||0))/Math.max(s0.x,.001);
  else{k=(cfg.autoSize||230)/Math.max(s0.x,s0.z,.001);info.auto=true;}
  model.scale.multiplyScalar(k);
  ref=best?box(best):box(model);
  const c=new THREE.Vector3();ref.getCenter(c);
  const topY=best?ref.max.y:ref.min.y;
  const off=cfg.offset||[0,0,0];
  model.position.set(model.position.x-c.x+off[0],model.position.y-topY+off[1],model.position.z-c.z+off[2]);
  info.pitch=!!best;info.scale=k;info.pitchName=best?best.name:'';
  // esconde o gramado e os gols do arquivo (o jogo usa os próprios, alinhados com a física)
  if(best&&cfg.pitchMode!=='glb')best.visible=false;
  const hideRe=cfg.hide?new RegExp(cfg.hide,'i'):null;
  model.traverse(o=>{if(!o.isMesh)return;
   if(cfg.goals!=='glb'&&GOAL_RE.test(o.name||''))o.visible=false;
   if(hideRe&&hideRe.test(o.name||''))o.visible=false;
   const ms=Array.isArray(o.material)?o.material:[o.material];
   for(const m of ms){if(!m)continue;
    if(m.metalness>.6&&!m.envMap)m.metalness=.25;
    for(const key of ['map','emissiveMap','normalMap','roughnessMap'])if(m[key])m[key].anisotropy=Math.min(4,T.renderer.capabilities.getMaxAnisotropy());}});
  return info;
 }

 /* ---- gramado + linhas + gols + bandeirinhas (coordenadas do jogo) ---- */
 function pitchTexture(){
  const M=6,ppm=16,W=2*HL+2*M,H=2*HW+2*M,cw=Math.round(W*ppm),ch=Math.round(H*ppm);
  const c=document.createElement('canvas');c.width=cw;c.height=ch;const g=c.getContext('2d');
  const X=x=>(x+HL+M)*ppm,Z=z=>(z+HW+M)*ppm;
  g.fillStyle='#1b6b2e';g.fillRect(0,0,cw,ch);
  const n=14,w=2*HL/n;
  for(let i=0;i<n;i++){g.fillStyle=i%2?'#26853b':'#2e9a46';g.fillRect(X(-HL+i*w),Z(-HW),w*ppm+1,2*HW*ppm);}
  g.strokeStyle='rgba(255,255,255,.93)';g.fillStyle='rgba(255,255,255,.93)';g.lineWidth=Math.max(2,.13*ppm);
  const R=(x0,z0,x1,z1)=>g.strokeRect(X(x0),Z(z0),(x1-x0)*ppm,(z1-z0)*ppm);
  const A=(x,z,r,a0,a1)=>{g.beginPath();g.arc(X(x),Z(z),r*ppm,a0,a1);g.stroke();};
  R(-HL,-HW,HL,HW);
  g.beginPath();g.moveTo(X(0),Z(-HW));g.lineTo(X(0),Z(HW));g.stroke();
  A(0,0,9.15,0,Math.PI*2);
  g.beginPath();g.arc(X(0),Z(0),.25*ppm,0,Math.PI*2);g.fill();
  const aa=Math.acos((16.5-11)/9.15);
  for(const s of [-1,1]){
   R(s>0?HL-16.5:-HL,-20.16,s>0?HL:-HL+16.5,20.16);
   R(s>0?HL-5.5:-HL,-9.16,s>0?HL:-HL+5.5,9.16);
   g.beginPath();g.arc(X(s*(HL-11)),Z(0),.25*ppm,0,Math.PI*2);g.fill();
   if(s<0)A(-HL+11,0,9.15,-aa,aa);else A(HL-11,0,9.15,Math.PI-aa,Math.PI+aa);
   for(const t of [-1,1])A(s*HL,t*HW,1,0,Math.PI*2);
  }
  const tex=new THREE.CanvasTexture(c);
  if(THREE.sRGBEncoding)tex.encoding=THREE.sRGBEncoding;
  tex.anisotropy=Math.min(8,T.renderer.capabilities.getMaxAnisotropy());
  return tex;
 }
 function buildGoal(s){
  const grp=new THREE.Group(),wm=new THREE.MeshBasicMaterial({color:0xf7f7f7});
  const post=(x,z)=>{const m=new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,GH,8),wm);m.position.set(x,GH/2,z);grp.add(m);};
  post(s*HL,-GW);post(s*HL,GW);
  const bar=new THREE.Mesh(new THREE.CylinderGeometry(.06,.06,2*GW+.12,8),wm);bar.rotation.x=Math.PI/2;bar.position.set(s*HL,GH,0);grp.add(bar);
  const P=[];const seg=6;
  const line=(x0,y0,z0,x1,y1,z1)=>{for(let i=0;i<seg;i++){const a=i/seg,b=(i+1)/seg;
   P.push(x0+(x1-x0)*a,y0+(y1-y0)*a,z0+(z1-z0)*a,x0+(x1-x0)*b,y0+(y1-y0)*b,z0+(z1-z0)*b);}};
  const xb=s*(HL+GD);
  for(let i=0;i<=12;i++){const z=-GW+i*GW/6;line(xb,0,z,xb,GH,z);line(s*HL,GH,z,xb,GH,z);} // fundo e teto
  for(let j=0;j<=6;j++){const y=j*GH/6;line(xb,y,-GW,xb,y,GW);}
  for(const z of [-GW,GW]){for(let j=0;j<=6;j++){const y=j*GH/6;line(s*HL,y,z,xb,y,z);}for(let i=0;i<=4;i++){const x=s*(HL+i*GD/4);line(x,0,z,x,GH,z);}}
  for(let i=0;i<=4;i++){const x=s*(HL+i*GD/4);line(x,GH,-GW,x,GH,GW);}
  const base=new Float32Array(P),pos=new Float32Array(P);
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));
  const ls=new THREE.LineSegments(geo,new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:.42,depthWrite:false}));
  ls.frustumCulled=false;grp.add(ls);
  return {grp,s,base,pos,geo,wave:false};
 }
 function buildField(){
  const f=new THREE.Group(),M=6;
  const pm=new THREE.MeshBasicMaterial({map:pitchTexture(),polygonOffset:true,polygonOffsetFactor:-2,polygonOffsetUnits:-2});
  const pl=new THREE.Mesh(new THREE.PlaneGeometry(2*HL+2*M,2*HW+2*M),pm);pl.rotation.x=-Math.PI/2;pl.position.y=.02;f.add(pl);
  SD.goals=[buildGoal(-1),buildGoal(1)];SD.goals.forEach(g=>f.add(g.grp));
  const fm=new THREE.MeshBasicMaterial({color:0xffd21f,side:THREE.DoubleSide}),pm2=new THREE.MeshBasicMaterial({color:0xffffff});
  for(const sx of [-1,1])for(const sz of [-1,1]){
   const pole=new THREE.Mesh(new THREE.CylinderGeometry(.02,.02,1.5,6),pm2);pole.position.set(sx*HL,.75,sz*HW);f.add(pole);
   const fl=new THREE.Mesh(new THREE.PlaneGeometry(.4,.3),fm);fl.position.set(sx*HL-sx*.2,1.35,sz*HW);fl.rotation.y=Math.PI/2;f.add(fl);
  }
  return f;
 }
 function updateNets(){
  for(const g of SD.goals){
   const nt=G.net&&G.net.side===g.s?G.net:null;
   if(!nt){if(g.wave){g.pos.set(g.base);g.geo.attributes.position.needsUpdate=true;g.wave=false;}continue;}
   const wv=Math.exp(-nt.t*2.4)*Math.cos(nt.t*16)*.9,b=g.base,p=g.pos;
   for(let i=0;i<b.length;i+=3){
    const f=clamp((Math.abs(b[i])-HL)/GD,0,1),dz=b[i+2]-nt.z,dy=b[i+1]-nt.y;
    p[i]=b[i]+g.s*wv*f*Math.exp(-(dz*dz+dy*dy)/2.2);
   }
   g.geo.attributes.position.needsUpdate=true;g.wave=true;
  }
 }

 /* ---- sombras, anel do jogador e pontos de treino (substituem o drawGround do Canvas) ---- */
 const FXS={shadows:[],spots:[],ball:null,ring:null,ring2:null,arrow:null,tex:null};
 function buildFX(){
  const grp=new THREE.Group();
  const c=document.createElement('canvas');c.width=c.height=64;const g=c.getContext('2d');
  const gr=g.createRadialGradient(32,32,2,32,32,31);gr.addColorStop(0,'rgba(0,0,0,.6)');gr.addColorStop(.6,'rgba(0,0,0,.3)');gr.addColorStop(1,'rgba(0,0,0,0)');
  g.fillStyle=gr;g.fillRect(0,0,64,64);
  const tex=FXS.tex=new THREE.CanvasTexture(c);
  const po={transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-4,polygonOffsetUnits:-4,side:THREE.DoubleSide};
  FXS.shMat=new THREE.MeshBasicMaterial(Object.assign({map:tex},po));
  FXS.shGeo=new THREE.PlaneGeometry(1,1);
  FXS.ball=mkShadow(grp);
  const flat=(geo,mat,y)=>{const m=new THREE.Mesh(geo,mat);m.rotation.x=-Math.PI/2;m.position.y=y;m.renderOrder=2;m.visible=false;grp.add(m);return m;};
  FXS.ring2=flat(new THREE.RingGeometry(.9,1.04,40),new THREE.MeshBasicMaterial(Object.assign({color:0x000000,opacity:.45},po)),.035);
  FXS.ring=flat(new THREE.RingGeometry(.8,.92,40),new THREE.MeshBasicMaterial(Object.assign({color:0xffe14a,opacity:.95},po)),.04);
  const ag=new THREE.BufferGeometry();ag.setAttribute('position',new THREE.BufferAttribute(new Float32Array([.5,0,0,-.25,0,.28,-.25,0,-.28]),3));
  FXS.arrow=new THREE.Mesh(ag,new THREE.MeshBasicMaterial(Object.assign({color:0xffe14a,opacity:.85},po)));FXS.arrow.renderOrder=2;FXS.arrow.visible=false;grp.add(FXS.arrow);
  FXS.spotGeo=new THREE.RingGeometry(1.25,1.4,36);FXS.spotMat=new THREE.MeshBasicMaterial(Object.assign({color:0x5ec8ff,opacity:.9},po));
  FXS.grp=grp;return grp;
 }
 function mkShadow(grp){const m=new THREE.Mesh(FXS.shGeo,FXS.shMat);m.rotation.x=-Math.PI/2;m.position.y=.03;m.renderOrder=1;m.visible=false;grp.add(m);return m;}
 function updateFX(){
  const grp=FXS.grp;if(!grp)return;
  const lvl=S.shadow|0,big=lvl>1?1.1:1,pl=G.players.filter(p=>!p.out);
  while(FXS.shadows.length<pl.length)FXS.shadows.push(mkShadow(grp));
  FXS.shadows.forEach((m,i)=>{const p=pl[i];if(!p||!lvl){m.visible=false;return;}m.visible=true;m.position.set(p.x+.16,.03,p.z+.1);m.scale.setScalar(1.5*big);});
  const b=G.ball;
  if(b&&lvl){FXS.ball.visible=true;const sk=clamp(1-b.y*.08,.3,1);FXS.ball.position.set(b.x+.1,.03,b.z+.06);FXS.ball.scale.setScalar((.26*sk+.05)*2.4);}else FXS.ball.visible=false;
  const u=G.user,on=!!(S.ind&&u);
  FXS.ring.visible=FXS.ring2.visible=on;
  if(on){FXS.ring.position.x=FXS.ring2.position.x=u.x;FXS.ring.position.z=FXS.ring2.position.z=u.z;}
  const sp=u&&u.speed>1.2;FXS.arrow.visible=!!(on&&sp);
  if(on&&sp){const nx=u.vx/u.speed,nz=u.vz/u.speed;FXS.arrow.position.set(u.x+nx*1.4,.04,u.z+nz*1.4);FXS.arrow.rotation.y=-Math.atan2(nz,nx);}
  const spots=(G.train&&G.train.spots)||[];
  while(FXS.spots.length<spots.length){const m=new THREE.Mesh(FXS.spotGeo,FXS.spotMat);m.rotation.x=-Math.PI/2;m.position.y=.04;m.renderOrder=2;grp.add(m);FXS.spots.push(m);}
  FXS.spots.forEach((m,i)=>{const s=spots[i];m.visible=!!s;if(s)m.position.set(s[0],.04,s[1]);});
 }

 function applyTune(){
  if(!SD.tune)return;
  const t=STAD_TUNE;
  SD.tune.scale.setScalar(t.k||1);SD.tune.rotation.y=(t.rot||0)*D2R;SD.tune.position.y=t.y||0;
 }
 async function buildStadium(entry,token){
  let gltf;
  try{gltf=await loadGLTF(entry.blob?{blob:entry.blob}:{url:entry.url});}
  catch(e){if(token!==SD.token)return;SD.status='error';SD.err='não foi possível abrir '+(entry.url||entry.name);console.warn('[GLB] estádio',e);say('ESTÁDIO .GLB: ERRO AO CARREGAR',2.5);return;}
  if(token!==SD.token){disposeTree(gltf.scene);return;}
  try{
   const cfg=entry.cfg||{};
   const root=new THREE.Group(),tune=new THREE.Group();
   const model=gltf.scene;
   SD.info=fitModel(model,cfg);
   tune.add(model);root.add(tune);
   root.add(buildField());root.add(buildFX());
   if(gltf.animations&&gltf.animations.length&&cfg.playAnims!==false){
    SD.mixer=new THREE.AnimationMixer(model);gltf.animations.forEach(c=>SD.mixer.clipAction(c).play());
   }
   SD.group=root;SD.tune=tune;SD.model=model;T.scene.add(root);
   if(T.lights)T.lights.stadium(cfg);
   applyTune();SD.status='ready';SD.active=true;
   console.log('[GLB] estádio "'+entry.name+'" pronto · escala ×'+SD.info.scale.toFixed(3)+(SD.info.pitch?' · gramado: '+SD.info.pitchName:' · gramado NÃO detectado (escala automática)'));
  }catch(e){SD.status='error';SD.err=String(e&&e.message||e);console.warn('[GLB] estádio',e);say('ESTÁDIO .GLB: ERRO',2.5);}
 }
 function ensureStadium(id){
  if(!T||!man.ready)return;
  id=MAIN_STADIUM;
  if(id===SD.want)return;
  if(SD.group||SD.status!=='none')unloadStadium();
  SD.want=id;
  if(!id)return;
  const e=man.stadiums.find(s=>s.id===id);
  if(!e){SD.status='error';SD.err='estádio "'+id+'" não está na lista';return;}
  SD.status='loading';buildStadium(e,SD.token);
 }

 /* =====================================================================
    ANIMAÇÕES
    ===================================================================== */
 const AL={clips:new Map(),version:0,res:{}};
 const ALIAS={idle:['idle','standing','stand','breathing'],walk:['walk','walking'],run:['run','running','jog','jogging','sprint'],
  jog:['jog','jogging'],sprint:['sprint','sprinting'],dribble:['dribble','dribbling'],
  kick:['kick','shoot','shot','shooting','soccerkick','strike','pass'],slide:['slide','tackle','slidingtackle'],jump:['jump','jumping','header'],
  dive:['dive','save','diving','goalkeeperdive','gkdive'],diveR:['diver','diveright','gkdiver'],getup:['getup','standup','getting'],
  celebrate:['celebrate','celebration','victory','cheer','cheering','dance'],
  fall:['fall','falling','knockdown','stumble','hit'],gkidle:['gkidle','goalkeeperidle','keeperidle'],gkhold:['gkhold','goalkeeperhold','keeperhold','gkcatch']};
 const CHAIN={run:['jog','walk','idle'],jog:['run','walk','idle'],sprint:['run','jog','walk','idle'],dribble:['jog','run','walk','idle'],walk:['jog','run','idle'],
  kick:['idle'],slide:['fall','dive','idle'],jump:['idle'],dive:['jump','idle'],diveR:['dive','jump','idle'],getup:['idle'],
  celebrate:['jump','idle'],fall:['idle'],gkidle:['idle'],gkhold:['gkidle','idle'],idle:[]};
 const LOOPS={idle:1,walk:1,jog:1,run:1,sprint:1,dribble:1,celebrate:1,gkidle:1,gkhold:1};
 /* velocidade (m/s) para a qual cada ciclo embutido foi animado: timeScale = vel_real/DESIGN -> pés sem patinar */
 const DESIGN={walk:1.4,jog:3.8,run:6.3,sprint:8.4,dribble:4.4};
 const TSCLAMP={walk:[.6,1.8],jog:[.6,1.5],run:[.75,1.4],sprint:[.8,1.25],dribble:[.5,1.8]};
 const FADE={kick:.05,slide:.08,dive:.08,diveR:.08,jump:.10,getup:.10,fall:.08,celebrate:.20};
 const LOCOMO={walk:1,jog:1,run:1,sprint:1,dribble:1};

 function isGeneric(n){return !n||/mixamo\.?com|^(take[ _]?\d*|animation|anim|default|clip|armature|unnamed|action|layer0|baselayer)$/i.test(n);}
 function nodeHipsY(scene){let y=null;scene.traverse(o=>{if(y===null&&['hips','pelvis'].includes(bonekey(o.name)))y=o.position.y;});return y;}
 function registerClips(gltf,fileName,embedded){
  const cl=gltf.animations||[];if(!cl.length)return 0;
  const base=String(fileName||'').replace(/^.*\//,'').replace(/\.[^.]+$/,'');
  const hy=embedded?null:nodeHipsY(gltf.scene);
  cl.forEach((c,i)=>{
   let nm=String(c.name||'');if(nm.includes('|'))nm=nm.split('|').pop();
   if(isGeneric(nm))nm=cl.length>1?base+'_'+(i+1):base;
   const k=norm(nm);AL.clips.set(k,{name:nm,key:k,clip:c,hipsY:hy,rt:null,emb:!!embedded});
  });
  AL.version++;AL.res={};return cl.length;
 }
 function findClip(state,variant){
  const key=state+(variant||'');if(key in AL.res)return AL.res[key];
  const want=[];
  const um=man.animMap[state];if(um)(Array.isArray(um)?um:[um]).forEach(u=>want.push(norm(u)));
  if(variant)want.push(norm(state)+variant);
  (ALIAS[state]||[state]).forEach(a=>want.push(a));
  const all=[...AL.clips.values()];let r=null;
  for(const w of want){r=all.find(c=>c.key===w);if(r)break;}
  if(!r)for(const w of want){r=all.find(c=>c.key.includes(w));if(r)break;}
  return AL.res[key]=r||null;
 }
 function modelInfo(root){
  const bones=new Map();let hips=null,first=null;
  root.traverse(o=>{if(!o.name)return;const k=bonekey(o.name);
   if(!bones.has(k)||o.isBone)bones.set(k,o.name);
   if(o.isBone){if(!first)first=o;if(!hips&&(k==='hips'||k==='pelvis'))hips=o;}});
  hips=hips||first;
  return {bones,hipsKey:hips?bonekey(hips.name):null,hipsY:hips?hips.position.y:null,sig:bones.size+':'+(hips?hips.name:'')};
 }
 function retarget(rec,info){
  if(rec.rt&&rec.rt.sig===info.sig)return rec.rt.clip;
  const tracks=[];
  const ratio=man.player.animPosScale||((rec.hipsY&&info.hipsY)?info.hipsY/rec.hipsY:1);
  for(const t of rec.clip.tracks){
   const d=t.name.indexOf('.');if(d<0)continue;
   const key=bonekey(t.name.slice(0,d)),prop=t.name.slice(d+1),target=info.bones.get(key);
   if(!target||prop==='scale')continue;
   if(prop==='position'&&key!==info.hipsKey)continue;
   const nt=t.clone();nt.name=target+'.'+prop;
   if(prop==='position'){ // só o quadril, sem deslocamento horizontal (animação "no lugar")
    const v=nt.values,x0=v[0],z0=v[2];
    for(let i=0;i<v.length;i+=3){v[i]=x0*ratio;v[i+1]*=ratio;v[i+2]=z0*ratio;}
   }
   tracks.push(nt);
  }
  const clip=new THREE.AnimationClip(rec.name,rec.clip.duration,tracks);
  rec.rt={sig:info.sig,clip};return clip;
 }
 function bind(entry){
  if(entry.animVer===AL.version)return;
  entry.animVer=AL.version;entry.mixer.stopAllAction();entry.actions={};entry.cur=null;
  entry.info=entry.info||modelInfo(entry.root);
 }
 function actionFor(entry,state,variant){
  const k=state+(variant||'');let a=entry.actions[k];if(a!==undefined)return a;
  const rec=findClip(state,variant);
  if(!rec||!entry.info){return entry.actions[k]=null;}
  const clip=retarget(rec,entry.info);
  if(!clip.tracks.length){return entry.actions[k]=null;}
  a=entry.mixer.clipAction(clip);a._emb=!!rec.emb;
  if(LOOPS[state])a.setLoop(THREE.LoopRepeat,Infinity);else{a.setLoop(THREE.LoopOnce,1);a.clampWhenFinished=true;}
  return entry.actions[k]=a;
 }
 /* Marcha: histerese entre os degraus (evita piscar entre jog/run perto do limite). 0 idle · 1 walk · 2 jog · 3 run · 4 sprint */
 const UP=[0,1.0,2.3,5.2,7.2],DN=[0,.7,2.0,4.8,6.8],LOCO=['idle','walk','jog','run','sprint'];
 function locoState(entry,spd){
  let i=entry.locoI|0;
  while(i<4&&spd>UP[i+1])i++;
  while(i>0&&spd<DN[i])i--;
  entry.locoI=i;return LOCO[i];
 }
 /* Retorna 2 = clipe do próprio estado tocando, 1 = clipe substituto, 0 = nenhum (use animação procedural) */
 function animate(entry,p,dt){
  if(!entry.mixer)return 0;
  bind(entry);
  if(!AL.clips.size){return 0;}
  const spd=p.speed||0;
  const hasBall=(typeof G!=='undefined'&&G&&G.ball&&G.ball.owner===p);
  let st,variant='';
  if(p.diveT>0){ // mergulho para a esquerda ou direita do goleiro (a esquerda do modelo = +X local)
   st='dive';const th=entry.root.rotation.y,dz=p.dvz||1;
   if(-Math.sin(th)*dz<0)st='diveR';
  }else if(p.slideT>0)st='slide';
  else if(p.stumbleT>0||p.stun>0)st='fall';
  else if(p.kickT>0)st='kick';
  else if(p.jumpT>0)st='jump';
  else if(p.celeb>0){
   st='celebrate';const ct=p.celebType|0;
   if(entry.celMv)entry.celMv=spd>1.8;else entry.celMv=spd>2.6;
   variant=ct===1?(entry.celMv?'4':'2'):ct===2?(entry.celMv?'5':'3'):'1';
  }else{
   st=locoState(entry,spd);
   if(st==='idle'){st=p.role==='GK'?(hasBall?'gkhold':'gkidle'):'idle';}
   else if(hasBall&&(st==='jog'||st==='run')&&spd<6.3)st='dribble';
  }
  // levantar depois do carrinho / mergulho: toca o clipe "getup" antes de voltar ao jogo
  const ls=entry.lastSt;
  if((ls==='slide'||ls==='dive'||ls==='diveR')&&st!=='slide'&&st!=='dive'&&st!=='diveR')entry.guT=.5;
  if(entry.guT>0){
   entry.guT-=dt;
   if(st!=='slide'&&st!=='dive'&&st!=='diveR'&&st!=='kick'&&st!=='jump'&&st!=='celebrate')st='getup';
  }
  entry.lastSt=st;
  let act=null,use=st;
  for(const s of [st].concat(CHAIN[st]||[])){act=actionFor(entry,s,s===st?variant:'');if(act){use=s;break;}}
  if(!act)return 0;
  if(entry.cur!==act){
   const prev=entry.cur,fd=FADE[use]!==undefined?FADE[use]:.2,pd=prev?prev.getClip().duration:0,dur0=act.getClip().duration;
   act.enabled=true;act.reset();act.setEffectiveWeight(1);
   if(LOOPS[use]&&dur0>0){ // entre ciclos de corrida mantém a fase da passada; nos demais, começa em ponto aleatório
    if(prev&&pd>0&&LOCOMO[use]&&LOCOMO[entry.curUse])act.time=((prev.time%pd)/pd)*dur0;
    else act.time=Math.random()*dur0;
   }
   act.fadeIn(fd).play();if(prev)prev.fadeOut(fd);entry.cur=act;entry.curUse=use;
  }
  const dur=act.getClip().duration||1,Vd=DESIGN[use],tc=TSCLAMP[use];
  let ts=1;
  if(act._emb){ // clipes embutidos: velocidade da passada = velocidade real / velocidade de projeto
   const cn=act.getClip().name;
   if(Vd)ts=clamp(spd/Vd,tc[0],tc[1]);
   else if(cn==='celebrate4'||cn==='celebrate5')ts=clamp(spd/6.3,.6,1.3);
  }else{ // clipes externos (Mixamo etc.): comportamento original
   ts=use==='run'||use==='sprint'?clamp(spd/7,.7,1.6):use==='walk'||use==='jog'?clamp(spd/2,.6,1.6):use==='kick'?clamp(dur/.38,.8,3):1;
  }
  act.timeScale=ts;
  entry.mixer.update(dt);
  return use===st?2:1;
 }
 async function loadAnimations(){
  if(!T||!T.loader)return;
  const srcs=man.animations.map(u=>({url:u,name:u}));
  let i=0;const worker=async()=>{while(i<srcs.length){const s=srcs[i++];
   try{const g=await loadGLTF(s);registerClips(g,s.name,false);disposeTree(g.scene);}
   catch(e){console.warn('[GLB] animação não carregou:',s.name,e);}}};
  await Promise.all([worker(),worker(),worker()]);
  console.log('[GLB] animações disponíveis:',[...AL.clips.values()].map(c=>c.name).join(', ')||'(nenhuma)');
 }
 function cloneModel(scene){
  if(THREE.SkeletonUtils&&THREE.SkeletonUtils.clone)return THREE.SkeletonUtils.clone(scene);
  return scene.clone(true);
 }

 /* =====================================================================
    INTERFACE (Configurações)
    ===================================================================== */
 function stateReport(){
  return ['idle','walk','jog','run','sprint','dribble','kick','slide','getup','jump','dive','diveR','celebrate','fall','gkidle','gkhold'].map(s=>{const r=findClip(s);return s+(r?' ✓':' ✗');}).join(' · ');
 }
 function statusText(){
  let a='Estádio: ';
  if(SD.status==='loading')a+='carregando…';
  else if(SD.status==='ready')a+='Arena Horizon';
  else if(SD.status==='error')a+='erro — '+SD.err;
  return a+'\nAnimações ('+AL.clips.size+' clipes): '+(AL.clips.size?stateReport():'nenhuma');
 }
 function buildUI(box,rebuild){
  const d=document.createElement('div');d.className='sec';d.textContent='Estádios e animações 3D (.glb)';box.appendChild(d);
  const st=document.createElement('div');st.style.cssText='white-space:pre-line;font-size:12px;opacity:.8;padding:6px 4px';st.textContent=statusText();box.appendChild(st);
 }

 /* ---------------- Luzes ---------------- */
 function setupLights(scene){
  // ambiente + hemisfério (céu/gramado) + sol + preenchimento + luz de recorte: relevo e separação melhores nos jogadores
  const amb=new THREE.AmbientLight(0xffffff,.28),hemi=new THREE.HemisphereLight(0xe6efff,0x3f5a2e,.42),dir=new THREE.DirectionalLight(0xfff5e0,.95),dir2=new THREE.DirectionalLight(0xaaccff,.3),rim=new THREE.DirectionalLight(0xffffff,.3);
  dir.position.set(20,40,10);dir2.position.set(-30,20,-15);rim.position.set(-8,22,-38);scene.add(amb,hemi,dir,dir2,rim);
  return {restore(){amb.intensity=.28;hemi.intensity=.42;dir.intensity=.95;dir2.intensity=.3;rim.intensity=.3;},
   stadium(cfg){const l=cfg.light||{};const a=l.ambient!=null?l.ambient:.95,k=a/.65;amb.intensity=.28*k;hemi.intensity=.42*k;dir.intensity=l.sun!=null?l.sun:.8;dir2.intensity=l.fill!=null?l.fill:.4;rim.intensity=.25;}};
 }

 /* ---------------- API ---------------- */
 return {
  init(t3){T=t3;T.lights=setupLights(T.scene);loadManifest().then(()=>{loadAnimations();}).catch(e=>console.warn('[GLB] manifesto',e));},
  get ready(){return man.ready;},
  ensureStadium,applyTune,updateNets,updateFX,
  stadiumActive(){return !!(SD.active&&SD.group);},
  stadiumMixer(dt){if(SD.mixer)SD.mixer.update(dt);},
  stadiumGroup(){return SD.group;},
  fieldFX(){return FXS.grp;},
  registerClips,animate,cloneModel,buildUI,statusText,
  playerCfg(){const p=man.player||{};return {scale:p.scale||1,faceOffset:(p.faceOffset||0)*D2R,yOffset:p.yOffset||0};},
  _test:{norm,bonekey,retarget,modelInfo,findClip,AL,man}
 };
})();
