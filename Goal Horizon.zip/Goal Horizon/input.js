'use strict';
/* =====================================================================
   FC CARREIRA 3D — ENTRADA (input.js)
   Multitouch, HUD de controles, analógicos, teclado.
   Depende de (game.js): $, S, Au, hyp, clamp, saveCfg
   ===================================================================== */

/* ---------------- Estado de entrada (lido por game.js) ---------------- */
const In={held:{},dn:{},up:{},L:{x:0,y:0},R:{x:0,y:0},kx:0,ky:0,
 press(id){ // ignora pressionamentos duplicados (teclado/toque repetido)
  if(this.held[id])return;
  this.held[id]=true;this.dn[id]=true;
  if(S.vib&&navigator.vibrate)try{navigator.vibrate(6);}catch(e){}
 },
 release(id){if(!this.held[id])return;this.held[id]=false;this.up[id]=true;},
 pd(id){const v=this.dn[id];this.dn[id]=false;return !!v;},
 pu(id){const v=this.up[id];this.up[id]=false;return !!v;},
 clear(){this.dn={};this.up={};},
 /* solta tudo (pausa, troca de tela, perda de foco): evita botão "preso" */
 releaseAll(){
  for(const id in this.held)if(this.held[id]){this.held[id]=false;this.up[id]=true;}
  this.L.x=this.L.y=this.R.x=this.R.y=0;
  TouchCtl.reset();
 }
};

/* ---------------- Layout do HUD ----------------
   Unidades "u" = k pixels, com k = min(altura/720, largura/1200) × tamanho do HUD.
   a: âncora (L esquerda · R direita · C centro) · x: distância do centro do botão até a margem
   y: do topo (após a margem) · yb: da base (após a margem) · ya: absoluta a partir do topo
   Topo: LT/LB (esq.) · RT/RB (dir.) · placar + CAM no centro. Embaixo: analógico + L3 (esq.), losango Y/X/B/A (dir.), pausa (centro).
   Centro da tela livre para a partida. */
const HD=[
 // Topo esquerdo / direito: ombros com o mesmo tamanho, mesma altura, espaçamento fixo de 12u
 {id:'LT',t:'LT',a:'L',x:62,y:44,w:120,h:68,c:'sh1',fs:28},
 {id:'LB',t:'LB',a:'L',x:194,y:44,w:120,h:68,c:'sh2',fs:28},
 {id:'RT',t:'RT',a:'R',x:62,y:44,w:120,h:68,c:'sh3',fs:28},
 {id:'RB',t:'RB',a:'R',x:194,y:44,w:120,h:68,c:'sh4',fs:28},
 // Esquerda embaixo: analógico (mesmo tamanho/sensibilidade de antes), L3 ao lado sem invadir a área do polegar
 {id:'LS',stick:1,a:'L',x:150,yb:150,w:270,h:270},
 {id:'L3',t:'L3',a:'L',x:355,yb:78,w:76,h:76,c:'rd',fs:24},
 // Direita embaixo: losango estilo Xbox (Y topo · X esquerda · B direita · A base), passo uniforme de 78u
 {id:'Y',t:'Y',a:'R',x:150,yb:253,w:96,h:96,c:'fb fy',fs:40},
 {id:'X',t:'X',a:'R',x:228,yb:175,w:96,h:96,c:'fb fx',fs:40},
 {id:'B',t:'B',a:'R',x:72,yb:175,w:96,h:96,c:'fb fb2',fs:40},
 {id:'A',t:'A',a:'R',x:150,yb:97,w:96,h:96,c:'fb fa',fs:40},
 // CAM logo à direita do placar (x é recalculado em layoutHUD conforme a largura do placar) · pausa embaixo ao centro
 {id:'NEXT',t:'CAM',a:'C',x:206,y:44,w:96,h:52,c:'pill',fs:22},
 {id:'MENU',menu:1,a:'C',x:0,yb:44,w:96,h:52,c:'mn'},
];
const HUDM={k:1,ml:0,mr:0,mt:0,mb:0};
let hudRoot=null;

function safeInsets(){
 const e=document.getElementById('safe');if(!e)return{t:0,r:0,b:0,l:0};
 const cs=getComputedStyle(e);
 return{t:parseFloat(cs.paddingTop)||0,r:parseFloat(cs.paddingRight)||0,b:parseFloat(cs.paddingBottom)||0,l:parseFloat(cs.paddingLeft)||0};
}
/* meia-largura visível do placar (em u): o CAM fica logo à direita dele, sem sobrepor */
function boardHalfU(){
 if(typeof SB!=='undefined'&&SB&&SB.ok&&SB.img){const c=SB.cfg||{},w=typeof c.width==='number'?c.width:380,vl=typeof c.visibleLeft==='number'?c.visibleLeft:0;return w*(.5-vl);}
 return 190;
}
function buildHUD(){
 hudRoot=$('#hud');hudRoot.innerHTML='';
 for(const d of HD){
  const e=document.createElement('div');
  e.className='hb '+(d.stick?'stk':d.c||'');e.id='hb-'+d.id;
  if(d.menu)e.innerHTML='<i></i><i></i><i></i>';
  else if(d.t){const s=document.createElement('span');s.textContent=d.t;e.appendChild(s);}
  if(d.stick){const kn=document.createElement('div');kn.className='knob';e.appendChild(kn);d.knob=kn;}
  d.el=e;d.pid=null;d.round=!!(d.stick||/\b(fb|rd)\b/.test(d.c||''));
  hudRoot.appendChild(e);
 }
 hudRoot.addEventListener('pointerdown',TouchCtl.down);
 hudRoot.addEventListener('pointermove',TouchCtl.move);
 hudRoot.addEventListener('pointerup',TouchCtl.up);
 hudRoot.addEventListener('pointercancel',TouchCtl.up);
 hudRoot.addEventListener('lostpointercapture',TouchCtl.up);
 layoutHUD();
}
function layoutHUD(){
 if(!hudRoot)return;
 const W=innerWidth,H=innerHeight,hs=S.hudS/100,sf=safeInsets();
 const kb=Math.min(H/720,W/1200);
 const k=Math.min(kb*hs,H/700); // nunca deixa a coluna estourar a altura
 HUDM.k=k;HUDM.kb=kb;
 HUDM.ml=Math.max(10,26*k)+sf.l;HUDM.mr=Math.max(10,26*k)+sf.r;
 HUDM.mt=Math.max(8,14*k)+sf.t;HUDM.mb=Math.max(10,22*k)+sf.b;
 const st=document.documentElement.style;
 st.setProperty('--u',k+'px');st.setProperty('--ho',(S.hudO/100).toString());
 for(const d of HD){
  const e=d.el;if(!e)continue;
  if(d.id==='NEXT')d.x=boardHalfU()+14+d.w/2;
  const w=d.w*k,h=d.h*k;
  d.cx=d.a==='L'?HUDM.ml+d.x*k:d.a==='R'?W-HUDM.mr-d.x*k:W/2+d.x*k;
  d.cy=d.ya!==undefined?d.ya*k:d.yb!==undefined?H-HUDM.mb-d.yb*k:HUDM.mt+d.y*k;
  d.pw=w;d.ph=h;d.R=Math.min(w,h)/2;
  d.pad=d.stick?d.R*.28:Math.max(9,13*k); // área de toque extra além do desenho
  e.style.left=d.cx+'px';e.style.top=d.cy+'px';e.style.width=w+'px';e.style.height=h+'px';
  if(d.fs)e.style.fontSize=(d.fs*k)+'px';
 }
 const lb=HD.find(d=>d.id==='LB');HUDM.lbR=lb&&lb.cx!==undefined?lb.cx+lb.pw/2:0; // borda direita do LB (limite do minimapa)
}

/* ---------------- Despachante de multitouch ----------------
   Cada dedo (pointerId) fica ligado a UM controle, escolhido pelo mais próximo do toque
   (dentro da área de toque ampliada). Vários dedos = vários botões ao mesmo tempo. */
function sDist(d,x,y){ // distância assinada até a borda do controle (negativa = dentro)
 const dx=x-d.cx,dy=y-d.cy;
 if(d.round)return hyp(dx,dy)-d.R;
 return Math.max(abs(dx)-d.pw/2,abs(dy)-d.ph/2);
}
function hitTest(x,y,grp){
 let best=null,bd=1e9;
 for(const d of HD){
  if(grp&&d.grp!==grp)continue;
  const s=sDist(d,x,y);
  if(s<=d.pad&&s<bd){bd=s;best=d;}
 }
 return best;
}
function setOn(d,on){d.el.classList.toggle('on',on);}
function moveStick(d,ev){
 const R=d.R,lim=R*.58,dx0=ev.clientX-d.cx,dy0=ev.clientY-d.cy,m=hyp(dx0,dy0);
 let dx=dx0,dy=dy0;if(m>lim){dx*=lim/m;dy*=lim/m;}
 const v=d.id==='LS'?In.L:In.R;v.x=dx/lim;v.y=dy/lim;
 d.knob.style.transform='translate(calc(-50% + '+dx.toFixed(1)+'px),calc(-50% + '+dy.toFixed(1)+'px))';
}
function freeCtl(d){
 if(d.stick){const v=d.id==='LS'?In.L:In.R;v.x=0;v.y=0;d.knob.style.transform='translate(-50%,-50%)';}
 else{setOn(d,false);In.release(d.id);}
 d.pid=null;
}
const TouchCtl={
 ptr:new Map(),
 down(ev){
  if(ev.pointerType==='mouse'&&ev.button!==0)return;
  ev.preventDefault();Au.init();Au.resume();
  const d=hitTest(ev.clientX,ev.clientY);
  if(!d||d.pid!==null)return; // fora de qualquer botão ou botão já ocupado por outro dedo
  try{hudRoot.setPointerCapture(ev.pointerId);}catch(x){}
  d.pid=ev.pointerId;TouchCtl.ptr.set(ev.pointerId,d);
  if(d.stick)moveStick(d,ev);else{setOn(d,true);In.press(d.id);}
 },
 move(ev){
  const d=TouchCtl.ptr.get(ev.pointerId);if(!d)return;
  ev.preventDefault();
  if(d.stick){moveStick(d,ev);return;}
  if(d.grp){ // direcional: deslizar o dedo troca de direção sem soltar
   const n=hitTest(ev.clientX,ev.clientY,d.grp);
   if(n&&n!==d&&n.pid===null){freeCtl(d);n.pid=ev.pointerId;TouchCtl.ptr.set(ev.pointerId,n);setOn(n,true);In.press(n.id);}
   else if(!n)TouchCtl.drop(ev.pointerId);
   return;
  }
  if(sDist(d,ev.clientX,ev.clientY)>d.pad+60*HUDM.k)TouchCtl.drop(ev.pointerId); // dedo arrastado para longe
 },
 up(ev){TouchCtl.drop(ev.pointerId);},
 drop(id){
  const d=TouchCtl.ptr.get(id);if(!d)return;
  TouchCtl.ptr.delete(id);freeCtl(d);
 },
 reset(){
  for(const d of HD)if(d.el&&(d.pid!==null||d.el.classList.contains('on')||d.stick))freeCtl(d);
  TouchCtl.ptr.clear();
 }
};
/* Qualquer perda de foco solta todos os controles */
addEventListener('blur',()=>In.releaseAll());
addEventListener('pagehide',()=>In.releaseAll());
document.addEventListener('visibilitychange',()=>{if(document.hidden)In.releaseAll();});

/* ---------------- Teclado (para testar no PC) ---------------- */
const KM={KeyJ:'A',KeyK:'B',KeyU:'X',KeyI:'Y',ShiftLeft:'RT',ShiftRight:'RT',KeyQ:'LB',KeyE:'RB',KeyZ:'LT',KeyC:'L3',KeyV:'R3',Escape:'MENU',
 KeyR:'DU',KeyF:'DD',KeyG:'DL',KeyH:'DR',KeyN:'PREV',KeyM:'NEXT'};
const kd={};
function keyVec(){
 In.kx=(kd.KeyD||kd.ArrowRight?1:0)-(kd.KeyA||kd.ArrowLeft?1:0);
 In.ky=(kd.KeyS||kd.ArrowDown?1:0)-(kd.KeyW||kd.ArrowUp?1:0);
 const m=hyp(In.kx,In.ky);if(m>1){In.kx/=m;In.ky/=m;}
}
addEventListener('keydown',e=>{
 if(e.repeat)return;const id=KM[e.code];
 if(id){In.press(id);e.preventDefault();}
 kd[e.code]=1;keyVec();Au.init();Au.resume();
});
addEventListener('keyup',e=>{const id=KM[e.code];if(id)In.release(id);kd[e.code]=0;keyVec();});

/* Bloqueia gestos do navegador (rolagem, zoom, menu de contexto) fora das listas com rolagem */
document.addEventListener('touchmove',e=>{if(!e.target.closest||!e.target.closest('.scroll'))e.preventDefault();},{passive:false});
document.addEventListener('contextmenu',e=>e.preventDefault());
document.addEventListener('gesturestart',e=>e.preventDefault());
