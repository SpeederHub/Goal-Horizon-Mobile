/* ============================================================
   FC CARREIRA 3D — MOTOR DE CAMPEONATOS
   Cada campeonato é independente: participantes, calendário,
   tabela, artilharia, campeão, promoção e rebaixamento.
   Tudo é guardado por ID de clube (nunca por posição em lista).
   ============================================================ */
'use strict';
const FCL=(function(){
 function rng(seed){let a=seed>>>0;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}

 /* Calendário por método do círculo. ids precisa ser par. */
 function schedule(ids,format){
  const n=ids.length,a=ids.slice(),rounds=[];
  for(let r=0;r<n-1;r++){
   const m=[];
   for(let i=0;i<n/2;i++){
    let h=a[i],w=a[n-1-i];
    if(i===0&&r%2===1){const t=h;h=w;w=t;}
    else if(i>0&&(r+i)%2===1){const t=h;h=w;w=t;}
    m.push([h,w]);
   }
   rounds.push(m);
   a.splice(1,0,a.pop());
  }
  if(format==='single')return rounds;
  return rounds.concat(rounds.map(m=>m.map(p=>[p[1],p[0]])));
 }

 const NAMEPOOL={
  BRA:['Silva','Santos','Oliveira','Souza','Lima','Pereira','Costa','Ribeiro','Carvalho','Gomes','Almeida','Rocha','Barbosa','Martins','Araújo','Nunes','Teixeira','Moreira'],
  ENG:['Smith','Taylor','Brown','Wilson','Evans','Walker','Wright','Hughes','Turner','Clarke','Hall','Parker','Cooper','Ward','Morgan','Bennett','Price','Reed'],
  ESP:['García','Martínez','López','Sánchez','Pérez','Gómez','Ruiz','Díaz','Moreno','Álvarez','Romero','Navarro','Torres','Ramos','Serrano','Molina','Castro','Ortega'],
  ITA:['Rossi','Russo','Ferrari','Esposito','Bianchi','Romano','Colombo','Ricci','Marino','Greco','Bruno','Gallo','Conti','De Luca','Costa','Fontana','Rinaldi','Moretti'],
  GER:['Müller','Schmidt','Schneider','Fischer','Weber','Meyer','Wagner','Becker','Hoffmann','Koch','Richter','Klein','Wolf','Neumann','Schwarz','Braun','Krüger','Lange'],
  FRA:['Martin','Bernard','Dubois','Thomas','Robert','Richard','Petit','Durand','Leroy','Moreau','Simon','Laurent','Lefebvre','Michel','Garcia','David','Bertrand','Roux'],
  POR:['Silva','Santos','Ferreira','Pereira','Oliveira','Costa','Rodrigues','Martins','Jesus','Sousa','Fernandes','Gonçalves','Gomes','Lopes','Marques','Alves','Almeida','Ribeiro'],
  NED:['de Jong','Jansen','de Vries','van den Berg','van Dijk','Bakker','Visser','Smit','Meijer','de Boer','Mulder','de Groot','Bos','Vos','Peters','Hendriks','Dekker','Brouwer']
 };
 const INI='ABCDEFGHJKLMNOPRSTVW';
 /* Elenco de artilheiros (fictício/procedural) — determinístico por clube */
 function squad(club){
  const r=rng(fcHash('sq'+club.id)),pool=NAMEPOOL[club.country]||NAMEPOOL.BRA,used={};
  const real=(typeof FCS!=='undefined'&&FCS.scorerPool(club.id))||[],out=real.slice(0,6); // elenco real (players/*.json) tem prioridade
  out.forEach(n=>used[n]=1);
  for(let i=out.length;i<6;i++){
   let nm;
   for(let k=0;k<20;k++){nm=INI[(r()*INI.length)|0]+'. '+pool[(r()*pool.length)|0];if(!used[nm])break;}
   used[nm]=1;out.push(nm);
  }
  return out;
 }
 const SW=[.30,.23,.18,.13,.10,.06];
 function pickScorer(club,r){
  const s=squad(club);let x=r(),a=0;
  for(let i=0;i<6;i++){a+=SW[i];if(x<=a)return s[i];}
  return s[0];
 }
 function poisson(l,r){const L=Math.exp(-l);let k=0,p=1;do{k++;p*=r();}while(p>L&&k<12);return k-1;}
 /* Resultado simulado entre dois clubes (ratings por ataque/meio/defesa) */
 function simScore(h,a,r){
  const st=c=>(c.att*.45+c.mid*.25);
  const xh=1.38*Math.exp((h.att*.55+h.mid*.2-a.def*.55-a.mid*.2)/32)*1.12;
  const xa=1.38*Math.exp((a.att*.55+a.mid*.2-h.def*.55-h.mid*.2)/32)*.92;
  return[Math.min(7,poisson(xh,r)),Math.min(7,poisson(xa,r))];
 }

 function emptyRow(){return{p:0,w:0,d:0,l:0,gf:0,ga:0,pts:0};}
 /* ids = participantes. state serializável (JSON). */
 function create(leagueId,ids,format){
  const table={};ids.forEach(id=>table[id]=emptyRow());
  return{id:leagueId,format:format==='single'?'single':'double',order:ids.slice(),round:0,table,scorers:{},last:null,lastRound:-1,champion:null};
 }
 function rounds(L){return L.order.length%2?0:(L.format==='single'?L.order.length-1:(L.order.length-1)*2);}
 function fixtures(L){return schedule(L.order,L.format);}
 function apply(L,h,a,gh,ga){
  const H=L.table[h],A=L.table[a];if(!H||!A)return;
  H.p++;A.p++;H.gf+=gh;H.ga+=ga;A.gf+=ga;A.ga+=gh;
  if(gh>ga){H.w++;A.l++;H.pts+=3;}else if(gh<ga){A.w++;H.l++;A.pts+=3;}else{H.d++;A.d++;H.pts++;A.pts++;}
 }
 function addScorer(L,clubId,name,n){
  const k=clubId+'|'+name,s=L.scorers[k]||(L.scorers[k]={c:clubId,n:name,g:0});s.g+=n||1;
 }
 /* joga a próxima rodada. userMatch = {h,a,gh,ga,scorers:[{c,n}]} é o jogo real do usuário (opcional).
    skipUser: id do clube do usuário cujo jogo não deve ser simulado quando userMatch for passado. */
 function playRound(L,userMatch,seedExtra){
  const fx=fixtures(L),r=L.round;if(r>=fx.length)return null;
  const rr=rng(fcHash(L.id+'|'+r+'|'+(seedExtra||0))),res=[];
  for(const[h,a]of fx[r]){
   let gh,ga,real=false;
   if(userMatch&&userMatch.h===h&&userMatch.a===a){gh=userMatch.gh;ga=userMatch.ga;real=true;
    (userMatch.scorers||[]).forEach(s=>addScorer(L,s.c,s.n,1));}
   else{
    const ch=FC_BY_ID[h],ca=FC_BY_ID[a];
    [gh,ga]=simScore(ch,ca,rr);
    for(let i=0;i<gh;i++)addScorer(L,h,pickScorer(ch,rr),1);
    for(let i=0;i<ga;i++)addScorer(L,a,pickScorer(ca,rr),1);
   }
   apply(L,h,a,gh,ga);res.push([h,a,gh,ga,real?1:0]);
  }
  L.last=res;L.lastRound=r;L.round=r+1;
  if(L.round>=fx.length)finish(L);
  return res;
 }
 function sorted(L){
  return L.order.slice().sort((x,y)=>{
   const A=L.table[x],B=L.table[y];
   return B.pts-A.pts||(B.gf-B.ga)-(A.gf-A.ga)||B.gf-A.gf||(FC_BY_ID[x].name<FC_BY_ID[y].name?-1:1);
  });
 }
 function finish(L){if(!L.champion)L.champion=sorted(L)[0];}
 function done(L){return L.round>=rounds(L);}
 function topScorers(L,n){
  return Object.values(L.scorers).sort((a,b)=>b.g-a.g||(a.n<b.n?-1:1)).slice(0,n||10);
 }
 /* simula até a rodada alvo (para a divisão-irmã) */
 function playUntil(L,target){while(L.round<Math.min(target,rounds(L)))playRound(L,null);}

 /* Promoção/rebaixamento entre divisão 1 e 2 de um país.
    Retorna novos membros {tier1:[ids],tier2:[ids]} + movimentos. */
 function promoRelegate(country,L1,L2){
  const n=country.promo,t1=sorted(L1),t2=sorted(L2);
  const down=t1.slice(-n);
  const up=t2.filter(id=>!FC_BY_ID[id].reserve).slice(0,n);
  const nt1=t1.filter(id=>!down.includes(id)).concat(up);
  const nt2=t2.filter(id=>!up.includes(id)).concat(down);
  return{tier1:nt1,tier2:nt2,up,down};
 }
 /* força do adversário controlado pela IA no jogo real */
 function aiStrength(opp,mine){
  let s=.80+(opp.ovr-55)*.0125+(opp.ovr-(mine?mine.ovr:opp.ovr))*.003;
  return Math.max(.78,Math.min(1.26,s));
 }
 return{rng,schedule,create,rounds,fixtures,playRound,playUntil,sorted,finish,done,topScorers,promoRelegate,aiStrength,squad,apply,simScore,poisson,pickScorer};
})();
