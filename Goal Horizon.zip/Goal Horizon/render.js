'use strict';
/* =====================================================================
   FC CARREIRA 3D — RENDERIZAÇÃO (render.js)
   Câmera, projeção 3D (Canvas 2D), campo, arquibancadas, jogadores, bola e overlay.
   Depende de (game.js): G, S, HL, HW, GW, GH, GD, BR, KIT, GKK, TEAMA, halfLen, fpsShow, math helpers
   Depende de (input.js): HUDM
   ===================================================================== */

/* ---------------- Câmera ---------------- */
const C={px:0,py:20,pz:40,tx:0,ty:0,tz:0,fx:0,fy:-.6,fz:-.8,rx:1,ry:0,rz:0,ux:0,uy:.8,uz:-.6,focal:800,cx:0,cy:0,fov:46,
 gfx:0,gfz:-1,grx:1,grz:0};
function snapCamera(){updateCamera(1,true);}
function updateCamera(dt,snap){
 const b=G.ball,u=G.user||{x:0,z:0,face:0,vx:0,vz:0};
 let h,d,a=0,fov=46,fxp,fzp,ty=.6;
 if(G.pen){
  // Câmera dedicada dos pênaltis: sempre o mesmo gol (+x); olhando "de trás" do cobrador
  const pn=G.pen,ph=pn.phase,mine=pn.kickTeam===0;
  a=-PI/2;fxp=HL-2;fzp=0;h=4.6;d=19;fov=50;ty=1.4;
  if(mine){ // eu chuto: câmera atrás do cobrador, acompanha a mira e aproxima no chute
   fzp=pn.aimZ*GW*.55;
   if(ph==='runup'){h=3.0;d=14.5;fov=46;ty=1.3;}
   else if(ph==='flight'){fxp=HL-3;fzp=b.z*.6;h=2.3;d=13;fov=43;ty=1.2+Math.min(2,b.y*.5);}
   else if(ph==='resolve'){fxp=HL-4;fzp=b.z*.5;h=pn.result==='goal'?4.2:3;d=pn.result==='goal'?15:13;if(pn.result==='goal')a=-PI/2+.55*(b.z>=0?-1:1);fov=48;ty=1.4;}
  }else{ // eu defendo: visão mais alta/aberta, vendo cobrador + goleiro; no chute fecha no gol
   h=4.6;d=22;fxp=HL-7;fov=52;ty=1.2;
   if(ph==='runup'){h=4.2;d=20;fxp=HL-6;fov=49;}
   else if(ph==='flight'){fxp=HL-4;fzp=b.z*.5;h=3.2;d=15;fov=46;ty=1.2+Math.min(2,b.y*.5);}
   else if(ph==='resolve'){fxp=HL-4;fzp=b.z*.5;h=3.6;d=15;fov=48;}
  }
 }else if(G.sp){ // Cobrança com mira (falta/pênalti da partida e Treino de falta): câmera atrás do cobrador olhando o gol (+x), como na disputa de pênaltis
  const sp=G.sp,ph=sp.phase;
  a=-PI/2;
  if(sp.kind==='pen'){fxp=HL-2;fzp=sp.aimZ*GW*.55;h=4.6;d=19;fov=50;ty=1.4;
   if(ph==='runup'){h=3.0;d=14.5;fov=46;ty=1.3;}
   else if(ph==='flight'){fxp=HL-3;fzp=b.z*.6;h=2.3;d=13;fov=43;ty=1.2+Math.min(2,b.y*.5);}
  }else{fxp=b.x+(HL-b.x)*.45;fzp=b.z*.55+sp.aimZ*GW*.2;h=5.2;d=15;fov=48;ty=1.1;
   if(ph==='runup'){h=4.2;d=13;fov=46;}
   else if(ph==='flight'){fxp=b.x+(HL-b.x)*.55;fzp=b.z*.6;h=3.6;d=14;fov=46;ty=1.2+Math.min(2,b.y*.4);}
  }
 }else if(G.train&&G.train.type==='foul'){ // Treino de falta: câmera atrás do cobrador, olhando a barreira e o gol (+x); acompanha a bola depois do chute
  a=-PI/2;fxp=b.x+(HL-b.x)*.45;fzp=b.z*.55;h=5.2;d=15;fov=48;ty=1.1;
 }else switch(S.cam){
  case 0:fxp=b.x*.92+b.vx*.3;fzp=b.z*.45;h=26;d=34;fov=48;break;
  case 1:fxp=b.x+b.vx*.25;fzp=b.z*.7;h=13;d=24;fov=50;break;
  case 2:fxp=b.x*.65+u.x*.35+b.vx*.25;fzp=b.z*.65+u.z*.35;h=18;d=26;a=-PI/3;fov=50;break;
  case 3:fxp=u.x+cos(u.face)*3+u.vx*.2;fzp=u.z+sin(u.face)*3+u.vz*.2;h=6.5;d=10.5;a=-PI/2;fov=55;ty=1;break;
  default:fxp=b.x;fzp=b.z*.6;h=20;d=30;fov=48;
 }
 h*=S.camH;d*=S.camD;a+=S.camA*PI/180;
 if(Net.mp&&Net.role==='guest')a+=PI; // visitante ataca para a direita da própria tela
 fxp=clamp(fxp,-HL-6,HL+6);fzp=clamp(fzp,-HW,HW);
 const wx=fxp+sin(a)*d,wy=h,wz=fzp+cos(a)*d;
 const k=snap?1:1-Math.exp(-4.2*dt),k2=snap?1:1-Math.exp(-6.5*dt);
 C.px+=(wx-C.px)*k;C.py+=(wy-C.py)*k;C.pz+=(wz-C.pz)*k;
 C.tx+=(fxp-C.tx)*k2;C.ty+=(ty-C.ty)*k2;C.tz+=(fzp-C.tz)*k2;C.fov+=(fov-C.fov)*k2;
 let fx=C.tx-C.px,fy=C.ty-C.py,fz=C.tz-C.pz;const fl=hyp(fx,fy,fz)||1;fx/=fl;fy/=fl;fz/=fl;
 let rx=-fz,rz=fx;const rl=hyp(rx,rz)||1;rx/=rl;rz/=rl;
 C.fx=fx;C.fy=fy;C.fz=fz;C.rx=rx;C.ry=0;C.rz=rz;
 C.ux=-rz*fy;C.uy=rz*fx-rx*fz;C.uz=rx*fy;
 const gl=hyp(fx,fz)||1;C.gfx=fx/gl;C.gfz=fz/gl;C.grx=rx;C.grz=rz;
}

/* ---------------- Canvas e projeção ---------------- */
const cv=$('#c'),ctxBase=cv.getContext('2d',{alpha:false});
let ctx=ctxBase,cvTop=null,ctxTop=null; // cvTop: camada 2D por cima do Three (usada só com estádio .glb: HUD, tags e partículas)
let CW=640,CH=360,QK=1,sky=null,FX=null; // QK = pixels do canvas por pixel CSS · FX = vinheta/névoa pré-renderizada

/* =====================================================================
   THREE.JS — modelos 3D dos jogadores (GLTF + AnimationMixer)
   Campo, estádio, placar e UI continuam no Canvas 2D.
   A câmera Three.js é sincronizada com C (perspectiva atual).
   ===================================================================== */
let T3=null; // {renderer, scene, camera, players: Map, clock, loader, baseModel, fallback}
function initThreePlayers(){
 if(typeof THREE==='undefined'){console.warn('[T3] Three.js não carregou');return;}
 const canvas3=document.createElement('canvas');
 canvas3.id='c3';
 canvas3.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:2';
 document.body.appendChild(canvas3);
 const renderer=new THREE.WebGLRenderer({canvas:canvas3,alpha:true,antialias:true,powerPreference:'high-performance'});
 renderer.setClearColor(0x000000,0);
 // Compatibilidade de cor com Three.js r147 (outputEncoding/sRGBEncoding).
 if('outputColorSpace' in renderer && THREE.SRGBColorSpace){
  renderer.outputColorSpace=THREE.SRGBColorSpace;
 }else if(THREE.sRGBEncoding){
  renderer.outputEncoding=THREE.sRGBEncoding;
 }
 renderer.shadowMap.enabled=false;
 const scene=new THREE.Scene();
 const camera=new THREE.PerspectiveCamera(46,16/9,.5,200);
 // Luzes simples de estádio
 if(typeof GLBSys==='undefined'){ // sem glb-system.js: luzes simples
  const amb=new THREE.AmbientLight(0xffffff,.28);scene.add(amb);
  const hemi=new THREE.HemisphereLight(0xe6efff,0x3f5a2e,.42);scene.add(hemi);          // céu + rebote do gramado: tira a cara de "plástico chapado"
  const dir=new THREE.DirectionalLight(0xfff5e0,.95);dir.position.set(20,40,10);scene.add(dir);
  const dir2=new THREE.DirectionalLight(0xaaccff,.3);dir2.position.set(-30,20,-15);scene.add(dir2);
  const rim=new THREE.DirectionalLight(0xffffff,.3);rim.position.set(-8,22,-38);scene.add(rim); // luz de recorte (separa o jogador do fundo)
 }
 T3={renderer,scene,camera,players:new Map(),clock:new THREE.Clock(),loader:null,baseGltf:null,ready:false,fallbackMat:{},ball:null,ballTrail:null};
 // camada 2D por cima do Three (só visível no modo estádio .glb)
 cvTop=document.createElement('canvas');cvTop.id='c4';
 cvTop.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:3;display:none';
 document.body.appendChild(cvTop);ctxTop=cvTop.getContext('2d');
 // Tenta carregar modelo .glb (coloque em models/player.glb). Se falhar, usa humanóide procedural.
 if(typeof THREE.GLTFLoader!=='undefined'){
  T3.loader=new THREE.GLTFLoader();
  if(typeof GLBSys!=='undefined')GLBSys.init(T3);
  // Variantes de tom de pele (legado: models/players/player-N-*.glb). O modelo novo (v2) já traz todas as variações
  // (10 penteados, 4 barbas, morphs de corpo/rosto) em models/player.glb e dispensa estes arquivos; só são carregados se player.glb for um modelo antigo.
  T3.skinVariants=[];
  T3.loadLegacyVariants=function(){
   [['player-1-claro','#f1c9a5'],['player-2-moreno-claro','#d9a47a'],['player-3-moreno','#b87a4e'],['player-4-negro-retinto','#8a5a38'],['player-5-negro-escuro','#5e3b24']].forEach(([f,hex])=>{
    T3.loader.load('models/players/'+f+'.glb',(g)=>{
     T3.skinVariants.push({hex,rgb:[1,3,5].map(i=>parseInt(hex.substr(i,2),16)),scene:g.scene});
    },undefined,(e)=>{console.warn('[T3] variante não carregou:',f,e);});
   });
  };
  T3.loader.load('models/player.glb',(gltf)=>{
   T3.baseGltf=gltf;
   T3.v2=false;gltf.scene.traverse(o=>{if(o.isMesh&&/^hair_/i.test(o.name||''))T3.v2=true;});
   if(!T3.v2)T3.loadLegacyVariants();
   if(typeof GLBSys!=='undefined')GLBSys.registerClips(gltf,'player',true);
   T3.ready=true;
   console.log('[T3] Modelo GLB carregado, animações:',Object.keys(gltf.animations||{}).map(i=>gltf.animations[i].name));
  },undefined,(err)=>{
   ghDiag('models/player.glb não carregou (arquivo ausente ou inválido) → boneco simples.');
   console.warn('[T3] models/player.glb não encontrado — usando humanóide procedural. Coloque um .glb animado em models/player.glb para usar GLTF+AnimationMixer.');
   T3.ready=true;
  });
 }else{
  console.warn('[T3] GLTFLoader indisponível — humanóide procedural.');
  T3.ready=true;
 }
 // Materiais de fallback por cor
 function mat(hex){if(T3.fallbackMat[hex])return T3.fallbackMat[hex];const m=new THREE.MeshStandardMaterial({color:new THREE.Color(hex),roughness:.7,metalness:.05});T3.fallbackMat[hex]=m;return m;}
 T3.mat=mat;
 // Bola 3D — Trionda 2026 (GLB oficial da Copa) com fallback procedural
 (function createBall(){
  const R=typeof BR==='number'?BR:.22;
  const root=new THREE.Group();
  root.visible=false;
  scene.add(root);
  T3.ball=root;

  // Rastro de velocidade
  const trailMat=new THREE.LineBasicMaterial({color:0xffffff,transparent:true,opacity:.35});
  const trailGeo=new THREE.BufferGeometry();
  const trail=new THREE.Line(trailGeo,trailMat);
  trail.frustumCulled=false;
  scene.add(trail);
  T3.ballTrail=trail;

  function makeProceduralFallback(){
   const geo=new THREE.SphereGeometry(R,24,18);
   const matBall=new THREE.MeshStandardMaterial({
    color:0xf4f6f8, roughness:.35, metalness:.08,
    emissive:0x111111, emissiveIntensity:.05
   });
   const mesh=new THREE.Mesh(geo,matBall);
   const darkMat=new THREE.MeshStandardMaterial({color:0x1a1e24,roughness:.45,metalness:.05});
   const patches=new THREE.Group();
   const dirs=[
    [0,1,0],[0,-1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1],
    [.7,.7,0],[-.7,.7,0],[.7,-.7,0],[-.7,-.7,0],
    [0,.7,.7],[0,-.7,.7]
   ];
   for(const d of dirs){
    const len=Math.hypot(d[0],d[1],d[2])||1;
    const px=d[0]/len*(R*0.92),py=d[1]/len*(R*0.92),pz=d[2]/len*(R*0.92);
    const p=new THREE.Mesh(new THREE.CircleGeometry(R*0.28,10),darkMat);
    p.position.set(px,py,pz);
    p.lookAt(0,0,0);
    p.rotateY(Math.PI);
    patches.add(p);
   }
   mesh.add(patches);
   return mesh;
  }

  function fitBallToRadius(obj, targetR){
   // Calcula bounding sphere e escala para o raio do jogo (BR)
   const box=new THREE.Box3().setFromObject(obj);
   const size=new THREE.Vector3();
   box.getSize(size);
   const maxDim=Math.max(size.x,size.y,size.z)||1;
   const scale=(targetR*2)/maxDim;
   obj.scale.setScalar(scale);
   // recentra no origin (pivô no centro da bola)
   box.setFromObject(obj);
   const center=new THREE.Vector3();
   box.getCenter(center);
   obj.position.sub(center);
  }

  function onBallLoaded(gltf){
   const model=gltf.scene;
   model.traverse(c=>{
    if(c.isMesh){
     c.castShadow=true;
     c.receiveShadow=true;
     if(c.material){
      // garante brilho realista de bola de futebol
      if(Array.isArray(c.material)) c.material.forEach(m=>{m.roughness=Math.min(m.roughness??.4,.45); m.metalness=Math.max(m.metalness??0,.05);});
      else { c.material.roughness=Math.min(c.material.roughness??.4,.45); c.material.metalness=Math.max(c.material.metalness??0,.05); }
     }
    }
   });
   fitBallToRadius(model, R);
   // limpa filhos anteriores (fallback) e adiciona o modelo
   while(root.children.length) root.remove(root.children[0]);
   root.add(model);
   console.log('[T3] Bola Trionda 2026 carregada e escalada para R='+R);
  }

  // tenta carregar o GLB oficial
  if(T3.loader){
   T3.loader.load('models/trionda2026.glb', onBallLoaded, undefined, (err)=>{
    console.warn('[T3] Falha ao carregar models/trionda2026.glb — usando bola procedural.', err);
    root.add(makeProceduralFallback());
   });
  }else{
   console.warn('[T3] GLTFLoader indisponível — bola procedural.');
   root.add(makeProceduralFallback());
  }
 })();
 // Cria humanóide procedural simples (substituível pelo GLB)
 T3.createProcedural=function(kit,skinHex,hairHex,bodyScale){
  const g=new THREE.Group();
  const s=bodyScale||1;
  const skinM=mat(skinHex||'#d9a47a'), shirtM=mat(kit.sh||'#1f5fd6'), shortM=mat(kit.sh2||'#ffffff'), sockM=mat(kit.so||'#1f5fd6'), hairM=mat(hairHex||'#161210'), bootM=mat('#111111');
  // tronco
  const torso=new THREE.Mesh(new THREE.CylinderGeometry(.18*s,.22*s,.45*s,8),shirtM);torso.position.y=1.15*s;g.add(torso);
  // cabeça
  const head=new THREE.Mesh(new THREE.SphereGeometry(.14*s,10,8),skinM);head.position.y=1.52*s;g.add(head);
  // cabelo
  const hair=new THREE.Mesh(new THREE.SphereGeometry(.145*s,8,6),hairM);hair.position.y=1.58*s;hair.scale.set(1,.7,1);g.add(hair);
  // braços
  const armGeo=new THREE.CylinderGeometry(.05*s,.045*s,.42*s,6);
  const lArm=new THREE.Mesh(armGeo,skinM);lArm.position.set(-.28*s,1.2*s,0);lArm.rotation.z=.25;g.add(lArm);
  const rArm=new THREE.Mesh(armGeo,skinM);rArm.position.set(.28*s,1.2*s,0);rArm.rotation.z=-.25;g.add(rArm);
  // pernas
  const legGeo=new THREE.CylinderGeometry(.07*s,.055*s,.55*s,6);
  const lLeg=new THREE.Mesh(legGeo,shortM);lLeg.position.set(-.1*s,.55*s,0);g.add(lLeg);
  const rLeg=new THREE.Mesh(legGeo,shortM);rLeg.position.set(.1*s,.55*s,0);g.add(rLeg);
  // meias + chuteiras
  const sockGeo=new THREE.CylinderGeometry(.055*s,.05*s,.22*s,6);
  const lSock=new THREE.Mesh(sockGeo,sockM);lSock.position.set(-.1*s,.18*s,0);g.add(lSock);
  const rSock=new THREE.Mesh(sockGeo,sockM);rSock.position.set(.1*s,.18*s,0);g.add(rSock);
  const bootGeo=new THREE.BoxGeometry(.12*s,.08*s,.22*s);
  const lBoot=new THREE.Mesh(bootGeo,bootM);lBoot.position.set(-.1*s,.04*s,.04*s);g.add(lBoot);
  const rBoot=new THREE.Mesh(bootGeo,bootM);rBoot.position.set(.1*s,.04*s,.04*s);g.add(rBoot);
  g.userData={lArm,rArm,lLeg,rLeg,lSock,rSock,lBoot,rBoot,head,torso,procedural:true};
  return g;
 };
}

function syncThreeCamera(){
 if(!T3)return;
 const cam=T3.camera;
 cam.fov=2*Math.atan(Math.tan(C.fov*PI/360)/(S.camZ||1))*180/PI; // mesmo zoom do Canvas
 cam.aspect=CW/Math.max(1,CH);
 const st=typeof GLBSys!=='undefined'&&GLBSys.stadiumActive();
 cam.near=st?.3:.5;cam.far=st?900:180;
 if(Math.abs(C.cx-CW/2)>.01||Math.abs(C.cy-CH/2)>.01)cam.setViewOffset(CW,CH,-(C.cx-CW/2),-(C.cy-CH/2),CW,CH); // tremor de câmera
 else if(cam.view)cam.clearViewOffset();
 cam.position.set(C.px,C.py,C.pz);
 cam.up.set(C.ux,C.uy,C.uz);
 cam.lookAt(C.tx,C.ty,C.tz);
 cam.updateProjectionMatrix();
}

function ghDiag(txt){ // aviso visível na tela (útil no celular, sem console)
 try{console.warn('[GLB jogadores] '+txt);
  let d=document.getElementById('gh-diag');
  if(!d){d=document.createElement('div');d.id='gh-diag';d.style.cssText='position:fixed;left:6px;bottom:6px;max-width:92vw;z-index:99999;background:rgba(0,0,0,.78);color:#ffd54a;font:12px/1.3 monospace;padding:6px 8px;border-radius:6px;white-space:pre-wrap;pointer-events:none';document.body.appendChild(d);}
  d.textContent='JOGADORES 3D: '+txt;clearTimeout(d._t);d._t=setTimeout(()=>{d.remove();},25000);}catch(e){}
}
/* =====================================================================
   VISUAL DOS JOGADORES v2 (modelo models/player.glb gerado por tools/gerar-jogadores.py)
   Cada jogador ganha um "look" determinístico (mesmo jogador = mesmo visual sempre):
   penteado (10), barba (4), formato do rosto (morphs), constituição física (morph Build), altura, chuteira.
   Usa dados do elenco (altura, físico, ritmo, idade) quando existem. Não altera física/IA/controles.
   Materiais são COMPARTILHADOS entre jogadores (mesma cor = mesmo material) para economizar memória e trocas de estado.
   ===================================================================== */
function ghHash(s){let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}return h>>>0;}
function ghRng(seed){let a=seed>>>0||1;return function(){a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};}
function ghFabricTex(kind){ // textura de tecido (tons de cinza, ~0.9 de média: só modula a cor do clube)
 T3.fabTex=T3.fabTex||{};if(T3.fabTex[kind])return T3.fabTex[kind];
 const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');
 x.fillStyle='#f2f2f2';x.fillRect(0,0,64,64);
 if(kind==='shirt'){for(let i=0;i<64;i+=4){for(let j=0;j<64;j+=4){x.fillStyle='rgba(0,0,0,.07)';x.fillRect(i+((j/4)%2)*2,j,2,2);}}for(let i=0;i<64;i+=16){x.fillStyle='rgba(0,0,0,.05)';x.fillRect(i,0,8,64);}}
 else if(kind==='shorts'){for(let i=0;i<64;i+=3){for(let j=0;j<64;j+=3){x.fillStyle='rgba(0,0,0,.06)';x.fillRect(i,j,1,1);}}}
 else{for(let i=0;i<64;i+=4){x.fillStyle='rgba(0,0,0,.10)';x.fillRect(i,0,1,64);}}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=2;
 return T3.fabTex[kind]=t;
}
function ghTrimColor(hex){ // cor do colarinho/punhos/faixa da meia: contraste suave com a camisa
 const c=new THREE.Color(hex),h={};c.getHSL(h);
 h.l=h.l>.62?h.l*.52:Math.min(.95,h.l+.36);c.setHSL(h.h,h.s,h.l);return c;
}
const GH_HAIR_POOL={ // v4: +quiff, twists, dreads, bald (raspado/careca)
 dark:['buzz','crop','fade','curly','afro','braids','mohawk','twists','dreads','quiff','bald','fade','curly','long','twists','afro'],
 mid:['crop','fade','curly','slick','buzz','mohawk','bun','long','quiff','twists','bald','dreads','slick','fade','crop','curly'],
 light:['crop','slick','fade','buzz','long','bun','quiff','slick','curly','mohawk','bald','crop','quiff','fade','long','crop']};
const GH_GLOVES=['#d9ff3a','#ff7ad9','#ffffff','#ff7a1a','#2fd0ff','#14161b','#ffd21f','#7b5cff'];
const GH_BOOTS=['#15171a','#f2f2f2','#15171a','#f2a900','#ff4d2e','#27d3ff','#7bff3a','#d8dadd'];
/* Distribuição de visuais por time: cada time recebe um "baralho" de combinações (penteado, barba, rosto, chuteira) montado de uma vez
   para os 11 jogadores, na ordem do elenco, evitando repetir o mesmo penteado/barba/rosto no mesmo time. Determinístico (mesmo elenco =
   mesmos visuais) e refeito quando uma nova partida cria novos jogadores. */
const GH_BEARDS=['stubble','full','goatee','moustache','circle'];
function ghTeamLooks(p){
 const arr=(typeof G!=='undefined'&&G.teamP&&G.teamP[p.team])||null;
 if(!arr||arr.indexOf(p)<0)return null;
 T3.lookReg=T3.lookReg||{};
 let reg=T3.lookReg[p.team];
 if(!reg||reg.arr!==arr||reg.n!==arr.length||reg.sig!==arr.map(q=>q.pid||q.name).join('|')){
  reg={arr,n:arr.length,sig:arr.map(q=>q.pid||q.name).join('|'),by:new Map()};T3.lookReg[p.team]=reg;
  const useS={},useB={},useBoot={},faces=[];let nBeard=0;
  arr.forEach((q,idx)=>{
   const rnd=ghRng(ghHash((q.pid||q.name||'')+'|'+q.team+'|'+(q.num||q.i||0)+'|v3'));
   const sk=q.skin||'#d9a47a',sc=[1,3,5].map(i=>(parseInt(String(sk).substr(i,2),16)||0)/255),lum=sc[0]*.3+sc[1]*.59+sc[2]*.11;
   const pool=lum<.42?GH_HAIR_POOL.dark:lum<.66?GH_HAIR_POOL.mid:GH_HAIR_POOL.light;
   const uniq=[...new Set(pool)];
   // penteado: o menos usado do time entre os que combinam com o tom de pele (sorteio desempata)
   let bs=1e9,style=uniq[0];for(const st of uniq){const sc2=(useS[st]||0)*10+rnd();if(sc2<bs){bs=sc2;style=st;}}
   useS[style]=(useS[style]||0)+1;
   // barba: ~4 de 11 por time, variando o tipo; goleiro/zagueiro mais propensos
   let beard=null;const age=ghSquadOf(q).age||26;
   const want=(age>=24?.36:.14)+(q.role==='CB'||q.role==='GK'?.08:0);
   if(rnd()<want&&nBeard<5){let bb=1e9;for(const bt of GH_BEARDS){const s2=(useB[bt]||0)*10+rnd();if(s2<bb){bb=s2;beard=bt;}}useB[beard]=(useB[beard]||0)+1;nBeard++;}
   // chuteira: a menos usada do time
   let bb2=1e9,boot=GH_BOOTS[0];for(const bt of GH_BOOTS){const s2=(useBoot[bt]||0)*10+rnd();if(s2<bb2){bb2=s2;boot=bt;}}
   useBoot[boot]=(useBoot[boot]||0)+1;
   // rosto: entre 6 candidatos, o mais distante dos já usados no time (formatos de cabeça realmente diferentes)
   let face=null,fd=-1;
   for(let c=0;c<6;c++){const f=[(rnd()-.5)*1.9,(rnd()-.5)*1.9,rnd()*1.2-.2];let md=9;for(const g of faces)md=Math.min(md,Math.hypot(f[0]-g[0],f[1]-g[1],(f[2]-g[2])*.8));if(md>fd){fd=md;face=f;}}
   faces.push(face);
   reg.by.set(q,{style,beard,boot,face,rnd});
  });
 }
 return reg.by.get(p)||null;
}
function fcLumSafe(hex){const c=new THREE.Color(hex);return c.r*.3+c.g*.59+c.b*.11;}
function ghSquadOf(p){let sq=null;try{if(p.pid&&typeof FCS!=='undefined'&&FCS.player){sq=FCS.player(String(p.pid).split('.').slice(0,2).join('.'),p.pid);}}catch(e){}return sq||{};}
function ghApplyLook(root,p,kit,skin,hair){
 // 0) começa escondendo todas as variantes de cabelo/barba (assim, mesmo se algo falhar, nada fica sobreposto)
 root.traverse(o=>{if(o.isMesh){const n=(o.name||'').toLowerCase();if(/^(hair|beard)_/.test(n)||n==='gkarms'||n==='gloves'||n==='gkpants')o.visible=false;o.frustumCulled=false;}});
 const sq0=ghSquadOf(p),sq=(sq0&&Object.keys(sq0).length)?sq0:null;
 const tl=ghTeamLooks(p);
 const rnd=tl?tl.rnd:ghRng(ghHash((p.pid||p.name||'')+'|'+p.team+'|'+(p.num||p.i||0)));
 const sc=[1,3,5].map(i=>(parseInt(String(skin).substr(i,2),16)||0)/255),lum=sc[0]*.3+sc[1]*.59+sc[2]*.11;
 const role=p.role,isGK=role==='GK';
 // constituição: -1 magro ... +1 forte
 let b;
 if(sq&&isFinite(sq.physical)&&isFinite(sq.pace))b=(sq.physical-64)/28*.9-(sq.pace-64)/30*.45+(rnd()-.5)*.5;
 else b=(({GK:.3,CB:.35,ST:.15,CM:0,LB:-.2,RB:-.2,LM:-.3,RM:-.3})[role]||0)+(rnd()-.5)*.8;
 b=Math.max(-1,Math.min(1,b));
 // altura (m = 1.8 * h)
 let h;
 if(sq&&sq.height>=140&&sq.height<=220)h=Math.max(.9,Math.min(1.1,sq.height/181));
 else h=Math.max(.92,Math.min(1.08,(({GK:1.04,CB:1.03,ST:1.01,CM:1,LB:.98,RB:.98,LM:.97,RM:.97})[role]||1)+(rnd()-.5)*.06));
 // penteado / barba / chuteira / rosto
 let style,beard,boot,face;
 if(tl){style=tl.style;beard=tl.beard;boot=tl.boot;face=tl.face;}
 else{
  const pool=lum<.42?GH_HAIR_POOL.dark:lum<.66?GH_HAIR_POOL.mid:GH_HAIR_POOL.light;
  style=pool[Math.floor(rnd()*pool.length)];
  const age=sq&&sq.age?sq.age:26;beard=null;const rb=rnd();
  if(rb<(age>=24?.36:.14)){const q=rnd();beard=q<.35?'stubble':q<.58?'full':q<.74?'goatee':q<.88?'circle':'moustache';}
  boot=GH_BOOTS[Math.floor(rnd()*GH_BOOTS.length)];
  face=[(rnd()-.5)*1.7,(rnd()-.5)*1.7,rnd()*1.1-.15];
 }
 // largura do corpo (tipos físicos: magro, atlético, forte) — escala em X/Z por cima da altura
 const bw=Math.max(.9,Math.min(1.12,1+b*.055+(rnd()-.5)*.05+(isGK?.02:0)));
 // goleiro: luvas (cor sorteada, longe da cor da camisa), manga longa, calça comprida em ~40% dos goleiros
 let gloveC=null,longPants=false;
 if(isGK){
  const kc=new THREE.Color(kit.sh),h0=ghHash((p.pid||p.name||'gk')+'|'+p.team+'|gl');
  for(let i=0;i<GH_GLOVES.length;i++){const c=new THREE.Color(GH_GLOVES[(h0+i)%GH_GLOVES.length]);if(Math.abs(c.r-kc.r)+Math.abs(c.g-kc.g)+Math.abs(c.b-kc.b)>.7){gloveC=GH_GLOVES[(h0+i)%GH_GLOVES.length];break;}}
  if(!gloveC)gloveC=fcLumSafe(kit.sh)>.5?'#14161b':'#ffffff';
  longPants=((h0>>>3)%10)<4;
 }
 const infl={Build:b>0?b*.9:b*.85,FaceWidth:face[0],FaceLength:face[1],Jaw:face[2]};
 const hairC=new THREE.Color(hair),skinC=new THREE.Color(skin);
 const eyes=[];
 const shared=(o,key,setup)=>{T3.matCache=T3.matCache||{};let m=T3.matCache[key];if(!m){m=o.material.clone();setup(m);T3.matCache[key]=m;}o.material=m;};
 root.traverse(o=>{
  if(!o.isMesh||!o.material)return;
  const n=(o.name||'').toLowerCase();
  // morphs (formato do rosto / físico)
  if(o.morphTargetInfluences&&o.morphTargetInfluences.length){
   let d=o.morphTargetDictionary;
   if(!d&&o.userData&&o.userData.targetNames){d={};o.userData.targetNames.forEach((t,i)=>{d[t]=i;});}
   if(d)for(const k in infl)if(d[k]!==undefined)o.morphTargetInfluences[d[k]]=infl[k];
  }
  const uv=o.geometry&&o.geometry.attributes&&o.geometry.attributes.uv;
  if(n==='skin')shared(o,'skin|'+skin,m=>{m.color.set(skin);m.roughness=.62;m.metalness=0;if(m.emissive){m.emissive.copy(skinC).multiplyScalar(.10);} });
  else if(n==='shirt')shared(o,'shirt|'+kit.sh,m=>{m.color.set(kit.sh);m.roughness=.74;m.metalness=0;if(uv)m.map=ghFabricTex('shirt');});
  else if(n==='trim')shared(o,'trim|'+kit.sh,m=>{m.color.copy(ghTrimColor(kit.sh));m.roughness=.7;});
  else if(n==='shorts')shared(o,'shorts|'+kit.sh2,m=>{m.color.set(kit.sh2);m.roughness=.68;m.metalness=0;if(uv)m.map=ghFabricTex('shorts');});
  else if(n==='socks')shared(o,'socks|'+kit.so,m=>{m.color.set(kit.so);m.roughness=.86;m.metalness=0;if(uv)m.map=ghFabricTex('socks');});
  else if(n==='boots')shared(o,'boots|'+boot,m=>{m.color.set(boot);m.roughness=.38;m.metalness=.1;});
  else if(n==='eyes'){eyes.push(o);}
  else if(n==='gkarms'){if(isGK){o.visible=true;shared(o,'gkarms|'+kit.sh,m=>{m.color.set(kit.sh);m.roughness=.72;m.metalness=0;});}}
  else if(n==='gloves'){if(isGK){o.visible=true;shared(o,'gloves|'+gloveC,m=>{m.color.set(gloveC);m.roughness=.5;m.metalness=0;});}}
  else if(n==='gkpants'){if(isGK&&longPants){o.visible=true;shared(o,'gkpants|'+kit.sh2,m=>{m.color.set(kit.sh2);m.roughness=.68;m.metalness=0;});}}
  else if(n.indexOf('hair_')===0){
   o.visible=(n==='hair_'+style);
   if(o.visible)shared(o,'hair|'+hair,m=>{m.color.set(hair);m.roughness=.55;m.metalness=0;});
  }else if(n.indexOf('beard_')===0){
   o.visible=(beard&&n==='beard_'+beard);
   if(o.visible){
    if(n==='beard_stubble')shared(o,'stubble|'+skin+'|'+hair,m=>{m.color.copy(skinC).lerp(hairC,.55);m.roughness=.8;});
    else shared(o,'beard|'+hair,m=>{m.color.copy(hairC).multiplyScalar(.92);m.roughness=.6;});
   }
  }
 });
 return {h,bw,style,beard,eyes,gloveC,longPants};
}

function ensurePlayerMesh(p){
 if(!T3||!T3.ready)return null;
 let entry=T3.players.get(p);
 if(entry)return entry;
 const kit=p.role==='GK'?GKK[p.team]:KIT[p.team];
 const skin=p.skin||'#d9a47a',hair=p.hair||'#161210',body=clamp(p.body||1,.85,1.15);
 let root,mixer=null,actions={},look=null;
 if(T3.baseGltf&&!T3.glbBroken){
  try{
  // Clona o modelo (SkeletonUtils mantém esqueleto/skin de cada jogador independente)
  const pc=(typeof GLBSys!=='undefined')?GLBSys.playerCfg():{scale:1};
  // escolhe a variante cujo tom de pele é mais próximo do jogador (se houver)
  let src=T3.baseGltf.scene;
  if(T3.skinVariants&&T3.skinVariants.length){
   const sc=[1,3,5].map(i=>parseInt(String(skin).substr(i,2),16)||0);let bd=1e9;
   for(const v of T3.skinVariants){const d=(v.rgb[0]-sc[0])**2+(v.rgb[1]-sc[1])**2+(v.rgb[2]-sc[2])**2;if(d<bd){bd=d;src=v.scene;}}
  }
  root=(typeof GLBSys!=='undefined')?GLBSys.cloneModel(src):src.clone(true);
  root.scale.setScalar((pc.scale||1)*body);
  mixer=new THREE.AnimationMixer(root); // clipes (embutidos + models/animations + importados) são ligados por GLBSys.animate
  // v2: look individual (penteado, barba, rosto, físico, altura) | modelo antigo: só pinta pele/cabelo/uniforme por nome
  if(T3.v2){try{look=ghApplyLook(root,p,kit,skin,hair);{const k=(pc.scale||1)*body*look.h;root.scale.set(k*look.bw,k,k*look.bw);}}catch(err){look=null;console.warn('[T3] look v2 falhou, usando pintura simples:',err);}}
  if(!look)root.traverse(o=>{
   if(o.isMesh&&o.material){
    const n=(o.name||'').toLowerCase();
    if(n.includes('shirt')||n.includes('jersey')||n.includes('torso')){o.material=o.material.clone();o.material.color.set(kit.sh);}
    else if(n.includes('short')){o.material=o.material.clone();o.material.color.set(kit.sh2);}
    else if(n.includes('sock')||n.includes('meia')){o.material=o.material.clone();o.material.color.set(kit.so);}
    else if(n==='skin'){o.material=o.material.clone();o.material.color.set(skin);}   // tom de pele exato do jogador
    else if(n==='hair'){o.material=o.material.clone();o.material.color.set(hair);}   // cor do cabelo do jogador
   }
   if(o.isMesh)o.frustumCulled=false; // malhas com esqueleto: evita sumirem por limite (bounding) desatualizado
  });
  // confere o tamanho do modelo: vazio/NaN/gigante = algo errado -> usa o boneco procedural
  root.updateMatrixWorld(true);
  const bb=new THREE.Box3().setFromObject(root),sz=bb.getSize(new THREE.Vector3());
  if(!isFinite(sz.y)||sz.y<.3||sz.y>6)throw new Error('modelo com tamanho inválido ('+sz.y+' m)');
  if(!T3.glbOk){T3.glbOk=true;console.log('[T3] jogador .glb OK, altura '+sz.y.toFixed(2)+' m');}
  }catch(err){
   T3.glbBroken=true;ghDiag('falha ao montar o jogador .glb → usando boneco simples.\n'+(err&&err.message||err));
   if(root&&root.parent)root.parent.remove(root);
   mixer=null;actions={};
   root=T3.createProcedural(kit,skin,hair,body);
  }
 }else{
  root=T3.createProcedural(kit,skin,hair,body);
 }
 T3.scene.add(root);
 entry={root,mixer,actions,currAnim:null,kit,skin,hair,eyes:look?look.eyes:null};
 T3.players.set(p,entry);
 return entry;
}

function setPlayerAnim(entry,name,fade=.2){
 if(!entry.mixer||!entry.actions)return;
 const act=entry.actions[name]||entry.actions[name.toLowerCase()];
 if(!act)return;
 if(entry.currAnim===name)return;
 if(entry.currAnim&&entry.actions[entry.currAnim])entry.actions[entry.currAnim].fadeOut(fade);
 act.reset().fadeIn(fade).play();
 entry.currAnim=name;
}

function updateThreePlayers(dt){
 if(!T3||!T3.ready)return;
 // limpa jogadores que saíram
 for(const [p,entry] of T3.players){
  if(p.out||!G.players.includes(p)){
   T3.scene.remove(entry.root);
   if(entry.mixer)entry.mixer.stopAllAction();
   T3.players.delete(p);
  }
 }
 for(const p of G.players){
  if(p.out)continue;
  const entry=ensurePlayerMesh(p);
  if(!entry)continue;
  const root=entry.root;
  // posição e rotação (y=0 no chão; jump/dive ajustam)
  let y=0;
  if(p.jumpT>0)y=Math.sin(Math.PI*(1-p.jumpT/.55))*.5;
  if(p.slideT>0)y=-.15;
  if(p.diveT>0)y=.1;
  root.position.set(p.x,y,p.z);
  if(entry.eyes&&entry.eyes.length&&typeof C!=='undefined'){const dx=p.x-C.px,dy=C.py,dz=p.z-C.pz,far=(dx*dx+dy*dy+dz*dz)>3600;if(entry.eyesFar!==far){entry.eyesFar=far;entry.eyes.forEach(e=>{e.visible=!far;});}} // LOD: sem olhos a mais de 60 m da câmera
  root.rotation.y=-p.face+Math.PI+(entry.mixer&&typeof GLBSys!=='undefined'?GLBSys.playerCfg().faceOffset:0); // convenção de face do modelo (ajustável em models/manifest.json -> player.faceOffset)
  // animações: clipes .glb (GLBSys) quando existirem; senão, animação procedural
  let handled=0;
  if(entry.mixer&&typeof GLBSys!=='undefined'&&!entry.animBad){try{handled=GLBSys.animate(entry,p,dt);}catch(err){entry.animBad=true;ghDiag('erro nas animações: '+(err&&err.message||err));}}
  if(handled===2)y=0;
  root.position.y=y;
  if(handled){
  }else if(entry.mixer&&!root.userData.procedural){
   entry.mixer.update(dt);
  }else if(root.userData.procedural){
   // animação manual simples das pernas/braços
   const ud=root.userData,ph=p.phase||0,amp=clamp((p.speed||0)/7.5,0,1);
   const swing=Math.sin(ph)*.7*amp;
   ud.lLeg.rotation.x=swing;ud.rLeg.rotation.x=-swing;
   ud.lSock.rotation.x=swing;ud.rSock.rotation.x=-swing;
   ud.lBoot.rotation.x=swing;ud.rBoot.rotation.x=-swing;
   ud.lArm.rotation.x=-swing*.8;ud.rArm.rotation.x=swing*.8;
   if(p.slideT>0){root.rotation.x=-.9;root.position.y=-.2;}
   else root.rotation.x=0;
  }
 }
}

function resizeThree(){
 if(!T3)return;
 T3.renderer.setSize(CW,CH,false);
 T3.renderer.setPixelRatio(1); // já estamos em resolução nativa via CW/CH
 const c3=T3.renderer.domElement;
 c3.style.width=cv.style.width||'100%';
 c3.style.height=cv.style.height||'100%';
 if(cvTop){if(cvTop.width!==CW||cvTop.height!==CH){cvTop.width=CW;cvTop.height=CH;}ctxTop.imageSmoothingEnabled=true;}
}

function updateThreeBall(){
 if(!T3||!T3.ball)return;
 const b=G.ball,mesh=T3.ball;
 if(!b){mesh.visible=false;return;}
 mesh.visible=true;
 mesh.position.set(b.x,b.y,b.z);
 // Rotação: usa o quaternão do jogo (b.q = [w,x,y,z]) se existir
 if(b.q&&b.q.length===4){
  mesh.quaternion.set(b.q[1],b.q[2],b.q[3],b.q[0]); // Three usa (x,y,z,w)
 }else if(typeof b.rot==='number'){
  // fallback: gira em torno do eixo de deslocamento
  const vx=b.owner?b.owner.vx:b.vx, vz=b.owner?b.owner.vz:b.vz;
  const vm=Math.hypot(vx,vz)||1;
  mesh.rotation.x=b.rot*(vz/vm);
  mesh.rotation.z=-b.rot*(vx/vm);
 }
 // Rastro de velocidade (quando o jogo preenche b.tr)
 if(T3.ballTrail){
  const tr=b.tr;
  if(tr&&tr.length>=6){
   const pts=[];
   for(let i=0;i<tr.length;i+=3)pts.push(new THREE.Vector3(tr[i],tr[i+1],tr[i+2]));
   T3.ballTrail.geometry.setFromPoints(pts);
   T3.ballTrail.visible=true;
   const sp=Math.hypot(b.vx||0,b.vy||0,b.vz||0);
   T3.ballTrail.material.opacity=clamp(sp/40,.08,.45);
  }else{
   T3.ballTrail.visible=false;
  }
 }
}

function renderThree(){
 if(!T3||!T3.ready)return;
 syncThreeCamera();
 updateThreeBall();
 T3.renderer.render(T3.scene,T3.camera);
}

// Inicializa quando o DOM e Three estiverem prontos
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{setTimeout(initThreePlayers,50);});
else setTimeout(initThreePlayers,50);

/* clareia (f>0) ou escurece (f<0) uma cor #rrggbb — com cache para não pesar no quadro */
const _SH={},_SHM={};
function shade(hex,f){
 let m=_SHM[hex];if(!m)m=_SHM[hex]=new Map();let v=m.get(f);if(v)return v;const key=hex+f;if(_SH[key]){m.set(f,_SH[key]);return _SH[key];}
 const n=parseInt(hex.slice(1),16);let r=n>>16,g=(n>>8)&255,b=n&255;
 if(f>=0){r+=(255-r)*f;g+=(255-g)*f;b+=(255-b)*f;}else{r*=1+f;g*=1+f;b*=1+f;}
 v=_SH[key]='rgb('+(r|0)+','+(g|0)+','+(b|0)+')';m.set(f,v);return v;
}
function buildFX(){ // camada única desenhada por cima da cena: dá profundidade e clima de estádio
 FX=document.createElement('canvas');FX.width=CW;FX.height=CH;
 const f=FX.getContext('2d');
 const v=f.createRadialGradient(CW/2,CH*.52,Math.min(CW,CH)*.35,CW/2,CH*.52,Math.hypot(CW,CH)*.62);
 v.addColorStop(0,'rgba(0,0,0,0)');v.addColorStop(1,'rgba(2,6,14,.55)');
 f.fillStyle=v;f.fillRect(0,0,CW,CH);
 const h=f.createLinearGradient(0,0,0,CH*.5); // névoa fria no fundo (arquibancadas distantes)
 h.addColorStop(0,'rgba(10,24,50,.42)');h.addColorStop(1,'rgba(10,24,50,0)');
 f.fillStyle=h;f.fillRect(0,0,CW,CH*.5);
 const g=f.createLinearGradient(0,CH*.72,0,CH); // base levemente mais escura
 g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.22)');
 f.fillStyle=g;f.fillRect(0,CH*.72,CW,CH*.28);
}
const P={x:0,y:0,s:0,z:0},V=new Float32Array(3);
const NEAR=.6;
function toCam(x,y,z){const dx=x-C.px,dy=y-C.py,dz=z-C.pz;
 V[0]=dx*C.rx+dz*C.rz;V[1]=dx*C.ux+dy*C.uy+dz*C.uz;V[2]=dx*C.fx+dy*C.fy+dz*C.fz;}
function proj(x,y,z){
 toCam(x,y,z);const zc=V[2];P.z=zc;
 if(zc<NEAR){P.s=0;return false;}
 const s=C.focal/zc;P.s=s;P.x=C.cx+V[0]*s;P.y=C.cy-V[1]*s;return true;
}
/* Polígono com recorte no plano próximo da câmera (Sutherland–Hodgman).
   Corrige o campo/linhas que sumiam quando um vértice ficava atrás da câmera. */
const PB=new Float32Array(96),PO=new Float32Array(96),WQ=new Float32Array(12);
function polyPath(w,n){
 let m=0;
 for(let i=0;i<n;i++){toCam(w[i*3],w[i*3+1],w[i*3+2]);PB[m*3]=V[0];PB[m*3+1]=V[1];PB[m*3+2]=V[2];m++;}
 let k=0;
 for(let i=0;i<m;i++){
  const a=i*3,b=((i+1)%m)*3,az=PB[a+2],bz=PB[b+2],ai=az>=NEAR,bi=bz>=NEAR;
  if(ai){PO[k*3]=PB[a];PO[k*3+1]=PB[a+1];PO[k*3+2]=az;k++;}
  if(ai!==bi){const t=(NEAR-az)/(bz-az);PO[k*3]=PB[a]+(PB[b]-PB[a])*t;PO[k*3+1]=PB[a+1]+(PB[b+1]-PB[a+1])*t;PO[k*3+2]=NEAR;k++;}
 }
 if(k<3)return false;
 for(let i=0;i<k;i++){const s=C.focal/PO[i*3+2],x=C.cx+PO[i*3]*s,y=C.cy-PO[i*3+1]*s;if(i)ctx.lineTo(x,y);else ctx.moveTo(x,y);}
 ctx.closePath();return true;
}
function quad(a,b,c,d,e,f,g,h,i,j,k,l,fill){
 WQ[0]=a;WQ[1]=b;WQ[2]=c;WQ[3]=d;WQ[4]=e;WQ[5]=f;WQ[6]=g;WQ[7]=h;WQ[8]=i;WQ[9]=j;WQ[10]=k;WQ[11]=l;
 ctx.fillStyle=fill;ctx.beginPath();const ok=polyPath(WQ,4);if(ok)ctx.fill();return ok;
}
/* Faixas planas no chão (linhas do campo) com largura real em metros → perspectiva correta */
function stripPath(pts,hw){
 for(let i=0;i+3<pts.length;i+=2){
  const ax=pts[i],az=pts[i+1],bx=pts[i+2],bz=pts[i+3];
  let dx=bx-ax,dz=bz-az;const l=hyp(dx,dz);if(l<1e-6)continue;
  dx/=l;dz/=l;const nx=-dz*hw,nz=dx*hw,ex=dx*hw*.5,ez=dz*hw*.5;
  WQ[0]=ax-ex+nx;WQ[1]=0;WQ[2]=az-ez+nz;WQ[3]=bx+ex+nx;WQ[4]=0;WQ[5]=bz+ez+nz;
  WQ[6]=bx+ex-nx;WQ[7]=0;WQ[8]=bz+ez-nz;WQ[9]=ax-ex-nx;WQ[10]=0;WQ[11]=az-ez-nz;
  polyPath(WQ,4);
 }
}
function resize(){
 const dpr=Math.min(window.devicePixelRatio||1,2),sc=clamp(Math.max(S.scale,.9)*G.adapt,.75,1); // nitidez: resolução nativa quase total
 const w=Math.max(320,Math.min(1920,Math.round(innerWidth*dpr*sc))),h=Math.max(180,Math.min(1080,Math.round(innerHeight*dpr*sc)));
 if(cv.width!==w||cv.height!==h){cv.width=w;cv.height=h;}
 ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';
 CW=cv.width;CH=cv.height;QK=CW/Math.max(1,innerWidth);
 sky=ctx.createLinearGradient(0,0,0,CH);sky.addColorStop(0,'#050b18');sky.addColorStop(.35,'#10203a');sky.addColorStop(.6,'#1b2f4d');sky.addColorStop(1,'#0c1520');
 buildFX();
 layoutHUD();
 if(typeof resizeThree==='function')resizeThree();
 if(innerHeight>innerWidth&&curScreen===null)pauseGame(); // retrato durante a partida: pausa
}

/* ---------------- Linhas do campo (pré-calculadas, x/z em metros) ---------------- */
const LINES=[],LINE_HW=.09;
function arcPts(cx,cz,r,a0,a1,n){const o=[];for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n;o.push(cx+cos(a)*r,cz+sin(a)*r);}return o;}
(function buildLines(){
 LINES.push([-HL,-HW,HL,-HW,HL,HW,-HL,HW,-HL,-HW],[0,-HW,0,HW],arcPts(0,0,9.15,0,TAU,48),arcPts(0,0,.3,0,TAU,8));
 for(const s of [-1,1]){
  LINES.push([s*HL,-20.15,s*(HL-16.5),-20.15,s*(HL-16.5),20.15,s*HL,20.15]); // grande área
  LINES.push([s*HL,-9.16,s*(HL-5.5),-9.16,s*(HL-5.5),9.16,s*HL,9.16]);       // pequena área
  const a0=s>0?PI-.926:-.926,a1=s>0?PI+.926:.926;
  LINES.push(arcPts(s*(HL-11),0,9.15,a0,a1,24));                              // meia-lua
  LINES.push(arcPts(s*(HL-11),0,.3,0,TAU,8));                                 // marca do pênalti
  for(const z of [-1,1]){const c=Math.atan2(-z,-s);LINES.push(arcPts(s*HL,z*HW,1,c-PI/4,c+PI/4,8));} // escanteios
 }
})();
const PATCH=[];for(let i=0;i<160;i++)PATCH.push([(rnd()-.5)*105,(rnd()-.5)*68,.8+rnd()*2.2,rnd()]);

/* ---------------- Arquibancadas ---------------- */
const M0=5,M1=24;
const CROWD=[],CCOL=['#d9423b','#e8e1d0','#2f6fd6','#f0c53a','#3a3f4d','#e07b2c'];
function standPt(side,a,v,o){
 const m=M0+(M1-M0)*v,y=1+14*v;
 // Cada lado acompanha o mesmo raio nos cantos: as quatro arquibancadas
 // terminam exatamente no mesmo vértice, sem atravessar umas às outras.
 if(side===0){o[0]=a*(HL+m);o[1]=y;o[2]=-(HW+m);}
 else if(side===1){o[0]=a*(HL+m);o[1]=y;o[2]=HW+m;}
 else if(side===2){o[0]=-(HL+m);o[1]=y;o[2]=a*(HW+m);}
 else{o[0]=HL+m;o[1]=y;o[2]=a*(HW+m);}
}
function buildCrowd(){
 CROWD.length=0;const rows=S.gfx>=2?10:6,cols=S.gfx>=2?64:42,o=[0,0,0];
 for(let side=0;side<4;side++){
  const bins=CCOL.map(()=>[]);
  for(let r=0;r<rows;r++)for(let c=0;c<cols;c++){
   const v=(r+.5)/rows,a=-1+2*(c+.5+(r%2)*.4+(rnd()-.5)*.3)/cols;standPt(side,clamp(a,-1,1),v,o);
   bins[(rnd()*CCOL.length)|0].push(o[0],o[1]+.35,o[2]);
  }
  CROWD.push(bins.map(b=>Float32Array.from(b)));
 }
}
const BOARD=['#c8202a','#f2f2f2','#1a4fb8','#f2c200'];
function farSide(side){ // só desenha as arquibancadas que ficam atrás do campo (em relação à câmera)
 const mid=[0,0,0];standPt(side,0,.5,mid);
 const dx=mid[0]-C.px,dz=mid[2]-C.pz;
 return dx*C.gfx+dz*C.gfz>0;
}
const STAND_ROW=['#46517a','#38426a','#2e3758','#262d49','#1e243b'];
function drawStands(){
 const a=[0,0,0],b=[0,0,0],c=[0,0,0],d=[0,0,0],mid=[0,0,0];
 for(let side=0;side<4;side++){
  // if(!farSide(side))continue;
  const N=S.gfx===0?2:5;
  for(let r=0;r<N;r++){
   standPt(side,-1,r/N,a);standPt(side,1,r/N,b);standPt(side,1,(r+1)/N,c);standPt(side,-1,(r+1)/N,d);
   quad(a[0],a[1],a[2],b[0],b[1],b[2],c[0],c[1],c[2],d[0],d[1],d[2],STAND_ROW[Math.min(4,(r*5/N)|0)]);
  }
  if(S.gfx>0||G.train){
   standPt(side,0,.5,mid);
   for(let ci=0;ci<CCOL.length;ci++){
    const arr=CROWD[side][ci];
    for(let pass=0;pass<(S.gfx>=2?2:1);pass++){ // 1ª passada: corpo · 2ª: cabeça clara (volume)
     ctx.fillStyle=pass?'rgba(255,222,190,.85)':CCOL[ci];ctx.beginPath();
     for(let k=0;k<arr.length;k+=3){
      if(!proj(arr[k],arr[k+1]+(pass?.55:0),arr[k+2]))continue;
      const s2=Math.max(.8,.3*P.s);
      if(pass)ctx.rect(P.x-s2*.55,P.y-s2*.55,s2*1.1,s2*1.1);else ctx.rect(P.x-s2,P.y-s2*1.2,s2*2,s2*2.4);
     }
     ctx.fill();
    }
   }
  }
 }
}
/* Placas de publicidade: desenhadas DEPOIS do gramado para não ficarem cobertas */
function drawBoards(){
 for(let side=0;side<4;side++){
  // if(!farSide(side))continue;
  const long=side<2,e=long?HL+2.6:HW+2.6,off=long?HW+2.6:HL+2.6,sg=(side===0||side===2)?-1:1;
  const nb=S.gfx===0?1:12;
  for(let i=0;i<nb;i++){
   const t0=-e+2*e*i/nb,t1=-e+2*e*(i+1)/nb,col=S.gfx===0?'#243a55':BOARD[i%4];
   if(long){quad(t0,0,sg*off,t1,0,sg*off,t1,1,sg*off,t0,1,sg*off,col);
    if(S.gfx>0)quad(t0,.62,sg*off,t1,.62,sg*off,t1,1,sg*off,t0,1,sg*off,'rgba(255,255,255,.22)');}
   else{quad(sg*off,0,t0,sg*off,0,t1,sg*off,1,t1,sg*off,1,t0,col);
    if(S.gfx>0)quad(sg*off,.62,t0,sg*off,.62,t1,sg*off,1,t1,sg*off,1,t0,'rgba(255,255,255,.22)');}
  }
 }
}

/* ---------------- Gramado e linhas ---------------- */
function drawPitch(){
 quad(-HL-5,0,-HW-5,HL+5,0,-HW-5,HL+5,0,HW+5,-HL-5,0,HW+5,'#144a24'); // faixa externa
 quad(-HL,0,-HW,HL,0,-HW,HL,0,HW,-HL,0,HW,'#268a3c');
 const n=14,w=105/n;
 for(let i=0;i<n;i+=2){const x0=-HL+i*w;quad(x0,0,-HW,x0+w,0,-HW,x0+w,0,HW,x0,0,HW,'#32a04a');}
 // brilho suave no centro do campo (luz dos refletores)
 if(S.gfx>=1)quad(-18,0,-12,18,0,-12,18,0,12,-18,0,12,'rgba(255,255,220,.04)');
 if(S.tex>=1){for(let j=0;j<4;j+=2){const z0=-HW+j*17;quad(-HL,0,z0,HL,0,z0,HL,0,z0+17,-HL,0,z0+17,'rgba(255,255,255,.035)');}}
 if(S.tex>=2){for(const pt of PATCH){quad(pt[0],0,pt[1],pt[0]+pt[2],0,pt[1],pt[0]+pt[2],0,pt[1]+pt[2]*.6,pt[0],0,pt[1]+pt[2]*.6,pt[3]>.5?'rgba(0,60,15,.10)':'rgba(255,255,255,.04)');}}
 ctx.fillStyle='rgba(255,255,255,.93)';ctx.beginPath();
 for(const L of LINES)stripPath(L,LINE_HW);
 ctx.fill();
}
function drawGoals(){
 ctx.lineCap='round';
 for(const s of [-1,1]){
  const x0=s*HL,x1=s*(HL+GD);
  proj(x0,0,0);const lw=Math.max(1.5,.13*P.s);
  if(S.gfx>0){ // rede
   quad(x1,0,-GW,x1,GH,-GW,x1,GH,GW,x1,0,GW,'rgba(8,12,18,.38)');
   ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=1;ctx.beginPath();
   if(G.net&&G.net.side===s){ // rede balançando: malha subdividida deslocada pela onda
    const nt=G.net,wv=Math.exp(-nt.t*2.4)*Math.cos(nt.t*16)*.9;ctx.strokeStyle='rgba(255,255,255,'+(.28+.3*Math.exp(-nt.t*2)).toFixed(2)+')';
    const nx=(y,z)=>x1+s*wv*Math.exp(-((z-nt.z)*(z-nt.z)+(y-nt.y)*(y-nt.y))/2.2);
    for(let i=-3;i<=3;i++){const z=i*GW/3;let first=true;
     for(let j=0;j<=6;j++){const y=j*GH/6;if(proj(nx(y,z),y,z)){if(first)ctx.moveTo(P.x,P.y);else ctx.lineTo(P.x,P.y);first=false;}else first=true;}}
    for(let j=0;j<=4;j++){const y=j*GH/4;let first=true;
     for(let i=0;i<=12;i++){const z=-GW+i*GW/6;if(proj(nx(y,z),y,z)){if(first)ctx.moveTo(P.x,P.y);else ctx.lineTo(P.x,P.y);first=false;}else first=true;}}
   }else{
   for(let i=-3;i<=3;i++){const z=i*GW/3;if(proj(x1,0,z)){ctx.moveTo(P.x,P.y);if(proj(x1,GH,z))ctx.lineTo(P.x,P.y);}}
   for(let j=0;j<=4;j++){const y=j*GH/4;if(proj(x1,y,-GW)){ctx.moveTo(P.x,P.y);if(proj(x1,y,GW))ctx.lineTo(P.x,P.y);}}
   }
   for(const z of [-GW,GW]){
    if(proj(x0,GH,z)){ctx.moveTo(P.x,P.y);if(proj(x1,GH,z))ctx.lineTo(P.x,P.y);}
    if(proj(x0,0,z)){ctx.moveTo(P.x,P.y);if(proj(x1,0,z))ctx.lineTo(P.x,P.y);}
   }
   ctx.stroke();
  }
  ctx.strokeStyle='rgba(0,0,0,.35)';ctx.lineWidth=lw*1.7;ctx.beginPath();
  if(proj(x0,0,-GW)){ctx.moveTo(P.x+lw*.4,P.y+lw*.4);if(proj(x0,GH,-GW))ctx.lineTo(P.x+lw*.4,P.y+lw*.4);if(proj(x0,GH,GW))ctx.lineTo(P.x+lw*.4,P.y+lw*.4);if(proj(x0,0,GW))ctx.lineTo(P.x+lw*.4,P.y+lw*.4);}
  ctx.stroke();
  ctx.strokeStyle='#f7f7f7';ctx.lineWidth=lw;ctx.beginPath();
  if(proj(x0,0,-GW)){ctx.moveTo(P.x,P.y);if(proj(x0,GH,-GW))ctx.lineTo(P.x,P.y);if(proj(x0,GH,GW))ctx.lineTo(P.x,P.y);if(proj(x0,0,GW))ctx.lineTo(P.x,P.y);}
  ctx.stroke();
 }
}
function drawLights(){
 for(const sx of [-1,1])for(const sz of [-1,1]){
  const x=sx*(HL+11),z=sz*(HW+9);
  if(!proj(x,0,z))continue;const bx=P.x,by=P.y;if(!proj(x,30,z))continue;
  if(S.gfx>=1){
   const R=Math.max(10,3.4*P.s),g=ctx.createRadialGradient(P.x,P.y,0,P.x,P.y,R);
   g.addColorStop(0,'rgba(255,252,230,.95)');g.addColorStop(.25,'rgba(255,244,200,.45)');g.addColorStop(1,'rgba(255,244,200,0)');
   ctx.globalCompositeOperation='lighter';ctx.fillStyle=g;ctx.beginPath();ctx.arc(P.x,P.y,R,0,TAU);ctx.fill();ctx.globalCompositeOperation='source-over';
  }
 }
}

/* ---------------- Camada do chão: sombras e anel do jogador controlado ---------------- */
function groundEllipse(x,z,r){ // elipse com a inclinação correta para o ponto visto pela câmera
 if(!proj(x,0,z))return;
 const rx=r*P.s,rat=clamp(C.py/hyp(x-C.px,C.py,z-C.pz),.12,1),ry=rx*rat;
 ctx.moveTo(P.x+rx,P.y);ctx.ellipse(P.x,P.y,rx,ry,0,0,TAU);
}
function ringPath(x,z,r){ // círculo no chão projetado ponto a ponto (alinhado ao gramado)
 const n=28;let ok=true;
 for(let i=0;i<=n;i++){const a=i/n*TAU;if(!proj(x+cos(a)*r,0,z+sin(a)*r)){ok=false;break;}if(i)ctx.lineTo(P.x,P.y);else ctx.moveTo(P.x,P.y);}
 return ok;
}
function drawGround(){
 const k=CH/720;
 if(S.shadow>0){
  const big=S.shadow>1?1.1:1;
  if(S.shadow>1){ctx.fillStyle='rgba(0,0,0,.14)';ctx.beginPath();for(const p of G.players){if(p.out)continue;groundEllipse(p.x+.3,p.z+.2,.85*big);}ctx.fill();}
  ctx.fillStyle='rgba(0,0,0,.30)';ctx.beginPath();
  for(const p of G.players){if(p.out)continue;groundEllipse(p.x+.16,p.z+.1,.55*big);}
  const b=G.ball,sk=clamp(1-b.y*.08,.3,1);groundEllipse(b.x+.1,b.z+.06,.26*sk+.05);
  ctx.fill();
 }
 if(G.train&&G.train.spots){ // pontos de passe do treino
  ctx.lineJoin='round';
  for(const sp of G.train.spots){proj(sp[0],0,sp[1]);const w=Math.max(2,.1*P.s);
   ctx.strokeStyle='rgba(0,0,0,.4)';ctx.lineWidth=w*1.8;ctx.beginPath();if(ringPath(sp[0],sp[1],1.4))ctx.stroke();
   ctx.strokeStyle='#5ec8ff';ctx.lineWidth=w;ctx.beginPath();if(ringPath(sp[0],sp[1],1.4))ctx.stroke();}
 }
 const u=G.user;
 if(S.ind&&u){
  const proj0=proj(u.x,0,u.z),sc=P.s;
  ctx.lineJoin='round';
  ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=Math.max(3,.16*sc);ctx.beginPath();if(ringPath(u.x,u.z,.9))ctx.stroke();
  ctx.strokeStyle='#ffe14a';ctx.lineWidth=Math.max(1.6,.09*sc);ctx.beginPath();if(ringPath(u.x,u.z,.9))ctx.stroke();
  // seta de direção do movimento (mesma camada do chão)
  if(proj0&&u.speed>1.2){
   const nx=u.vx/u.speed,nz=u.vz/u.speed;
   ctx.fillStyle='rgba(255,225,74,.85)';ctx.beginPath();
   if(proj(u.x+nx*1.15-nz*.28,0,u.z+nz*1.15+nx*.28)){ctx.moveTo(P.x,P.y);
    if(proj(u.x+nx*1.65,0,u.z+nz*1.65))ctx.lineTo(P.x,P.y);
    if(proj(u.x+nx*1.15+nz*.28,0,u.z+nz*1.15-nx*.28))ctx.lineTo(P.x,P.y);ctx.closePath();ctx.fill();}
  }
 }
}

/* ---------------- Jogadores e bola ----------------
   Bonecos 100% sólidos: cada peça (bota, meia, calção, camisa, braço, cabeça...) entra numa fila,
   é ordenada pela distância da câmera e pintada de trás para frente, sem nenhum alpha.
   As peças se sobrepõem (sem frestas) e os contornos escuros fecham as emendas. */
const LGT=[-.35,.8,.45];
const SXS=[-1,1,1,-1],SFS=[-1,-1,1,1],MXS=[0,1,0,-1],MFS=[-1,0,1,0];
const FIDX=[[0,1,5,4],[1,2,6,5],[2,3,7,6],[3,0,4,7],[0,1,2,3],[4,5,6,7]];
const BX=new Float32Array(8),BY=new Float32Array(8);
const BOOT=['#14161b','#f4f4f4','#ff7a1a','#25d17c','#2f9bff','#ffd21f'],GBOOT=['#14161b','#14161b'],GLOVE=['#d9ff3a','#ff7ad9'];
const PPOOL=[];let PN=0;
function pitem(){let q=PPOOL[PN];
 if(!q){q=PPOOL[PN]={d:0,n:0,k:0,xy:new Float32Array(48),fill:['','','','','',''],ol:'',lw:1,
  ns:false,det:1,hdx:0,hdY:0,hdz:0,cf:0,sf:0,skin:'',hair:'',body:1,style:0,celeb:0,tx:0,ty:0,sx:1,fs:10,col:'',txt:'',nm:''};}
 PN++;q.n=0;return q;}
function qz(v){return Math.round(v*20)/20;} // quantiza o brilho: o cache de cores não cresce sem parar
function lerp3(a,b,t){return [a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,a[2]+(b[2]-a[2])*t];}
/* Caixa 3D sólida. skip: 1 = sem tampa em A, 2 = sem tampa em B (tampas escondidas dentro de outra peça). */
function box3D(a,b,hw,hd,color,hint,skip){
 let ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2];const ul=Math.hypot(ux,uy,uz)||1;ux/=ul;uy/=ul;uz/=ul;
 let hx=hint[0],hy=hint[1],hz=hint[2];const d=hx*ux+hy*uy+hz*uz;
 let sx=hx-d*ux,sy=hy-d*uy,sz=hz-d*uz,sl=Math.hypot(sx,sy,sz);
 if(sl<1e-4){hx=0;hy=0;hz=1;const d2=hz*uz;sx=-d2*ux;sy=-d2*uy;sz=hz-d2*uz;sl=Math.hypot(sx,sy,sz)||1;}
 sx/=sl;sy/=sl;sz/=sl;
 const fx=uy*sz-uz*sy,fy=uz*sx-ux*sz,fz=ux*sy-uy*sx;
 for(let e=0;e<2;e++){const c=e?b:a;for(let i=0;i<4;i++){const kx=SXS[i]*hw,kf=SFS[i]*hd;
  if(!proj(c[0]+kx*sx+kf*fx,c[1]+kx*sy+kf*fy,c[2]+kx*sz+kf*fz))return;
  BX[e*4+i]=P.x;BY[e*4+i]=P.y;}}
 const mx=(a[0]+b[0])*.5,my=(a[1]+b[1])*.5,mz=(a[2]+b[2])*.5;
 if(!proj(mx,my,mz))return;
 const q=pitem();q.k=0;q.d=P.z;q.lw=Math.max(.55,.026*P.s);q.ol=shade(color,-.6);q.ns=P.s/CH*720<24; // longe: sem contorno
 skip=skip|0;
 for(let f=0;f<6;f++){
  if(f===4&&(skip&1))continue;if(f===5&&(skip&2))continue;
  let nx,ny,nz,cx,cy,cz;
  if(f<4){const m=MXS[f],g=MFS[f];nx=m*sx+g*fx;ny=m*sy+g*fy;nz=m*sz+g*fz;cx=mx+nx*0+m*hw*sx+g*hd*fx;cy=my+m*hw*sy+g*hd*fy;cz=mz+m*hw*sz+g*hd*fz;}
  else if(f===4){nx=-ux;ny=-uy;nz=-uz;cx=a[0];cy=a[1];cz=a[2];}
  else{nx=ux;ny=uy;nz=uz;cx=b[0];cy=b[1];cz=b[2];}
  if(nx*(cx-C.px)+ny*(cy-C.py)+nz*(cz-C.pz)>=0)continue; // face de trás
  const L=nx*LGT[0]+ny*LGT[1]+nz*LGT[2],o=q.n*8,idx=FIDX[f];
  for(let i=0;i<4;i++){q.xy[o+i*2]=BX[idx[i]];q.xy[o+i*2+1]=BY[idx[i]];}
  q.fill[q.n]=shade(color,qz(clamp(L*.4-.02,-.36,.32)));q.n++;
 }
 if(!q.n)PN--;
}
function drawHead(q){
  // Cabeça blocada com cantos suaves: mantém projeção 3D e orientação do jogador.
  const body=q.body,hw=.15*body,hs=.145*body,det=q.det;
  if(!proj(q.hdx,q.hdY+hs*.08,q.hdz))return;
  const x=P.x,y=P.y,s=P.s,R=.15*body*s,Ry=R*1.02,cf=q.cf,sf=q.sf,rx=-sf,rz=cf,skin=q.skin,hc=q.hair,st=q.style;
  let dx=C.px-q.hdx,dz=C.pz-q.hdz;const dl=Math.hypot(dx,dz)||1;dx/=dl;dz/=dl;
  const fz=cf*dx+sf*dz,sd=rx*dx+rz*dz;
  let fox=0,foy=0;if(proj(q.hdx+cf*.12,q.hdY+hs*.08,q.hdz+sf*.12)){fox=P.x-x;foy=P.y-y;}
  const w=R*1.12,h=Ry*1.18,rad=Math.max(2,R*.16),lw=Math.max(.7,.024*s);
  ctx.lineJoin='round';ctx.lineWidth=lw;
  // Volume traseiro do cabelo e orelhas.
  if(st===3){ctx.fillStyle=shade(hc,-.25);ctx.beginPath();ctx.roundRect(x-w*.62,y-h*.52,w*1.24,h*1.22,rad);ctx.fill();}
  if(det>=1){ctx.fillStyle=shade(skin,-.12);ctx.strokeStyle=shade(skin,-.48);
   for(const sg of [-1,1]){if(fz>-.2&&sg*sd<-.4)continue;
    if(proj(q.hdx+rx*hw*1.02*sg,q.hdY-hs*.04,q.hdz+rz*hw*1.02*sg)){ctx.beginPath();ctx.roundRect(P.x-R*.17,P.y-R*.19,R*.34,R*.38,rad*.55);ctx.fill();ctx.stroke();}}}
  // Crânio quadrado com leve arredondamento e sombreado.
  const headX=x-w,headY=y-h*.82,headW=w*2,headH=h*1.64;
  ctx.beginPath();ctx.roundRect(headX,headY,headW,headH,rad);
  if(det>=1){const g=ctx.createLinearGradient(headX,headY,headX+headW,headY+headH);g.addColorStop(0,shade(skin,.19));g.addColorStop(.52,skin);g.addColorStop(1,shade(skin,-.22));ctx.fillStyle=g;}else ctx.fillStyle=skin;
  ctx.fill();ctx.strokeStyle=shade(skin,-.58);ctx.stroke();
  // Cabelo em massa geométrica, com variações de corte e mechas.
  ctx.save();ctx.beginPath();ctx.roundRect(headX,headY,headW,headH,rad);ctx.clip();ctx.fillStyle=hc;
  const hairH=[.43,.30,.52,.35][st]||.38;
  ctx.beginPath();ctx.roundRect(headX-R*.08,headY-R*.20,headW+R*.16,h*hairH+R*.2,rad*.7);ctx.fill();
  if(st===1){ctx.beginPath();ctx.ellipse(x-fox*.08,headY+R*.04,w*.82,R*.27,-.08,0,TAU);ctx.fill();}
  if(st===2||st===3){
    for(let k=-2;k<=2;k++){ctx.beginPath();ctx.ellipse(x+k*R*.28+fox*.08,headY+R*.13,R*.23,R*.16,-.12,0,TAU);ctx.fill();}
  }else if(det>=1){
    for(let k=-2;k<=2;k++){ctx.strokeStyle=shade(hc,.18);ctx.lineWidth=Math.max(1,R*.09);ctx.beginPath();ctx.moveTo(x+k*R*.27,headY+R*.08);ctx.lineTo(x+k*R*.17,headY+R*.31);ctx.stroke();}
  }
  ctx.restore();
  // Face: olhos, sobrancelhas, nariz e sorriso. Só aparece na face voltada à câmera.
  if(det>=1&&fz>.12&&s>11){
    const eyeY=y-R*.02,eyeGap=R*.43,eyeW=Math.max(1.5,R*.19),eyeH=Math.max(2,R*.25);
    for(const sg of [-1,1]){
      if(fz<.5&&sg*sd<0)continue;
      const ex=x+fox*.12+sg*eyeGap;
      ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(ex,eyeY,eyeW,eyeH,0,0,TAU);ctx.fill();
      ctx.fillStyle='#171717';ctx.beginPath();ctx.ellipse(ex+fox*.015,eyeY+eyeH*.08,eyeW*.48,eyeH*.72,0,0,TAU);ctx.fill();
      ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(ex-eyeW*.12,eyeY-eyeH*.25,Math.max(.7,eyeW*.2),0,TAU);ctx.fill();
      ctx.strokeStyle=shade(hc,-.2);ctx.lineWidth=Math.max(1,R*.09);ctx.beginPath();ctx.moveTo(ex-eyeW*1.05,eyeY-eyeH*1.65);ctx.lineTo(ex+eyeW*.8,eyeY-eyeH*1.8);ctx.stroke();
    }
    if(proj(q.hdx+cf*(hw+.012),q.hdY-hs*.22,q.hdz+sf*(hw+.012))){ctx.fillStyle=shade(skin,-.22);ctx.beginPath();ctx.roundRect(P.x-Math.max(1,R*.07),P.y-Math.max(1,R*.07),Math.max(2,R*.14),Math.max(2,R*.16),2);ctx.fill();}
    if(proj(q.hdx+cf*(hw+.015),q.hdY-hs*.57,q.hdz+sf*(hw+.015))){
      const mx=P.x,my=P.y,mw=Math.max(3,R*.48),mh=Math.max(1.5,R*.12);
      ctx.strokeStyle='#30201b';ctx.lineWidth=Math.max(1,R*.075);ctx.beginPath();ctx.moveTo(mx-mw*.5,my);ctx.quadraticCurveTo(mx,my+mh*1.9,mx+mw*.5,my);ctx.stroke();
      ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(mx-mw*.42,my+.5);ctx.quadraticCurveTo(mx,my+mh*1.45,mx+mw*.42,my+.5);ctx.closePath();ctx.fill();
    }
  }
}

function drawNum(q){
 ctx.save();ctx.translate(q.tx,q.ty);ctx.scale(q.sx,1);ctx.fillStyle=q.col;ctx.textAlign='center';ctx.textBaseline='middle';
 if(q.nm){ctx.font='800 '+(q.fs*.3).toFixed(1)+'px sans-serif';ctx.fillText(q.nm,0,-q.fs*.62);}
 ctx.font='900 '+q.fs.toFixed(1)+'px sans-serif';ctx.fillText(q.txt,0,0);ctx.restore();
}
function flushParts(){
 for(let i=1;i<PN;i++){const q=PPOOL[i];let j=i-1;while(j>=0&&PPOOL[j].d<q.d){PPOOL[j+1]=PPOOL[j];j--;}PPOOL[j+1]=q;} // mais distante primeiro
 ctx.lineJoin='round';ctx.lineCap='round';
 for(let i=0;i<PN;i++){const q=PPOOL[i];
  if(q.k===0){ctx.strokeStyle=q.ol;ctx.lineWidth=q.lw;const ns=q.ns;
   for(let f=0;f<q.n;f++){const o=f*8,v=q.xy;ctx.beginPath();ctx.moveTo(v[o],v[o+1]);ctx.lineTo(v[o+2],v[o+3]);ctx.lineTo(v[o+4],v[o+5]);ctx.lineTo(v[o+6],v[o+7]);ctx.closePath();ctx.fillStyle=q.fill[f];ctx.fill();if(!ns)ctx.stroke();}
  }else if(q.k===1)drawHead(q);else drawNum(q);
 }
 PN=0;
}

function drawPlayer(p){
 if(!proj(p.x,0,p.z))return;
 const s=P.s,fx=P.x,fy=P.y;if(fx<-80||fx>CW+80||fy<-120||fy>CH+80)return;
 const f=p.face,cf=cos(f),sf=sin(f),rx=-sf,rz=cf,amp=clamp(p.speed/7.5,0,1),ph=p.phase;
 const kit=p.role==='GK'?GKK[p.team]:KIT[p.team],hi=S.gfx>=1;
 let yo=p.jumpT>0?sin(PI*(1-p.jumpT/.55))*.5:0;
 const brth=amp<.1?sin(G.t*2.4+p.num)*.014:0; // respiração parado
 // proporções mais humanas: pernas longas, tronco médio, cabeça ~1/7.5
 let hipY=.95+yo,shY=1.52+yo+brth,lean=.05+.14*amp;
 const hx=p.x,hz=p.z;
 let shx=hx+cf*lean,shz=hz+sf*lean,hdx=hx+cf*(lean+.04),hdz=hz+sf*(lean+.04),hdY=shY+.28;
 const A=sin(ph)*.62*amp; // balanço mais natural
 let lfx=hx-rx*.12+cf*A,lfz=hz-rz*.12+sf*A,lfy=yo+Math.max(0,-cos(ph))*.25*amp;
 let rfx=hx+rx*.12-cf*A,rfz=hz+rz*.12-sf*A,rfy=yo+Math.max(0,cos(ph))*.25*amp;
 let lhx=shx-rx*.3-cf*A*.8,lhz=shz-rz*.3-sf*A*.8,lhy=shY-.55+yo;
 let rhx=shx+rx*.3+cf*A*.8,rhz=shz+rz*.3+sf*A*.8,rhy=shY-.55+yo;
 if(p.kickT>0){const k=sin(PI*(1-p.kickT/.3));rfx=hx+rx*.12+cf*(.95*k-.1);rfz=hz+rz*.12+sf*(.95*k-.1);rfy=.25*k;
  shx-=cf*.1*k;shz-=sf*.1*k;lhx-=rx*.35*k;lhz-=rz*.35*k;lhy+=.2*k;rhx+=rx*.3*k;rhz+=rz*.3*k;rhy+=.1*k;} // braços abrem no chute
 if(p.jumpT>0){const jk=sin(PI*(1-p.jumpT/.55)); // cabeceio / salto: cabeça à frente, braços ao alto
  shx+=cf*.1*jk;shz+=sf*.1*jk;hdx+=cf*.2*jk;hdz+=sf*.2*jk;lhy=shY+.1+.35*jk;rhy=shY+.1+.35*jk;lhx-=rx*.12*jk;rhx+=rx*.12*jk;
  lfy=Math.max(lfy,yo*.6);rfy=Math.max(rfy,yo*.45);}
 if(p.role==='GK'&&p.diveT<=0&&p.celeb<=0&&amp<.5){ // goleiro em posição de espera / segurando a bola
  if(G.ball.owner===p){lhx=shx+cf*.42-rx*.22;lhz=shz+sf*.42-rz*.22;lhy=shY-.4;rhx=shx+cf*.42+rx*.22;rhz=shz+sf*.42+rz*.22;rhy=shY-.4;}
  else{hipY-=.07;shY-=.07;lhx=shx-rx*.6+cf*.15;lhz=shz-rz*.6+sf*.15;lhy=shY-.35;rhx=shx+rx*.6+cf*.15;rhz=shz+rz*.6+sf*.15;rhy=shY-.35;}
 }
 if(p.celeb>0){const jy=abs(sin(G.t*9))*.2;hipY+=jy;shY+=jy;hdY+=jy;lhy=shY+.5;rhy=shY+.5;lhx=shx-rx*.4;lhz=shz-rz*.4;rhx=shx+rx*.4;rhz=shz+rz*.4;
  if(p.celebType===1&&p.speed>2){ // deslize de joelhos, braços abertos
   hipY=.62;shY=1.22;shx=hx-cf*.25;shz=hz-sf*.25;hdx=shx-cf*.04;hdz=shz-sf*.04;hdY=shY+.32;
   lfx=hx-cf*.55-rx*.15;lfz=hz-sf*.55-rz*.15;lfy=.1;rfx=hx-cf*.55+rx*.15;rfz=hz-sf*.55+rz*.15;rfy=.1;
   lhx=shx-rx*.65;lhz=shz-rz*.65;lhy=shY+.5;rhx=shx+rx*.65;rhz=shz+rz*.65;rhy=shY+.5;
  }else if(p.celebType===2&&p.speed>2){ // aviãozinho: braços abertos correndo
   shx+=cf*.12;shz+=sf*.12;hdx+=cf*.14;hdz+=sf*.14;lhx=shx-rx*.95;lhz=shz-rz*.95;lhy=shY-.02;rhx=shx+rx*.95;rhz=shz+rz*.95;rhy=shY-.02;
  }
 }
 if(G.state==='goal'&&p.team!==G.goalTeam&&p.speed<2&&p.celeb<=0){ // time que sofreu o gol: cabeça baixa, mãos na cintura
  shx+=cf*.06;shz+=sf*.06;shY-=.05;hdx=shx+cf*.12;hdz=shz+sf*.12;hdY=shY+.2;
  lhx=hx-rx*.34;lhz=hz-rz*.34;lhy=hipY+.12;rhx=hx+rx*.34;rhz=hz+rz*.34;rhy=hipY+.12;
 }
 const sb=p.stumbleT>0?sin(PI*(1-p.stumbleT/.55)):0,sn=p.stun>0&&p.slideT<=0?clamp(p.stun/.5,0,1):0;
 if(sb>0){ // desarmado: corpo para trás, braços balançando
  shx-=cf*.3*sb;shz-=sf*.3*sb;hdx-=cf*.45*sb;hdz-=sf*.45*sb;hdY-=.12*sb;shY-=.15*sb;
  lhy+=.7*sb;rhy+=.7*sb;lhx-=rx*.3*sb;lhz-=rz*.3*sb;rhx+=rx*.3*sb;rhz+=rz*.3*sb;lfx-=cf*.25*sb;lfz-=sf*.25*sb;
 }
 if(sn>0){ // tropeço / levantando após deslize ou desarme errado: tronco inclinado à frente
  shx+=cf*.28*sn;shz+=sf*.28*sn;hdx+=cf*.34*sn;hdz+=sf*.34*sn;hdY-=.22*sn;shY-=.14*sn;lhy-=.25*sn;rhy-=.25*sn;
 }
 if(p.slideT>0){
  hipY=.3;shY=.45;shx=hx-cf*.75;shz=hz-sf*.75;hdx=shx-cf*.3;hdz=shz-sf*.3;hdY=.5;
  lfx=hx+cf*.95-rx*.1;lfz=hz+sf*.95-rz*.1;lfy=.15;rfx=hx+cf*.85+rx*.1;rfz=hz+sf*.85+rz*.1;rfy=.12;
  lhx=shx-rx*.4;lhz=shz-rz*.4;lhy=.2;rhx=shx+rx*.4;rhz=shz+rz*.4;rhy=.2;
 }
 if(p.diveT>0){
  const dz=p.dvz||1;hipY=.85;shY=1.15;shx=hx;shz=hz+dz*.9;hdx=hx;hdz=hz+dz*1.2;hdY=1.35;
  lhx=hx;lhz=hz+dz*1.7;lhy=1.65;rhx=hx+.1;rhz=hz+dz*1.7;rhy=1.55;
  lfx=hx-.1;lfz=hz-dz*.5;lfy=.5;rfx=hx+.1;rfz=hz-dz*.6;rfy=.35;
 }
 ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
 if(!proj(hx,hipY,hz)||!proj(shx,shY,shz)||!proj(hdx,hdY,hdz))return;
 const sLod=s/CH*720,far=sLod<17,det=sLod<19?0:S.gfx,sh=kit.sh,sh2=kit.sh2,so=kit.so,gk=p.role==='GK',skin=p.skin,body=clamp(p.body||1,.85,1.15),sd=[rx,0,rz];
 const boot=gk?GBOOT[p.team&1]:BOOT[(((p.num|0)*3)+p.team)%BOOT.length];
 PN=0;
 // ===== PERNAS: chuteira, meião, joelho, calção =====
 for(let side=0;side<2;side++){
  const sg=side?1:-1,ax=side?rfx:lfx,ay=side?rfy:lfy,az=side?rfz:lfz;
  const ha=[hx+rx*.125*sg*body,hipY-.1,hz+rz*.125*sg*body],an=[ax,ay+.1,az];
  const kb=.03+.13*clamp(ay*3,0,1)+.05*amp;
  const kn=[(ha[0]+an[0])*.5+cf*kb,(ha[1]+an[1])*.5+.03,(ha[2]+an[2])*.5+sf*kb];
  const heel=[ax-cf*.07,ay+.03,az-sf*.07],toe=[ax+cf*.21,ay+.04,az+sf*.21];
  box3D(heel,toe,.088,.058,boot,sd);                                  // chuteira
  if(!far)box3D([heel[0],ay+.005,heel[2]],[toe[0],ay+.005,toe[2]],.092,.028,shade(boot,-.5),sd); // sola
  if(det>=2){box3D([ax+cf*.03,ay+.085,az+sf*.03],[ax+cf*.13,ay+.088,az+sf*.13],.04,.012,'#e8e8e8',sd);} // cadarço
  if(det>=1){
   const tm=lerp3(ha,kn,.6);
   box3D(ha,tm,.118*body,.115*body,sh2,sd,1);                         // perna do calção
   box3D(tm,kn,.086*body,.086*body,shade(skin,-.04),sd,1);            // coxa / joelho
   box3D(kn,an,.074*body,.074*body,so,sd);                            // meião
   box3D(kn,lerp3(kn,an,.2),.079*body,.079*body,shade(so,.32),sd);   // faixa do meião
   box3D(lerp3(kn,an,.9),an,.07,.07,shade(so,-.1),sd);
  }else{
   box3D(ha,kn,.11*body,.11*body,sh2,sd,1);
   box3D(kn,an,.08*body,.08*body,so,sd);
  }
 }
 // ===== TRONCO: calção, camisa, ombros, gola =====
 const wa=[hx+(shx-hx)*.12,hipY+.05,hz+(shz-hz)*.12],ch=[shx,shY-.04,shz];
 box3D([hx,hipY-.2,hz],[hx,hipY+.07,hz],.235*body,.135*body,sh2,sd);           // quadril / calção
 box3D(wa,ch,.235*body,.145*body,sh,sd,3);                                         // camisa
 if(det>=1)box3D([hx,hipY+.06,hz],[hx+(shx-hx)*.1,hipY+.1,hz+(shz-hz)*.1],.21*body,.132*body,shade(sh2,-.05),sd); // barra / elástico
 box3D([shx,shY-.1,shz],[shx,shY+.035,shz],.265*body,.145*body,sh,sd);              // ombros
 if(det>=1){
  box3D([shx,shY+.015,shz],[shx,shY+.06,shz],.1*body,.085*body,sh2,sd);            // gola
  box3D([shx,shY+.03,shz],[hdx,hdY-.15,hdz],.058*body,.058*body,shade(skin,-.1),sd,1); // pescoço
 }else box3D([shx,shY+.02,shz],[hdx,hdY-.15,hdz],.06,.06,shade(skin,-.1),sd,1);
 // número (e nome) no lado da camisa voltado para a câmera
 {const dxc=C.px-hx,dzc=C.pz-hz,dl=Math.hypot(dxc,dzc)||1,fb=(cf*dxc+sf*dzc)/dl,back=fb<0,af=Math.abs(fb);
  if(af>.22){const sgn=back?-1:1,my=back?(hipY*.3+shY*.7):(hipY*.35+shY*.65);
   if(proj((hx+shx)*.5+cf*.14*sgn,my,(hz+shz)*.5+sf*.14*sgn)){const q=pitem();q.k=2;q.d=P.z-.03;q.tx=P.x;q.ty=P.y;q.sx=clamp(af,.2,1);
    q.col=kit.num;q.txt=String(p.num);q.fs=Math.max(3,(back?.3:.15)*P.s);q.nm=(back&&det>=2&&P.s>26&&p.name)?String(p.name).toUpperCase().slice(0,9):'';}}}
 // ===== BRAÇOS: manga com punho, braço, mão / luva =====
 for(let side=0;side<2;side++){
  const sg=side?1:-1,hX=side?rhx:lhx,hY=side?rhy:lhy,hZ=side?rhz:lhz;
  const S0=[shx+rx*.28*sg*body,shY-.05,shz+rz*.28*sg*body],H=[hX,hY,hZ];
  const E=lerp3(S0,H,.5);E[0]+=rx*sg*.045+cf*.07*amp;E[1]-=.02;E[2]+=rz*sg*.045+sf*.07*amp;
  const sl=lerp3(S0,E,.62);
  box3D(S0,sl,.105*body,.095*body,sh,sd);                                        // manga
  if(det>=1)box3D(lerp3(S0,E,.5),sl,.092*body,.092*body,sh2,sd);                  // punho da manga
  if(far){box3D(sl,H,.06*body,.06*body,skin,sd,1);continue;}                      // longe: braço inteiro numa peça só
  box3D(sl,E,.064*body,.064*body,skin,sd,1);                                       // braço
  box3D(E,H,.058*body,.058*body,shade(skin,-.03),sd,1);                            // antebraço
  const dir=[H[0]-E[0],H[1]-E[1],H[2]-E[2]],dl2=Math.hypot(dir[0],dir[1],dir[2])||1,hl=gk?.12:.085;
  const tip=[H[0]+dir[0]/dl2*hl,H[1]+dir[1]/dl2*hl,H[2]+dir[2]/dl2*hl];
  if(gk){box3D(lerp3(E,H,.8),H,.066,.066,shade(GLOVE[p.team&1],-.3),sd,1);box3D(H,tip,.075,.062,GLOVE[p.team&1],sd,1);}
  else box3D(H,tip,.052,.045,shade(skin,-.06),sd,1);
 }
 // ===== CABEÇA (ordenada junto das outras peças) =====
 {const q=pitem();q.k=1;q.d=(proj(hdx,hdY,hdz)?P.z:0)-.25;q.hdx=hdx;q.hdY=hdY;q.hdz=hdz;q.cf=cf;q.sf=sf;q.skin=skin;q.hair=p.hair;q.det=det;q.body=body;q.celeb=p.celeb>0?1:0;
  q.style=((p.num*7)+(p.team*3)+((p.name||'').length*5))%4;}
 flushParts();
}
function drawBall(){
 const b=G.ball,tr=b.tr;
 if(tr&&tr.length>=6){ // rastro de velocidade em chutes fortes
  ctx.lineCap='round';let px=0,py=0,has=false;
  for(let i=0;i<tr.length;i+=3){
   if(!proj(tr[i],tr[i+1],tr[i+2])){has=false;continue;}
   if(has){const t=i/tr.length;ctx.strokeStyle='rgba(255,255,255,'+(.06+t*.34).toFixed(2)+')';ctx.lineWidth=Math.max(1,BR*P.s*(.3+t*1.1));
    ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(P.x,P.y);ctx.stroke();}
   px=P.x;py=P.y;has=true;
  }
 }
 if(!proj(b.x,b.y,b.z))return;
 const r=Math.max(2.6,BR*P.s*1.5),x=P.x,y=P.y;
 // orientação 3D da bola: gira em torno do eixo de rolagem conforme anda
 if(!b.q){b.q=[1,0,0,0];b._rp=b.rot;}
 let dth=b.rot-b._rp;b._rp=b.rot;if(dth>1||dth<-1)dth=0;
 const o=b.owner,vx=o?o.vx:b.vx,vz=o?o.vz:b.vz,vm=hyp(vx,vz);
 if(vm>.05&&dth){const ax=-vz/vm,az=vx/vm,h=dth/2,sn=Math.sin(h),qq=[Math.cos(h),ax*sn,0,az*sn],q=b.q;
  const n=[qq[0]*q[0]-qq[1]*q[1]-qq[2]*q[2]-qq[3]*q[3],qq[0]*q[1]+qq[1]*q[0]+qq[2]*q[3]-qq[3]*q[2],qq[0]*q[2]-qq[1]*q[3]+qq[2]*q[0]+qq[3]*q[1],qq[0]*q[3]+qq[1]*q[2]-qq[2]*q[1]+qq[3]*q[0]];
  const l=hyp(n[0],n[1],n[2],n[3])||1;b.q=[n[0]/l,n[1]/l,n[2]/l,n[3]/l];}
 // esfera sombreada: luz vinda de cima/esquerda, lado oposto escuro, brilho especular
 const g=ctx.createRadialGradient(x-r*.35,y-r*.4,r*.05,x+r*.1,y+r*.1,r*1.08);
 g.addColorStop(0,'#ffffff');g.addColorStop(.45,'#eef1f4');g.addColorStop(.8,'#a9b1bb');g.addColorStop(1,'#4b535e');
 ctx.fillStyle=g;ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();
 if(r>4){
  const q=b.q,PH=BALL_PATCH;
  ctx.save();ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.clip();
  for(let k=0;k<PH.length;k++){
   const p=PH[k],px=p[0],py=p[1],pz=p[2];
   // v' = q * v * q^-1
   const tx=2*(q[2]*pz-q[3]*py),ty=2*(q[3]*px-q[1]*pz),tz=2*(q[1]*py-q[2]*px);
   const wx=px+q[0]*tx+(q[2]*tz-q[3]*ty),wy=py+q[0]*ty+(q[3]*tx-q[1]*tz),wz=pz+q[0]*tz+(q[1]*ty-q[2]*tx);
   // mundo -> câmera
   const cxv=wx*C.rx+wz*C.rz,cyv=wx*C.ux+wy*C.uy+wz*C.uz,czv=wx*C.fx+wy*C.fy+wz*C.fz;
   if(czv>-.05)continue; // lado de trás
   const f=-czv,sx=x+cxv*r,sy=y-cyv*r,rad=Math.hypot(cxv,cyv)||1e-3;
   const rr=r*.34,a=rr*Math.max(.25,f),ang=Math.atan2(-cyv,cxv);
   ctx.fillStyle='rgba(24,28,34,'+(.55+.4*f).toFixed(2)+')';
   ctx.beginPath();ctx.ellipse(sx,sy,rr*(.55+.45*f)*1.0,Math.max(rr*.25,a),ang+PI/2,0,TAU);ctx.fill();
  }
  // sombreamento do volume (terminador) e brilho
  const sh=ctx.createRadialGradient(x-r*.3,y-r*.35,r*.2,x,y,r);
  sh.addColorStop(0,'rgba(255,255,255,0)');sh.addColorStop(.6,'rgba(20,28,40,.12)');sh.addColorStop(1,'rgba(10,14,22,.55)');
  ctx.fillStyle=sh;ctx.fillRect(x-r,y-r,r*2,r*2);
  ctx.restore();
  ctx.fillStyle='rgba(255,255,255,.85)';ctx.beginPath();ctx.ellipse(x-r*.36,y-r*.42,r*.22,r*.13,-.6,0,TAU);ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.45)';ctx.lineWidth=Math.max(1,r*.09);ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.stroke();
 }
}
const BALL_PATCH=(()=>{const t=(1+Math.sqrt(5))/2,v=[[0,1,t],[0,-1,t],[0,1,-t],[0,-1,-t],[1,t,0],[-1,t,0],[1,-t,0],[-1,-t,0],[t,0,1],[-t,0,1],[t,0,-1],[-t,0,-1]];
 return v.map(p=>{const l=Math.hypot(p[0],p[1],p[2]);return [p[0]/l,p[1]/l,p[2]/l];});})();


/* ---------------- Efeitos e partículas (poeira, grama, confete, faíscas, rastro) ----------------
   Partículas vivem em coordenadas do mundo (metros) e são projetadas na hora de desenhar.
   fx* são chamadas pelo game.js; stepFX roda dentro do simStep (congela junto com a pausa). */
const PT=[],PTMAX=260,PTQ=[.35,.7,1],CONF=['#ffd23a','#ff5a5a','#5aa8ff','#4ee08a','#ffffff','#ff8a3a'];
function ptAdd(type,x,y,z,vx,vy,vz,life,size,col,g){
 if(PT.length>=PTMAX)return;
 PT.push({type,x,y,z,vx,vy,vz,life,max:life,size,col,g:g||0,rot:rnd()*TAU,vr:(rnd()-.5)*14});
}
function fxPuff(x,z,n,sp){ // nuvenzinha de poeira
 n=Math.ceil(n*PTQ[S.gfx]);
 for(let i=0;i<n;i++)ptAdd('puff',x+(rnd()-.5)*.3,.08,z+(rnd()-.5)*.3,(rnd()-.5)*sp,.25+rnd()*.4,(rnd()-.5)*sp,.45+rnd()*.3,.16+rnd()*.12,'#d8e6c8',0);
}
function fxBurst(x,z,n){ // pedaços de grama arrancados
 n=Math.ceil(n*PTQ[S.gfx]);
 for(let i=0;i<n;i++){const a=rnd()*TAU,sp=1.2+rnd()*2.6;
  ptAdd('grass',x,.1,z,cos(a)*sp,2+rnd()*2.6,sin(a)*sp,.5+rnd()*.35,.12+rnd()*.1,rnd()<.4?'#1f6a30':'#3fae55',11);}
}
function fxKick(b,sp,vy){ // contato do pé com a bola
 if(b.y<.7){fxBurst(b.x,b.z,2+(sp*.12|0));fxPuff(b.x,b.z,2,1);}
 if(sp>24&&S.gfx>=1)for(let i=0;i<7;i++){const a=rnd()*TAU,v=3+rnd()*4;
  ptAdd('spark',b.x,b.y+.1,b.z,cos(a)*v,rnd()*3,sin(a)*v,.22+rnd()*.15,.1,'#ffe9a0',0);}
}
function fxGhost(p){ // imagem residual da arrancada
 const k=p.role==='GK'?GKK[p.team]:KIT[p.team];
 ptAdd('ghost',p.x,0,p.z,0,0,0,.28,1,k.sh,0);
}
function fxGoal(side){ // flash, tremor e onda na rede (sem confete)
 const b=G.ball;G.shake=1;G.flash=1;G.net={side:side>0?1:-1,t:0,z:b.z,y:clamp(b.y,.2,GH)};
}
function stepFX(dt){
 if(G.shake>0)G.shake=Math.max(0,G.shake-dt*1.6);
 if(G.flash>0)G.flash=Math.max(0,G.flash-dt*2.2);
 if(G.net){G.net.t+=dt;if(G.net.t>2.2)G.net=null;}
 for(let i=PT.length-1;i>=0;i--){
  const q=PT[i];q.life-=dt;
  if(q.life<=0){PT[i]=PT[PT.length-1];PT.pop();continue;}
  q.vy-=q.g*dt;
  if(q.type==='conf'){q.vy=Math.max(q.vy,-2.2);q.rot+=q.vr*dt;q.vx*=Math.exp(-1.2*dt);q.vz*=Math.exp(-1.2*dt);}
  else if(q.type==='puff'){q.vx*=Math.exp(-2.5*dt);q.vz*=Math.exp(-2.5*dt);}
  q.x+=q.vx*dt;q.y+=q.vy*dt;q.z+=q.vz*dt;
  if(q.y<0&&q.type!=='puff'&&q.type!=='ghost'){q.y=0;q.vy=0;q.vx*=.3;q.vz*=.3;}
 }
}
function drawPT(late){ // late=false: poeira/rastros (antes dos jogadores) · true: grama, confete, faíscas (depois)
 for(let i=0;i<PT.length;i++){
  const q=PT[i],isLate=q.type==='grass'||q.type==='conf'||q.type==='spark';
  if(isLate!==late)continue;
  const a=q.life/q.max;
  if(!proj(q.x,q.y,q.z))continue;
  const s=P.s,x=P.x,y=P.y;
  if(q.type==='puff'){
   ctx.globalAlpha=a*.5;ctx.fillStyle=q.col;ctx.beginPath();ctx.arc(x,y,Math.max(1,q.size*s*(1+(1-a)*1.8)),0,TAU);ctx.fill();
  }else if(q.type==='grass'){
   ctx.globalAlpha=Math.min(1,a*3);ctx.fillStyle=q.col;const r=Math.max(1,q.size*s*.5);ctx.fillRect(x-r,y-r,r*2,r*1.4);
  }else if(q.type==='conf'){
   ctx.globalAlpha=Math.min(1,a*2.5);ctx.fillStyle=q.col;
   const h=Math.max(1.2,q.size*s*.5),w=h*(abs(cos(q.rot*2))*.9+.15);ctx.fillRect(x-w,y-h,w*2,h*2);
  }else if(q.type==='spark'){
   ctx.globalAlpha=a;ctx.fillStyle=q.col;ctx.globalCompositeOperation='lighter';
   const r=Math.max(1.2,q.size*s*.6);ctx.beginPath();ctx.arc(x,y,r,0,TAU);ctx.fill();ctx.globalCompositeOperation='source-over';
  }else if(q.type==='ghost'){
   const bx=x,by=y;if(!proj(q.x,1.55,q.z))continue;
   ctx.globalAlpha=a*.38;ctx.strokeStyle=q.col;ctx.lineWidth=Math.max(2,.5*s);ctx.lineCap='round';
   ctx.beginPath();ctx.moveTo(bx,by);ctx.lineTo(P.x,P.y);ctx.stroke();
  }
 }
 ctx.globalAlpha=1;
}

/* ---------------- Marcadores sobre os jogadores (camada superior, sem sobreposição) ----------------
   Âncora estável: ponto 2,0 m acima dos pés (não depende da inclinação/animação do corpo). */
const TAGS=[];
function drawTags(){
 const k=CH/720;TAGS.length=0;
 const u=G.user,o=G.ball.owner;
 if(S.ind&&u)TAGS.push({p:u,txt:'VOCÊ',user:true});
 {const ou=Net.mp?(Net.role==='guest'?Net.other:(RC.active?RC.user:null)):null;if(ou&&ou!==u)TAGS.push({p:ou,txt:Net.role==='guest'?'JOGADOR 1':'JOGADOR 2',user:false});}
 if(S.names&&o&&o!==u)TAGS.push({p:o,txt:o.name,user:false});
 ctx.textAlign='center';ctx.textBaseline='middle';
 const placed=[];
 for(const t of TAGS){
  const p=t.p;if(!proj(p.x,2.05+(p.jumpT>0?.4:0),p.z))continue;
  const s=P.s,ax=P.x;let ay=P.y;
  if(ax<-40||ax>CW+40||ay<-40||ay>CH+40)continue;
  const fs=clamp(.34*s,17*k,25*k);
  if(t.user){ // seta flutuante logo acima da cabeça
   const aw=clamp(.2*s,7*k,14*k),ah=aw*1.25,bob=sin(G.t*6)*2*k;
   const tip=ay-3*k+bob;
   ctx.fillStyle='#ffe14a';ctx.strokeStyle='rgba(0,0,0,.65)';ctx.lineWidth=Math.max(1.5,1.6*k);ctx.lineJoin='round';
   ctx.beginPath();ctx.moveTo(ax-aw,tip-ah);ctx.lineTo(ax+aw,tip-ah);ctx.lineTo(ax,tip);ctx.closePath();ctx.stroke();ctx.fill();
   ay=tip-ah-2*k;
  }else ay-=3*k;
  ctx.font='800 '+fs+'px sans-serif';
  const tw=ctx.measureText(t.txt).width,pw=tw+fs*.9,ph=fs*1.3;
  let bx=ax-pw/2,by=ay-ph;
  for(const r of placed){ // evita sobreposição com outro rótulo
   if(bx<r.x+r.w&&bx+pw>r.x&&by<r.y+r.h&&by+ph>r.y)by=r.y-ph-2*k;
  }
  placed.push({x:bx,y:by,w:pw,h:ph});
  ctx.fillStyle=t.user?'rgba(20,24,10,.78)':'rgba(8,12,18,.72)';rr(bx,by,pw,ph,ph/2);ctx.fill();
  ctx.strokeStyle=t.user?'#ffe14a':'rgba(255,255,255,.55)';ctx.lineWidth=Math.max(1.2,1.4*k);rr(bx,by,pw,ph,ph/2);ctx.stroke();
  ctx.fillStyle=t.user?'#ffe14a':'#fff';ctx.fillText(t.txt,ax,by+ph/2+.04*fs);
 }
 ctx.textBaseline='alphabetic';
}

/* ---------------- Overlay (placar, radar, barra de força, mensagens) ---------------- */
const ENT=[];
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function cmpZ(a,b){return b.dz-a.dz;}
function fmtClock(){
 if(G.pen){
  const p=G.pen;
  if(p.sudden)return 'MS';
  return Math.min(5,Math.max(p.taken[0],p.taken[1])+1)+'/5';
 }
 if(G.train)return G.train.clk||'00:00';
 const sec=(G.half-1)*2700+Math.min(1,G.clock/halfLen())*2700;
 const m=(sec/60)|0,s=(sec%60)|0;return (m<10?'0':'')+m+':'+(s<10?'0':'')+s;
}
function clipRR(x,y,w,h,r){rr(x,y,w,h,r);ctx.save();ctx.clip();}
/* ---------------- Placar personalizado (images/scoreboard/scoreboard.png) ----------------
   Se o PNG existir e carregar, ele vira a base visual do placar; nomes, escudos, gols e relógio continuam
   sendo desenhados pelo jogo por cima. Se não existir/falhar, usa-se o placar original (nada muda).
   Ajustes opcionais de posição: images/scoreboard/scoreboard.json (ver LEIA-ME.txt na mesma pasta). */
const SB={img:null,ok:false,cfg:{},crest:{}};
(function(){
 const v='?v='+Date.now(); // troca do arquivo vale ao recarregar, sem cache antigo
 try{
  const im=new Image();
  im.onload=()=>{if(im.naturalWidth>0&&im.naturalHeight>0){SB.img=im;SB.ok=true;if(typeof layoutHUD==='function')layoutHUD();}};
  im.onerror=()=>{SB.ok=false;SB.img=null;};
  im.src='images/scoreboard/scoreboard.png'+v;
  fetch('images/scoreboard/scoreboard.json'+v,{cache:'no-cache'}).then(r=>r.ok?r.json():null).then(j=>{if(j&&typeof j==='object'){SB.cfg=j;if(typeof layoutHUD==='function')layoutHUD();}}).catch(()=>{});
 }catch(e){SB.ok=false;}
})();
function sbCrest(i){
 if(G.train)return null;
 // clube da partida atual (Amistoso, Carreira, Pênaltis...): MATCH_CLUBS é preenchido por applyTeams()
 const id=(typeof MATCH_CLUBS!=='undefined'&&MATCH_CLUBS[i])||((typeof CLUB!=='undefined'&&CLUB.teams&&CLUB.teams[i])?CLUB.teams[i].id:null);
 if(!id||typeof CREST_FILES==='undefined'||!CREST_FILES[id])return null;
 let c=SB.crest[id];
 if(!c){c=SB.crest[id]={img:new Image(),ok:false};c.img.onload=()=>{c.ok=c.img.naturalWidth>0;};c.img.onerror=()=>{c.ok=false;};c.img.src=CREST_FILES[id];}
 return c.ok?c.img:null;
}
function sbNum(a,d){return(typeof a==='number'&&isFinite(a))?a:d;}
function drawScoreboardPNG(bx,by,bw,bh){
 const C=SB.cfg,u=bh/50*sbNum(C.textScale,1); // u: escala dos textos (acompanha a altura da imagem)
 ctx.drawImage(SB.img,bx,by,bw,bh);
 const tx=Array.isArray(C.teams)?C.teams:[.15,.85],sx=Array.isArray(C.scores)?C.scores:[.292,.708],cx=sbNum(C.clock,.5),
       cr=Array.isArray(C.crests)?C.crests:[.06,.94],csz=sbNum(C.crestSize,.7)*bh,ty=sbNum(C.textY,.5);
 const col=C.colors||{},fT=sbNum(C.teamSize,19),fS=sbNum(C.scoreSize,28),fC=sbNum(C.clockSize,19);
 for(let i=0;i<2;i++){const im=C.showCrests===false?null:sbCrest(i);
  if(im){const r=im.naturalWidth/im.naturalHeight,w=r>=1?csz:csz*r,h=r>=1?csz/r:csz;ctx.drawImage(im,bx+cr[i]*bw-w/2,by+bh*ty-h/2,w,h);}}
 ctx.shadowColor='rgba(0,0,0,.6)';ctx.shadowBlur=3*u;
 ctx.fillStyle=col.teams||'#fff';ctx.font='900 '+(fT*u).toFixed(1)+'px sans-serif';
 for(let i=0;i<2;i++)ctx.fillText(hudL(i),bx+tx[i]*bw,by+bh*ty+fT*u*.36,bw*sbNum(C.teamMaxW,.14));
 ctx.fillStyle=col.scores||'#fff';ctx.font='900 '+(fS*u).toFixed(1)+'px sans-serif';
 for(let i=0;i<2;i++)ctx.fillText(hudS(i),bx+sx[i]*bw,by+bh*ty+fS*u*.36,bw*.09);
 ctx.shadowBlur=0;ctx.shadowColor='transparent';
 let extra=0;
 const P=C.clockPill;
 if(P&&P!==false){ // cápsula do cronômetro (ex.: logo abaixo do escudo central)
  const pw=bw*sbNum(P.w,.16),ph=bh*sbNum(P.h,.17),px=bx+cx*bw-pw/2,py=by+bh*sbNum(P.y,.985)-ph/2;
  ctx.fillStyle='rgba(8,12,22,.94)';rr(px,py,pw,ph,ph/2);ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.28)';ctx.lineWidth=Math.max(1,bh*.012);rr(px,py,pw,ph,ph/2);ctx.stroke();
  ctx.fillStyle=col.clock||'#ffe14a';ctx.font='800 '+(ph*.62).toFixed(1)+'px sans-serif';ctx.fillText(fmtClock(),bx+cx*bw,py+ph*.5+ph*.22,pw*.88);
  extra=Math.max(0,py+ph-(by+bh));
 }else{
  ctx.shadowColor='rgba(0,0,0,.6)';ctx.shadowBlur=3*u;
  ctx.fillStyle=col.clock||'#ffe14a';ctx.font='800 '+(fC*u).toFixed(1)+'px sans-serif';ctx.fillText(fmtClock(),bx+cx*bw,by+bh*ty+fC*u*.36,bw*.16);
  ctx.shadowBlur=0;ctx.shadowColor='transparent';
 }
 return extra;
}
/* ---------------- Barra de força (chute / pênalti / falta) ----------------
   Barra em losango inclinado, segmentada, com cor por zona (azul → amarelo → VERDE ideal 70–90% → vermelho), marcador exato,
   rastro suave, brilho e aviso "MAX". Ao soltar o botão a força final fica congelada, pisca e desaparece (≈0,45 s).
   O valor desenhado é SEMPRE o valor recebido (o mesmo usado no cálculo do chute): só o rastro/brilho são suavizados. */
const PBS={shot:{v:0,tr:0,a:0,rel:0,was:false,t:0},pen:{v:0,tr:0,a:0,rel:0,was:false,t:0}};
const PB_ZONES=[[0,.5,'#35b8ff'],[.5,.7,'#ffd23a'],[.7,.9,'#37e07a'],[.9,1.0001,'#ff4a2a']];
function pbColor(v){for(const z of PB_ZONES)if(v<z[1])return z[2];return '#ff4a2a';}
function drawPowerBar(st,cx,y,w,h,v,live,label,hint){
 const now=performance.now(),dt=Math.min(.1,Math.max(0,(now-(st.t||now))/1000));st.t=now;
 v=Math.max(0,Math.min(1,v||0));
 if(live){st.v=v;st.a=Math.min(1,st.a+dt*9);st.rel=0;st.was=true;st.tr+=(v-st.tr)*Math.min(1,dt*10);if(st.tr>v)st.tr=v;}
 else{if(st.was){st.rel=.45;st.was=false;}st.rel=Math.max(0,st.rel-dt);st.a=Math.max(0,st.a-dt*(st.rel>0?2.2:7));st.tr+=(st.v-st.tr)*Math.min(1,dt*10);}
 if(st.a<=.01&&!live)return;
 const val=live?v:st.v,col=pbColor(val),max=val>=.95,ideal=val>=.7&&val<=.9,sk=h*.55,pulse=.5+.5*Math.sin(now/90);
 const bw=w,x=cx-bw/2,r=Math.max(2,h*.18);
 ctx.save();ctx.globalAlpha=st.a;ctx.textBaseline='alphabetic';ctx.textAlign='center';
 // base escura inclinada
 const para=(px,py,pw,ph,s)=>{ctx.beginPath();ctx.moveTo(px+s,py);ctx.lineTo(px+pw,py);ctx.lineTo(px+pw-s,py+ph);ctx.lineTo(px,py+ph);ctx.closePath();};
 const pad=3*(h/15);
 ctx.shadowColor='rgba(0,0,0,.55)';ctx.shadowBlur=10*(h/15);
 para(x-pad*2,y-pad,bw+pad*4,h+pad*2,sk+pad);ctx.fillStyle='rgba(8,14,24,.82)';ctx.fill();ctx.shadowBlur=0;ctx.shadowColor='transparent';
 ctx.lineWidth=Math.max(1,h*.08);ctx.strokeStyle='rgba(255,255,255,.28)';ctx.stroke();
 // segmentos
 const N=25,gap=h*.12,sw=(bw-(N-1)*gap)/N;
 for(let i=0;i<N;i++){
  const f0=i/N,f1=(i+1)/N,sx=x+i*(sw+gap),lit=val>=f1-.0001||(val>f0&&val<f1),part=lit&&val<f1?(val-f0)/(f1-f0):1;
  const zc=pbColor((f0+f1)/2);
  ctx.beginPath();ctx.moveTo(sx+sk*.6,y);ctx.lineTo(sx+sw+sk*.6,y);ctx.lineTo(sx+sw,y+h);ctx.lineTo(sx,y+h);ctx.closePath();
  ctx.fillStyle='rgba(255,255,255,.10)';ctx.fill();
  if(f1<=st.tr+.0001&&!lit){ctx.fillStyle=zc;ctx.globalAlpha=st.a*.28;ctx.fill();ctx.globalAlpha=st.a;}
  if(lit){ctx.save();ctx.clip();ctx.fillStyle=zc;ctx.fillRect(sx,y,(sw+sk)*part,h);
   const gl=ctx.createLinearGradient(0,y,0,y+h);gl.addColorStop(0,'rgba(255,255,255,.55)');gl.addColorStop(.5,'rgba(255,255,255,0)');ctx.fillStyle=gl;ctx.fillRect(sx,y,sw+sk,h);ctx.restore();}
 }
 // brilho da ponta
 if(val>0){ctx.shadowColor=col;ctx.shadowBlur=(max?16+pulse*10:9)*(h/15);ctx.fillStyle=col;const mx=x+bw*val;ctx.fillRect(mx-1.2*(h/15),y-h*.18,2.4*(h/15),h*1.36);ctx.shadowBlur=0;ctx.shadowColor='transparent';
  // marcador triangular
  ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(mx,y-h*.2);ctx.lineTo(mx-h*.28,y-h*.62);ctx.lineTo(mx+h*.28,y-h*.62);ctx.closePath();ctx.fill();}
 // zona ideal 70–90%: colchete verde
 {const z0=x+bw*.7,z1=x+bw*.9,yb=y+h+h*.26;ctx.strokeStyle='#37e07a';ctx.lineWidth=Math.max(1.2,h*.12);ctx.globalAlpha=st.a*(ideal?1:.75);
  ctx.beginPath();ctx.moveTo(z0,yb-h*.2);ctx.lineTo(z0,yb);ctx.lineTo(z1,yb);ctx.lineTo(z1,yb-h*.2);ctx.stroke();ctx.globalAlpha=st.a;}
 // rótulo + porcentagem
 const fs=Math.max(9,h*.74);
 ctx.font='800 '+fs.toFixed(1)+'px sans-serif';ctx.textAlign='left';ctx.fillStyle='rgba(255,255,255,.9)';ctx.fillText(label||'FORÇA',x,y-h*.55);
 ctx.textAlign='right';ctx.font='900 '+(fs*1.45).toFixed(1)+'px sans-serif';ctx.fillStyle=col;ctx.shadowColor='rgba(0,0,0,.7)';ctx.shadowBlur=4;
 ctx.fillText(Math.round(val*100)+'%',x+bw,y-h*.5);ctx.shadowBlur=0;ctx.shadowColor='transparent';
 // aviso de força máxima / zona ideal
 ctx.textAlign='center';ctx.font='900 '+(fs*.95).toFixed(1)+'px sans-serif';
 if(max){ctx.globalAlpha=st.a*(.55+.45*pulse);ctx.fillStyle='#ff4a2a';ctx.fillText('MÁXIMA',cx,y-h*.55);}
 else if(ideal&&live){ctx.fillStyle='#37e07a';ctx.fillText('IDEAL',cx,y-h*.55);}
 // flash ao soltar
 if(!live&&st.rel>0){ctx.globalAlpha=st.a*Math.min(1,st.rel/.45)*.35;para(x-pad*2,y-pad,bw+pad*4,h+pad*2,sk+pad);ctx.fillStyle='#fff';ctx.fill();}
 ctx.restore();
}
function drawOverlay(){
 const k=HUDM.k*QK; // mesma escala do HUD de controles
 ctx.textAlign='center';
 // ---- placar: [TIME] [gols] [relógio] [gols] [TIME]
 let bw=380*k,bh=50*k,bx,by=10*k,cr=12*k,g;const sbc=SB.ok&&SB.img;
 if(sbc){bw=sbNum(SB.cfg.width,380)*k;bh=bw*SB.img.naturalHeight/SB.img.naturalWidth;by=sbNum(SB.cfg.top,10)*k;}
 bx=CW/2-bw/2;
 let sbExtra=0;if(sbc)sbExtra=drawScoreboardPNG(bx,by,bw,bh);else{
 ctx.fillStyle='rgba(0,0,0,.38)';rr(bx+1*k,by+4*k,bw,bh,cr);ctx.fill(); // sombra
 const bg=ctx.createLinearGradient(0,by,0,by+bh);bg.addColorStop(0,'rgba(30,40,58,.95)');bg.addColorStop(1,'rgba(8,12,20,.95)');
 ctx.fillStyle=bg;rr(bx,by,bw,bh,cr);ctx.fill();
 const wT=88*k,wS=46*k;
 clipRR(bx,by,bw,bh,cr);
 g=ctx.createLinearGradient(0,by,0,by+bh);g.addColorStop(0,'#3d82ff');g.addColorStop(1,'#1346b8');ctx.fillStyle=g;ctx.fillRect(bx,by,wT,bh);
 g=ctx.createLinearGradient(0,by,0,by+bh);g.addColorStop(0,'#ff5a5a');g.addColorStop(1,'#a81818');ctx.fillStyle=g;ctx.fillRect(bx+bw-wT,by,wT,bh);
 g=ctx.createLinearGradient(0,by,0,by+bh*.5);g.addColorStop(0,'rgba(255,255,255,.22)');g.addColorStop(1,'rgba(255,255,255,0)');ctx.fillStyle=g;ctx.fillRect(bx,by,bw,bh*.5);
 ctx.restore();
 ctx.strokeStyle='rgba(255,255,255,.2)';ctx.lineWidth=1.2*k;rr(bx,by,bw,bh,cr);ctx.stroke();
 ctx.shadowColor='rgba(0,0,0,.6)';ctx.shadowBlur=3*k;
 ctx.fillStyle='#fff';ctx.font='900 '+(19*k).toFixed(1)+'px sans-serif';
 ctx.fillText(hudL(0),bx+wT/2,by+bh/2+7*k);ctx.fillText(hudL(1),bx+bw-wT/2,by+bh/2+7*k);
 ctx.font='900 '+(28*k).toFixed(1)+'px sans-serif';
 ctx.fillText(hudS(0),bx+wT+wS/2,by+bh/2+10*k);ctx.fillText(hudS(1),bx+bw-wT-wS/2,by+bh/2+10*k);
 ctx.fillStyle='#ffe14a';ctx.font='800 '+(19*k).toFixed(1)+'px sans-serif';ctx.fillText(fmtClock(),CW/2,by+bh/2+7*k);
 ctx.shadowBlur=0;ctx.shadowColor='transparent';
 }
 // ---- radar compacto, imediatamente à esquerda do placar
 if(S.radar&&!G.pen){
  const vl=bx+(sbc?sbNum(SB.cfg.visibleLeft,0)*bw:0),gapR=8*k; // borda visível esquerda do placar
  const minL=Math.max(6*QK,(HUDM.lbR||0)*QK+8*k); // não passa por cima do botão LB
  let rw=156*k;if(vl-gapR-rw<minL)rw=Math.max(70*k,vl-gapR-minL); // em telas estreitas encolhe um pouco, nunca sobrepõe
  const rh=rw*68/105,rx0=vl-gapR-rw,ry0=Math.max(4*k,by+(sbc?bh*sbNum(SB.cfg.textY,.5):bh/2)-rh/2);
  ctx.globalAlpha=.78;
  g=ctx.createLinearGradient(0,ry0,0,ry0+rh);g.addColorStop(0,'rgba(24,96,44,.85)');g.addColorStop(1,'rgba(10,52,24,.85)');
  ctx.fillStyle=g;rr(rx0,ry0,rw,rh,7*k);ctx.fill();
  ctx.strokeStyle='rgba(255,255,255,.45)';ctx.lineWidth=1;
  ctx.beginPath();ctx.moveTo(rx0+rw/2,ry0);ctx.lineTo(rx0+rw/2,ry0+rh);ctx.stroke();
  ctx.beginPath();ctx.arc(rx0+rw/2,ry0+rh/2,rh*.14,0,TAU);ctx.stroke();
  ctx.strokeRect(rx0,ry0+rh*.28,rw*.15,rh*.44);ctx.strokeRect(rx0+rw*.85,ry0+rh*.28,rw*.15,rh*.44);
  ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1.4*k;rr(rx0,ry0,rw,rh,7*k);ctx.stroke();
  for(const p of G.players){if(p.out)continue;ctx.fillStyle=p.team?'#ff6a6a':'#6aa8ff';{const fl=Net.mp&&Net.role==='guest',m=(p===G.user?3.6:2.4)*k,mx=rx0+(fl?1-(p.x+HL)/105:(p.x+HL)/105)*rw,my=ry0+(fl?1-(p.z+HW)/68:(p.z+HW)/68)*rh;
   ctx.fillRect(mx-m,my-m,m*2,m*2);
   if(p===G.user){ctx.strokeStyle='#ffe14a';ctx.lineWidth=1.6*k;ctx.strokeRect(mx-m,my-m,m*2,m*2);}}}
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(rx0+((Net.mp&&Net.role==='guest')?1-(G.ball.x+HL)/105:(G.ball.x+HL)/105)*rw,ry0+((Net.mp&&Net.role==='guest')?1-(G.ball.z+HW)/68:(G.ball.z+HW)/68)*rh,2.6*k,0,TAU);ctx.fill();
  ctx.strokeStyle='rgba(0,0,0,.5)';ctx.lineWidth=1;ctx.stroke();
  ctx.globalAlpha=1;
 }
 // ---- barra de força do chute (jogo corrido): mostra exatamente a força usada pelo chute (começa no mínimo real) e some após soltar
 {const live=!!(G.charging&&!G.pen&&!G.sp&&G.state==='play'&&!G.paused);
  const w=Math.min(250*k,CW*.58),h=15*k;
  drawPowerBar(PBS.shot,CW/2,CH-(HUDM.mb*QK)-134*k,w,h,Math.min(1,G.charge||0),live,'FORÇA','');}
 // ---- histórico visual da disputa de pênaltis (bolinhas)
 if(G.pen){
  const p=G.pen,dot=7*k,gap=11*k,y0=by+bh+sbExtra+6*k;
  for(let t=0;t<2;t++){
   const hist=p.history.filter(h=>h.team===t);
   const maxN=p.sudden?Math.max(5,p.taken[0],p.taken[1]):5;
   const total=Math.max(maxN,hist.length);
   const baseX=t===0?bx+10*k:bx+bw-10*k-(total-1)*gap;
   for(let i=0;i<total;i++){
    const h=hist[i];
    ctx.beginPath();ctx.arc(baseX+i*gap,y0,dot/2,0,TAU);
    if(h){
     ctx.fillStyle=h.result==='goal'?'#37e07a':(h.result==='save'?'#ffd21f':'#ff5a5a');
     ctx.fill();
    }else{
     ctx.strokeStyle='rgba(255,255,255,.35)';ctx.lineWidth=1.2*k;ctx.stroke();
    }
   }
  }
 }
 // ---- mira da disputa de pênaltis (retículo projetado no gol 3D + barra de força)
 if((G.pen&&(G.pen.phase==='aim'||G.pen.phase==='runup'||G.pen.phase==='walk')&&G.pen.kickTeam===0)||(G.sp&&G.sp.phase!=='flight')){
  const pn=G.pen||G.sp,aiming=pn.phase!=='walk',tz=pn.aimZ*GW*.92,ty=.25+pn.aimY*(GH-.35),pw=pn.power,tm=G.t;
  // moldura do gol
  ctx.lineWidth=2*k;ctx.strokeStyle='rgba(255,255,255,.28)';ctx.setLineDash([6*k,5*k]);
  if(proj(HL,0,-GW)){const x0=P.x,y0=P.y;if(proj(HL,GH,-GW)){const x1=P.x,y1=P.y;if(proj(HL,GH,GW)){const x2=P.x,y2=P.y;if(proj(HL,0,GW)){ctx.beginPath();ctx.moveTo(x0,y0);ctx.lineTo(x1,y1);ctx.lineTo(x2,y2);ctx.lineTo(P.x,P.y);ctx.stroke();}}}}
  ctx.setLineDash([]);
  if(aiming&&proj(HL,ty,tz)){
   const ax=P.x,ay=P.y,s=P.s;
   // linha tracejada bola -> alvo
   const bp=G.ball;
   if(proj(bp.x,bp.y,bp.z)){ctx.strokeStyle='rgba(255,230,90,.55)';ctx.lineWidth=2*k;ctx.setLineDash([4*k,6*k]);ctx.lineDashOffset=-tm*30*k;ctx.beginPath();ctx.moveTo(P.x,P.y);ctx.lineTo(ax,ay);ctx.stroke();ctx.setLineDash([]);ctx.lineDashOffset=0;}
   // a cor segue a zona de força
   const eff=(pn.charging||pn.phase==='runup')?pw:.8,col=(pw>.9&&eff===pw)?'#ff5a3a':(pw>=.7||!pn.charging?'#37e07a':'#ffd21f');
   const e=G.sp?spDisp(pn,eff):penErr(eff)*PEN_DIFF[pn.diff].userErr,rx=Math.max(8*k,e*GW*s),ry=Math.max(8*k,e*.7*s);
   // anel de dispersão (onde a bola pode cair)
   ctx.strokeStyle=col;ctx.globalAlpha=.6;ctx.lineWidth=2*k;ctx.beginPath();ctx.ellipse(ax,ay,rx,ry,0,0,TAU);ctx.stroke();ctx.globalAlpha=1;
   // retículo pulsante
   const r0=7*k+Math.sin(tm*8)*1.2*k;
   ctx.strokeStyle='rgba(0,0,0,.6)';ctx.lineWidth=4.5*k;ctx.beginPath();ctx.arc(ax,ay,r0,0,TAU);ctx.stroke();
   ctx.strokeStyle='#fff';ctx.lineWidth=2.2*k;ctx.beginPath();ctx.arc(ax,ay,r0,0,TAU);
   ctx.moveTo(ax-r0-6*k,ay);ctx.lineTo(ax-r0+3*k,ay);ctx.moveTo(ax+r0-3*k,ay);ctx.lineTo(ax+r0+6*k,ay);
   ctx.moveTo(ax,ay-r0-6*k);ctx.lineTo(ax,ay-r0+3*k);ctx.moveTo(ax,ay+r0-3*k);ctx.lineTo(ax,ay+r0+6*k);ctx.stroke();
   ctx.fillStyle=col;ctx.beginPath();ctx.arc(ax,ay,2.4*k,0,TAU);ctx.fill();
  }
  // barra de força (mesmo componente da barra do chute corrido; zona ideal 70–90%)
  {const w=Math.min(280*k,CW*.62),h=16*k,c=aiming?Math.min(1,pw):0;
   drawPowerBar(PBS.pen,CW/2,CH*.17,w,h,c,true,pn.charging?'FORÇA':(pn.phase==='aim'?'SEGURE X · SOLTE NA ZONA VERDE':'FORÇA'),'');}
  if(G.sp&&pn.phase==='aim'&&!pn.charging){ctx.font='700 '+(10*k).toFixed(1)+'px sans-serif';ctx.fillStyle='rgba(255,255,255,.75)';ctx.fillText((pn.kind==='free'?'ANALÓGICO DIREITO: EFEITO'+(pn.canPass?' · A/B: PASSAR':'')+(pn.train?' · L3: NOVA':''):'MIRE NO CANTO'),CW/2,CH*.17+16*k+22*k);}
 }
 // ---- dica do goleiro (quando o usuário defende)
 if(G.pen&&G.pen.kickTeam===1&&!G.pen.gkDecided&&(G.pen.phase==='runup'||G.pen.phase==='flight'||G.pen.phase==='ai_prep')){
  const y=CH*.17,txt='◀  ESCOLHA O LADO  ▶';
  ctx.globalAlpha=.6+.4*Math.sin(G.t*9);ctx.font='900 '+(22*k).toFixed(1)+'px sans-serif';ctx.lineWidth=5*k;ctx.strokeStyle='rgba(0,0,0,.7)';
  ctx.strokeText(txt,CW/2,y);ctx.fillStyle='#fff';ctx.fillText(txt,CW/2,y);ctx.globalAlpha=1;
 }
 // ---- mensagem de jogo
 if(G.t<G.msgUntil&&G.msg){
  const age=G.t-G.msgT0,pop=age<.3?1+Math.pow(1-age/.3,2)*.7:1; // entra grande e assenta
  const al=Math.min(1,(G.msgUntil-G.t)*2,age*6+.2),fy=CH*.34,fs=38*k;ctx.globalAlpha=al;
  ctx.save();ctx.translate(CW/2,fy);ctx.scale(pop,pop);ctx.translate(-CW/2,-fy);
  ctx.font='900 italic '+fs.toFixed(1)+'px sans-serif';ctx.lineJoin='round';
  ctx.lineWidth=8*k;ctx.strokeStyle='rgba(0,0,0,.75)';ctx.strokeText(G.msg,CW/2,fy+3*k);
  ctx.lineWidth=5*k;ctx.strokeStyle='#0d3d20';ctx.strokeText(G.msg,CW/2,fy);
  g=ctx.createLinearGradient(0,fy-fs*.8,0,fy+fs*.2);g.addColorStop(0,'#ffffff');g.addColorStop(1,'#a8ffcc');
  ctx.fillStyle=g;ctx.fillText(G.msg,CW/2,fy);ctx.restore();ctx.globalAlpha=1;
 }
 if(S.showFps){ctx.textAlign='left';ctx.fillStyle='#9f9';ctx.font=(14*QK)+'px monospace';ctx.fillText(fpsShow.toFixed(0)+' fps · '+CW+'x'+CH,(HUDM.ml+300*HUDM.k)*QK,CH-8*QK);}
}

/* ---------------- Quadro completo ---------------- */
function render(){
 ctx.fillStyle=sky;ctx.fillRect(0,0,CW,CH);
 const shk=G.shake>0?G.shake*G.shake*9*(CH/720):0; // tremor de câmera (gol / chute forte)
 C.cx=CW/2+(shk?(rnd()-.5)*2*shk:0);C.cy=CH*.5+(shk?(rnd()-.5)*2*shk:0);C.focal=(CH/2)/Math.tan(C.fov*PI/360)*S.camZ;
 // Estádio .glb: tudo (estádio, campo, gols, jogadores, bola, sombras) é desenhado pelo Three; o Canvas 2D fica só com HUD/tags/partículas por cima
 const glb=typeof GLBSys!=='undefined'&&T3&&T3.ready;
 if(glb)GLBSys.ensureStadium('arenahorizon');
 const stad=glb&&GLBSys.stadiumActive();
 if(cvTop)cvTop.style.display=stad?'block':'none';
 if(stad){
  const dt=Math.min(T3.clock.getDelta(),.05);
  GLBSys.stadiumMixer(dt);GLBSys.updateNets();GLBSys.updateFX();
  updateThreePlayers(dt);
  renderThree();
  ctx=ctxTop;ctx.clearRect(0,0,CW,CH);
  drawPT(false);
 }else{
 drawStands();drawPitch();drawBoards();drawGoals();drawLights();
 drawGround();drawPT(false);
 // Three.js: jogadores + bola (quando pronto). Sombra da bola continua no Canvas (drawGround).
 if(T3&&T3.ready){
  const dt=T3.clock.getDelta();
  updateThreePlayers(Math.min(dt,.05));
  renderThree(); // já chama updateThreeBall internamente
 }else{
  // fallback enquanto Three não carrega: tudo no Canvas antigo
  ENT.length=0;
  for(const p of G.players){if(p.out)continue;proj(p.x,0,p.z);p.dz=P.z;ENT.push(p);}
  const b=G.ball;proj(b.x,b.y,b.z);b.dz=P.z;ENT.push(b);
  ENT.sort(cmpZ);
  for(let i=0;i<ENT.length;i++){const e=ENT[i];if(e.isBall)drawBall();else drawPlayer(e);}
 }
 }
 drawPT(true);
 if(FX)ctx.drawImage(FX,0,0);
 if(G.flash>0){ctx.fillStyle='rgba(255,255,255,'+(G.flash*.32).toFixed(3)+')';ctx.fillRect(0,0,CW,CH);} // clarão do gol
 drawTags();
 drawOverlay();
 ctx=ctxBase;
}
