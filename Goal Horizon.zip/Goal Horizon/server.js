#!/usr/bin/env node
'use strict';
/* =====================================================================
   FC CARREIRA 3D — SERVIDOR LAN (server.js)
   • Serve o jogo (index.html, game.js, input.js, render.js, style.css) por HTTP.
   • Faz o "encontro" dos dois jogadores na MESMA rede Wi-Fi (salas + WebSocket).
   • NÃO usa internet e NÃO tem dependências: só o Node.js (versão 14 ou superior).

   Como usar:   node server.js            (porta padrão 3000)
                node server.js 8080       (outra porta)   ou   PORT=8080 node server.js

   O servidor apenas repassa mensagens entre o anfitrião e o visitante.
   Quem simula a partida é o aparelho do anfitrião (autoridade do jogo).
   ===================================================================== */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = +process.env.PORT || +process.argv[2] || 3000;
const ROOT = __dirname;
const MAX_PAYLOAD = 256 * 1024;      // limite de uma mensagem (o jogo usa ~2 KB)
const PING_MS = 10000;               // ping WebSocket para detectar aparelhos que sumiram (Wi-Fi caiu)
const DEAD_MS = 30000;               // sem resposta por este tempo = desconectado
const CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.webp': 'image/webp', '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg',
  '.wav': 'audio/wav', '.oga': 'audio/ogg', '.m4a': 'audio/mp4', '.aac': 'audio/aac', '.flac': 'audio/flac', '.webm': 'audio/webm', '.opus': 'audio/ogg', '.woff': 'font/woff', '.woff2': 'font/woff2', '.txt': 'text/plain; charset=utf-8',
  '.webmanifest': 'application/manifest+json', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json', '.bin': 'application/octet-stream'
};
const BLOCKED = new Set(['server.js', 'package.json', 'iniciar-servidor.bat', 'iniciar-servidor.sh']);

/* ---------------- Rede local ---------------- */
function lanIPs() {
  const out = [];
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const a of ifs[name] || []) {
      if ((a.family === 'IPv4' || a.family === 4) && !a.internal) out.push(a.address);
    }
  }
  // Wi-Fi doméstico costuma ser 192.168.x.x: mostra esses primeiro
  out.sort((a, b) => (b.startsWith('192.168.') ? 1 : 0) - (a.startsWith('192.168.') ? 1 : 0));
  return out;
}

/* ---------------- Salas ---------------- */
const rooms = new Map(); // code -> { code, name, host, guest, created }
let nextId = 1;

function newCode() {
  for (let n = 0; n < 200; n++) {
    let c = '';
    for (let i = 0; i < 4; i++) c += CODE_CHARS[crypto.randomInt(CODE_CHARS.length)];
    if (!rooms.has(c)) return c;
  }
  return null;
}
function roomList() {
  const out = [];
  for (const r of rooms.values()) out.push({ code: r.code, name: r.name, full: !!r.guest, age: Date.now() - r.created });
  return out;
}

/* ---------------- WebSocket mínimo (RFC 6455) ---------------- */
function frame(op, data) {
  const len = data.length;
  let head;
  if (len < 126) { head = Buffer.from([0x80 | op, len]); }
  else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
  else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
  return Buffer.concat([head, data]);
}
function wsSend(c, text) {
  if (!c || c.closed) return false;
  try { c.sock.write(frame(1, Buffer.from(text, 'utf8'))); return true; } catch (e) { return false; }
}
function wsClose(c, code) {
  if (!c || c.closed) return;
  try {
    const b = Buffer.alloc(2); b.writeUInt16BE(code || 1000, 0);
    c.sock.write(frame(8, b));
  } catch (e) { /* ignora */ }
  try { c.sock.end(); } catch (e) { /* ignora */ }
  setTimeout(() => { try { c.sock.destroy(); } catch (e) { /* ignora */ } }, 500);
  dropClient(c);
}

/* Remove o cliente das salas e avisa o parceiro */
function leaveRoom(c) {
  const r = c.room;
  if (!r) return;
  c.room = null;
  if (r.host === c) {
    rooms.delete(r.code);
    if (r.guest) { wsSend(r.guest, JSON.stringify({ s: 'closed' })); r.guest.room = null; r.guest.role = null; }
    log('sala ' + r.code + ' encerrada (anfitrião saiu)');
  } else if (r.guest === c) {
    r.guest = null;
    if (r.host) wsSend(r.host, JSON.stringify({ s: 'peer-left' }));
    log('sala ' + r.code + ': visitante saiu');
  }
}
function dropClient(c) {
  if (c.closed) return;
  c.closed = true;
  leaveRoom(c);
}

function handleControl(c, m) {
  switch (m.c) {
    case 'create': {
      leaveRoom(c);
      let code = typeof m.code === 'string' ? m.code.toUpperCase() : '';
      if (code) {
        // reconexão do anfitrião: reaproveita o código se ele estiver livre
        if (!/^[A-Z2-9]{4}$/.test(code)) return wsSend(c, JSON.stringify({ s: 'error', e: 'bad-code' }));
        const old = rooms.get(code);
        if (old) {
          if (old.host && !old.host.closed) return wsSend(c, JSON.stringify({ s: 'error', e: 'in-use' }));
          rooms.delete(code);
        }
      } else code = newCode();
      if (!code) return wsSend(c, JSON.stringify({ s: 'error', e: 'busy' }));
      const name = String(m.name || 'Anfitrião').replace(/[^\p{L}\p{N} _.\-]/gu, '').slice(0, 20) || 'Anfitrião';
      const r = { code, name, host: c, guest: null, created: Date.now() };
      rooms.set(code, r); c.room = r; c.role = 'host';
      wsSend(c, JSON.stringify({ s: 'created', code, ips: lanIPs(), port: PORT }));
      log('sala ' + code + ' criada por ' + c.ip);
      break;
    }
    case 'join': {
      leaveRoom(c);
      const code = String(m.code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      const r = rooms.get(code);
      if (!r || !r.host || r.host.closed) return wsSend(c, JSON.stringify({ s: 'error', e: 'no-room' }));
      if (r.guest && !r.guest.closed) return wsSend(c, JSON.stringify({ s: 'error', e: 'room-full' }));
      r.guest = c; c.room = r; c.role = 'guest';
      wsSend(c, JSON.stringify({ s: 'joined', code, name: r.name }));
      wsSend(r.host, JSON.stringify({ s: 'peer' }));
      log('sala ' + code + ': visitante ' + c.ip + ' entrou');
      break;
    }
    case 'list': wsSend(c, JSON.stringify({ s: 'rooms', rooms: roomList() })); break;
    case 'leave': leaveRoom(c); break;
    case 'ping': wsSend(c, JSON.stringify({ s: 'pong', ts: m.ts })); break;
    default: break;
  }
}

function handleText(c, text) {
  c.lastSeen = Date.now();
  if (text.startsWith('{"c":')) {                  // mensagem de controle para o servidor
    let m; try { m = JSON.parse(text); } catch (e) { return; }
    if (m && typeof m.c === 'string') handleControl(c, m);
    return;
  }
  // qualquer outra mensagem é do jogo: repassa ao parceiro sem alterar
  const r = c.room;
  if (!r) return;
  const other = r.host === c ? r.guest : r.host;
  if (other) wsSend(other, text);
}

function onData(c, chunk) {
  c.buf = c.buf.length ? Buffer.concat([c.buf, chunk]) : chunk;
  for (;;) {
    const b = c.buf;
    if (b.length < 2) return;
    const fin = (b[0] & 0x80) !== 0, op = b[0] & 0x0f, masked = (b[1] & 0x80) !== 0;
    let len = b[1] & 0x7f, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) {
      if (b.length < 10) return;
      if (b.readUInt32BE(2) !== 0) return wsClose(c, 1009);
      len = b.readUInt32BE(6); off = 10;
    }
    if (len > MAX_PAYLOAD) return wsClose(c, 1009);
    const need = off + (masked ? 4 : 0) + len;
    if (b.length < need) return;
    let payload = b.subarray(off + (masked ? 4 : 0), need);
    if (masked) {
      const mask = b.subarray(off, off + 4), out = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) out[i] = payload[i] ^ mask[i & 3];
      payload = out;
    }
    c.buf = b.subarray(need);
    if (op === 8) return wsClose(c, 1000);
    if (op === 9) { try { c.sock.write(frame(10, payload)); } catch (e) { /* ignora */ } continue; }
    if (op === 10) { c.lastSeen = Date.now(); continue; }
    if (op === 1 || op === 0) {                      // texto (ou continuação de mensagem fragmentada)
      if (op === 1) c.frag = [];
      if (!c.frag) continue;
      c.frag.push(payload);
      if ((c.fragLen = (c.fragLen || 0) + payload.length) > MAX_PAYLOAD) return wsClose(c, 1009);
      if (fin) {
        const text = Buffer.concat(c.frag).toString('utf8');
        c.frag = null; c.fragLen = 0;
        handleText(c, text);
      }
    }
    // frames binários são ignorados
  }
}

/* ---------------- HTTP (arquivos do jogo + API) ---------------- */
function json(res, obj) {
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*'
  });
  res.end(JSON.stringify(obj));
}
const server = http.createServer((req, res) => {
  let url;
  try { url = decodeURIComponent((req.url || '/').split('?')[0]); } catch (e) { res.writeHead(400); return res.end('Bad request'); }
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, OPTIONS' });
    return res.end();
  }
  if (url === '/api/info') return json(res, { game: 'fc3d', v: 3, port: PORT, ips: lanIPs(), rooms: rooms.size });
  if (url === '/api/rooms') return json(res, { rooms: roomList() });
  if (url === '/api/sons') { // lista os arquivos de áudio da pasta sons/ (o jogo carrega sozinho)
    return fs.readdir(path.join(ROOT, 'sons'), (err, names) => json(res, { files: err ? [] : names.filter(n => /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm|opus)$/i.test(n)).sort() }));
  }
  if (url === '/api/modelos') return json(res, require('./tools/modelos-scan.js')(ROOT)); // estádios e animações .glb
  if (url.endsWith('/')) url += 'index.html';
  const file = path.normalize(path.join(ROOT, url));
  const base = path.basename(file);
  if (!file.startsWith(ROOT + path.sep) || BLOCKED.has(base) || base.startsWith('.')) { res.writeHead(403); return res.end('Forbidden'); }
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Não encontrado'); }
    res.writeHead(200, {
      'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
      'Content-Length': st.size, 'Cache-Control': 'no-cache'
    });
    fs.createReadStream(file).pipe(res);
  });
});

server.on('upgrade', (req, sock) => {
  const url = (req.url || '').split('?')[0];
  const key = req.headers['sec-websocket-key'];
  if (url !== '/ws' || !key || (req.headers.upgrade || '').toLowerCase() !== 'websocket') { sock.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + GUID).digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  sock.setNoDelay(true);
  sock.setTimeout(0);
  const c = { id: nextId++, sock, buf: Buffer.alloc(0), room: null, role: null, closed: false, lastSeen: Date.now(),
              ip: (req.socket.remoteAddress || '').replace('::ffff:', ''), frag: null, fragLen: 0 };
  sock.on('data', d => { try { onData(c, d); } catch (e) { wsClose(c, 1011); } });
  sock.on('close', () => dropClient(c));
  sock.on('error', () => dropClient(c));
});

/* Detecta aparelhos que sumiram sem fechar a conexão */
setInterval(() => {
  const now = Date.now();
  for (const r of Array.from(rooms.values())) {
    for (const c of [r.host, r.guest]) {
      if (!c || c.closed) continue;
      if (now - c.lastSeen > DEAD_MS) { log('cliente ' + c.ip + ' sem resposta — removido'); wsClose(c, 1001); continue; }
      try { c.sock.write(frame(9, Buffer.alloc(0))); } catch (e) { /* ignora */ }
    }
  }
}, PING_MS).unref();

function log(t) { console.log('[' + new Date().toLocaleTimeString() + '] ' + t); }

server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error('\nA porta ' + PORT + ' já está em uso. Feche o outro servidor ou use:  node server.js ' + (PORT + 1) + '\n');
  else console.error(e);
  process.exit(1);
});
server.listen(PORT, '0.0.0.0', () => {
  const ips = lanIPs();
  console.log('\n  FC CARREIRA 3D — servidor LAN rodando (sem internet)\n');
  console.log('  Neste aparelho:   http://localhost:' + PORT);
  if (ips.length) {
    console.log('  Outros aparelhos na mesma Wi-Fi abrem um destes endereços:');
    for (const ip of ips) console.log('      http://' + ip + ':' + PORT);
  } else console.log('  (nenhuma rede detectada — conecte-se a uma Wi-Fi)');
  console.log('\n  Pare com Ctrl+C.\n');
});
process.on('SIGINT', () => process.exit(0));
