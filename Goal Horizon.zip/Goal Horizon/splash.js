/* GOAL HORIZON — controle da tela de inicialização.
   Roda uma única vez por carregamento da página (abrir/recarregar o jogo).
   Voltar de partida ao menu usa show('title') e NÃO recarrega a página, então a splash
   não volta: depois de encerrar, o elemento é removido do DOM.
   Animação completa sem interrupção: toque/tecla NÃO pulam a splash. */
(function(){
 'use strict';
 var el=document.getElementById('splash');
 if(!el)return;
 var done=false,t0=Date.now();
 var SHOW_MS=5300;   // logo completa + brilho + alguns instantes visível
 function finish(){
  if(done)return;done=true;
  var lg=el.querySelector('.sp-logo');if(lg)lg.classList.add('go');
  el.classList.add('out');                       // fade suave para o menu (já renderizado por baixo)
  var removed=false;
  function rm(){if(removed)return;removed=true;if(el.parentNode)el.parentNode.removeChild(el);el=null;}
  el.addEventListener('transitionend',function(e){if(e.target===el)rm();});
  setTimeout(rm,1100);                           // garantia
 }
 // pré-carrega as imagens para a animação não engasgar; segue mesmo se falhar
 var imgs=['bg.jpg','shield.png','line.png','text.png'],left=imgs.length,started=false;
 function start(){
  if(started)return;started=true;
  el.classList.add('run');t0=Date.now();
  setTimeout(finish,SHOW_MS);
 }
 imgs.forEach(function(n){var i=new Image();i.onload=i.onerror=function(){if(--left===0)start();};i.src='images/splash/'+n;});
 setTimeout(start,1500);                         // não espera para sempre
 // sem skip por toque/tecla: a animação roda até o fim
})();
