/* ============================================================
   GOAL HORIZON — SISTEMA DE ELENCOS (squads.js)
   Um elenco por clube, ligado ao ID do banco de clubes (clubs.js).
   Dados: players/<arquivo>.json  (um clube por arquivo)  +  players/index.json
   Importar/validar: node tools/importar-elencos.js
   Funciona no navegador (global FCS) e no Node (module.exports).
   ============================================================ */
(function(root){
'use strict';

/* ---- posições aceitas ---- */
const POS={GK:'Goleiro',CB:'Zagueiro',RB:'Lateral direito',LB:'Lateral esquerdo',DM:'Volante',CM:'Meio-campista',AM:'Meia ofensivo',RW:'Ponta direito',LW:'Ponta esquerdo',ST:'Atacante'};
const POS_LIST=Object.keys(POS);

/* ---- as 11 vagas do motor (mesma ordem de FORM em game.js: GK,LB,CB,CB,RB,LM,CM,CM,RM,ST,ST) ---- */
const SLOT_NAME=['Goleiro','Lateral esq.','Zagueiro','Zagueiro','Lateral dir.','Ponta esq.','Meio-campo','Meio-campo','Ponta dir.','Atacante','Atacante'];
const SLOT_POS=[['GK'],['LB'],['CB'],['CB'],['RB'],['LW'],['CM','DM','AM'],['CM','DM','AM'],['RW'],['ST'],['ST']];

const MIN_PLAYERS=11;      // mínimo para o elenco ser usado no jogo
const MAX_PLAYERS=40;      // limite de segurança por arquivo (só 11 jogam; não há banco/substituições)
const FOOT=['right','left','both'];
const STATS=['pace','acceleration','shooting','passing','dribbling','defending','physical'];

/* ---------------- validação ---------------- */
const isInt=v=>typeof v==='number'&&isFinite(v)&&Math.floor(v)===v;
const str=v=>typeof v==='string'&&v.trim().length>0;
const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,' ').trim();

/* Valida e normaliza UM jogador. Retorna {p, errors[]} */
function cleanPlayer(r,clubId,idx){
 const e=[],w='jogador #'+(idx+1)+(r&&r.displayName?' ('+r.displayName+')':'')+': ';
 if(!r||typeof r!=='object')return{p:null,errors:[w+'não é um objeto']};
 const p={id:String(r.id==null?'':r.id).trim(),fullName:str(r.fullName)?r.fullName.trim():'',displayName:str(r.displayName)?r.displayName.trim():'',
  number:r.number,age:r.age,nationality:str(r.nationality)?r.nationality.trim():'',position:r.position,secondaryPosition:r.secondaryPosition||null,
  overall:r.overall,potential:r.potential,pace:r.pace,acceleration:r.acceleration,shooting:r.shooting,passing:r.passing,dribbling:r.dribbling,defending:r.defending,physical:r.physical,
  height:r.height,foot:r.foot,clubId:clubId};
 if(!p.id)e.push(w+'falta "id"');else if(!/^[a-z0-9._-]{3,60}$/i.test(p.id))e.push(w+'"id" inválido (use letras, números, ponto, _ ou -; 3 a 60)');
 if(!p.fullName)e.push(w+'falta "fullName"');
 if(!p.displayName)e.push(w+'falta "displayName"');else if(p.displayName.length>24)e.push(w+'"displayName" passa de 24 caracteres');
 if(!isInt(p.number)||p.number<1||p.number>99)e.push(w+'"number" deve ser inteiro de 1 a 99');
 if(!isInt(p.age)||p.age<14||p.age>50)e.push(w+'"age" deve ser inteiro de 14 a 50');
 if(!p.nationality)e.push(w+'falta "nationality"');
 if(POS_LIST.indexOf(p.position)<0)e.push(w+'"position" inválida (use '+POS_LIST.join(', ')+')');
 if(p.secondaryPosition!==null&&POS_LIST.indexOf(p.secondaryPosition)<0)e.push(w+'"secondaryPosition" inválida');
 if(p.secondaryPosition&&p.secondaryPosition===p.position)e.push(w+'"secondaryPosition" igual à principal (use null)');
 ['overall','potential'].concat(STATS).forEach(k=>{if(!isInt(p[k])||p[k]<1||p[k]>99)e.push(w+'"'+k+'" deve ser inteiro de 1 a 99');});
 if(isInt(p.overall)&&isInt(p.potential)&&p.potential<p.overall)e.push(w+'"potential" menor que "overall"');
 if(!isInt(p.height)||p.height<140||p.height>220)e.push(w+'"height" deve ser inteiro em cm (140 a 220)');
 if(FOOT.indexOf(p.foot)<0)e.push(w+'"foot" deve ser right, left ou both');
 // aparência (opcional): usada pelo motor se existir
 if(r.skin!=null){if(/^#[0-9a-fA-F]{6}$/.test(r.skin))p.skin=r.skin.toLowerCase();else e.push(w+'"skin" deve ser #rrggbb');}
 if(r.hair!=null){if(/^#[0-9a-fA-F]{6}$/.test(r.hair))p.hair=r.hair.toLowerCase();else e.push(w+'"hair" deve ser #rrggbb');}
 return{p:e.length?null:p,errors:e};
}

/* Valida um arquivo de elenco inteiro.
   clubLookup(id) -> clube|null  ·  findByName(txt) -> clube|null (opcional)
   Retorna {ok, clubId, players[], errors[], warnings[]} */
function validateSquadFile(obj,fileName,clubLookup,findByName){
 const errors=[],warnings=[];let clubId=null;
 if(!obj||typeof obj!=='object'||Array.isArray(obj))return{ok:false,clubId:null,players:[],errors:['o arquivo precisa ser um objeto JSON com "clubId" e "players"'],warnings};
 // 1) clubId explícito  2) nome do arquivo = parte final do id (flamengo.json -> bra.flamengo)  3) nome do clube
 if(str(obj.clubId)&&clubLookup(obj.clubId))clubId=obj.clubId;
 else if(str(obj.clubId))errors.push('"clubId" "'+obj.clubId+'" não existe no banco de clubes (clubs.js)');
 if(!clubId&&!str(obj.clubId)&&findByName){
  const stem=String(fileName||'').replace(/\.json$/i,'').replace(/[\\/]/g,'/').split('/').pop();
  const c=findByName(stem)||(str(obj.clubName)?findByName(obj.clubName):null);
  if(c){clubId=c.id;warnings.push('"clubId" ausente: clube identificado como '+c.id+' pelo nome');}
  else errors.push('falta "clubId" e não foi possível identificar o clube pelo nome do arquivo');
 }
 if(!Array.isArray(obj.players))errors.push('"players" deve ser uma lista');
 const list=Array.isArray(obj.players)?obj.players:[],out=[];
 if(list.length>MAX_PLAYERS)errors.push('mais de '+MAX_PLAYERS+' jogadores no arquivo');
 const ids={},nums={},names={};
 list.slice(0,MAX_PLAYERS).forEach((r,i)=>{
  const c=cleanPlayer(r,clubId,i);
  c.errors.forEach(x=>errors.push(x));
  if(!c.p)return;
  const p=c.p;
  if(ids[p.id])errors.push('jogador duplicado (id repetido): '+p.id);
  else if(nums[p.number])errors.push('número de camisa '+p.number+' repetido ('+nums[p.number]+' e '+p.displayName+')');
  else if(names[norm(p.fullName)+'|'+p.age])errors.push('jogador duplicado (mesmo nome e idade): '+p.fullName);
  else{ids[p.id]=1;nums[p.number]=p.displayName;names[norm(p.fullName)+'|'+p.age]=1;out.push(p);}
 });
 if(!errors.length){
  if(out.length<MIN_PLAYERS)warnings.push('só '+out.length+' jogadores: o clube precisa de pelo menos '+MIN_PLAYERS+' para usar o elenco no jogo');
  else{
   const l=autoLineup(out);
   const miss=l.map((x,i)=>x?null:SLOT_NAME[i]).filter(Boolean);
   if(miss.length)warnings.push('sem jogador elegível para: '+miss.join(', ')+' (essas vagas usam jogador genérico)');
  }
 }
 return{ok:!errors.length,clubId,players:out,errors,warnings};
}

/* ---------------- escalação ---------------- */
function eligible(players,slot){ // jogadores que podem jogar na vaga (posição principal ou secundária)
 const ok=SLOT_POS[slot]||[];
 return players.filter(p=>ok.indexOf(p.position)>=0||(p.secondaryPosition&&ok.indexOf(p.secondaryPosition)>=0));
}
function fit(p,slot){ // posição principal vale mais que a secundária
 return(SLOT_POS[slot].indexOf(p.position)>=0?1000:0)+p.overall;
}
function fillEmpty(players,out){
 const used={};out.forEach(p=>{if(p)used[p.id]=1;});
 // vagas que ficaram sem candidato elegível (ex.: clube sem ponta): preenche com o melhor reserva livre da posição mais próxima,
 // em vez de deixar a vaga vazia (vaga vazia virava jogador genérico com visual sorteado). Goleiro só entra no gol.
 const NEAR={LW:['LB','AM','CM','ST','RW','DM','RB','CB'],RW:['RB','AM','CM','ST','LW','DM','LB','CB'],ST:['AM','LW','RW','CM','DM'],
  CB:['DM','LB','RB','CM'],LB:['CB','LW','DM','RB','CM'],RB:['CB','RW','DM','LB','CM'],CM:['DM','AM','LB','RB','LW','RW','CB','ST'],GK:[]};
 for(let s=0;s<11;s++){
  if(out[s])continue;
  const want=SLOT_POS[s][0],pref=NEAR[want]||[],pool=players.filter(p=>!used[p.id]&&(s===0?p.position==='GK':p.position!=='GK'));
  pool.sort((a,b)=>{const ra=pref.indexOf(a.position),rb=pref.indexOf(b.position);return((ra<0?99:ra)-(rb<0?99:rb))||(b.overall-a.overall);});
  if(!pool[0]&&s>0){const gks=players.filter(p=>!used[p.id]);if(gks.length)pool.push(gks.sort((x,y)=>y.overall-x.overall)[0]);} // último recurso (elenco com só 11 e 2 goleiros)
  if(pool[0]){out[s]=pool[0];used[pool[0].id]=1;}
 }
 return out;
}
function autoLineup(players){ // 11 vagas -> jogador|null, sem repetir ninguém
 const used={},out=new Array(11).fill(null);
 // vagas com menos candidatos primeiro (goleiro, pontas...) para ninguém ficar sem vaga à toa
 const order=[0,1,4,5,8,2,3,9,10,6,7];
 order.forEach(s=>{
  const c=eligible(players,s).filter(p=>!used[p.id]).sort((a,b)=>fit(b,s)-fit(a,s));
  if(c[0]){out[s]=c[0];used[c[0].id]=1;}
 });
 return fillEmpty(players,out);
}
/* valida uma escalação salva (lista de 11 ids). Retorna lista de 11 jogadores|null ou null se inválida */
function checkLineup(players,ids){
 if(!Array.isArray(ids)||ids.length!==11)return null;
 const by={},used={},out=[];players.forEach(p=>by[p.id]=p);
 for(let s=0;s<11;s++){
  const id=ids[s];
  if(id==null){out.push(null);continue;}
  const p=by[id];
  if(!p||used[id]||eligible(players,s).indexOf(p)<0)return null;
  used[id]=1;out.push(p);
 }
 return out;
}

/* ---------------- estado (navegador) ----------------
   FILE = elencos dos arquivos do projeto (players/*.json via index.json/bundle.js)
   IMP  = elencos importados dentro do jogo (localStorage) — têm prioridade sobre FILE para o mesmo clube */
const FILE={},IMP={};
const get=id=>IMP[id]||FILE[id]||null;
const LS_KEY='goalhorizon_lineups_v1',LS_SQ='goalhorizon_squads_v1';
const BACKUP_FORMAT='goalhorizon-elencos';
const MAX_FILE_BYTES=2*1024*1024;
let lineups={};         // clubId -> [11 ids]
let loaded=false,loadErrors=[];

function readLineups(){try{const o=JSON.parse(localStorage.getItem(LS_KEY)||'null');if(o&&typeof o==='object')lineups=o;}catch(e){}}
function saveLineups(){try{localStorage.setItem(LS_KEY,JSON.stringify(lineups));}catch(e){}}

const lookupClub=id=>(root.fcClub?root.fcClub(id):null);
const findClub=t=>{if(!root.fcSearch)return null;const r=root.fcSearch(t);return r.length===1?r[0]:null;};

/* ---- elencos importados: persistência (localStorage) ---- */
function readImported(){
 try{
  const o=JSON.parse(localStorage.getItem(LS_SQ)||'null');
  if(!o||!o.squads)return;
  for(const id in o.squads){
   const r=o.squads[id],v=validateSquadFile({clubId:id,players:r.p},id,lookupClub,null);
   if(v.ok&&v.clubId===id&&v.players.length>=MIN_PLAYERS)IMP[id]={players:v.players,fileName:r.f||'',importedAt:r.t||0};
   else loadErrors.push('elenco salvo de '+id+' está corrompido e foi ignorado');
  }
 }catch(e){loadErrors.push('não foi possível ler os elencos salvos');}
}
function writeImported(){ // retorna true/false (cota do navegador cheia etc.)
 const o={v:1,squads:{}};
 for(const id in IMP)o.squads[id]={f:IMP[id].fileName,t:IMP[id].importedAt,p:IMP[id].players.map(p=>{const q=Object.assign({},p);delete q.clubId;return q;})};
 try{localStorage.setItem(LS_SQ,JSON.stringify(o));return true;}catch(e){return false;}
}

function addSquad(obj,fileName){ // elenco vindo de arquivo do projeto
 const v=validateSquadFile(obj,fileName,lookupClub,findClub);
 if(!v.ok||!v.clubId||v.players.length<MIN_PLAYERS){if(!v.ok)loadErrors.push((fileName||'?')+': '+v.errors[0]);return false;}
 if(FILE[v.clubId]){loadErrors.push((fileName||'?')+': clube '+v.clubId+' já carregado por outro arquivo');return false;}
 FILE[v.clubId]={players:v.players,fileName:fileName||''};return true;
}

/* Carrega elencos: 1) importados no jogo (localStorage, síncrono)  2) players/bundle.js  3) players/index.json via http */
function load(){
 readLineups();readImported();
 if(root.FC_PLAYERS_BUNDLE&&Array.isArray(root.FC_PLAYERS_BUNDLE.squads)&&root.FC_PLAYERS_BUNDLE.squads.length){
  root.FC_PLAYERS_BUNDLE.squads.forEach(s=>addSquad(s,s&&s.clubId));
  loaded=true;return Promise.resolve(info());
 }
 try{
  if(typeof fetch!=='function'||(root.location&&root.location.protocol==='file:')){loaded=true;return Promise.resolve(info());}
  return fetch('players/index.json',{cache:'no-cache'}).then(r=>r.ok?r.json():null).then(ix=>{
   if(!ix||!Array.isArray(ix.files))return;
   return Promise.all(ix.files.map(f=>fetch('players/'+f,{cache:'no-cache'}).then(r=>r.ok?r.json():null).then(o=>{if(o)addSquad(o,f);}).catch(()=>{})));
  }).catch(()=>{}).then(()=>{loaded=true;return info();});
 }catch(e){loaded=true;return Promise.resolve(info());}
}

/* ---------------- importação dentro do jogo ---------------- */
/* Analisa o conteúdo de UM arquivo (texto JSON) sem gravar nada.
   Retorna {fileName, kind:'invalid'|'squad'|'backup', error?, items:[{clubId,players,errors,warnings,ok,replaces}], lineups?} */
function preview(text,fileName,batch){
 const out={fileName:fileName||'',kind:'invalid',items:[],error:null,lineups:null};
 if(typeof text!=='string'||!text.trim()){out.error='arquivo vazio';return out;}
 if(text.length>MAX_FILE_BYTES){out.error='arquivo grande demais (máx. 2 MB)';return out;}
 let obj;try{obj=JSON.parse(text.replace(/^\uFEFF/,''));}catch(e){out.error='JSON inválido: '+String(e.message||e).slice(0,120);return out;}
 if(!obj||typeof obj!=='object'||Array.isArray(obj)){out.error='o arquivo precisa ser um objeto JSON com "clubId" e "players"';return out;}
 let list;
 if(Array.isArray(obj.squads)){out.kind='backup';list=obj.squads;if(obj.lineups&&typeof obj.lineups==='object')out.lineups=obj.lineups;}
 else{out.kind='squad';list=[obj];}
 if(!list.length){out.kind='invalid';out.error='nenhum elenco dentro do arquivo';return out;}
 if(list.length>400){out.kind='invalid';out.error='elencos demais no arquivo';return out;}
 const seen=batch||{ids:{},clubs:{},persons:{}}; // controle entre arquivos selecionados juntos
 list.forEach((sq,i)=>{
  const v=validateSquadFile(sq,fileName,lookupClub,findClub);
  const it={clubId:v.clubId,players:v.players,errors:v.errors.slice(),warnings:v.warnings.slice(),ok:false,replaces:null};
  if(!it.clubId&&!it.errors.length)it.errors.push('clube não identificado');
  if(it.clubId&&!it.errors.length){
   if(v.players.length<MIN_PLAYERS)it.errors.push('elenco com menos de '+MIN_PLAYERS+' jogadores ('+v.players.length+')');
   if(seen.clubs[it.clubId])it.errors.push('este clube já aparece em outro arquivo selecionado ('+seen.clubs[it.clubId]+')');
   const mine=get(it.clubId);if(mine)it.replaces=IMP[it.clubId]?'importado':'do projeto';
   v.players.forEach(p=>{
    const own=idOwner(p.id,it.clubId,seen);
    if(own)it.errors.push('id "'+p.id+'" já é usado pelo clube '+own);
    const po=personOwner(p,it.clubId,seen);
    if(po)it.warnings.push(p.fullName+' também está no clube '+po+' (mesmo jogador em dois clubes?)');
   });
  }
  it.ok=!it.errors.length;
  if(it.ok){seen.clubs[it.clubId]=fileName||'arquivo';v.players.forEach(p=>{seen.ids[p.id]=it.clubId;seen.persons[norm(p.fullName)+'|'+norm(p.nationality)]=it.clubId;});}
  out.items.push(it);
 });
 return out;
}
function idOwner(id,clubId,seen){
 if(seen.ids[id]&&seen.ids[id]!==clubId)return seen.ids[id];
 for(const c in IMP)if(c!==clubId&&IMP[c].players.some(p=>p.id===id))return c;
 for(const c in FILE)if(c!==clubId&&!IMP[c]&&FILE[c].players.some(p=>p.id===id))return c;
 return null;
}
function personOwner(p,clubId,seen){
 const k=norm(p.fullName)+'|'+norm(p.nationality);
 if(seen.persons[k]&&seen.persons[k]!==clubId)return seen.persons[k];
 const all=[IMP,FILE];
 for(const M of all)for(const c in M){if(c===clubId||(M===FILE&&IMP[c]))continue;if(M[c].players.some(q=>norm(q.fullName)+'|'+norm(q.nationality)===k))return c;}
 return null;
}
/* Grava os itens válidos das análises. Retorna {saved:[clubIds], failed:[{clubId,reason}], storageFull?} */
function importItems(previews){
 const saved=[],failed=[];
 const prevIMP=Object.assign({},IMP);
 previews.forEach(pv=>pv.items.forEach(it=>{
  if(!it.ok){failed.push({clubId:it.clubId,reason:it.errors[0]||'inválido'});return;}
  IMP[it.clubId]={players:it.players,fileName:pv.fileName,importedAt:Date.now()};
  saved.push(it.clubId);
 }));
 if(saved.length&&!writeImported()){ // cota cheia: desfaz tudo e não deixa dado pela metade
  for(const k in IMP)delete IMP[k];Object.assign(IMP,prevIMP);
  return{saved:[],failed:failed.concat(saved.map(c=>({clubId:c,reason:'sem espaço no armazenamento do navegador'}))),storageFull:true};
 }
 previews.forEach(pv=>{if(pv.lineups)saved.forEach(c=>{const l=pv.lineups[c];if(l&&checkLineup(IMP[c].players,l))lineups[c]=l.slice();});});
 if(saved.length){saveLineups();try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist();}catch(e){}}
 return{saved,failed,storageFull:false};
}
function removeImported(clubId){ // volta ao elenco do projeto (se houver) ou a jogadores genéricos
 if(!IMP[clubId])return false;
 const old=IMP[clubId];delete IMP[clubId];
 if(!writeImported()){IMP[clubId]=old;return false;}
 return true;
}
function importedList(){return Object.keys(IMP).map(id=>({clubId:id,count:IMP[id].players.length,fileName:IMP[id].fileName,importedAt:IMP[id].importedAt}));}
/* Cópia de segurança: JSON com todos os elencos importados (ou só um clube) + escalações */
function exportBackup(clubId){
 const ids=clubId?[clubId]:Object.keys(IMP);
 const sq=ids.filter(id=>IMP[id]).map(id=>({clubId:id,players:IMP[id].players.map(p=>{const q=Object.assign({},p);delete q.clubId;return q;})}));
 if(clubId&&sq.length===1)return{clubId:sq[0].clubId,players:sq[0].players}; // mesmo formato do arquivo de clube (aceito também pelo importador Node)
 const ln={};ids.forEach(id=>{if(lineups[id]&&checkLineup(IMP[id]?IMP[id].players:[],lineups[id]))ln[id]=lineups[id];});
 return{format:BACKUP_FORMAT,version:1,exportedAt:new Date().toISOString(),squads:sq,lineups:ln};
}

function has(clubId){return !!get(clubId);}
function squad(clubId){const s=get(clubId);return s?s.players.slice():null;}
function player(clubId,id){const s=get(clubId);return s?(s.players.find(p=>p.id===id)||null):null;}

/* 11 titulares do clube (por vaga) — escalação salva se válida, senão automática. null se o clube não tem elenco. */
function lineupRaw(clubId){ // escalação sem o preenchimento de vagas vazias (usada para validar/editar)
 const s=get(clubId);if(!s)return null;
 return checkLineup(s.players,lineups[clubId])||autoLineup(s.players);
}
function lineup(clubId){
 const s=get(clubId);if(!s)return null;
 return fillEmpty(s.players,(checkLineup(s.players,lineups[clubId])||autoLineup(s.players)).slice());
}
function isCustom(clubId){const s=get(clubId);return !!(s&&checkLineup(s.players,lineups[clubId]));}
/* troca o titular de uma vaga. Se o jogador já está em outra vaga, os dois trocam de lugar (nunca duplica). */
function setSlot(clubId,slot,playerId){
 const s=get(clubId);if(!s||slot<0||slot>10)return false;
 const cur=lineupRaw(clubId).map(p=>p?p.id:null);
 const p=playerId==null?null:s.players.find(x=>x.id===playerId);
 if(playerId!=null&&(!p||eligible(s.players,slot).indexOf(p)<0))return false;
 const old=cur[slot],at=playerId==null?-1:cur.indexOf(playerId);
 if(at>=0&&at!==slot){ // o outro precisa aceitar o jogador que sai
  const o=old?s.players.find(x=>x.id===old):null;
  if(o&&eligible(s.players,at).indexOf(o)<0)cur[at]=null;else cur[at]=old;
 }
 cur[slot]=playerId;
 if(!checkLineup(s.players,cur))return false;
 lineups[clubId]=cur;saveLineups();return true;
}
function resetLineup(clubId){delete lineups[clubId];saveLineups();}

/* Dados da vaga para o motor: {name,num,skin?,hair?,id} ou null (clube sem elenco / vaga sem jogador) */
function slotData(clubId,slot){
 const l=lineup(clubId);if(!l||!l[slot])return null;
 const p=l[slot];
 return{id:p.id,name:p.displayName,num:p.number,skin:p.skin,hair:p.hair};
}
/* nomes reais para artilheiros simulados (atacantes/meias primeiro). null se o clube não tem elenco. */
function scorerPool(clubId){
 const s=get(clubId);if(!s)return null;
 const w={ST:6,LW:4,RW:4,AM:4,CM:2,DM:1,LB:1,RB:1,CB:1,GK:0};
 const l=s.players.filter(p=>w[p.position]>0).sort((a,b)=>(w[b.position]*100+b.overall)-(w[a.position]*100+a.overall)).slice(0,6);
 return l.length?l.map(p=>p.displayName):null;
}
function info(){const ids={};Object.keys(FILE).concat(Object.keys(IMP)).forEach(i=>ids[i]=1);let n=0;for(const i in ids)n+=get(i).players.length;return{loaded,clubs:Object.keys(ids).length,players:n,imported:Object.keys(IMP).length,errors:loadErrors.slice()};}
function source(clubId){return IMP[clubId]?'import':FILE[clubId]?'file':null;}

const API={POS,POS_LIST,SLOT_NAME,SLOT_POS,MIN_PLAYERS,MAX_PLAYERS,STATS,FOOT,norm,
 validateSquadFile,cleanPlayer,eligible,autoLineup,checkLineup,
 load,has,squad,player,lineup,isCustom,setSlot,resetLineup,slotData,scorerPool,info,source,
 preview,importItems,removeImported,importedList,exportBackup,MAX_FILE_BYTES};
if(typeof module!=='undefined'&&module.exports)module.exports=API;
else root.FCS=API;
})(typeof window!=='undefined'?window:globalThis);
