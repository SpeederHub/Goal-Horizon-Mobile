// node tools/atualizar-manifest.js  -> atualiza crests/manifest.json conforme os arquivos presentes
const fs=require('fs'),p=require('path');const f=p.join(__dirname,'..','crests','manifest.json');
const m=JSON.parse(fs.readFileSync(f,'utf8'));let n=0;
for(const id in m.clubs){const c=m.clubs[id];const png=p.join(__dirname,'..',c.file),svg=png.replace(/\.png$/,'.svg');
 const has=fs.existsSync(png)||fs.existsSync(svg);
 if(fs.existsSync(svg)&&!fs.existsSync(png))c.file=c.file.replace(/\.png$/,'.svg');
 if(has&&c.status==='provisional'){c.status='official';}
 if(!has)c.status='provisional'; if(has)n++;}
fs.writeFileSync(f,JSON.stringify(m,null,1));console.log(n+' escudos encontrados; '+(Object.keys(m.clubs).length-n)+' provisorios.');
