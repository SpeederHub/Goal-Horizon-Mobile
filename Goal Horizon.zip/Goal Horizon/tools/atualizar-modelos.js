// node tools/atualizar-modelos.js  -> gera models/manifest.json (use quando o jogo roda SEM o server.js, ex.: SPCK Editor)
const fs=require('fs'),p=require('path'),root=p.join(__dirname,'..');
const m=require('./modelos-scan.js')(root);
fs.writeFileSync(p.join(root,'models','manifest.json'),JSON.stringify(m,null,1));
console.log(m.stadiums.length+' estádio(s), '+m.animations.length+' arquivo(s) de animação -> models/manifest.json');
