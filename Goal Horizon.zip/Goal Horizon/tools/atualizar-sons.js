// node tools/atualizar-sons.js  -> cria/atualiza sons/manifest.json (use se hospedar o jogo SEM o server.js)
const fs = require('fs'), p = require('path');
const dir = p.join(__dirname, '..', 'sons');
if (!fs.existsSync(dir)) fs.mkdirSync(dir);
const files = fs.readdirSync(dir).filter(n => /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm|opus)$/i.test(n)).sort();
fs.writeFileSync(p.join(dir, 'manifest.json'), JSON.stringify({ files }, null, 1));
console.log(files.length + ' arquivo(s) de áudio registrados em sons/manifest.json');
