// Gera "Arena Horizon" (GLB) compativel com Goal Horizon. Sem dependencias.
// node estadio.js <saida.glb>
const fs = require('fs');
const HL = 52.5, HW = 34;           // meio campo (x = comprimento, z = largura), topo do gramado em y=0

// ---------- util ----------
let seed = 12345; const rnd = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
const G = {};   // material -> {pos,nor,col,idx}
const MAT = {};
function mat(name, rgb, o = {}) { MAT[name] = { rgb, ...o }; G[name] = { pos: [], nor: [], col: [], idx: [] }; }
mat('Pitch_Base', [.16, .5, .2], { rough: 1 });
mat('Apron_Track', [.12, .36, .15], { rough: 1 });
mat('Apron_Stripe', [.15, .42, .18], { rough: 1 });
mat('Plaza_Ground', [.42, .42, .44], { rough: .95 });
mat('Seats_Crowd', [1, 1, 1], { rough: .9, vc: true });
mat('Seats_Lower', [1, 1, 1], { rough: .9, vc: true });
mat('Concrete', [.6, .6, .63], { rough: .9 });
mat('Concrete_Dark', [.32, .33, .36], { rough: .9 });
mat('Facade', [.82, .84, .88], { rough: .7 });
mat('Roof_Panel', [.88, .9, .93], { rough: .6 });
mat('Roof_Under', [.35, .37, .42], { rough: .9 });
mat('Steel', [.5, .52, .56], { rough: .5, metal: .5 });
mat('Boards_Red', [.85, .1, .12], { rough: .6, emis: [.25, .02, .02] });
mat('Boards_Blue', [.1, .3, .85], { rough: .6, emis: [.02, .08, .3] });
mat('Boards_White', [.93, .93, .95], { rough: .6, emis: [.2, .2, .2] });
mat('Dugout_Glass', [.55, .8, .9], { rough: .1, alpha: .35 });
mat('Tunnel_Dark', [.05, .05, .07], { rough: 1 });
mat('Light_Lamp', [1, 1, .9], { rough: .4, emis: [1, 1, .85] });
mat('LED_Strip', [.9, .95, 1], { rough: .4, emis: [.6, .8, 1] });
mat('Banner_Blue', [.1, .25, .7], { rough: .8 });
mat('Banner_Gold', [.95, .75, .15], { rough: .8 });

function quad(m, a, b, c, d, n, col) {
  const g = G[m], base = g.pos.length / 3;
  for (const v of [a, b, c, d]) { g.pos.push(...v); g.nor.push(...n); const cc = col || [1, 1, 1]; g.col.push(cc[0], cc[1], cc[2], 1); }
  g.idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
}
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const crossv = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const normz = v => { const l = Math.hypot(...v) || 1; return [v[0] / l, v[1] / l, v[2] / l]; };
function quadAuto(m, a, b, c, d, col) { quad(m, a, b, c, d, normz(crossv(sub(b, a), sub(c, a))), col); }
function box(m, cx, cy, cz, sx, sy, sz, col) {
  const x0 = cx - sx / 2, x1 = cx + sx / 2, y0 = cy - sy / 2, y1 = cy + sy / 2, z0 = cz - sz / 2, z1 = cz + sz / 2;
  quad(m, [x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0], col);
  quad(m, [x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0], col);
  quad(m, [x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], [0, 1, 0], col);
  quad(m, [x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [0, -1, 0], col);
  quad(m, [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1], col);
  quad(m, [x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [0, 0, -1], col);
}
// caixa rotacionada em Y
function boxR(m, cx, cy, cz, sx, sy, sz, ry, col) {
  const c = Math.cos(ry), s = Math.sin(ry);
  const P = (x, y, z) => [cx + x * c + z * s, cy + y, cz - x * s + z * c];
  const h = [sx / 2, sy / 2, sz / 2];
  const V = (a, b, cc) => P(a * h[0], b * h[1], cc * h[2]);
  quadAuto(m, V(1, -1, 1), V(1, -1, -1), V(1, 1, -1), V(1, 1, 1), col);
  quadAuto(m, V(-1, -1, -1), V(-1, -1, 1), V(-1, 1, 1), V(-1, 1, -1), col);
  quadAuto(m, V(-1, 1, 1), V(1, 1, 1), V(1, 1, -1), V(-1, 1, -1), col);
  quadAuto(m, V(-1, -1, -1), V(1, -1, -1), V(1, -1, 1), V(-1, -1, 1), col);
  quadAuto(m, V(-1, -1, 1), V(1, -1, 1), V(1, 1, 1), V(-1, 1, 1), col);
  quadAuto(m, V(1, -1, -1), V(-1, -1, -1), V(-1, 1, -1), V(1, 1, -1), col);
}

// ---------- anel (retangulo arredondado) ----------
// meio-eixos A (x), B (z), raio de canto R; devolve pontos em sentido anti-horario com normal externa
function ring(A, B, R, step) {
  R = Math.min(R, A - .1, B - .1);
  const pts = [];
  const corners = [[A - R, B - R, 0], [-(A - R), B - R, Math.PI / 2], [-(A - R), -(B - R), Math.PI], [A - R, -(B - R), 1.5 * Math.PI]];
  const nArc = 12; const NXS = 84, NZS = 56;  // contagem fixa: todos os aneis tem a mesma topologia
  // percorre: lado +x (z de -..+), canto, lado +z ...
  const segs = [];
  // usamos parametrizacao por arco
  const straightX = 2 * (B - R), straightZ = 2 * (A - R);
  // construcao direta: para cada canto, arco de 90 graus; entre cantos, linhas retas
  for (let ci = 0; ci < 4; ci++) {
    const [cx, cz, a0] = corners[ci];
    // canto
    for (let k = 0; k <= nArc; k++) {
      const a = a0 + (k / nArc) * Math.PI / 2;
      pts.push({ x: cx + R * Math.cos(a), z: cz + R * Math.sin(a), nx: Math.cos(a), nz: Math.sin(a) });
    }
    // reta ate o proximo canto
    const nxt = corners[(ci + 1) % 4], aN = a0 + Math.PI / 2;
    const p0 = { x: cx + R * Math.cos(aN), z: cz + R * Math.sin(aN) };
    const p1 = { x: nxt[0] + R * Math.cos(aN), z: nxt[1] + R * Math.sin(aN) };
    const L = Math.hypot(p1.x - p0.x, p1.z - p0.z), n = (ci % 2 === 0) ? NXS : NZS;
    for (let k = 1; k < n; k++) pts.push({ x: p0.x + (p1.x - p0.x) * k / n, z: p0.z + (p1.z - p0.z) * k / n, nx: Math.cos(aN), nz: Math.sin(aN) });
  }
  return pts;
}
// ponto do anel deslocado d metros para fora (mantem a forma de retangulo arredondado "offset")
const ringAt = (A, B, R, d, step) => ring(A + d, B + d, R + d, step);

// ---------- cores da torcida ----------
const CROWD = [[.85, .1, .12], [.1, .3, .85], [.95, .95, .97], [.95, .8, .15], [.15, .15, .2], [.9, .4, .1], [.2, .65, .3], [.75, .75, .8]];
function crowdCol(i, j, theme) {
  const r = rnd();
  if (r < .42) return theme[0]; if (r < .66) return theme[1];
  if (r < .75) return [.95, .95, .97];
  if (r < .83) return [.12, .12, .16];
  return CROWD[Math.floor(rnd() * CROWD.length)].map(v => v * (.85 + rnd() * .2));
}
const shade = (c, k) => [c[0] * k, c[1] * k, c[2] * k];

// ---------- campo base / entorno ----------
// "Pitch" fino (a escala 105x68 e a deteccao dependem dele). O jogo desenha gramado/linhas/gols proprios por cima.
box('Pitch_Base', 0, -.05, 0, 2 * HL, .1, 2 * HW);
// area de escape em torno do gramado (ligeiramente abaixo de y=0 para nao brigar com o plano do jogo)
const AX = HL + 10, AZ = HW + 8;      // limite interno das placas de publicidade/arquibancada
box('Apron_Track', 0, -.09, 0, 2 * AX + 4, .1, 2 * AZ + 4);
// listras de corte do gramado no entorno (leves)
for (let i = -2; i <= 2; i++) if (i % 2 === 0) box('Apron_Stripe', 0, -.04, i * 14, 2 * AX + 3.8, .02, 7);

// ---------- placas de publicidade (LED) ----------
const BX = HL + 7, BZ = HW + 4.5;
(function boards() {
  const cols = ['Boards_Red', 'Boards_Blue', 'Boards_White'];
  // lados longos
  let k = 0;
  for (const s of [-1, 1]) for (let x = -BX + 3; x < BX - 2; x += 6, k++) {
    box(cols[k % 3], x, .5, s * BZ, 5.8, 1, .22);
    box('Concrete_Dark', x, .04, s * (BZ + .12), 5.8, .08, .1);
  }
  for (const s of [-1, 1]) for (let z = -BZ + 3; z < BZ - 2; z += 6, k++) {
    // atras dos gols: afastado para a rede (profundidade 2.2m + folga)
    box(cols[(k + 1) % 3], s * BX, .5, z, .22, 1, 5.8);
  }
})();

// ---------- arquibancada ----------
const STEP = 1.2;                       // resolucao ao longo do perimetro
const ROW_D = .82, ROW_H = .42;          // profundidade e altura de cada fileira
const ringR = 16;                        // raio de canto
function bowl() {
  const A0 = BX + 2.5, B0 = BZ + 2.5;    // anel inicial
  // cantos: no bowl real laterais sao mais profundos que fundos
  const tierRows = [14, 18];             // inferior / superior
  const gapAisle = 2.4, aisleH = .9;
  let d = 0, y = 0.3;
  // base de concreto/muro frontal
  const base = ringAt(A0, B0, ringR, 0, STEP);
  const wallH = 1.3;
  for (let i = 0; i < base.length; i++) {
    const a = base[i], b = base[(i + 1) % base.length];
    quadAuto('Concrete_Dark', [a.x, 0, a.z], [b.x, 0, b.z], [b.x, wallH, b.z], [a.x, wallH, a.z]);
  }
  y = wallH; d = 0;
  const theme = [[.85, .1, .12], [.95, .95, .97]];
  const theme2 = [[.1, .3, .85], [.95, .95, .97]];
  const info = { topLowerY: 0, topUpperY: 0, outerD: 0, upperStartD: 0 };
  for (let t = 0; t < 2; t++) {
    const rows = tierRows[t];
    const matName = t ? 'Seats_Crowd' : 'Seats_Lower';
    const th = t ? theme2 : theme;
    if (t === 1) {
      // corredor / mezanino entre andares
      const r0 = ringAt(A0, B0, ringR, d, STEP);
      const hh = 6.0;   // faixa vertical de concreto (camarotes) entre os andares
      const r1 = ringAt(A0, B0, ringR, d + gapAisle, STEP);
      for (let i = 0; i < r0.length; i++) {
        const a = r0[i], b = r0[(i + 1) % r0.length], c = r1[(i + 1) % r1.length], e = r1[i];
        quadAuto('Concrete', [a.x, y, a.z], [b.x, y, b.z], [c.x, y, c.z], [e.x, y, e.z]);
      }
      d += gapAisle;
      // camarotes: faixa fechada de vidro/painel
      const top = y + hh;
      const rb = ringAt(A0, B0, ringR, d, STEP);
      for (let i = 0; i < rb.length; i++) {
        const a = rb[i], b = rb[(i + 1) % rb.length];
        const glass = (i % 3 !== 2);
        quadAuto(glass ? 'Dugout_Glass' : 'Concrete_Dark', [a.x, y, a.z], [b.x, y, b.z], [b.x, top, b.z], [a.x, top, a.z]);
      }
      // laje do teto dos camarotes
      const rbo = ringAt(A0, B0, ringR, d + 2.0, STEP);
      for (let i = 0; i < rb.length; i++) {
        const a = rb[i], b = rb[(i + 1) % rb.length], c = rbo[(i + 1) % rbo.length], e = rbo[i];
        quadAuto('Concrete', [a.x, top, a.z], [b.x, top, b.z], [c.x, top, c.z], [e.x, top, e.z]);
      }
      d += 2.0; y = top; info.upperStartD = d;
    }
    for (let r = 0; r < rows; r++) {
      const dd = d + r * ROW_D;
      const yy = y + (r + 1) * (ROW_H + (t ? .08 : 0));
      const rin = ringAt(A0, B0, ringR, dd, STEP), rout = ringAt(A0, B0, ringR, dd + ROW_D, STEP);
      const yprev = y + r * (ROW_H + (t ? .08 : 0));
      for (let i = 0; i < rin.length; i++) {
        const a = rin[i], b = rin[(i + 1) % rin.length], c = rout[(i + 1) % rout.length], e = rout[i];
        // piso do degrau (com torcida colorida) e espelho
        const cc = crowdCol(i, r, th), sh = .78 + .22 * (r % 2);
        quadAuto(matName, [a.x, yy, a.z], [b.x, yy, b.z], [c.x, yy, c.z], [e.x, yy, e.z], shade(cc, sh));
        quadAuto(matName, [a.x, yprev, a.z], [b.x, yprev, b.z], [b.x, yy, b.z], [a.x, yy, a.z], shade(cc, .55));
      }
    }
    const dEnd = d + rows * ROW_D, yEnd = y + rows * (ROW_H + (t ? .08 : 0));
    // muro de fundo do andar
    const rr = ringAt(A0, B0, ringR, dEnd, STEP);
    const wH = t ? 1.2 : 0.6;
    for (let i = 0; i < rr.length; i++) {
      const a = rr[i], b = rr[(i + 1) % rr.length];
      quadAuto('Concrete', [a.x, yEnd - 1.5 + (t ? 0 : 0), a.z], [b.x, yEnd - 1.5, b.z], [b.x, yEnd + wH, b.z], [a.x, yEnd + wH, a.z]);
    }
    if (t === 0) { info.topLowerY = yEnd; d = dEnd; y = yEnd; }
    else { info.topUpperY = yEnd; info.outerD = dEnd; d = dEnd; y = yEnd; }
  }
  info.A0 = A0; info.B0 = B0;
  return info;
}
const bw = bowl();

// ---------- fachada externa ----------
(function facade() {
  const A0 = bw.A0, B0 = bw.B0, d = bw.outerD + .6;
  const topY = bw.topUpperY + 3.2;
  const r = ringAt(A0, B0, ringR, d, STEP);
  for (let i = 0; i < r.length; i++) {
    const a = r[i], b = r[(i + 1) % r.length];
    quadAuto('Facade', [a.x, 0, a.z], [b.x, 0, b.z], [b.x, topY, b.z], [a.x, topY, a.z]);
    // pilares verticais a cada 6 m
    if (i % 6 === 0) {
      const ang = Math.atan2(a.nx, a.nz);
      boxR('Concrete_Dark', a.x + a.nx * .35, topY / 2, a.z + a.nz * .35, .9, topY, .9, ang);
    }
  }
  // faixa de janelas escuras
  const rw = ringAt(A0, B0, ringR, d + .05, STEP);
  for (let i = 0; i < rw.length; i++) {
    if (i % 2) continue;
    const a = rw[i], b = rw[(i + 1) % rw.length];
    quadAuto('Dugout_Glass', [a.x, 4, a.z], [b.x, 4, b.z], [b.x, 9, b.z], [a.x, 9, a.z]);
  }
  // topo da fachada fecha com o teto
  bw.facadeD = d; bw.facadeTop = topY;
})();

// ---------- cobertura ----------
(function roof() {
  const A0 = bw.A0, B0 = bw.B0;
  const dIn = bw.upperStartD + 10.5;         // borda interna (sobre o campo)
  const dOut = bw.facadeD + 1.2;
  const yIn = bw.topUpperY + 4.2, yOut = bw.facadeTop + 2.2;
  const rin = ringAt(A0, B0, ringR, dIn, STEP), rout = ringAt(A0, B0, ringR, dOut, STEP);
  // note: rin e rout tem o mesmo no de pontos? (mesma topologia, steps diferem) -> reamostra por indice normalizado
  const N = Math.min(rin.length, rout.length);
  const at = (arr, i) => arr[Math.round(i * arr.length / N) % arr.length];
  const th = .5;
  for (let i = 0; i < N; i++) {
    const a = at(rin, i), b = at(rin, i + 1), c = at(rout, i + 1), e = at(rout, i);
    const A = [a.x, yIn, a.z], B = [b.x, yIn, b.z], C = [c.x, yOut, c.z], E = [e.x, yOut, e.z];
    quadAuto('Roof_Panel', E, C, B, A);                         // face de cima
    quadAuto('Roof_Under', [a.x, yIn - th, a.z], [b.x, yIn - th, b.z], [c.x, yOut - th, c.z], [e.x, yOut - th, e.z]); // baixo
    // borda interna espessa + LED
    quadAuto('LED_Strip', [a.x, yIn - th, a.z], [b.x, yIn - th, b.z], [b.x, yIn + .05, b.z], [a.x, yIn + .05, a.z]);
    // vigas radiais
    if (i % 8 === 0) {
      const mid = (p, q, t) => [p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t, p[2] + (q[2] - p[2]) * t];
      const ang = Math.atan2(a.nx, a.nz);
      const mp = mid([a.x, yIn - th - .5, a.z], [e.x, yOut - th - .5, e.z], .5);
      const len = Math.hypot(e.x - a.x, e.z - a.z);
      boxR('Steel', mp[0], mp[1], mp[2], .35, .7, len, ang);
    }
  }
  // luzes de estadio (refletores) na borda do teto — nomeadas "Floodlight_*" (sem "goal" no nome)
  const rl = ringAt(A0, B0, ringR, dIn, STEP);
  const nL = 4;
  for (let i = 0; i < rl.length; i += Math.round(rl.length / 28)) {
    const p = rl[i], ang = Math.atan2(p.nx, p.nz);
    // fileira de lampadas
    for (let k = -2; k <= 2; k++) {
      const ox = Math.cos(ang) * k * .8, oz = -Math.sin(ang) * k * .8;
      box('Light_Lamp', p.x + ox - p.nx * .6, yIn - 1.3, p.z + oz - p.nz * .6, .5, .5, .5);
    }
    boxR('Steel', p.x - p.nx * .6, yIn - .75, p.z - p.nz * .6, 4.4, .12, .3, ang);
  }
})();

// ---------- pilares de canto / torres (visuais) ----------
(function masts() {
  const A0 = bw.A0 + 14, B0 = bw.B0 + 14;
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    const x = sx * (bw.A0 - 6), z = sz * (bw.B0 - 6);
    // pylons externos de canto
    const px = sx * (bw.A0 + bw.outerD - 4), pz = sz * (bw.B0 + bw.outerD - 4);
    box('Steel', px, 22, pz, 1.4, 44, 1.4);
  }
})();

// ---------- tunel e bancos de reservas ----------
(function benches() {
  // abrigo dos reservas: lado -z (camera principal costuma ficar no +z ou -z, aqui nos dois lados mais discretos no -z)
  const z = -(HW + 2.2);
  for (const cx of [-18, 18]) {
    box('Concrete_Dark', cx, .15, z, 10, .3, 2.2);
    box('Dugout_Glass', cx, 1.2, z - 1.1, 10, 1.8, .06);
    box('Dugout_Glass', cx - 5, 1.2, z, .06, 1.8, 2.2);
    box('Dugout_Glass', cx + 5, 1.2, z, .06, 1.8, 2.2);
    box('Roof_Panel', cx, 2.15, z, 10.6, .12, 2.8);
    for (let k = 0; k < 6; k++) box('Boards_Blue', cx - 3.5 + k * 1.4, .5, z, .9, .5, .7);
  }
  // tunel dos jogadores no centro do lado -z
  const tz = -(BZ + 3.5);
  box('Tunnel_Dark', 0, 1.6, tz - 2, 4.4, 3.2, 4);
  box('Concrete', 0, 3.3, tz - 2, 5.4, .3, 5);
  box('Concrete', -2.5, 1.6, tz - 2, .5, 3.2, 4.6);
  box('Concrete', 2.5, 1.6, tz - 2, .5, 3.2, 4.6);
})();

// ---------- praca externa ----------
box('Plaza_Ground', 0, -.2, 0, 2 * (bw.A0 + bw.outerD + 60), .1, 2 * (bw.B0 + bw.outerD + 60));

// ---------- bandeiras / faixas nos angulos do anel superior ----------
(function banners() {
  const A0 = bw.A0, B0 = bw.B0;
  const r = ringAt(A0, B0, ringR, bw.upperStartD + 6, STEP);
  for (let i = 0; i < r.length; i += 14) {
    const p = r[i], ang = Math.atan2(p.nx, p.nz);
    boxR(i % 28 ? 'Banner_Gold' : 'Banner_Blue', p.x - p.nx * 1.8, bw.topLowerY + 8 + 6 * .0, p.z - p.nz * 1.8, 5, 2.2, .06, ang);
  }
})();

// ---------- escreve glTF ----------
const names = Object.keys(G).filter(k => G[k].idx.length);
const bufs = [], views = [], acc = [], meshes = [], nodes = [], materials = [];
let off = 0;
const push = (ta, target) => {
  const b = Buffer.from(ta.buffer, ta.byteOffset, ta.byteLength);
  const pad = (4 - (off % 4)) % 4; if (pad) { bufs.push(Buffer.alloc(pad)); off += pad; }
  bufs.push(b); views.push({ buffer: 0, byteOffset: off, byteLength: b.length, target }); off += b.length; return views.length - 1;
};
let totalTris = 0, totalVerts = 0;
names.forEach(k => {
  const g = G[k], m = MAT[k];
  const P = new Float32Array(g.pos), N = new Float32Array(g.nor), C = new Uint8Array(g.col.map(v => Math.round(Math.min(1, Math.max(0, v)) * 255))), I = new Uint32Array(g.idx);
  const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
  for (let j = 0; j < P.length; j += 3) for (let a = 0; a < 3; a++) { mn[a] = Math.min(mn[a], P[j + a]); mx[a] = Math.max(mx[a], P[j + a]); }
  const a0 = acc.length;
  acc.push({ bufferView: push(P, 34962), componentType: 5126, count: P.length / 3, type: 'VEC3', min: mn, max: mx });
  acc.push({ bufferView: push(N, 34962), componentType: 5126, count: N.length / 3, type: 'VEC3' });
  const attrs = { POSITION: a0, NORMAL: a0 + 1 };
  if (m.vc) { acc.push({ bufferView: push(C, 34962), componentType: 5121, normalized: true, count: C.length / 4, type: 'VEC4' }); attrs.COLOR_0 = acc.length - 1; }
  acc.push({ bufferView: push(I, 34963), componentType: 5125, count: I.length, type: 'SCALAR' });
  const mo = { name: k, pbrMetallicRoughness: { baseColorFactor: [...m.rgb, m.alpha || 1], metallicFactor: m.metal || 0, roughnessFactor: m.rough ?? .8 } };
  if (m.emis) mo.emissiveFactor = m.emis;
  if (m.alpha) mo.alphaMode = 'BLEND';
  materials.push(mo);
  meshes.push({ name: k, primitives: [{ attributes: attrs, indices: acc.length - 1, material: materials.length - 1 }] });
  nodes.push({ name: k, mesh: meshes.length - 1 });
  totalTris += I.length / 3; totalVerts += P.length / 3;
});
const json = { asset: { version: '2.0', generator: 'Arena Horizon (Goal Horizon)' }, scene: 0, scenes: [{ name: 'Arena Horizon', nodes: nodes.map((_, i) => i) }], nodes, meshes, materials, accessors: acc, bufferViews: views, buffers: [{ byteLength: off }] };
let js = Buffer.from(JSON.stringify(json)); js = Buffer.concat([js, Buffer.alloc((4 - js.length % 4) % 4, 0x20)]);
let bin = Buffer.concat(bufs); bin = Buffer.concat([bin, Buffer.alloc((4 - bin.length % 4) % 4)]);
const total = 12 + 8 + js.length + 8 + bin.length, h = Buffer.alloc(12);
h.writeUInt32LE(0x46546C67, 0); h.writeUInt32LE(2, 4); h.writeUInt32LE(total, 8);
const c1 = Buffer.alloc(8); c1.writeUInt32LE(js.length, 0); c1.writeUInt32LE(0x4E4F534A, 4);
const c2 = Buffer.alloc(8); c2.writeUInt32LE(bin.length, 0); c2.writeUInt32LE(0x004E4942, 4);
const out = process.argv[2] || 'arena-horizon.glb';
fs.writeFileSync(out, Buffer.concat([h, c1, js, c2, bin]));
console.log(out, total + ' bytes', totalTris + ' tris', totalVerts + ' verts', names.length + ' meshes');
