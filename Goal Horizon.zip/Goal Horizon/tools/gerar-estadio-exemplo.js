// node tools/gerar-estadio-exemplo.js -> cria models/stadiums/estadio-exemplo.glb (sem dependências)
const fs=require('fs'),p=require('path');
const mats={Pitch_Grass:[.18,.55,.2],Apron:[.1,.38,.14],Concrete:[.55,.55,.58],Seats_A:[.1,.3,.75],Seats_B:[.92,.92,.95],Roof:[.25,.27,.3],Boards:[.8,.1,.1],Tower:[.4,.4,.42]};
const G={};for(const k in mats)G[k]={pos:[],nor:[],idx:[]};
function box(m,cx,cy,cz,sx,sy,sz){const g=G[m],h=[sx/2,sy/2,sz/2];
 const F=[[[1,0,0],[[1,-1,-1],[1,1,-1],[1,1,1],[1,-1,1]]],[[-1,0,0],[[-1,-1,1],[-1,1,1],[-1,1,-1],[-1,-1,-1]]],[[0,1,0],[[-1,1,-1],[-1,1,1],[1,1,1],[1,1,-1]]],
 [[0,-1,0],[[-1,-1,1],[-1,-1,-1],[1,-1,-1],[1,-1,1]]],[[0,0,1],[[-1,-1,1],[1,-1,1],[1,1,1],[-1,1,1]]],[[0,0,-1],[[1,-1,-1],[-1,-1,-1],[-1,1,-1],[1,1,-1]]]];
 for(const [n,vs] of F){const b=g.pos.length/3;for(const v of vs){g.pos.push(cx+v[0]*h[0],cy+v[1]*h[1],cz+v[2]*h[2]);g.nor.push(...n);}g.idx.push(b,b+1,b+2,b,b+2,b+3);}}
box('Pitch_Grass',0,-.05,0,105,.1,68);           // topo em y=0
box('Apron',0,-.1,0,125,.1,88);
// arquibancadas em degraus (4 lados)
const ROWS=16;
for(let i=0;i<ROWS;i++){
 const h=.45+i*.5,d=.8;
 for(const s of [-1,1]){
  const zc=s*(44+2+i*d),M=i%2?'Seats_A':'Seats_B';
  box(M,0,h/2,zc,112+i*1.6,h,d);               // laterais
  const xc=s*(62.5+2+i*d);
  box(i%2?'Seats_B':'Seats_A',xc,h/2,0,d,h,76+i*1.6); // fundos
 }
}
box('Concrete',0,.25,0,0,0,0);
for(const s of [-1,1]){box('Roof',0,13.5,s*(46+6.5),122,.5,13);box('Roof',s*(64.5+6.5),13.5,0,13,.5,88);}
// placas de publicidade
for(const s of [-1,1]){box('Boards',0,.45,s*37.5,112,.9,.3);box('Boards',s*58,.45,0,.3,.9,64);}
// torres de iluminação
for(const sx of [-1,1])for(const sz of [-1,1]){box('Tower',sx*72,17,sz*52,1.2,34,1.2);box('Tower',sx*70.8,34.5,sz*50.8,5,2,3);}
// monta glTF
const names=Object.keys(G).filter(k=>G[k].idx.length);
const bufs=[],views=[],acc=[],meshes=[],nodes=[],materials=[];
let off=0;const push=(ta)=>{const b=Buffer.from(ta.buffer,ta.byteOffset,ta.byteLength);bufs.push(b);views.push({buffer:0,byteOffset:off,byteLength:b.length});off+=b.length;return views.length-1;};
names.forEach((k,i)=>{const g=G[k];
 const P=new Float32Array(g.pos),N=new Float32Array(g.nor),I=new Uint32Array(g.idx);
 const mn=[1e9,1e9,1e9],mx=[-1e9,-1e9,-1e9];for(let j=0;j<P.length;j+=3)for(let a=0;a<3;a++){mn[a]=Math.min(mn[a],P[j+a]);mx[a]=Math.max(mx[a],P[j+a]);}
 const a0=acc.length;
 acc.push({bufferView:push(P),componentType:5126,count:P.length/3,type:'VEC3',min:mn,max:mx});
 acc.push({bufferView:push(N),componentType:5126,count:N.length/3,type:'VEC3'});
 acc.push({bufferView:push(I),componentType:5125,count:I.length,type:'SCALAR'});
 materials.push({name:k,pbrMetallicRoughness:{baseColorFactor:[...mats[k],1],metallicFactor:0,roughnessFactor:.85}});
 meshes.push({name:k,primitives:[{attributes:{POSITION:a0,NORMAL:a0+1},indices:a0+2,material:materials.length-1}]});
 nodes.push({name:k,mesh:meshes.length-1});});
const json={asset:{version:'2.0',generator:'Goal Horizon estadio-exemplo'},scene:0,scenes:[{nodes:nodes.map((_,i)=>i)}],nodes,meshes,materials,accessors:acc,bufferViews:views,buffers:[{byteLength:off}]};
let js=Buffer.from(JSON.stringify(json));js=Buffer.concat([js,Buffer.alloc((4-js.length%4)%4,0x20)]);
let bin=Buffer.concat(bufs);bin=Buffer.concat([bin,Buffer.alloc((4-bin.length%4)%4)]);
const total=12+8+js.length+8+bin.length,h=Buffer.alloc(12);h.writeUInt32LE(0x46546C67,0);h.writeUInt32LE(2,4);h.writeUInt32LE(total,8);
const c1=Buffer.alloc(8);c1.writeUInt32LE(js.length,0);c1.writeUInt32LE(0x4E4F534A,4);const c2=Buffer.alloc(8);c2.writeUInt32LE(bin.length,0);c2.writeUInt32LE(0x004E4942,4);
const out=p.join(__dirname,'..','models','stadiums','estadio-exemplo.glb');
fs.writeFileSync(out,Buffer.concat([h,c1,js,c2,bin,]));console.log(out,total+' bytes');
