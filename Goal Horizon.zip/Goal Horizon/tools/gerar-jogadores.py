#!/usr/bin/env python3
"""Gerador de jogadores de futebol .glb — Goal Horizon (v2: rostos, cabelos, anatomia, uniformes).
Uso: python3 tools/gerar-jogadores.py <pasta_saida>        (ex.: models  -> models/player.glb + models/players/*.glb)

O que há no GLB (um único modelo com TODAS as variações; o jogo liga/desliga por jogador):
  Skin, Shirt, Trim, Shorts, Socks, Boots, Eyes      malhas-base (pintadas pelo render.js: pele, cores do clube)
  Hair_<estilo>   13 penteados (v4: +quiff, twists, dreads; 'bald' = sem malha)  (só um fica visível por jogador)
  Beard_<estilo>  5 barbas (v4: +circle)
  GKArms, Gloves, GKPants  (v4) partes do goleiro: manga longa, luvas, calça comprida (escondidas nos jogadores de linha pelo render.js)      (opcional por jogador)
  Morph targets (influência -1..1): Build (magro<->forte), FaceWidth, FaceLength, Jaw
  Esqueleto: os MESMOS 22 ossos mixamorig* e a mesma T-pose do gerador anterior.
  Animações v3 (embutidas): idle, gkidle, gkhold, walk, jog, run, sprint, dribble, kick, slide, getup, jump, dive, diveR, fall, celebrate1-5.
     Marcha com IK de pernas (pés firmes no chão), contato com o gramado calculado quadro a quadro, interpolação PCHIP, 60 fps.
  Cores por vértice (COLOR_0): sombras de oclusão, lábios, sobrancelhas, narinas, íris, solas, raiz do cabelo.
"""
import sys, os, json, struct, math
import numpy as np

OUT = sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].startswith('--') else '.'
D2R = math.pi / 180

# ------------------------------------------------------------------ esqueleto
# (nome, pai, posição de repouso no mundo) — T-pose, +Y cima, personagem olhando +Z, "Left" = +X
J = [
    ('Hips', None, (0, .95, 0)),
    ('Spine', 'Hips', (0, 1.02, 0)),
    ('Spine1', 'Spine', (0, 1.14, 0)),
    ('Spine2', 'Spine1', (0, 1.27, 0)),
    ('Neck', 'Spine2', (0, 1.45, 0)),
    ('Head', 'Neck', (0, 1.54, 0)),
    ('LeftShoulder', 'Spine2', (.03, 1.40, 0)),
    ('LeftArm', 'LeftShoulder', (.17, 1.40, 0)),
    ('LeftForeArm', 'LeftArm', (.43, 1.40, 0)),
    ('LeftHand', 'LeftForeArm', (.68, 1.40, 0)),
    ('RightShoulder', 'Spine2', (-.03, 1.40, 0)),
    ('RightArm', 'RightShoulder', (-.17, 1.40, 0)),
    ('RightForeArm', 'RightArm', (-.43, 1.40, 0)),
    ('RightHand', 'RightForeArm', (-.68, 1.40, 0)),
    ('LeftUpLeg', 'Hips', (.09, .93, 0)),
    ('LeftLeg', 'LeftUpLeg', (.09, .50, 0)),
    ('LeftFoot', 'LeftLeg', (.09, .09, 0)),
    ('LeftToeBase', 'LeftFoot', (.09, .04, .13)),
    ('RightUpLeg', 'Hips', (-.09, .93, 0)),
    ('RightLeg', 'RightUpLeg', (-.09, .50, 0)),
    ('RightFoot', 'RightLeg', (-.09, .09, 0)),
    ('RightToeBase', 'RightFoot', (-.09, .04, .13)),
]
PFX = 'mixamorig'
BN = [PFX + j[0] for j in J]
IDX = {j[0]: i for i, j in enumerate(J)}
WPOS = np.array([j[2] for j in J], dtype=np.float64)


# ------------------------------------------------------------------ utilidades de geometria
def sstep(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def G(x, y, cx, cy, sx, sy):
    return np.exp(-((x - cx) / sx) ** 2 - ((y - cy) / sy) ** 2)


class Part:
    """malha com atributos por vértice: v, f, w (lista de dict junta->peso), col, uv, ctr (centro do anel), bk (ganho do morph Build), hd (preso à cabeça)"""
    def __init__(s, v, f, w, col=None, uv=None, ctr=None, bk=0.0, hd=False):
        n = len(v)
        s.v = np.asarray(v, float).reshape(-1, 3)
        s.f = np.asarray(f, int).reshape(-1, 3)
        s.w = w
        s.col = np.ones((n, 3)) if col is None else np.broadcast_to(np.asarray(col, float), (n, 3)).copy()
        s.uv = None if uv is None else np.asarray(uv, float).reshape(-1, 2)
        s.ctr = s.v.copy() if ctr is None else np.asarray(ctr, float).reshape(-1, 3)
        s.bk = np.broadcast_to(np.asarray(bk, float), (n,)).copy()
        s.hd = np.broadcast_to(np.asarray(hd, bool), (n,)).copy()


def orient(P):
    f = P.f
    a, b, c = P.v[f[:, 0]], P.v[f[:, 1]], P.v[f[:, 2]]
    n = np.cross(b - a, c - a)
    cen = (a + b + c) / 3
    ref = (P.ctr[f[:, 0]] + P.ctr[f[:, 1]] + P.ctr[f[:, 2]]) / 3
    flip = np.einsum('ij,ij->i', n, cen - ref) < 0
    P.f = f.copy(); P.f[flip] = f[flip][:, ::-1]
    return P


def merge(parts):
    parts = [p for p in parts if p is not None and len(p.v)]
    off = 0; V, F, W, C, U, CT, BK, HD = [], [], [], [], [], [], [], []
    anyuv = any(p.uv is not None for p in parts)
    for p in parts:
        V.append(p.v); F.append(p.f + off); W += p.w; C.append(p.col); CT.append(p.ctr); BK.append(p.bk); HD.append(p.hd)
        if anyuv: U.append(p.uv if p.uv is not None else np.zeros((len(p.v), 2)))
        off += len(p.v)
    return Part(np.vstack(V), np.vstack(F), W, np.vstack(C), np.vstack(U) if anyuv else None, np.vstack(CT), np.concatenate(BK), np.concatenate(HD))


def chain(t, joints, bounds, hws):
    """pesos suaves ao longo de uma cadeia: t cresce de joints[0] até joints[-1]; bounds/hws = fronteiras e meia-largura da transição"""
    w = {}; rem = 1.0
    for i, (b, hw) in enumerate(zip(bounds, hws)):
        k = float(sstep((t - (b - hw)) / (2 * hw)))
        w[joints[i]] = w.get(joints[i], 0) + rem * (1 - k)
        rem *= k
    w[joints[-1]] = w.get(joints[-1], 0) + rem
    return {a: b for a, b in w.items() if b > 1e-4}


def spow(x, e):
    return np.sign(x) * np.abs(x) ** e


def ring_pts(c, U, V, seg, fb=1.0, e=1.0, a0=0.0, a1=2 * math.pi):
    """anel elíptico: c + cos(a)*U*(frente->trás: 1->fb) + sin(a)*V ; e<1 deixa 'quadrado'"""
    c, U, V = map(lambda q: np.asarray(q, float), (c, U, V))
    pts = []
    for k in range(seg):
        a = a0 + (a1 - a0) * k / seg
        ca, sa = math.cos(a), math.sin(a)
        fbk = 1 + (fb - 1) * (1 - ca) / 2
        pts.append(c + spow(ca, e) * U * fbk + spow(sa, e) * V)
    return np.array(pts)


def loft_pts(ptl, ctrs, wf, seg, bk=0.0, hd=False, caps=(True, True), cf=None, uvs=None, closed=True):
    """ptl: lista de arrays (seg,3) (um por anel); ctrs: centros; wf(p)->dict; cf(p,ring)->cor(3)"""
    n = len(ptl)
    V, W, C, CT, U, BK = [], [], [], [], [], []
    vacc = 0.0
    for i, (pts, c) in enumerate(zip(ptl, ctrs)):
        if i > 0: vacc += np.linalg.norm(np.asarray(c) - np.asarray(ctrs[i - 1]))
        per = np.sum(np.linalg.norm(np.roll(pts, -1, 0) - pts, axis=1))
        for k in range(seg):
            p = pts[k]; V.append(p); W.append(wf(p)); CT.append(c)
            C.append(cf(p, i) if cf else (1, 1, 1))
            U.append((k / seg * per / .03, vacc / .03))
            BK.append(bk(p, i) if callable(bk) else bk)
    F = []
    rng = seg if closed else seg - 1
    for i in range(n - 1):
        for k in range(rng):
            a, b = i * seg + k, i * seg + (k + 1) % seg
            c_, d = (i + 1) * seg + k, (i + 1) * seg + (k + 1) % seg
            F += [[a, b, d], [a, d, c_]]
    for end, on in zip((0, n - 1), caps):
        if not on: continue
        c = np.asarray(ctrs[end], float); ci = len(V)
        V.append(c); W.append(wf(c)); CT.append(c); C.append(cf(c, end) if cf else (1, 1, 1)); U.append((0, vacc / .03 if end else 0)); BK.append(0)
        for k in range(rng):
            F.append([ci, end * seg + k, end * seg + (k + 1) % seg])
    P = Part(V, F, W, C, U if uvs else None, CT, BK, hd)
    return orient(P)


def ellipsoid(c, rx, ry, rz, wf, seg=10, rings=6, col=None, bk=0.0, hd=False, rot=None, cf=None, lim=None):
    """elipsoide (opcional rot = matriz 3x3 em torno do centro). lim=(ymin,ymax) em coordenadas locais normalizadas recorta uma calota"""
    c = np.asarray(c, float)
    V, F, W, C = [], [], [], []
    r0, r1 = (0, rings) if lim is None else lim
    for i in range(r0, r1 + 1):
        th = math.pi * i / rings
        for k in range(seg):
            a = 2 * math.pi * k / seg
            if i == 0 or i == rings:
                if k > 0: pass
            lp = np.array([rx * math.sin(th) * math.sin(a), ry * math.cos(th), rz * math.sin(th) * math.cos(a)])
            p = c + (rot @ lp if rot is not None else lp)
            V.append(p); W.append(wf(p)); C.append(cf(lp, p) if cf else (col if col is not None else (1, 1, 1)))
    nr = r1 - r0 + 1
    for i in range(nr - 1):
        for k in range(seg):
            a, b = i * seg + k, i * seg + (k + 1) % seg
            c_, d = (i + 1) * seg + k, (i + 1) * seg + (k + 1) % seg
            F += [[a, b, d], [a, d, c_]]
    P = Part(V, F, W, C, None, np.tile(c, (len(V), 1)), bk, hd)
    # remove triângulos degenerados dos polos
    f = P.f; v = P.v
    ar = np.linalg.norm(np.cross(v[f[:, 1]] - v[f[:, 0]], v[f[:, 2]] - v[f[:, 0]]), axis=1)
    P.f = f[ar > 1e-12]
    return orient(P)


def Rmat(ax, deg):
    a = deg * D2R; c, s = math.cos(a), math.sin(a)
    if ax == 'x': return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if ax == 'y': return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def smooth_normals(P):
    v, f = P.v, P.f
    n = np.zeros_like(v)
    a, b, c = v[f[:, 0]], v[f[:, 1]], v[f[:, 2]]
    fn = np.cross(b - a, c - a)
    for k in range(3): np.add.at(n, f[:, k], fn)
    l = np.linalg.norm(n, axis=1, keepdims=True); l[l == 0] = 1
    return n / l


def tube(p0, p1, r0, r1, seg, nr, wf, bend=(0, 0, 0), col=None, bk=0.0, hd=False, cap_end=True):
    p0, p1 = np.asarray(p0, float), np.asarray(p1, float)
    ax = p1 - p0; L = np.linalg.norm(ax); ax /= L
    ref = np.array([0, 1, 0]) if abs(ax[1]) < .9 else np.array([1, 0, 0])
    u = np.cross(ax, ref); u /= np.linalg.norm(u); v = np.cross(ax, u)
    ptl, ctrs = [], []
    for i in range(nr):
        t = i / (nr - 1); c = p0 + ax * L * t + np.asarray(bend, float) * t * t
        r = r0 + (r1 - r0) * t
        ptl.append(ring_pts(c, u * r, v * r, seg)); ctrs.append(c)
    P = loft_pts(ptl, ctrs, wf, seg, bk=bk, hd=hd, caps=(False, cap_end))
    if col is not None: P.col[:] = col
    return P

# ------------------------------------------------------------------ CABEÇA / ROSTO
HC = np.array([0, 1.655, 0.005])      # centro da cabeça
SEGH, RNGH = 30, 22
LIPC = np.array([.90, .70, .67])       # multiplicador da cor da pele nos lábios
WH = lambda p: {IDX['Head']: 1.0}


def head_grid():
    dirs = [(0, 1, 0)]
    for i in range(1, RNGH):
        th = math.pi * i / RNGH
        for k in range(SEGH):
            t = k / SEGH; phi = 2 * math.pi * t - .36 * math.sin(2 * math.pi * t)   # mais vértices na frente (rosto)
            dirs.append((math.sin(th) * math.sin(phi), math.cos(th), math.sin(th) * math.cos(phi)))
    dirs.append((0, -1, 0))
    F = []
    for k in range(SEGH):
        F.append([0, 1 + k, 1 + (k + 1) % SEGH])
    for i in range(RNGH - 2):
        for k in range(SEGH):
            a, b = 1 + i * SEGH + k, 1 + i * SEGH + (k + 1) % SEGH
            c, d = 1 + (i + 1) * SEGH + k, 1 + (i + 1) * SEGH + (k + 1) % SEGH
            F += [[a, b, d], [a, d, c]]
    last = len(dirs) - 1
    for k in range(SEGH):
        F.append([last, 1 + (RNGH - 2) * SEGH + (k + 1) % SEGH, 1 + (RNGH - 2) * SEGH + k])
    return np.array(dirs, float), np.array(F, int)


HDIR, HF = head_grid()
HF = orient(Part(HDIR * np.array([.079, .116, .096]), HF, [{}] * len(HDIR), None, None, np.zeros((len(HDIR), 3)))).f


def sculpt(d):
    """direções unitárias -> posições relativas ao centro da cabeça (rosto esculpido por gaussianas)"""
    rx, ry, rz = .079, .116, .096
    p = d * np.array([rx, ry, rz])
    dx, dy, dz = d[:, 0], d[:, 1], d[:, 2]
    front = sstep((dz + .05) / .65)
    low = sstep((-p[:, 1] - .005) / .085)
    p[:, 0] *= 1 - .24 * low * (.55 + .45 * front)              # maxilar mais estreito que o crânio
    p[:, 2] += .010 * low * front                               # queixo projetado
    back = sstep((-dz + .1) / .9)
    p[:, 1] += .038 * low * back * sstep((-dy - .35) / .5)      # sob a nuca sobe (pescoço cobre)
    p[:, 1] *= 1 + .02 * sstep(dy)                              # topo do crânio mais cheio
    x, y = np.abs(p[:, 0]), p[:, 1]
    f2 = sstep((dz - .2) / .5)
    off = (G(x, y, .031, .041, .030, .010) * .0075            # arcada
           + G(x, y, 0, .078, .050, .030) * .004               # testa
           + G(x, y, .031, .021, .015, .011) * -.0100          # órbita
           + G(x, y, 0, .010, .008, .030) * .0085              # ponte do nariz
           + G(x, y, 0, -.022, .011, .020) * .0065             # corpo do nariz
           + G(x, y, .052, -.016, .024, .022) * .0070          # maçã do rosto
           + G(x, y, .046, -.052, .016, .020) * -.0035         # bochecha
           + G(x, y, 0, -.062, .030, .022) * .0055             # focinho/lábios
           + G(x, y, 0, -.0685, .022, .0035) * -.0045          # linha da boca
           + G(x, y, 0, -.085, .016, .005) * -.0030            # sulco do queixo
           + G(x, y, 0, -.100, .020, .012) * .0080)            # queixo
    p[:, 2] += off * f2
    return p


HP_LOC = sculpt(HDIR)                         # (n,3) relativos
HP = HP_LOC + HC
_hn = Part(HP, HF, [{}] * len(HP)); HN = smooth_normals(_hn)
HY = HP_LOC[:, 1]; HX = HP_LOC[:, 0]; HZD = HDIR[:, 2]


def surf_z(x, y):
    """z do rosto (mundo) na posição (x,y) relativa à cabeça, por interpolação dos vértices frontais"""
    m = HZD > .2
    idx = np.where(m)[0]
    dd = (HP_LOC[idx, 0] - x) ** 2 + (HP_LOC[idx, 1] - y) ** 2
    o = np.argsort(dd)[:4]
    w = 1 / (dd[o] + 1e-6); return float(np.sum(HP_LOC[idx[o], 2] * w) / w.sum() + HC[2])


def head_warp(P, kind, m=1.0):
    """warp espacial suave (aplicado a TODA malha presa à cabeça): devolve o delta"""
    q = P - HC; d = np.zeros_like(P)
    if kind == 'FaceWidth':
        d[:, 0] = q[:, 0] * .10 * m * (1 - .35 * sstep((-q[:, 1] - .03) / .08))
    elif kind == 'FaceLength':
        d[:, 1] = q[:, 1] * .09 * m
        d[:, 1] += -.012 * m * sstep((-q[:, 1] - .04) / .07)
    elif kind == 'Jaw':
        s = sstep((-q[:, 1] - .01) / .09)
        d[:, 0] = q[:, 0] * .15 * m * s
        d[:, 2] = .006 * m * s * sstep((q[:, 2] + .02) / .08)
        d[:, 1] = -.004 * m * s
    return d


def face_cols():
    x, y = np.abs(HX), HY
    c = np.ones((len(HP), 3))
    ao = 1 - .12 * G(x, y, .031, .021, .018, .013) - .10 * sstep((-y - .085) / .03) * sstep((.6 - HZD) / .8)
    c *= ao[:, None]
    blush = G(x, y, .050, -.030, .025, .020) * .08 + G(x, y, 0, -.020, .014, .012) * .05
    c[:, 1] -= blush; c[:, 2] -= blush * 1.3
    return np.clip(c, 0, 1.2)


def build_face_skin():
    P = Part(HP, HF, [WH(p) for p in HP], face_cols(), None, np.tile(HC, (len(HP), 1)), 0.0, True)
    return orient(P)


def make_ear(s):
    rot = Rmat('y', -s * 24) @ Rmat('z', -s * 8)
    def cf(lp, p):
        q = 1 - .30 * max(0, (lp[2] / .018)) * .6
        return np.array([1.0, .90, .86]) * (q if lp[0] * s < 0 else 1.0)
    return ellipsoid(HC + np.array([s * .0795, -.004, -.006]), .0075, .031, .019, WH, 8, 6, rot=rot, cf=cf, hd=True)


def build_nose():
    ny = -.0315; tipz = surf_z(0, ny) + .004
    parts = []
    def nosecol(lp, p):
        col = np.array([1.0, .93, .90])
        if lp[1] < -.003 and abs(abs(p[0]) - .0075) < .0045: col = col * .45
        return col
    parts.append(ellipsoid((0, HC[1] + ny, tipz - .002), .0105, .0125, .0125, WH, 10, 6, cf=nosecol, hd=True))
    for s in (1, -1):
        parts.append(ellipsoid((s * .0125, HC[1] - .0345, surf_z(s * .0125, -.0345) - .001), .0075, .0095, .0090, WH, 8, 5, cf=nosecol, hd=True))
    return merge(parts)


def build_lips():
    parts = []
    yu, yl = -.0585, -.0700
    parts.append(ellipsoid((0, HC[1] + yu, surf_z(0, yu) + .0006), .0200, .0047, .0085, WH, 12, 5, col=LIPC * .97, hd=True))
    parts.append(ellipsoid((0, HC[1] + yl, surf_z(0, yl) + .0008), .0175, .0056, .0090, WH, 12, 5, col=LIPC, hd=True))
    return merge(parts)


def build_brows():
    parts = []
    for s in (1, -1):
        ptl, ctrs = [], []
        for i in range(7):
            t = i / 6; x = .014 + t * .036
            y = .0475 + .006 * math.sin(t * math.pi * .8) - .004 * t * t
            z = surf_z(x, y) + .0010
            c = np.array([s * x, HC[1] + y, z])
            ptl.append(ring_pts(c, (0, 0, .0016), (0, .0052 * (1 - .35 * t), 0), 4)); ctrs.append(c - np.array([0, 0, .003]))
        parts.append(loft_pts(ptl, ctrs, WH, 4, hd=True, caps=(True, True), cf=lambda p, i: (.25, .20, .18)))
    return merge(parts)


def build_eyes():
    eyes, lids = [], []
    for s in (1, -1):
        x, y = .0315, .020
        z = surf_z(x, y) - .0042
        c = np.array([s * x, HC[1] + y, z])
        def ecol(lp, p):
            d = lp / np.linalg.norm(lp); a = math.degrees(math.acos(np.clip(d[1], -1, 1)))
            if a < 17: return np.array([.02, .02, .02])
            if a < 38: return np.array([.20, .11, .05])
            return np.array([.95, .93, .90])
        eyes.append(ellipsoid(c, .0122, .0120, .0120, WH, 12, 10, cf=ecol, hd=True, rot=Rmat('x', 90)))
        cl = lambda lp, p: np.array([.93, .88, .86])
        lids.append(ellipsoid(c + np.array([0, .0006, -.0004]), .0132, .0132, .0132, WH, 14, 10, cf=cl, hd=True, lim=(0, 3)))
        lids.append(ellipsoid(c + np.array([0, -.0006, -.0004]), .0130, .0130, .0130, WH, 14, 10, cf=cl, hd=True, lim=(8, 10)))
    return merge(eyes), merge(lids)


# ------------------------------------------------------------------ CABELOS (cascas sobre a malha da cabeça)
def shell_from_head(mask, t, vol=None, off=None, wf=WH, col=None, cf=None, edge=.010):
    field = None
    if isinstance(mask, tuple): mask, field = mask
    f = HF[np.all(mask[HF], axis=1)]
    used = np.unique(f); remap = -np.ones(len(HP), int); remap[used] = np.arange(len(used))
    P = HP[used].copy(); loc = HP_LOC[used]; N = HN[used]
    tt = t(loc, HDIR[used]) if callable(t) else t
    if field is not None: tt = np.asarray(tt) * (.25 + .75 * sstep(field[used] / edge))
    P = P + N * (np.asarray(tt)[:, None] if np.ndim(tt) else tt)
    if vol is not None:
        k = vol(loc, HDIR[used]); P = P + (loc * np.array([1, .6, 1])) * k[:, None]
    if off is not None: P = P + off(loc, HDIR[used])
    C = np.ones((len(used), 3)) * (col if col is not None else 1)
    if cf is not None: C = cf(loc, HDIR[used])
    return Part(P, remap[f], [wf(p) for p in P], C, None, np.tile(HC, (len(P), 1)), 0.0, True)


def hairline(dz):
    return np.interp(dz, [-1, -.35, .1, .5, 1], [-.050, -.020, .020, .040, .056])


def hair_mask(shift=0.0, back_ext=0.0, front=0.0):
    e = hairline(HZD) + shift
    e = np.where(HZD < -.2, e - back_ext, e)
    e = np.where(HZD > .4, e + front, e)
    return (HY > e, HY - e)


def clump_spheres(P, n, r, rng, ycut=-1, jitter=.4, col=(1, 1, 1)):
    out = []
    idx = np.arange(len(P.v))[P.v[:, 1] - HC[1] > ycut]
    if len(idx) == 0: return None
    pick = rng.choice(idx, size=min(n, len(idx)), replace=False)
    for i in pick:
        p = P.v[i]; dirn = (p - HC); dirn /= np.linalg.norm(dirn)
        rr = r * (1 + (rng.random() - .5) * jitter)
        out.append(ellipsoid(p + dirn * rr * .35, rr, rr, rr, WH, 6, 4, col=col, hd=True))
    return merge(out)


def hair_cf(root=.50):
    def f(loc, dd):
        h = np.clip((loc[:, 1] - hairline(dd[:, 2])) / .075, 0, 1)
        v = root + (1 - root) * h ** .8
        return np.stack([v, v, v], 1)
    return f


def hair_strands(n, rng, y_end, r0, r1, nr=5, curl=0):
    out = []
    back = np.where((HZD < -.15) & (HY > -.03) & (HY < .045))[0]
    wfn = lambda p: chain(-p[1], [IDX['Head'], IDX['Neck'], IDX['Spine2']], [-1.56, -1.45], [.05, .05])
    for i in range(n):
        j = back[int(rng.integers(len(back)))]
        p0 = HP[j] + HN[j] * .002
        p1 = np.array([p0[0] * .9, y_end + rng.random() * .03, p0[2] - .02 - rng.random() * .02])
        out.append(tube(p0, p1, r0, r1, 5, nr, wfn, bend=(curl * (rng.random() - .5), 0, -.01), col=(.8, .8, .8)))
    return merge(out)


def build_hair_styles():
    H = {}; rng = np.random.default_rng(7)
    H['buzz'] = shell_from_head(hair_mask(-.004), .0032, cf=hair_cf(.55))
    H['crop'] = shell_from_head(hair_mask(0), lambda l, d: .006 + .006 * sstep((l[:, 1] - .03) / .05),
                                lambda l, d: .03 * sstep((l[:, 1] - .03) / .06), cf=hair_cf(.55))
    H['fade'] = shell_from_head(hair_mask(-.002), lambda l, d: .003 + .016 * sstep((l[:, 1] - .028) / .035),
                                lambda l, d: .10 * sstep((l[:, 1] - .035) / .05), cf=hair_cf(.50))
    b = shell_from_head(hair_mask(0), .010, lambda l, d: .035 * sstep((l[:, 1] - .01) / .06), cf=hair_cf(.55))
    H['curly'] = merge([b, clump_spheres(b, 26, .0185, rng, ycut=.03, col=(.9, .9, .9))])
    b = shell_from_head(hair_mask(-.012), .018, lambda l, d: .24 * sstep((l[:, 1] + .01) / .06), cf=hair_cf(.50))
    H['afro'] = merge([b, clump_spheres(b, 34, .026, rng, ycut=.02, col=(.92, .92, .92))])
    H['slick'] = shell_from_head(hair_mask(-.004, .028), lambda l, d: .010 + .008 * sstep((l[:, 1] - .03) / .05) + .004 * sstep((-d[:, 2] - .2) / .6),
                                 lambda l, d: .075 * sstep((l[:, 1] - .03) / .045) * sstep((d[:, 2] + .6) / .9) + .02 * sstep((-d[:, 2]) / .8), cf=hair_cf(.50))
    b = shell_from_head(hair_mask(-.004, .02), .011, lambda l, d: .04 * sstep((l[:, 1]) / .07), cf=hair_cf(.55))
    ptl, ctrs = [], []
    for i in range(9):
        t = i / 8; y = HC[1] - .02 - t * .22; r = .092 - .012 * t
        c = np.array([0, y, HC[2] - .012 - .010 * t])
        ptl.append(ring_pts(c, (0, 0, r * .92), (r * .98, 0, 0), 20, a0=math.radians(78), a1=math.radians(282))); ctrs.append(c)
    wfl = lambda p: chain(-p[1], [IDX['Head'], IDX['Neck'], IDX['Spine2']], [-1.575, -1.45], [.06, .05])
    panel = loft_pts(ptl, ctrs, wfl, 20, caps=(False, False), closed=False, cf=lambda p, i: np.ones(3) * (.55 + .45 * min(1, i / 4) ** .7))
    H['long'] = merge([b, panel])
    b = shell_from_head(hair_mask(-.003), lambda l, d: .006 + .006 * sstep((l[:, 1] - .03) / .05), lambda l, d: .035 * sstep((l[:, 1] - .03) / .06), cf=hair_cf(.55))
    H['bun'] = merge([b, ellipsoid(HC + np.array([0, .122, -.040]), .034, .030, .034, WH, 10, 6, col=(.95, .95, .95), hd=True)])
    b = shell_from_head(hair_mask(-.005, .004), .0075, lambda l, d: .02 * sstep((l[:, 1] - .01) / .06), cf=hair_cf(.50))
    H['braids'] = merge([b, hair_strands(11, np.random.default_rng(3), 1.46, .0105, .0075, nr=6, curl=.02)])
    side = shell_from_head((hair_mask(-.004)[0] & (np.abs(HX) > .021), hair_mask(-.004)[1]), .003, cf=hair_cf(.50))
    mid = shell_from_head((hair_mask(0)[0] & (np.abs(HX) < .026), hair_mask(0)[1]), lambda l, d: .008 + .016 * sstep((l[:, 1] - .03) / .05),
                          lambda l, d: .17 * sstep((l[:, 1] - .02) / .08), cf=hair_cf(.55))
    H['mohawk'] = merge([side, mid])
    # --- v4: novos penteados
    # topete/quiff: volume na frente e no alto, laterais curtas
    H['quiff'] = shell_from_head(hair_mask(0), lambda l, d: .007 + .014 * sstep((l[:, 1] - .03) / .05) * sstep((d[:, 2] + .2) / .7),
                                 lambda l, d: .115 * sstep((l[:, 1] - .03) / .05) * sstep((d[:, 2] + .1) / .8) + .02 * sstep((l[:, 1] - .03) / .06),
                                 off=lambda l, d: np.stack([0 * l[:, 0] + .006 * sstep((l[:, 1] - .04) / .05) * np.sign(l[:, 0]) * -1 * 0, 0 * l[:, 0], .020 * sstep((l[:, 1] - .03) / .05) * sstep((d[:, 2] - .1) / .6)], 1),
                                 cf=hair_cf(.50))
    # twists/coroa de cachinhos curtos (tipo crespo definido), mais denso e menor que o 'curly'
    b = shell_from_head(hair_mask(-.002), .008, lambda l, d: .03 * sstep((l[:, 1] - .01) / .06), cf=hair_cf(.50))
    H['twists'] = merge([b, clump_spheres(b, 62, .0125, np.random.default_rng(11), ycut=.02, col=(.9, .9, .9))])
    # dreads: casquete + mechas ao redor da cabeça
    b = shell_from_head(hair_mask(-.006, .004), .009, lambda l, d: .03 * sstep((l[:, 1] - .01) / .06), cf=hair_cf(.50))
    H['dreads'] = merge([b, dread_strands(28, np.random.default_rng(5))])
    return H


def dread_strands(n, rng):
    out = []
    wfn = lambda p: chain(-p[1], [IDX['Head'], IDX['Neck'], IDX['Spine2']], [-1.56, -1.45], [.05, .05])
    cand = np.where((HY > .012) & (HY < .085) & (HZD > -.95))[0]
    for i in range(n):
        j = cand[int(rng.integers(len(cand)))]
        p0 = HP[j] + HN[j] * .004
        out_d = HN[j] / (np.linalg.norm(HN[j]) + 1e-9)
        back = 1.0 if HZD[j] < -.1 else .0
        drop = .06 + .05 * rng.random() + .06 * back
        p1 = p0 + out_d * (.020 + .012 * rng.random()) + np.array([0, -drop, -.012 * back])
        p1[1] = max(p1[1], 1.585)
        out.append(tube(p0, p1, .0125, .0085, 5, 4, wfn, bend=(.012 * (rng.random() - .5), 0, -.006), col=(.82 + .1 * rng.random(),) * 3))
    return merge(out)


def build_beards():
    B = {}
    bx = np.abs(HX)
    bound = (-.012 - .050 * (1 - np.clip((bx - .018) / .045, 0, 1)))
    low = (HY < bound) & (HZD > -.30); lowf = (bound - HY)
    mouth = (np.abs(HX) < .026) & (HY > -.0775) & (HY < -.0505) & (HZD > .5)
    B['stubble'] = shell_from_head((low & ~mouth, lowf), .0016, col=.9, edge=.014)
    B['full'] = shell_from_head((low & ~mouth, lowf), lambda l, d: .006 + .004 * sstep((-l[:, 1] - .07) / .03),
                                off=lambda l, d: np.stack([0 * l[:, 0], -.004 * sstep((-l[:, 1] - .07) / .04), .006 * sstep((-l[:, 1] - .07) / .03) * sstep(d[:, 2] * 2)], 1),
                                cf=lambda l, d: np.stack([.7 + .3 * sstep((-l[:, 1] - .03) / .06)] * 3, 1), edge=.014)
    B['goatee'] = shell_from_head((HY < -.074) & (np.abs(HX) < .030) & (HZD > .35), .006,
                                  off=lambda l, d: np.stack([0 * l[:, 0], -.003 + 0 * l[:, 0], .003 + 0 * l[:, 0]], 1), col=.9)
    B['moustache'] = shell_from_head((HY > -.060) & (HY < -.030) & (np.abs(HX) < .036) & (HZD > .35), .0055, col=.85)
    B['circle'] = merge([B['goatee'], B['moustache']])       # v4: cavanhaque + bigode ligados
    return B

# ------------------------------------------------------------------ CORPO
def jn(name): return IDX[name]


def w_torso(p):
    y = p[1]
    return chain(y, [jn('Hips'), jn('Spine'), jn('Spine1'), jn('Spine2'), jn('Neck')], [1.0, 1.10, 1.21, 1.40], [.05, .05, .05, .05][:4] if False else [.05, .05, .06, .045])


def w_neck(p):
    return chain(p[1], [jn('Spine2'), jn('Neck'), jn('Head')], [1.44, 1.545], [.04, .035])


def w_leg(sd):
    def f(p):
        return chain(-p[1], [jn(sd + 'UpLeg'), jn(sd + 'Leg'), jn(sd + 'Foot')], [-.50, -.09], [.075, .05])
    return f


def w_arm(sd):
    def f(p):
        return chain(abs(p[0]), [jn('Spine2'), jn(sd + 'Arm'), jn(sd + 'ForeArm'), jn(sd + 'Hand')], [.115, .43, .68], [.06, .05, .03])
    return f


def w_shirt_arm(sd):
    def f(p):
        return chain(abs(p[0]), [jn('Spine2'), jn(sd + 'Arm'), jn(sd + 'ForeArm')], [.125, .43], [.06, .05])
    return f


def w_boot(sd):
    def f(p):
        return chain(p[2], [jn(sd + 'Foot'), jn(sd + 'ToeBase')], [.115], [.05])
    return f


# --- perfis anatômicos
LEG_Y = np.array([.09, .11, .16, .22, .28, .34, .40, .46, .50, .53, .58, .65, .75, .85, .93])
LEG_RX = np.array([.034, .034, .036, .042, .050, .055, .056, .056, .056, .058, .066, .075, .080, .083, .082])
LEG_RZF = np.array([.031, .030, .031, .035, .040, .045, .047, .050, .054, .058, .068, .080, .086, .088, .088])
LEG_RZB = np.array([.032, .032, .034, .044, .058, .068, .066, .056, .054, .056, .066, .078, .084, .086, .084])
LEG_CZ = np.array([-.003, -.003, -.004, -.006, -.010, -.012, -.010, -.004, 0, 0, 0, 0, 0, 0, 0])


def leg_ring(sd, y, grow=0.0, rx_k=1.0):
    s = 1 if sd == 'Left' else -1
    rx = np.interp(y, LEG_Y, LEG_RX) * rx_k + grow
    zf = np.interp(y, LEG_Y, LEG_RZF) + grow; zb = np.interp(y, LEG_Y, LEG_RZB) + grow
    cz = np.interp(y, LEG_Y, LEG_CZ)
    cx = s * (.09 + .003 * sstep((y - .5) / .4))
    c = np.array([cx, y, cz + (zf - zb) * .5])
    return _leg_pts(c, rx, zf, zb), c


def _leg_pts(c, rx, zf, zb):
    # seção assimétrica (frente zf / trás zb) com centro deslocado
    pts = []
    for k in range(LSEG):
        a = 2 * math.pi * k / LSEG; ca, sa = math.cos(a), math.sin(a)
        zz = ca * (zf if ca > 0 else zb) ; xx = sa * rx
        pts.append(np.array([c[0] + spow(sa, .92) * rx, c[1], c[2] - (zf - zb) * .5 + spow(ca, .92) * (zf if ca > 0 else zb)]))
    return np.array(pts)


LSEG = 12


def build_leg_skin(sd):
    ys = np.concatenate([np.linspace(.12, .93, 13)])
    ptl, ctrs = [], []
    for y in ys:
        pts, c = leg_ring(sd, y, grow=-.0035 if y < .6 else 0.0); ptl.append(pts); ctrs.append(c)
    def cf(p, i):
        y = p[1]; kn = G(y, 0, .50, 0, .03, 1) * .08
        return np.array([1 - kn * .3, 1 - kn, 1 - kn * 1.2])
    return loft_pts(ptl, ctrs, w_leg(sd), LSEG, bk=.12, cf=cf)


def build_socks(sd):
    ys = np.concatenate([np.linspace(.10, .50, 10)])
    ptl, ctrs = [], []
    for y in ys:
        pts, c = leg_ring(sd, y, grow=.0045); ptl.append(pts); ctrs.append(c)
    def cf(p, i):
        return np.ones(3) * (.93 + .07 * math.sin(i * 1.7)) * (.85 + .15 * sstep((p[1] - .10) / .08))
    S = loft_pts(ptl, ctrs, w_leg(sd), LSEG, bk=.12, caps=(True, False), cf=cf, uvs=True)
    ys2 = np.linspace(.495, .545, 4); ptl2, ctrs2 = [], []
    for y in ys2:
        pts, c = leg_ring(sd, y, grow=.0062); ptl2.append(pts); ctrs2.append(c)
    T = loft_pts(ptl2, ctrs2, w_leg(sd), LSEG, bk=.12, caps=(False, False))
    return S, T


def build_shorts_legs(sd):
    ys = [.585, .60, .66, .75, .85, .93]
    ptl, ctrs = [], []
    for y in ys:
        s = 1 if sd == 'Left' else -1
        t = sstep((.75 - y) / .17)
        rx = .093 + .014 * t; rz = .094 + .012 * t
        c = np.array([s * (.09 + .003 * sstep((y - .5) / .4)), y, 0.0])
        ptl.append(ring_pts(c, (0, 0, rz), (rx, 0, 0), LSEG, e=.9)); ctrs.append(c)
    def cf(p, i): return np.ones(3) * (.88 + .12 * sstep(i / 2))
    return loft_pts(ptl, ctrs, w_leg(sd), LSEG, bk=.11, caps=(False, False), cf=cf, uvs=True)


TOR_Y = np.array([.88, .93, 1.00, 1.08, 1.16, 1.24, 1.31, 1.37, 1.41, 1.44, 1.462, 1.472])
TOR_RX = np.array([.181, .176, .164, .155, .157, .171, .194, .210, .190, .140, .078, .063])
TOR_RZF = np.array([.126, .121, .111, .104, .106, .114, .124, .122, .108, .082, .062, .058])
TOR_RZB = np.array([.120, .114, .104, .097, .099, .106, .112, .110, .098, .078, .060, .056])
TLS = 20


def torso_ring_pts(y, grow=0.0, wr=0.0, salt=0.0):
    rx = np.interp(y, TOR_Y, TOR_RX) + grow; zf = np.interp(y, TOR_Y, TOR_RZF) + grow; zb = np.interp(y, TOR_Y, TOR_RZB) + grow
    pts = []
    for k in range(TLS):
        a = 2 * math.pi * k / TLS; ca, sa = math.cos(a), math.sin(a)
        x = spow(sa, .88) * rx; z = spow(ca, .88) * (zf if ca > 0 else zb) + (zf - zb) * .5 * 0 
        ax = abs(x)
        if ca > 0:     # peitoral + abdômen
            z += .011 * G(ax, y, .068, 1.30, .042, .034) + .004 * G(ax, y, .0, 1.30, .012, .05) * -1 + .003 * G(ax, y, .035, 1.12, .03, .07)
        else:          # escápulas / coluna
            z -= .006 * G(ax, y, .075, 1.30, .05, .05) - .003 * G(ax, y, 0, 1.2, .01, .12)
        x *= 1 + .035 * G(0, y, 0, 1.24, 1, .06) * (1 if True else 0)       # dorsais
        if y < 1.2 and wr:
            z += wr * math.sin(a * 5 + y * 26 + salt) * sstep((1.2 - y) / .3)
        pts.append((x, y, z))
    return np.array(pts), np.array([0, y, 0.0])


def build_torso_shirt():
    ys = np.concatenate([[.88, .895], np.linspace(.93, 1.41, 10), [1.44, 1.462, 1.472]])
    ptl, ctrs = [], []
    for i, y in enumerate(ys):
        flare = .012 * sstep((.99 - y) / .10) if y < 1 else 0
        p, c = torso_ring_pts(y, grow=.0075 + flare, wr=.0028, salt=1.3); ptl.append(p); ctrs.append(c)
    def bk(p, i):
        y = p[1]; return .02 + .10 * G(y, 0, 1.31, 0, .12, 1)
    def cf(p, i):
        y = p[1]
        sh = 1 - .07 * sstep((1.0 - y) / .12) - .05 * G(y, 0, 1.16, 0, .05, 1)
        return np.ones(3) * sh
    return loft_pts(ptl, ctrs, w_torso, TLS, bk=bk, caps=(False, False), cf=cf, uvs=True)


def build_collar():
    ptl, ctrs = [], []
    for y, r in [(1.466, .066), (1.480, .060), (1.496, .0575), (1.5, .0565)]:
        c = np.array([0, y, .006]); ptl.append(ring_pts(c, (0, 0, r * .96), (r, 0, 0), 16)); ctrs.append(c)
    return loft_pts(ptl, ctrs, lambda p: chain(p[1], [jn('Spine2'), jn('Neck')], [1.455], [.04]), 16, bk=.12, caps=(False, False))


ARM_S = np.array([.10, .17, .24, .30, .36, .43, .47, .52, .58, .64, .68])
ARM_RY = np.array([.050, .058, .056, .052, .046, .040, .042, .043, .037, .030, .026])
ARM_RZ = np.array([.052, .060, .058, .054, .047, .040, .043, .044, .036, .030, .025])
ASEG = 10


def arm_ring(sd, s_, grow=0.0):
    sg = 1 if sd == 'Left' else -1
    ry = np.interp(s_, ARM_S, ARM_RY) + grow; rz = np.interp(s_, ARM_S, ARM_RZ) + grow
    c = np.array([sg * s_, 1.40, 0.0])
    return ring_pts(c, (0, 0, rz), (0, ry, 0), ASEG, e=.95), c


def build_arm_skin(sd):
    ss = np.concatenate([np.linspace(.10, .43, 6), np.linspace(.47, .68, 5)])
    ptl, ctrs = [], []
    for s_ in ss:
        p, c = arm_ring(sd, s_, grow=-.0045 if s_ < .34 else 0.0); ptl.append(p); ctrs.append(c)
    def cf(p, i):
        s_ = abs(p[0]); el = G(s_, 0, .43, 0, .03, 1) * .10
        return np.array([1 - el * .3, 1 - el, 1 - el * 1.1]) * (.96 if p[1] < 1.40 - .03 else 1.0)
    return loft_pts(ptl, ctrs, w_arm(sd), ASEG, bk=.10, cf=cf)


def build_sleeve(sd):
    ss = np.linspace(.105, .30, 8); ptl, ctrs = [], []
    for s_ in ss:
        p, c = arm_ring(sd, s_, grow=.0085 + .003 * G(s_, 0, .17, 0, .06, 1)); ptl.append(p); ctrs.append(c)
    def cf(p, i):
        return np.ones(3) * (1 - .08 * G(p[1], 0, 1.40 - .055, 0, .03, 1) * (abs(p[0]) < .26))
    S = loft_pts(ptl, ctrs, w_shirt_arm(sd), ASEG, bk=.10, caps=(False, False), cf=cf, uvs=True)
    sg = 1 if sd == 'Left' else -1
    cap = ellipsoid((sg * .165, 1.396, 0), .047, .066, .064, w_shirt_arm(sd), 10, 6, bk=.10, cf=lambda lp, p: np.ones(3))
    ss2 = np.linspace(.297, .335, 3); ptl2, ctrs2 = [], []
    for s_ in ss2:
        p, c = arm_ring(sd, s_, grow=.0065); ptl2.append(p); ctrs2.append(c)
    cuff = loft_pts(ptl2, ctrs2, w_shirt_arm(sd), ASEG, bk=.10, caps=(False, False))
    return merge([S, cap]), cuff


def build_hand(sd):
    sg = 1 if sd == 'Left' else -1
    wf = w_arm(sd); parts = []
    pr = [(.675, .024, .019), (.70, .033, .017), (.735, .041, .0155), (.772, .040, .0125)]
    ptl, ctrs = [], []
    for s_, rz, ry in pr:
        c = np.array([sg * s_, 1.397, .0]); ptl.append(ring_pts(c, (0, 0, rz), (0, ry, 0), 8)); ctrs.append(c)
    parts.append(loft_pts(ptl, ctrs, wf, 8, bk=.05, cf=lambda p, i: np.array([1, .97, .95]) * (.96 if p[1] < 1.397 else 1)))
    for zo, ln in [(-.0275, .066), (-.0095, .076), (.0085, .072), (.0265, .056)]:
        p0 = np.array([sg * .765, 1.396, zo]); p1 = np.array([sg * (.765 + ln), 1.396 - .016 - ln * .10, zo * 1.15])
        parts.append(tube(p0, p1, .0078, .0058, 5, 3, wf, bk=.05, col=(.97, .93, .90)))
    p0 = np.array([sg * .705, 1.398, .030]); p1 = np.array([sg * .745, 1.392, .072])
    parts.append(tube(p0, p1, .0105, .0078, 5, 3, wf, bk=.05, col=(.97, .93, .90)))
    return merge(parts)


def build_gloves(sd):
    """luvas de goleiro (v4): punho com elástico, palma acolchoada e dedos grossos; cor aplicada pelo jogo (render.js)"""
    sg = 1 if sd == 'Left' else -1
    wf = w_arm(sd); parts = []
    rings = [(.612, .046, .046, .55), (.640, .048, .048, .55), (.668, .048, .046, .50), (.680, .038, .034, .90),
             (.700, .046, .031, 1.0), (.735, .054, .030, 1.0), (.772, .053, .026, 1.0)]
    ptl, ctrs, cs = [], [], []
    for s_, rz, ry, k in rings:
        c = np.array([sg * s_, 1.397, 0.0]); ptl.append(ring_pts(c, (0, 0, rz), (0, ry, 0), 10, e=.92)); ctrs.append(c); cs.append(k)
    parts.append(loft_pts(ptl, ctrs, wf, 10, bk=.05, cf=lambda p, i: np.ones(3) * cs[i] * (.88 if (p[1] < 1.397 and i >= 4) else 1.0)))
    for zo, ln in [(-.0305, .074), (-.0105, .086), (.0095, .082), (.0295, .064)]:
        p0 = np.array([sg * .755, 1.396, zo]); p1 = np.array([sg * (.755 + ln), 1.396 - .016 - ln * .10, zo * 1.22])
        parts.append(tube(p0, p1, .0112, .0094, 6, 4, wf, bk=.05, col=(.97, .97, .97)))
    p0 = np.array([sg * .700, 1.398, .034]); p1 = np.array([sg * .748, 1.390, .082])
    parts.append(tube(p0, p1, .0140, .0112, 6, 3, wf, bk=.05, col=(.97, .97, .97)))
    return merge(parts)


def build_gk_sleeves(sd):
    """manga longa do goleiro (v4): do fim da manga curta até o punho (a luva cobre a ponta)"""
    ss = np.linspace(.285, .622, 9); ptl, ctrs = [], []
    for s_ in ss:
        p, c = arm_ring(sd, s_, grow=.0095); ptl.append(p); ctrs.append(c)
    def cf(p, i):
        return np.ones(3) * (1 - .10 * G(abs(p[0]), 0, .43, 0, .03, 1) * 1) * (.78 if i >= len(ss) - 1 else 1.0)
    return loft_pts(ptl, ctrs, w_shirt_arm(sd), ASEG, bk=.10, caps=(False, False), cf=cf)


def build_gk_pants(sd):
    """calça comprida do goleiro (v4): do calção até o tornozelo, com leve alargamento na barra"""
    ys = np.concatenate([np.linspace(.62, .16, 9), [.12, .105]]); ptl, ctrs = [], []
    for y in ys:
        g = .0125 if y > .3 else .0105 + .0020 * sstep((.3 - y) / .2)
        pts, c = leg_ring(sd, y, grow=g, rx_k=1.0); ptl.append(pts); ctrs.append(c)
    def cf(p, i):
        kn = G(p[1], 0, .50, 0, .035, 1) * .10
        return np.ones(3) * (1 - kn) * (.80 if i >= len(ys) - 1 else 1.0)
    return loft_pts(ptl, ctrs, w_leg(sd), LSEG, bk=.12, caps=(False, False), cf=cf)


def build_neck():
    ys = np.linspace(1.395, 1.575, 8); ptl, ctrs = [], []
    for y in ys:
        r = .052 - .005 * sstep((y - 1.44) / .12); c = np.array([0, y, .006 + .012 * sstep((y - 1.45) / .12)])
        ptl.append(ring_pts(c, (0, 0, r * .95), (r, 0, 0), 12)); ctrs.append(c)
    return loft_pts(ptl, ctrs, w_neck, 12, bk=.16, caps=(True, False), cf=lambda p, i: np.ones(3) * (1 - .12 * sstep((1.50 - p[1]) / .06) * 0))


def build_shorts_pelvis():
    ys = [1.012, 1.00, .96, .91, .86, .83]; ptl, ctrs = [], []
    rx = [.162, .165, .171, .176, .178, .170]; rz = [.109, .111, .115, .118, .119, .112]
    for y, a, b in zip(ys, rx, rz):
        c = np.array([0, y, 0]); ptl.append(ring_pts(c, (0, 0, b), (a, 0, 0), TLS, e=.9)); ctrs.append(c)
    def cf(p, i): return np.ones(3) * (.82 + .18 * sstep(i / 1.2) if i < 2 else 1)
    return loft_pts(ptl, ctrs, w_torso_hips, TLS, bk=.06, caps=(False, True), cf=cf, uvs=True)


def w_torso_hips(p):
    return chain(p[1], [jn('Hips'), jn('Spine')], [1.0], [.05]) if p[1] > .9 else {jn('Hips'): 1.0}


def build_boot(sd):
    s = 1 if sd == 'Left' else -1
    Z = [-.085, -.062, -.02, .03, .08, .13, .18, .225, .255]
    RX = [.030, .038, .043, .047, .048, .046, .040, .030, .017]
    RY = [.037, .043, .047, .043, .035, .029, .025, .021, .015]
    YC = [.053, .057, .062, .053, .043, .037, .031, .027, .025]
    ptl, ctrs = [], []
    for z, rx, ry, yc in zip(Z, RX, RY, YC):
        c = np.array([s * .09, yc, z]); ptl.append(ring_pts(c, (0, ry, 0), (rx, 0, 0), 12, e=.9)); ctrs.append(c)
    def cf(p, i):
        yrel = p[1] - (ctrs[i][1])
        if yrel < -RY[i] * .55: return np.array([.20, .20, .20])         # sola
        v = 1.0 - .18 * (yrel < -RY[i] * .35) - .10 * sstep((.02 - p[2]) / .1) * 0
        return np.ones(3) * v
    return loft_pts(ptl, ctrs, w_boot(sd), 12, cf=cf, uvs=False)


def build_body():
    sk, sh, tr, so, shorts, bo = [], [], [], [], [], []
    sk.append(build_face_skin()); sk.append(build_neck())
    for s in (1, -1): sk.append(make_ear(s))
    sk.append(build_nose()); sk.append(build_lips()); sk.append(build_brows())
    eyes, lids = build_eyes(); sk.append(lids)
    for sd in ('Left', 'Right'):
        sk.append(build_leg_skin(sd)); sk.append(build_arm_skin(sd)); sk.append(build_hand(sd))
        S, T = build_socks(sd); so.append(S); tr.append(T)
        shorts.append(build_shorts_legs(sd)); bo.append(build_boot(sd))
        sl, cuff = build_sleeve(sd); sh.append(sl); tr.append(cuff)
    sh.append(build_torso_shirt()); tr.append(build_collar()); shorts.append(build_shorts_pelvis())
    return {'Skin': merge(sk), 'Shirt': merge(sh), 'Trim': merge(tr), 'Shorts': merge(shorts), 'Socks': merge(so), 'Boots': merge(bo), 'Eyes': eyes,
            'GKArms': merge([build_gk_sleeves(d) for d in ('Left', 'Right')]), 'Gloves': merge([build_gloves(d) for d in ('Left', 'Right')]),
            'GKPants': merge([build_gk_pants(d) for d in ('Left', 'Right')])}


# ------------------------------------------------------------------ animação (parâmetros -> quaternions)
def qmul(a, b):
    w1, x1, y1, z1 = a; w2, x2, y2, z2 = b
    return (w1*w2 - x1*x2 - y1*y2 - z1*z2, w1*x2 + x1*w2 + y1*z2 - z1*y2, w1*y2 - x1*z2 + y1*w2 + z1*x2, w1*z2 + x1*y2 - y1*x2 + z1*w2)


def qax(ax, deg):
    h = deg * D2R / 2; s = math.sin(h)
    return (math.cos(h), ax[0]*s, ax[1]*s, ax[2]*s)


def Rx(d): return qax((1, 0, 0), d)
def Ry(d): return qax((0, 1, 0), d)
def Rz(d): return qax((0, 0, 1), d)


ID = (1, 0, 0, 0)
DEF = dict(hipY=0.0, hipRx=0, hipRy=0, hipRz=0, spX=0, spY=0, spZ=0, hdX=0, hdY=0,
           LU=0, LK=0, LA=0, LAb=3, RU=0, RK=0, RA=0, RAb=3,
           LS=0, LH=75, LE=8, RS=0, RH=75, RE=8, LSh=0, RSh=0, lift=0.0)


def pose_to_q(P):
    q = {}
    q['Hips'] = qmul(qmul(Ry(P['hipRy']), Rz(P['hipRz'])), Rx(P['hipRx']))
    sx, sy, sz = P['spX'] / 3, P['spY'] / 3, P['spZ'] / 3
    for b in ('Spine', 'Spine1', 'Spine2'):
        q[b] = qmul(qmul(Ry(sy), Rz(sz)), Rx(sx))
    q['Neck'] = Rx(P['hdX'] * .4)
    q['Head'] = qmul(Ry(P['hdY']), Rx(P['hdX'] * .6))
    q['LeftShoulder'] = Rz(-P['LSh']); q['RightShoulder'] = Rz(P['RSh'])
    q['LeftArm'] = qmul(Rx(-P['LS']), Rz(-P['LH'])); q['RightArm'] = qmul(Rx(-P['RS']), Rz(P['RH']))
    q['LeftForeArm'] = Ry(-P['LE']); q['RightForeArm'] = Ry(P['RE'])
    q['LeftHand'] = ID; q['RightHand'] = ID
    q['LeftUpLeg'] = qmul(Rx(-P['LU']), Rz(P['LAb'])); q['RightUpLeg'] = qmul(Rx(-P['RU']), Rz(-P['RAb']))
    q['LeftLeg'] = Rx(P['LK']); q['RightLeg'] = Rx(P['RK'])
    q['LeftFoot'] = Rx(P['LA']); q['RightFoot'] = Rx(P['RA'])
    q['LeftToeBase'] = ID; q['RightToeBase'] = ID
    return q


def P_(**kw):
    d = dict(DEF); d.update(kw); return d


def smoothstep(t): return t * t * (3 - 2 * t)
def smoother(t): return t * t * t * (t * (6 * t - 15) + 10)
def lerp(a, b, u): return a + (b - a) * u
def clamp(x, a, b): return max(a, min(b, x))
def bell(w): return math.sin(math.pi * clamp(w, 0, 1))


# ---- espelhamento (mergulho para o outro lado etc.)
_PAIRS = [('LU', 'RU'), ('LK', 'RK'), ('LA', 'RA'), ('LAb', 'RAb'), ('LS', 'RS'), ('LH', 'RH'), ('LE', 'RE'), ('LSh', 'RSh')]
_NEG = ('hipRy', 'hipRz', 'spY', 'spZ', 'hdY')


def mirror(frames):
    out = []
    for P in frames:
        Q = dict(P)
        for a, b in _PAIRS: Q[a], Q[b] = P[b], P[a]
        for k in _NEG: Q[k] = -P[k]
        out.append(Q)
    return out


# ---- interpolação PCHIP (velocidade contínua, sem overshoot): movimento fluido entre as poses-chave
def _end_slope(h0, h1, d0, d1):
    m = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1)
    if m * d0 <= 0: return 0.0
    if d0 * d1 <= 0 and abs(m) > 3 * abs(d0): return 3 * d0
    return m


def _pchip(ts, ys):
    n = len(ts); h = [ts[i + 1] - ts[i] for i in range(n - 1)]
    d = [(ys[i + 1] - ys[i]) / h[i] if h[i] > 1e-9 else 0.0 for i in range(n - 1)]
    m = [0.0] * n
    if n == 2: m = [d[0], d[0]]
    else:
        for i in range(1, n - 1):
            if d[i - 1] * d[i] <= 0: m[i] = 0.0
            else:
                w1 = 2 * h[i] + h[i - 1]; w2 = h[i] + 2 * h[i - 1]
                m[i] = (w1 + w2) / (w1 / d[i - 1] + w2 / d[i])
        m[0] = _end_slope(h[0], h[1], d[0], d[1]); m[-1] = _end_slope(h[-1], h[-2], d[-1], d[-2])

    def f(t):
        if t <= ts[0]: return ys[0]
        if t >= ts[-1]: return ys[-1]
        i = 0
        while ts[i + 1] < t: i += 1
        hh = h[i]; u = (t - ts[i]) / hh
        h00 = 2 * u**3 - 3 * u**2 + 1; h10 = u**3 - 2 * u**2 + u; h01 = -2 * u**3 + 3 * u**2; h11 = u**3 - u**2
        return h00 * ys[i] + h10 * hh * m[i] + h01 * ys[i + 1] + h11 * hh * m[i + 1]
    return f


def keyed(keys, T, fps=60):
    ks = [(t, P_(**p)) for t, p in keys]; ts = [k[0] for k in ks]
    fn = {k: _pchip(ts, [kp[k] for _, kp in ks]) for k in DEF}
    n = int(round(T * fps)) + 1
    return [{k: fn[k](i / fps) for k in DEF} for i in range(n)]


# ---- cinemática de perna (IK de 2 ossos, plano sagital): pés firmes no chão, sem deslizar
L1, L2 = .43, .41


def ankle_y(pitch):
    p = math.radians(pitch)
    return .09 * math.cos(p) + (.15 * math.sin(p) if p > 0 else .07 * math.sin(-p))


def leg_ik(dz, dy):
    d = math.hypot(dz, dy); d = clamp(d, abs(L1 - L2) + 1e-3, L1 + L2 - 1e-3)
    K = 180 - math.degrees(math.acos(clamp((L1 * L1 + L2 * L2 - d * d) / (2 * L1 * L2), -1, 1)))
    al = math.atan2(dz, -dy); be = math.acos(clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1))
    return math.degrees(al + be), K


def plant(P, side, z, pitch=0.0, ay=None, lat=0.0):
    """posiciona o pé (side 'L'/'R') em z (m à frente do quadril) e altura do tornozelo; usa P['hipY']"""
    Hj = .93 + P['hipY']; ay = ankle_y(pitch) if ay is None else ay
    U, K = leg_ik(z, ay - Hj)
    P[side + 'U'] = U; P[side + 'K'] = K; P[side + 'A'] = pitch + U - K
    return P


def legs_under(K):
    """coxa/tornozelo que mantêm o pé sob o quadril com joelho flexionado K (agachamento com pé plano)"""
    k = math.radians(K); U = math.degrees(math.atan2(L2 * math.sin(k), L1 + L2 * math.cos(k)))
    return U, K, U - K


# ---- marcha procedural com pés planejados: o pé de apoio recua à velocidade V (sem patinar quando timeScale = vel/V)
def foot_path(u, g):
    d = g['d']; s = g['duty']; z0 = g['z0f'] * d; hs = g['hs']; po = g['po']
    if u < s:
        w = u / s
        pitch = hs * (1 - smoothstep(clamp(w / .22, 0, 1))) + po * smoothstep(clamp((w - .52) / .48, 0, 1))
        return z0 - d * w, ankle_y(pitch), pitch
    w = (u - s) / (1 - s); zend = z0 - d
    y = lerp(ankle_y(po), ankle_y(hs), smoothstep(w)) + g['clear'] * bell(w ** g['pk'])
    pitch = lerp(po, hs, smoothstep(w)) + g['dors'] * bell(w)
    return zend + (z0 - zend) * smoother(w), y, pitch


def make_gait(g, fps=60):
    n = int(round(g['T'] * fps)); g = dict(g); g['duty'] = g['d'] / (g['V'] * g['T']); fr = []
    for i in range(n):
        ph = i / n; c = math.cos(2 * math.pi * ph); s_ = math.sin(2 * math.pi * ph)
        Hj = g['H'] + g['bob'] * math.cos(4 * math.pi * (ph - g['duty'] / 2))
        P = P_(hipY=Hj - .93)
        for sd, off in (('L', 0.0), ('R', .5)):
            z, y, pit = foot_path((ph + off) % 1.0, g)
            U, K = leg_ik(z, y - Hj)
            P[sd + 'U'] = U; P[sd + 'K'] = K; P[sd + 'A'] = pit + U - K
        P['LAb'] = P['RAb'] = g.get('abd', 3)
        P['hipRy'] = -g['tw'] * c; P['hipRz'] = g['tilt'] * math.cos(2 * math.pi * (ph - g['duty'] / 2)); P['hipRx'] = g.get('pel', 0)
        P['spX'] = g['lean'] + g.get('spbob', 0) * math.cos(4 * math.pi * (ph - g['duty'] / 2)); P['spY'] = g['sptw'] * c; P['spZ'] = -g['tilt'] * .5 * math.cos(2 * math.pi * (ph - g['duty'] / 2))
        P['hdY'] = -(P['hipRy'] + P['spY']) * .85; P['hdX'] = -g['lean'] * .55 + g.get('head', 0)
        a = g['armA']; lag = 2 * math.pi * .03
        P['LS'] = -a * math.cos(2 * math.pi * ph - lag) + g.get('armOff', 0); P['RS'] = a * math.cos(2 * math.pi * ph - lag) + g.get('armOff', 0)
        for sd in 'LR':
            f = P[sd + 'S'] - g.get('armOff', 0)
            P[sd + 'E'] = g['e0'] + g['ea'] * (.5 + .5 * f / max(a, 1e-3))
            P[sd + 'H'] = g.get('hang', 75) - 4 * (f / max(a, 1e-3))
        fr.append(P)
    return fr


GAITS = {
    # V = velocidade de projeto (m/s) — o glb-system.js usa timeScale = velocidade_real / V
    'walk':    dict(V=1.4, T=1.10, d=.90, z0f=.55, H=.905, bob=.016, lean=3, armA=22, e0=14, ea=10, clear=.07, hs=-14, po=22, tw=4.5, sptw=7, tilt=3, pk=1.0, dors=-4, hang=77),
    'jog':     dict(V=3.8, T=.72, d=.95, z0f=.46, H=.855, bob=-.030, lean=9, armA=40, e0=88, ea=14, clear=.20, hs=-10, po=30, tw=7, sptw=9, tilt=3, pk=.75, dors=-8, hang=72),
    'run':     dict(V=6.3, T=.60, d=1.02, z0f=.42, H=.848, bob=-.035, lean=15, armA=55, e0=92, ea=14, clear=.27, hs=-6, po=38, tw=9, sptw=11, tilt=3, pk=.72, dors=-10, hang=68),
    'sprint':  dict(V=8.4, T=.52, d=1.10, z0f=.38, H=.840, bob=-.040, lean=22, armA=68, e0=92, ea=12, clear=.32, hs=0, po=45, tw=11, sptw=13, tilt=3, pk=.70, dors=-12, hang=64, abd=2),
    'dribble': dict(V=4.4, T=.66, d=.88, z0f=.45, H=.852, bob=-.026, lean=12, armA=24, e0=76, ea=6, clear=.17, hs=-8, po=28, tw=6, sptw=6, tilt=2.5, pk=.75, dors=-6, hang=66, head=14, abd=4),
}


# ---- contato com o chão: acha o ponto mais baixo do corpo e ajusta o quadril (hipY) -> nunca flutua nem afunda
def _probes():
    pr = [('Hips', (0, -.02, 0), .14), ('Hips', (0, -.07, -.07), .12), ('Spine1', (0, 0, -.05), .14), ('Spine2', (0, .04, -.06), .15),
          ('Spine2', (0, 0, .07), .12), ('Head', (0, .10, 0), .11)]
    for sd, sx in (('Left', 1), ('Right', -1)):
        pr += [(sd + 'Arm', (.12 * sx, 0, 0), .06), (sd + 'ForeArm', (.12 * sx, 0, 0), .05), (sd + 'Hand', (.09 * sx, 0, 0), .05),
               (sd + 'UpLeg', (0, -.2, -.02), .09), (sd + 'Leg', (0, 0, .03), .07), (sd + 'Leg', (0, -.2, -.02), .06),
               (sd + 'Foot', (0, -.09, -.07), 0), (sd + 'ToeBase', (0, -.04, .04), 0), (sd + 'ToeBase', (0, -.04, .11), 0)]
    return pr


PROBES = _probes()


def lowest(P):
    Q = dict(P); Q['hipY'] = 0.0; Wm = fk(Q); m = 9.0
    for jn, off, r in PROBES:
        R, t = Wm[IDX[jn]]; m = min(m, (t + R @ np.array(off))[1] - r)
    return m


def lock_ground(frames):
    out = []
    for P in frames:
        Q = dict(P); Q['hipY'] = -lowest(P) + P['lift']; out.append(Q)
    return out


def loop_ok(frames, name=''):
    return frames


SL_END = dict(hipRx=-70, spX=-6, hipRy=8, hdX=16, LU=6, LK=152, LA=14, RU=22, RK=4, RA=-26, LS=-56, RS=-40, LH=42, RH=30, LE=16, RE=10, LAb=12, RAb=4)


def clips():
    C = {}
    # ---------------- parado: respiração, troca de apoio, olhar curioso (ciclo de 4 s)
    n = 120; fr = []
    for i in range(n):
        ph = 2 * math.pi * i / n; sh = math.sin(ph)               # troca de peso lenta
        br = math.sin(ph * 4)                                       # respiração
        P = P_(hipY=-.020 - .003 * (1 - math.cos(ph * 2)) / 2 + .0025 * br, hipRz=2.0 * sh, hipRy=3 * math.sin(ph) * .5 + 4, spX=2.5 + .9 * br, spY=-4 + 2 * sh, spZ=-1.8 * sh,
               hdX=-1.5 - .5 * br, hdY=-2 + 7 * math.sin(ph) * math.cos(ph * .5), LAb=7 + 1.5 * sh, RAb=7 - 1.5 * sh,
               LH=78 + 1.2 * br, RH=78 + 1.2 * br, LE=12 + 3 * sh, RE=12 - 3 * sh, LS=-3 + 2 * sh, RS=-3 - 2 * sh, LSh=1 + .8 * br, RSh=1 + .8 * br)
        # pés plantados: pé esquerdo levemente à frente, direito atrás (postura relaxada de atleta)
        plant(P, 'L', .10 + .01 * sh, pitch=0); plant(P, 'R', -.06, pitch=0)
        fr.append(P)
    C['idle'] = (fr, 4.0, True)

    # ---------------- goleiro em guarda: joelhos flexionados, braços abertos, quica nos dedos
    n = 54; fr = []
    for i in range(n):
        ph = 2 * math.pi * i / n; bn = math.sin(ph * 2)
        P = P_(hipY=-.20 + .018 * bn, spX=24 + 1.2 * bn, hdX=-20, hdY=2.5 * math.sin(ph), hipRy=2 * math.sin(ph), LAb=15, RAb=15,
               LH=40 + 2 * bn, RH=40 + 2 * bn, LS=24 + 3 * bn, RS=24 + 3 * bn, LE=72 - 5 * bn, RE=72 - 5 * bn, LSh=0)
        plant(P, 'L', .06 + .0 * bn, pitch=-2 + 5 * max(0, bn)); plant(P, 'R', .06, pitch=-2 + 5 * max(0, bn))
        fr.append(P)
    C['gkidle'] = (fr, 1.8, True)

    # ---------------- goleiro segurando a bola junto ao peito
    n = 60; fr = []
    for i in range(n):
        ph = 2 * math.pi * i / n; br = math.sin(ph * 3)
        P = P_(hipY=-.04 + .002 * br, spX=6 + .6 * br, hdX=4, hdY=4 * math.sin(ph), hipRy=0, LAb=6, RAb=6,
               LH=66, RH=66, LS=58, RS=58, LE=102 + 2 * br, RE=102 + 2 * br, LSh=3, RSh=3)
        plant(P, 'L', .05, 0); plant(P, 'R', -.02, 0)
        fr.append(P)
    C['gkhold'] = (fr, 2.0, True)

    for k, g in GAITS.items(): C[k] = (make_gait(g), g['T'], True)
    C['run_g'] = C['run']  # (alias interno, removido no final)
    del C['run_g']

    # ---------------- chute (perna direita) — o contato com a bola acontece em ~0,08 s (a bola sai no instante em que o clipe começa)
    K = [
        (0.00, dict(hipY=-.045, hipRy=-8, hipRz=-1, spX=14, spY=10, spZ=-2, hdX=8, RU=-34, RK=104, RA=44, RAb=0, LAb=4, LS=36, RS=-34, LH=60, RH=52, LE=48, RE=40)),
        (0.04, dict(hipY=-.052, hipRy=-1, spX=15, spY=3, hdX=10, RU=-4, RK=100, RA=44, RAb=0, LAb=4, LS=30, RS=-20, LH=60, RH=54, LE=46, RE=40)),
        (0.085, dict(hipY=-.055, hipRy=14, hipRz=1.5, spX=13, spY=-12, hdX=14, RU=46, RK=30, RA=40, RAb=0, LAb=4, LS=-22, RS=32, LH=62, RH=58, LE=40, RE=40)),
        (0.16, dict(hipY=-.050, hipRy=22, spX=11, spY=-18, hdX=12, RU=82, RK=16, RA=30, RAb=0, LAb=4, LS=-34, RS=44, LH=62, RH=60, LE=36, RE=34)),
        (0.26, dict(hipY=-.040, hipRy=18, spX=8, spY=-14, hdX=6, RU=72, RK=30, RA=20, RAb=2, LAb=4, LS=-26, RS=34, LH=66, RH=64, LE=30, RE=30)),
        (0.36, dict(hipY=-.030, hipRy=8, spX=6, spY=-6, hdX=2, RU=36, RK=36, RA=8, RAb=3, LAb=4, LS=-10, RS=14, LH=70, RH=70, LE=24, RE=22)),
        (0.46, dict(hipY=-.022, hipRy=2, spX=3, spY=0, hdX=0, RU=10, RK=14, RA=2, RAb=5, LAb=5, LS=-2, RS=0, LH=74, RH=74, LE=14, RE=14)),
    ]
    fr = keyed(K, .46)
    for P in fr:
        plant(P, 'L', .12, pitch=4)
        for _ in range(4):                       # a chuteira nunca atravessa o gramado: sobe o quadril e replanta a perna de apoio
            m = lowest(P) + P['hipY']
            if m >= -.004: break
            P['hipY'] += -m; plant(P, 'L', .12, pitch=4)
    C['kick'] = (fr, .46, False)

    # ---------------- carrinho: entrada rápida, desliza no gramado com a perna direita estendida (0,55 s)
    K = [
        (0.00, dict(spX=16, hipY=-.06, hdX=4, LU=22, LK=70, LA=14, RU=30, RK=40, LS=-40, RS=45, LH=62, RH=60, LE=70, RE=60)),
        (0.10, dict(hipRx=-28, spX=6, hdX=0, hipY=-.20, LU=24, LK=100, LA=20, RU=34, RK=18, RA=-8, LS=-58, RS=-20, LH=46, RH=40, LE=40, RE=30, LAb=8, lift=.06)),
        (0.22, dict(SL_END, hipRx=-58, LK=130, RU=26, lift=.02)),
        (0.34, dict(SL_END)),
        (0.55, dict(SL_END)),
    ]
    C['slide'] = (lock_ground(keyed(K, .55)), .55, False)

    # ---------------- levantar (depois do carrinho / do mergulho): do chão para a posição de jogo (0,5 s)
    K = [
        (0.00, dict(SL_END)),
        (0.14, dict(hipRx=-30, spX=26, hdX=-4, hipRy=0, LU=60, LK=120, LA=40, RU=40, RK=100, RA=30, LS=30, RS=10, LH=50, RH=50, LE=60, RE=60, LAb=8)),
        (0.30, dict(hipRx=0, spX=34, hdX=-12, LU=40, LK=88, LA=10, RU=44, RK=92, RA=10, LS=26, RS=28, LH=50, RH=50, LE=60, RE=60, LAb=6)),
        (0.50, dict(hipRx=0, spX=6, hdX=-2, LU=2, LK=6, RU=2, RK=6, LS=0, RS=0, LH=75, RH=75, LE=12, RE=12, LAb=5)),
    ]
    C['getup'] = (lock_ground(keyed(K, .50)), .50, False)

    # ---------------- cabeceio / salto: agacha, impulsiona, cabeceia no ápice, amortece a queda (0,55 s)
    K = [
        (0.00, dict(spX=8, LH=75, RH=75, LE=12, RE=12, LS=0, RS=0)),
        (0.08, dict(spX=24, hdX=-8, LS=-40, RS=-40, LH=60, RH=60, LE=24, RE=24, LAb=8, RAb=8, **dict(zip(('LU', 'LK', 'LA'), legs_under(70))), **dict(zip(('RU', 'RK', 'RA'), legs_under(70))))),
        (0.17, dict(spX=-12, hdX=-14, LS=-120, RS=-120, LH=40, RH=40, LE=10, RE=10, LU=2, RU=2, LK=4, RK=4, LA=36, RA=36, lift=.34)),
        (0.27, dict(spX=-16, hdX=-18, LS=-100, RS=-96, LH=36, RH=36, LE=20, RE=20, LU=8, RU=14, LK=34, RK=62, LA=26, RA=24, lift=.50)),
        (0.33, dict(spX=18, hdX=24, LS=-30, RS=-28, LH=48, RH=48, LE=40, RE=40, LU=14, RU=24, LK=40, RK=60, LA=22, RA=20, lift=.46)),
        (0.44, dict(spX=18, hdX=4, LS=10, RS=10, LH=60, RH=60, LE=40, RE=40, **dict(zip(('LU', 'LK', 'LA'), legs_under(26))), **dict(zip(('RU', 'RK', 'RA'), legs_under(26))), lift=.06)),
        (0.55, dict(spX=8, hdX=0, LS=0, RS=0, LH=72, RH=72, LE=14, RE=14, **dict(zip(('LU', 'LK', 'LA'), legs_under(46))), **dict(zip(('RU', 'RK', 'RA'), legs_under(46))), LAb=6, RAb=6)),
    ]
    C['jump'] = (lock_ground(keyed(K, .55)), .55, False)

    # ---------------- mergulho do goleiro (para a esquerda do personagem; 'diveR' é o espelho). Termina deitado de lado.
    K = [
        (0.00, dict(hipY=-.20, spX=24, hdX=-20, LAb=15, RAb=15, LH=40, RH=40, LS=24, RS=24, LE=72, RE=72, **dict(zip(('LU', 'LK', 'LA'), legs_under(66))), **dict(zip(('RU', 'RK', 'RA'), legs_under(66))))),
        (0.10, dict(hipRz=-30, hipRy=0, spX=14, hdX=-14, hdY=-14, LAb=20, RAb=10, LH=-20, RH=-30, LS=-20, RS=-24, LE=10, RE=12, LU=30, LK=80, RU=-10, RK=20, RA=30, lift=.04)),
        (0.22, dict(hipRz=-78, spX=2, hdX=-8, hdY=-6, LAb=12, RAb=6, LH=-78, RH=-70, LS=-4, RS=-2, LE=3, RE=3, LU=10, LK=24, RU=18, RK=30, LA=22, RA=26, lift=.42)),
        (0.32, dict(hipRz=-84, spX=2, hdX=-8, hdY=-6, LAb=12, RAb=6, LH=-82, RH=-72, LS=-4, RS=-2, LE=3, RE=3, LU=14, LK=34, RU=18, RK=36, LA=22, RA=26, lift=.26)),
        (0.44, dict(hipRz=-88, spX=2, hdX=-4, hdY=-6, LAb=12, RAb=6, LH=-84, RH=-74, LS=-4, RS=-2, LE=4, RE=4, LU=14, LK=34, RU=18, RK=38, LA=22, RA=26, lift=.0)),
        (0.60, dict(hipRz=-88, spX=2, hdX=-4, hdY=-6, LAb=12, RAb=6, LH=-84, RH=-74, LS=-4, RS=-2, LE=4, RE=4, LU=14, LK=34, RU=18, RK=38, LA=22, RA=26, lift=.0)),
    ]
    dv = lock_ground(keyed(K, .60))
    C['dive'] = (dv, .60, False); C['diveR'] = (mirror(dv), .60, False)

    # ---------------- desequilíbrio / trombada (0,55 s): projeta o corpo, abre os braços e recupera o equilíbrio
    K = [
        (0.00, dict(spX=10, hipY=-.03, LU=14, RU=8, LK=24, RK=18, LS=10, RS=10, LH=70, RH=70, LE=40, RE=40)),
        (0.10, dict(hipRx=14, hipRy=-8, spX=30, spY=10, hdX=-14, hipY=-.12, LU=46, RU=-16, LK=64, RK=44, LA=-10, RA=16, LS=-52, RS=-26, LH=34, RH=30, LE=24, RE=30, LAb=8, RAb=3)),
        (0.24, dict(hipRx=22, hipRy=6, spX=36, spY=-8, hdX=-24, hipY=-.20, LU=52, RU=30, LK=70, RK=26, LA=-6, RA=4, LS=-44, RS=-50, LH=24, RH=22, LE=18, RE=16, LAb=12, RAb=10)),
        (0.40, dict(hipRx=6, spX=22, hdX=-12, hipY=-.12, LU=34, RU=24, LK=56, RK=40, LS=-16, RS=-20, LH=42, RH=42, LE=34, RE=34, LAb=8, RAb=8)),
        (0.55, dict(hipRx=0, spX=8, hdX=0, hipY=-.04, LU=12, RU=10, LK=20, RK=18, LS=0, RS=0, LH=72, RH=72, LE=16, RE=16)),
    ]
    C['fall'] = (keyed(K, .55), .55, False)

    # ---------------- comemorações
    def loop_clip(fn, T, fps=60):
        n = int(round(T * fps)); return ([fn(2 * math.pi * i / n) for i in range(n)], T, True)
    # 1) pulo com os braços abertos, grito, soco no ar
    def c1(p):
        s = math.sin(p); j = max(0, s) ** .8
        U, Kk, A = legs_under(50 * (1 - j) + 8)
        return P_(lift=.30 * j, hipY=-.0, spX=-6 + 10 * (1 - j), hdX=-18 + 10 * (1 - j), hdY=6 * math.sin(p * .5), LU=U, RU=U, LK=Kk, RK=Kk, LA=A + 18 * j, RA=A + 18 * j, LAb=6, RAb=6,
                  LH=-62 - 14 * j + 6 * math.sin(p * 2), RH=-62 - 14 * j - 6 * math.sin(p * 2), LS=-10 + 8 * math.sin(p * 2), RS=-10 - 8 * math.sin(p * 2), LE=34 + 18 * (1 - j), RE=34 + 18 * (1 - j), LSh=-2, RSh=-2)
    C['celebrate1'] = (lock_ground(loop_clip(c1, 1.0)[0]), 1.0, True)
    # 2) estilo "avião": corre de braços abertos inclinando o corpo (usa a marcha de corrida)
    g = dict(GAITS['run']); g.update(armA=0, e0=8, ea=0, hang=4, lean=10, sptw=4, tw=6)
    fr = make_gait(g)
    for i, P in enumerate(fr):
        ph = 2 * math.pi * i / len(fr); P['hipRz'] += 7 * math.sin(ph * 2) * .3; P['spZ'] += -9 * math.sin(ph * 2 + .5) * .3; P['LS'] = 4; P['RS'] = 4; P['hdX'] = -8
    C['celebrate4'] = (fr, g['T'], True)
    # 3) apontando para o céu, mão no peito, cabeça erguida (parado)
    def c3(p):
        br = math.sin(p * 2); s = math.sin(p)
        P = P_(hipY=-.03 + .004 * br, hipRz=2 * s, hipRy=8, spX=-5 + .8 * br, spY=-6, hdX=-22, hdY=4 * s, LAb=8, RAb=8,
               RH=-88 + 5 * math.sin(p * 4), RS=-8, RE=14, LH=62, LS=34, LE=96, LSh=2, RSh=-3)
        plant(P, 'L', .09, 0); plant(P, 'R', -.05, 0); return P
    C['celebrate3'] = loop_clip(c3, 2.0)
    # 5) correndo com os dois punhos cerrados ao alto (usa marcha de corrida)
    g = dict(GAITS['run']); g.update(armA=0, e0=100, ea=0, hang=-40, lean=8, sptw=3, tw=6, head=-14)
    fr = make_gait(g)
    for i, P in enumerate(fr):
        ph = 2 * math.pi * i / len(fr); a = 10 * math.sin(ph * 2)
        P['LS'] = -10 + a; P['RS'] = -10 - a; P['LH'] = -35; P['RH'] = -35; P['LE'] = 100 + a; P['RE'] = 100 - a; P['hdX'] = -18
    C['celebrate5'] = (fr, g['T'], True)
    # 2') versão parada do "avião" -> dança de ombros com os braços abertos (celebrate2: usada quando o jogador já parou)
    def c2(p):
        s = math.sin(p); br = math.sin(p * 2)
        U, Kk, A = legs_under(22 + 10 * abs(br))
        return P_(hipY=-.0, hipRz=6 * s, hipRy=14 * s, spX=10, spZ=-6 * s, hdX=-6, hdY=-12 * s, LU=U, RU=U, LK=Kk + 4 * s, RK=Kk - 4 * s, LA=A, RA=A, LAb=10, RAb=10,
                  LH=-6 + 8 * s, RH=-6 - 8 * s, LS=2, RS=2, LE=8, RE=8, **{}) 
    fr = [c2(2 * math.pi * i / 36) for i in range(36)]
    for P in fr: P['lift'] = 0
    C['celebrate2'] = (lock_ground(fr), 1.2, True)
    return C


# ------------------------------------------------------------------ cinemática direta (pré-visualização)
def qmat(q):
    w, x, y, z = q
    return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])


def fk(P):
    q = pose_to_q(P)
    n = len(J); Wm = [None] * n
    for i, (name, par, wp) in enumerate(J):
        R = qmat(q[name]); pw = np.array(wp)
        if par is None:
            t = pw + np.array([0, P['hipY'], 0]); Wm[i] = (np.eye(3) @ R, t); continue
        pi_ = IDX[par]; PR, PT = Wm[pi_]
        loc = pw - WPOS[pi_]
        Wm[i] = (PR @ R, PT + PR @ loc)
    return Wm




# ------------------------------------------------------------------ pesos / skinning
def jw_arrays(P):
    n = len(P.v); J4 = np.zeros((n, 4), np.uint8); W4 = np.zeros((n, 4), np.float32)
    for i, d in enumerate(P.w):
        it = sorted(d.items(), key=lambda kv: -kv[1])[:4]
        tot = sum(w for _, w in it) or 1.0
        for k, (j_, w_) in enumerate(it): J4[i, k] = j_; W4[i, k] = w_ / tot
        if not it: W4[i, 0] = 1
    return J4, W4


def skin_verts(P, pose, v=None):
    """pré-visualização: skinning linear com até 4 ossos"""
    Wm = fk(pose); Rs = np.array([w[0] for w in Wm]); Ts = np.array([w[1] for w in Wm])
    v = P.v if v is None else v
    J4, W4 = jw_arrays(P); out = np.zeros_like(v)
    for k in range(4):
        j_ = J4[:, k]; w_ = W4[:, k][:, None]
        loc = v - WPOS[j_]
        out += w_ * (np.einsum('nij,nj->ni', Rs[j_], loc) + Ts[j_])
    return out


# ------------------------------------------------------------------ escrita GLB
def srgb2lin(h):
    h = h.lstrip('#'); c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    return [((x + .055) / 1.055) ** 2.4 if x > .04045 else x / 12.92 for x in c]


HEAD_KINDS = ['FaceWidth', 'FaceLength', 'Jaw']


def morphs_for(name, P):
    M = {}
    if name in ('Skin', 'Shirt', 'Trim', 'Shorts', 'Socks', 'GKArms', 'Gloves', 'GKPants'):
        M['Build'] = (P.v - P.ctr) * P.bk[:, None]
    if name == 'Skin' or name == 'Eyes' or name.startswith('Hair_') or name.startswith('Beard_'):
        for k in HEAD_KINDS: M[k] = head_warp(P.v, k) * P.hd[:, None]
    return M


def write_glb(path, meshes, mats, clipset, default_mats):
    buf = bytearray(); bv = []; acc = []

    def add_view(data, target=None):
        while len(buf) % 4: buf.append(0)
        off = len(buf); buf.extend(data)
        d = {'buffer': 0, 'byteOffset': off, 'byteLength': len(data)}
        if target: d['target'] = target
        bv.append(d); return len(bv) - 1

    def add_acc(data, ctype, count, atype, target=None, minmax=None, norm=False):
        v = add_view(data, target)
        a = {'bufferView': v, 'componentType': ctype, 'count': count, 'type': atype}
        if norm: a['normalized'] = True
        if minmax: a['min'], a['max'] = minmax
        acc.append(a); return len(acc) - 1

    nodes = []
    for i, (name, par, wp) in enumerate(J):
        loc = (np.array(wp) - (WPOS[IDX[par]] if par else 0)).tolist()
        nodes.append({'name': BN[i], 'translation': [round(x, 5) for x in loc]})
    for i, (name, par, wp) in enumerate(J):
        if par: nodes[IDX[par]].setdefault('children', []).append(i)
    arm = len(nodes); nodes.append({'name': 'Armature', 'children': [0]})
    ibm = np.zeros((len(J), 16), np.float32)
    for i in range(len(J)):
        m = np.eye(4); m[:3, 3] = -WPOS[i]; ibm[i] = m.T.flatten()
    ibm_acc = add_acc(ibm.tobytes(), 5126, len(J), 'MAT4')
    skins = [{'name': 'Skeleton', 'inverseBindMatrices': ibm_acc, 'joints': list(range(len(J))), 'skeleton': arm}]
    gmeshes, mesh_nodes, materials, matidx = [], [], [], {}
    for mname, P in meshes.items():
        base = 'Hair' if mname.startswith(('Hair_', 'Beard_')) else mname
        if base not in matidx:
            c, rough, metal, dbl = mats[base]
            materials.append({'name': base, 'pbrMetallicRoughness': {'baseColorFactor': srgb2lin(c) + [1], 'metallicFactor': metal, 'roughnessFactor': rough}, 'doubleSided': dbl})
            matidx[base] = len(materials) - 1
        pos = P.v.astype(np.float32); nor = smooth_normals(P).astype(np.float32)
        J4, W4 = jw_arrays(P); col = np.clip(P.col, 0, 4).astype(np.float32)
        idx = P.f.astype(np.uint16).flatten()
        assert len(pos) < 65535
        a_p = add_acc(pos.tobytes(), 5126, len(pos), 'VEC3', 34962, [pos.min(0).tolist(), pos.max(0).tolist()])
        a_n = add_acc(nor.tobytes(), 5126, len(pos), 'VEC3', 34962)
        a_c = add_acc(col.tobytes(), 5126, len(pos), 'VEC3', 34962)
        a_j = add_acc(J4.tobytes(), 5121, len(pos), 'VEC4', 34962)
        a_w = add_acc(W4.tobytes(), 5126, len(pos), 'VEC4', 34962)
        a_i = add_acc(idx.tobytes(), 5123, len(idx), 'SCALAR', 34963)
        attrs = {'POSITION': a_p, 'NORMAL': a_n, 'COLOR_0': a_c, 'JOINTS_0': a_j, 'WEIGHTS_0': a_w}
        if P.uv is not None and mname in ('Shirt', 'Shorts', 'Socks'):
            attrs['TEXCOORD_0'] = add_acc(P.uv.astype(np.float32).tobytes(), 5126, len(pos), 'VEC2', 34962)
        prim = {'attributes': attrs, 'indices': a_i, 'material': matidx[base]}
        M = morphs_for(mname, P); names = list(M.keys())
        if names:
            prim['targets'] = []
            for k in names:
                d = M[k].astype(np.float32)
                prim['targets'].append({'POSITION': add_acc(d.tobytes(), 5126, len(pos), 'VEC3', 34962, [d.min(0).tolist(), d.max(0).tolist()])})
        gm = {'name': mname, 'primitives': [prim]}
        node = {'name': mname, 'mesh': len(gmeshes), 'skin': 0}
        if names:
            gm['extras'] = {'targetNames': names}; gm['weights'] = [0.0] * len(names); node['extras'] = {'targetNames': names}
        gmeshes.append(gm); mesh_nodes.append(len(nodes)); nodes.append(node)
    anims = []
    for cname, (frames, T, loop) in clipset.items():
        frames = list(frames)
        if loop: fps = len(frames) / T; frames.append(frames[0])      # ciclo fechado: o último quadro = o primeiro (sem solavanco no loop)
        else: fps = (len(frames) - 1) / T
        n = len(frames); times = np.array([i / fps for i in range(n)], np.float32)
        a_t = add_acc(times.tobytes(), 5126, n, 'SCALAR', None, [[float(times.min())], [float(times.max())]])
        samplers = []; channels = []
        qs = [pose_to_q(P) for P in frames]
        for bi, (bname, par, wp) in enumerate(J):
            arr = np.array([q[bname] for q in qs], np.float32)[:, [1, 2, 3, 0]]
            for k in range(1, n):
                if np.dot(arr[k], arr[k - 1]) < 0: arr[k] = -arr[k]
            a_q = add_acc(arr.tobytes(), 5126, n, 'VEC4')
            samplers.append({'input': a_t, 'output': a_q, 'interpolation': 'LINEAR'})
            channels.append({'sampler': len(samplers) - 1, 'target': {'node': bi, 'path': 'rotation'}})
        hp = np.array([list(J[0][2]) for _ in range(n)], np.float32)
        for k, P in enumerate(frames): hp[k, 1] = J[0][2][1] + P['hipY']
        a_h = add_acc(hp.tobytes(), 5126, n, 'VEC3')
        samplers.append({'input': a_t, 'output': a_h, 'interpolation': 'LINEAR'})
        channels.append({'sampler': len(samplers) - 1, 'target': {'node': 0, 'path': 'translation'}})
        anims.append({'name': cname, 'samplers': samplers, 'channels': channels})
    g = {'asset': {'version': '2.0', 'generator': 'Goal Horizon player generator v2 + animações v3', 'extras': {'goalHorizon': {'playerModel': 4, 'gk': ['GKArms', 'Gloves', 'GKPants'], 'hair': [k for k in meshes if k.startswith('Hair_')], 'beards': [k for k in meshes if k.startswith('Beard_')]}}},
         'scene': 0, 'scenes': [{'name': 'Scene', 'nodes': [arm] + mesh_nodes}], 'nodes': nodes, 'meshes': gmeshes,
         'materials': materials, 'skins': skins, 'animations': anims, 'accessors': acc, 'bufferViews': bv, 'buffers': [{'byteLength': len(buf)}]}
    js = json.dumps(g, separators=(',', ':')).encode()
    while len(js) % 4: js += b' '
    while len(buf) % 4: buf.append(0)
    with open(path, 'wb') as f:
        f.write(struct.pack('<4sII', b'glTF', 2, 12 + 8 + len(js) + 8 + len(buf)))
        f.write(struct.pack('<I4s', len(js), b'JSON')); f.write(js)
        f.write(struct.pack('<I4s', len(buf), b'BIN\x00')); f.write(buf)


MATS = {'Skin': ('#d9a47a', .58, 0.0, False), 'Shirt': ('#1f5fd6', .72, 0.0, True), 'Trim': ('#ffffff', .70, 0.0, True),
        'Shorts': ('#ffffff', .66, 0.0, True), 'Socks': ('#1f5fd6', .86, 0.0, True), 'Boots': ('#d8dadd', .38, 0.1, False),
        'Eyes': ('#ffffff', .16, 0.0, False), 'Hair': ('#161210', .52, 0.0, True),
        'GKArms': ('#2fbf6a', .72, 0.0, True), 'Gloves': ('#d9ff3a', .60, 0.0, True), 'GKPants': ('#222222', .68, 0.0, True)}


def build_all():
    M = build_body()
    for k, v in build_hair_styles().items(): M['Hair_' + k] = v
    for k, v in build_beards().items(): M['Beard_' + k] = v
    return {k: v for k, v in M.items() if len(v.v) > 3 and len(v.f) > 0}


# arquivos legados (render.js antigo escolhia a variante mais próxima da pele). Todos agora têm o modelo completo.
SKINS = [('1-claro', '#f1c9a5'), ('2-moreno-claro', '#d9a47a'), ('3-moreno', '#b87a4e'), ('4-negro-retinto', '#8a5a38'), ('5-negro-escuro', '#5e3b24')]

if __name__ == '__main__':
    meshes = build_all(); cs = clips()
    print({k: len(v.v) for k, v in meshes.items()})
    if '--nowrite' in sys.argv: sys.exit(0)
    os.makedirs(os.path.join(OUT, 'players'), exist_ok=True)
    path = os.path.join(OUT, 'player.glb'); write_glb(path, meshes, MATS, cs, None)
    print(path, os.path.getsize(path) // 1024, 'KB')
    for name, skin in (SKINS if '--legado' in sys.argv else []):
        m = dict(MATS); m['Skin'] = (skin, .58, 0.0, False)
        path = os.path.join(OUT, 'players', f'player-{name}.glb'); write_glb(path, meshes, m, cs, None)
        print(path, os.path.getsize(path) // 1024, 'KB')
