#!/usr/bin/env node
'use strict';
/* =====================================================================
   GOAL HORIZON — IMPORTADOR/VALIDADOR DE ELENCOS
   Uso:   node tools/importar-elencos.js          valida players/*.json e atualiza index.json + bundle.js
          node tools/importar-elencos.js --check  só valida (não grava nada)
   - Cada arquivo players/<qualquer-nome>.json = um clube ("clubId" do clubs.js).
   - Arquivos que começam com "_" (ex.: _modelo-elenco.json) são ignorados.
   - Arquivos com erro NÃO entram no jogo; o jogo continua funcionando sem eles.
   ===================================================================== */
const fs=require('fs'),path=require('path'),vm=require('vm');
const ROOT=path.join(__dirname,'..'),DIR=path.join(ROOT,'players');
const FCS=require(path.join(ROOT,'squads.js'));
const check=process.argv.includes('--check');

// carrega o banco de clubes (clubs.js é um script de navegador)
const ctx={console,location:{protocol:'file:'},document:{},window:{}};ctx.window=ctx;
vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(ROOT,'clubs.js'),'utf8')+'\n;this.__FC={FC_BY_ID,FC_CLUBS,fcSearch};',ctx);
const {FC_BY_ID,FC_CLUBS,fcSearch}=ctx.__FC;
const lookup=id=>FC_BY_ID[id]||null;
const find=t=>{const k=FCS.norm(t);const m=FC_CLUBS.filter(c=>FCS.norm(c.slug)===k||FCS.norm(c.name)===k||c.id.split('.').pop()===k.replace(/ /g,''));return m.length===1?m[0]:null;};

if(!fs.existsSync(DIR)){console.error('Pasta players/ não encontrada.');process.exit(1);}
const files=fs.readdirSync(DIR).filter(f=>/\.json$/i.test(f)&&f[0]!=='_'&&f!=='index.json').sort();
const ok=[],squads=[],byClub={},byPlayerId={},byPerson={};let bad=0,warn=0;

for(const f of files){
  let obj;
  try{obj=JSON.parse(fs.readFileSync(path.join(DIR,f),'utf8'));}
  catch(e){console.log('✗ '+f+'\n    JSON inválido: '+e.message);bad++;continue;}
  const v=FCS.validateSquadFile(obj,f,lookup,find),errs=v.errors.slice(),ws=v.warnings.slice();
  if(v.ok&&v.clubId){
    if(byClub[v.clubId])errs.push('clube '+v.clubId+' já está em '+byClub[v.clubId]+' (um arquivo por clube)');
    v.players.forEach(p=>{
      if(byPlayerId[p.id]&&byPlayerId[p.id].club!==v.clubId)errs.push('id "'+p.id+'" já usado no clube '+byPlayerId[p.id].club);
      const k=FCS.norm(p.fullName)+'|'+p.nationality;
      if(byPerson[k]&&byPerson[k]!==v.clubId)ws.push(p.fullName+' também aparece no clube '+byPerson[k]+' (mesmo jogador em dois clubes?)');
    });
    if(v.players.length<FCS.MIN_PLAYERS)errs.push('elenco com menos de '+FCS.MIN_PLAYERS+' jogadores ('+v.players.length+')');
  }
  if(errs.length){bad++;console.log('✗ '+f);errs.forEach(e=>console.log('    ERRO: '+e));ws.forEach(w=>console.log('    aviso: '+w));continue;}
  byClub[v.clubId]=f;v.players.forEach(p=>{byPlayerId[p.id]={club:v.clubId};byPerson[FCS.norm(p.fullName)+'|'+p.nationality]=v.clubId;});
  ok.push(f);squads.push({clubId:v.clubId,players:v.players});
  console.log('✓ '+f+' → '+v.clubId+' ('+FC_BY_ID[v.clubId].name+') · '+v.players.length+' jogadores');
  ws.forEach(w=>{warn++;console.log('    aviso: '+w);});
}
console.log('\n'+ok.length+' elenco(s) válido(s), '+bad+' com erro, '+warn+' aviso(s). Clubes sem elenco: '+(FC_CLUBS.length-ok.length)+' de '+FC_CLUBS.length+' (usam jogadores genéricos).');
if(!check){
  fs.writeFileSync(path.join(DIR,'index.json'),JSON.stringify({version:1,files:ok},null,1)+'\n');
  fs.writeFileSync(path.join(DIR,'bundle.js'),'/* Gerado por: node tools/importar-elencos.js — não edite à mão */\nwindow.FC_PLAYERS_BUNDLE='+JSON.stringify({squads})+';\n');
  console.log('players/index.json e players/bundle.js atualizados.');
}
process.exit(bad?1:0);
