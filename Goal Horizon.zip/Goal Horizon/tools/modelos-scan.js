// Lê models/stadiums/*.glb, models/animations/*.glb e models/animations.json e devolve o manifesto usado pelo jogo.
const fs=require('fs'),p=require('path');
const slug=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,'');
const pretty=f=>f.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
function list(d){try{return fs.readdirSync(d).filter(f=>/\.(glb|gltf)$/i.test(f)).sort();}catch(e){return [];}}
function readJSON(f){try{return JSON.parse(fs.readFileSync(f,'utf8'));}catch(e){return null;}}
module.exports=function(root){
 const M=p.join(root,'models'),out={stadiums:[],animations:[],animMap:{},player:{}};
 for(const f of list(p.join(M,'stadiums'))){
  const cfg=readJSON(p.join(M,'stadiums',f.replace(/\.[^.]+$/,'.json')))||{};
  out.stadiums.push({id:slug(f.replace(/\.[^.]+$/,'')),name:cfg.name||pretty(f),file:'stadiums/'+f,cfg});
 }
 for(const f of list(p.join(M,'animations')))out.animations.push('animations/'+f);
 const a=readJSON(p.join(M,'animations.json'));
 if(a){out.animMap=a.map||{};out.player=a.player||{};}
 return out;
};
