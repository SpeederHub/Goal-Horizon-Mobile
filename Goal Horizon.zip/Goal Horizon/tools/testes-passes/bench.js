// Bancada de testes de passe (headless). uso: node bench.js <pasta do jogo> [seed]
const load=require('./load.js');
const dir=(process.argv[2]||require('path').join(__dirname,'../..'))||require('path').join(__dirname,'../..');let seed=+process.argv[3]||1;
const rng=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
Math.random=rng;
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,G=()=>s.G,{hyp,cos,sin,PI}=s;
const HLv=s.HL,HWv=s.HW;
const DT=1/60;
function setup(o){
 s.initMatch();const g=G();
 g.restart=null;g.clearR=0;g.restartT=0;g.state='play';
 const human=o.mode==='human';
 s.LC.active=human;s.CTL[1].active=false;
 // todos longe: time 0 (ataca +x) e time 1
 const T0=g.teamP[0],T1=g.teamP[1];
 T0.forEach((p,i)=>{p.x=-45+ (i%4)*3;p.z=-30+(i%11)*5.5;p.vx=p.vz=0;p.ctrlCd=0;});
 T1.forEach((p,i)=>{p.x=40+(i%4)*3;p.z=-30+(i%11)*5.5;p.vx=p.vz=0;p.ctrlCd=0;});
 T0[0].x=-HLv+1.5;T0[0].z=0;T1[0].x=HLv-1.5;T1[0].z=0;
 const P=T0[8];P.x=o.px??Math.min(-10,12-o.d*cos((o.ang||0)*PI/180));P.z=o.pz??(-(o.d*sin((o.ang||0)*PI/180))/2);P.vx=o.pvx??0;P.vz=o.pvz??0;P.face=o.face??0;
 g.ball.x=P.x;g.ball.z=P.z;g.ball.y=s.BR;
 s.setOwner(P);if(human)s.LC.user=P;
 const a=(o.ang||0)*PI/180,d=o.d;
 const R=T0[9];R.x=P.x+cos(a)*d;R.z=P.z+sin(a)*d;
 const rv=o.rv||0,ra=(o.rdir??o.ang??0)*PI/180;R.vx=cos(ra)*rv;R.vz=sin(ra)*rv;R.face=ra;
 // companheiros extra (opcional)
 (o.mates||[]).forEach((m,i)=>{const q=T0[1+i];q.x=P.x+m.x;q.z=P.z+m.z;q.vx=m.vx||0;q.vz=m.vz||0;});
 // adversários
 (o.opps||[]).forEach((m,i)=>{const q=T1[1+i];q.x=(m.abs?0:P.x)+m.x;q.z=(m.abs?0:P.z)+m.z;q.vx=m.vx||0;q.vz=m.vz||0;});
 g.possTeam=0;G().lastTouch=P;
 return{P,R,T0,T1};
}
function runPass(o){
 const {P,R,T0,T1}=setup(o);const g=G(),b=g.ball;
 const ai=o.mode!=='human';
 const aimA=(o.aim??o.ang??0)*PI/180,ax=cos(aimA),az=sin(aimA);
 s.SC=s.S;
 const tgt=o.force?R:s.bestTarget(P,ax,az,o.type,.7,ai);
 s.passTo(P,tgt,ax,az,o.type,.7,ai);
 const chosen=tgt===R?'R':tgt?('T0#'+tgt.i):'none';
 const r0={x:R.x,z:R.z};let t=0,out='timeout',who=null,bsp=0,maxY=0,bx0=b.x,bz0=b.z;
 const fly=[];
 let rel=0;
 for(let i=0;i<60*6;i++){
  rel=R.vx!==undefined?hyp(R.vx-b.vx,R.vz-b.vz):0;
  s.simStep(DT);t+=DT;maxY=Math.max(maxY,b.y);
  if(g.state!=='play'){out='dead';break;}
  if(b.owner){out=b.owner===R?'recv':(b.owner.team===0?'mate':'opp');who=b.owner;bsp=hyp(b.vx,b.vz);break;}
  if(g.restart){out='out';break;}
 }
 // distância ao alvo pretendido / sobra
 return{out,t,rel,chosen,moved:hyp(R.x-r0.x,R.z-r0.z),spd0:null,maxY,bx:b.x,bz:b.z,Rd:hyp(R.x-b.x,R.z-b.z),who:who?('t'+who.team+'#'+who.i):null,ballv:hyp(b.vx,b.vz)};
}
module.exports={runPass,setup,s,rng};
if(require.main===module){
 const rows=[];
 const R=(n,o,N=12)=>{const a={recv:0,mate:0,opp:0,out:0,timeout:0,dead:0},ts=[],rl=[];let ch=0;for(let k=0;k<N;k++){
  const oo=Object.assign({},o);oo.d=o.d*(1+(rng()-.5)*.1);const r=runPass(oo);a[r.out]++;if(r.out==='recv'){ts.push(r.t);rl.push(r.rel);}if(r.chosen==='R')ch++;}
  console.log(n.padEnd(46),`pick=${ch}/${N}`,`recv=${a.recv}`,`opp=${a.opp}`,`mate=${a.mate}`,`out=${a.out}`,`timeout=${a.timeout}`,ts.length?`t̄=${(ts.reduce((x,y)=>x+y,0)/ts.length).toFixed(2)}s rel̄=${(rl.reduce((x,y)=>x+y,0)/rl.length).toFixed(1)}`:'');};
 for(const mode of ['ai','human'])for(const type of [0,1,2]){
  for(const d of [8,15,25,40]){
   R(`${mode} t${type} d${d} still`,{mode,type,d,ang:0,rv:0,force:true});
   R(`${mode} t${type} d${d} runs fwd 6`,{mode,type,d,ang:20,rv:6,rdir:0,force:true});
   R(`${mode} t${type} d${d} diag60 still`,{mode,type,d,ang:60,rv:0,face:PI/3,force:true});
  }
 }
}
