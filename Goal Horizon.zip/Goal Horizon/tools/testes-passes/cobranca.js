// Teste headless das cobranças com mira (falta e pênalti da partida, usuário e IA) e do Treino de falta:  node tools/testes-passes/cobranca.js [N]
const load=require('./load.js');
let seed=11;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const dir=require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,{hyp,cos,sin,PI}=s;
const N=+process.argv[2]||60;
function sim(g,sec,stop){for(let i=0;i<60*sec;i++){s.simStep(1/60);if(stop&&stop())return true;}return false;}
function press(id){s.In.held[id]=true;s.In.dn[id]=true;}
function release(id){s.In.held[id]=false;s.In.up[id]=true;}
function userKick(kind,power,aimZ,aimY){
 const g=s.G,sp=g.sp;
 if(!sp)return 'nosp';
 // mira: o analógico move 1,8/s lateral e 1,2/s vertical → alimenta direto os valores (equivale a segurar o analógico)
 sp.aimZ=aimZ;sp.aimY=aimY;
 press('X');s.simStep(1/60);s.In.dn.X=false;
 let n=0;while(sp.power<power&&n++<200)s.simStep(1/60);
 release('X');
 return 'ok';
}
function outcome(g,b,ownerTeamFn){
 const r={goal:0,wall:0,gk:0,out:0,other:0};
 return r;
}
function runKind(kind,N,userSide){
 const res={goal:0,barreira:0,goleiro:0,defesa:0,fora:0,other:0,nosp:0},hs=[];
 for(let n=0;n<N;n++){
  s.initMatch();const g=s.G,b=g.ball;s.LC.active=true;
  const taker=g.teamP[userSide===0?0:1][9],def=g.teamP[userSide===0?1:0];
  const D=kind==='free'?17+Math.random()*15:11,z=kind==='free'?(Math.random()<.5?-1:1)*(1+Math.random()*13):0;
  const dir=taker.team?-1:1,bx=s.HL*dir-dir*(kind==='free'?Math.sqrt(Math.max(1,D*D-z*z)):11);
  // simula a falta no ponto
  g.state='play';
  const o=taker;o.x=bx;o.z=z;
  s.setRestart(kind,taker.team,bx,z,o,dir>0?0:PI);
  if(userSide===0){
   if(!g.sp){res.nosp++;continue;}
   userKick(kind,.8,(Math.random()-.5)*1.6,.3+Math.random()*.6);
  }else{
   // IA: espera restartAct
  }
  const wallx=bx+dir*9.15;let yw=null;
  const wallSet=new Set(g.wall||[]);let kicked=false,done=null;
  for(let i=0;i<60*8&&!done;i++){
   s.simStep(1/60);
   if(!kicked&&!g.restart&&b.kicker===taker){kicked=true;}
   if(kicked&&yw===null&&dir*(b.x-wallx)>=0)yw=b.y;
   if(!kicked)continue;
   if(g.state==='goal'){done='goal';break;}
   const lt=g.lastTouch;
   if(lt&&lt!==taker&&lt.team!==taker.team){done=lt.role==='GK'?'goleiro':(wallSet.has(lt)?'barreira':'defesa');break;} // primeiro toque do adversário
   if(g.restart&&(g.restart.kind==='goalkick'||g.restart.kind==='corner'||g.restart.kind==='throw')){done='fora';break;}
  }
  if(!kicked)done='nao-chutou';
  res[done||'other']++;if(yw!==null)hs.push(yw);
 }
 return {res,hAvg:hs.length?(hs.reduce((a,c)=>a+c,0)/hs.length).toFixed(2):'-'};
}
console.log('FALTA (usuário):',JSON.stringify(runKind('free',N,0)));
console.log('PÊNALTI (usuário):',JSON.stringify(runKind('pen',N,0)));
console.log('FALTA (IA):',JSON.stringify(runKind('free',N,1)));
console.log('PÊNALTI (IA):',JSON.stringify(runKind('pen',N,1)));
