// Valida a distribuição de jogadores/personagens. uso: node tools/testes-passes/elenco.js [pasta]
const load=require('./load.js');
const dir=process.argv[2]||require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,F=s.FCS;
const clubs=Object.keys(ctx.FC_PLAYERS_BUNDLE?{}:{}).length?[]:[];
let ids=new Set(),vazias=0,dup=0,tot=0,genericos=0;
for(const sq of ctx.FC_PLAYERS_BUNDLE.squads){
 const id=sq.clubId;if(!F.has(id))continue;tot++;
 const r=s.buildRoster([id,id]);
 for(const t of [0,1]){
  const pids=r[t].map(x=>x.pid);
  if(pids.some(p=>!p)){vazias++;genericos+=pids.filter(p=>!p).length;}
  if(new Set(pids.filter(Boolean)).size!==pids.filter(Boolean).length)dup++;
 }
}
console.log('clubes com elenco',tot,'| times com vaga genérica (sem jogador do clube):',vazias,'| vagas genéricas:',genericos,'| times com jogador repetido:',dup);
// determinismo do visual genérico entre partidas
let diff=0;
for(let k=0;k<5;k++){s.initMatch();const a=s.G.players.map(p=>p.skin+p.hair+p.pid);s.initMatch();const b=s.G.players.map(p=>p.skin+p.hair+p.pid);a.forEach((v,i)=>{if(v!==b[i])diff++;});}
console.log('jogadores com visual diferente entre duas partidas iguais:',diff);
