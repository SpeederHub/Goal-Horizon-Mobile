// Treino de falta com mira (fluxo completo, entrada por botão): node tools/testes-passes/falta-treino.js [N]
const load=require('./load.js');
let seed=5;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const dir=require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,In=s.In;s.LC.active=true;
const N=+process.argv[2]||40;
s.startTraining('foul');
let goals=0,att=0,stuck=0,nan=0,cnt={};
for(let n=0;n<N;n++){
 const g=s.G,tr=g.train,b=g.ball;
 if(!g.sp){stuck++;s.trainPlace();}
 const sp=g.sp;
 // mira com o analógico por 1 s (direita e para cima), depois solta
 In.L.x=.6;In.L.y=-.3;for(let i=0;i<30;i++)s.simStep(1/60);In.L.x=In.L.y=0;
 const before=tr.att,pw=.75+Math.random()*.15;
 In.held.X=true;In.dn.X=true;s.simStep(1/60);In.dn.X=false;
 let k=0;while(sp.power<pw&&k++<200)s.simStep(1/60);
 In.held.X=false;In.up.X=true;
 const a0=tr.att,g0=tr.goals;
 let t=0;for(;t<60*8;t++){s.simStep(1/60);if(tr.wait>0||g.state==='goal')break;}
 for(let i=0;i<60*5&&(tr.wait>0||g.state==='goal');i++)s.simStep(1/60);
 if(!isFinite(b.x)||!isFinite(b.y)||!isFinite(b.z))nan++;
 if(tr.att>a0)att++;
 if(tr.goals>g0)goals++;
 const key=g.state==='goal'?'gol':(b.owner?(b.owner.role==='GK'?'goleiro':'barreira'):'outro');cnt[key]=(cnt[key]||0)+1;
}
console.log({tentativas:att,gols:goals,semMira:stuck,NaN:nan,fim:cnt});
