// Estresse: faltas e pênaltis em sequência (IA e usuário), checando travas, barreira presa e NaN:  node tools/testes-passes/faltas-soak.js [N]
const load=require('./load.js');
let seed=3;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const dir=require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,In=s.In,N=+process.argv[2]||80;
let nan=0,stuckWall=0,stuckSp=0,stuckRestart=0,fouls=0,shots=0;
for(const userOn of [false,true]){
 s.initMatch();s.LC.active=userOn;s.CTL[1].active=false;
 for(let n=0;n<N;n++){
  const g=s.G;
  for(let i=0;i<60*4;i++)s.simStep(1/60); // joga um pouco
  if(g.state==='goal')g.stateT=0;
  // falta aleatória num jogador com a bola (ou qualquer um)
  const tk=g.teamP[n%2][3+(n%6)],o=g.teamP[1-(n%2)][1+((n*3)%9)];
  if(o.role==='GK')continue;
  const sh0=g.stats[0].shots+g.stats[1].shots;
  s.foul(tk,o);fouls++;
  for(let i=0;i<60*14;i++){
   s.simStep(1/60);
   if(g.sp&&g.sp.phase==='aim'&&g.sp.taker.team===0&&i%90===30){ // usuário "cobra"
    const sp=g.sp;sp.aimZ=(Math.random()-.5)*1.6;sp.aimY=.2+Math.random()*.7;
    In.held.X=true;In.dn.X=true;s.simStep(1/60);In.dn.X=false;let k=0;while(sp.power<.6+Math.random()*.35&&k++<200)s.simStep(1/60);In.held.X=false;In.up.X=true;
   }
   if(g.state==='goal'){g.stateT=0;}
   if(!isFinite(g.ball.x+g.ball.y+g.ball.z))nan++;
  }
  if(g.restart&&g.restart.t>12)stuckRestart++;
  if(g.wall)stuckWall++;
  if(g.sp&&g.sp.phase!=='aim')stuckSp++;
  shots+=g.stats[0].shots+g.stats[1].shots-sh0;
  if(g.sp){g.sp=null;} // usuário não respondeu: segue
 }
}
console.log({faltas:fouls,chutes:shots,NaN:nan,barreiraPresa:stuckWall,cobrancaPresa:stuckSp,reposicaoPresa:stuckRestart});
