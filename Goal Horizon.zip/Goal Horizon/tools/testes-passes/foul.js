// Teste headless do Treino de Falta: node tools/testes-passes/foul.js
const load=require('./load.js');
let seed=7;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const dir=require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,{hyp,cos,sin,PI}=s;
s.LC.active=true;
const res={goal:0,wall:0,gk:0,out:0,other:0},hs=[];
const N=+process.argv[2]||150;
for(let n=0;n<N;n++){
 s.startTraining('foul');const g=s.G,tr=g.train,u=g.user,b=g.ball;
 if(n===0){
  const wall=tr.wall.filter(p=>!p.out);
  const dw=wall.map(p=>hyp(p.x-b.x,p.z-b.z));
  console.log('barreira',wall.length,'jogadores, dist bola',dw.map(d=>d.toFixed(2)).join(','),'| cobrador atrás da bola',hyp(u.x-b.x,u.z-b.z).toFixed(2),'| goleiro x',g.teamP[1][0].x.toFixed(1),'| bola',b.x.toFixed(1),b.z.toFixed(1),'| fora do jogo:',g.players.filter(p=>p.out).length);
 }
 const pw=.35+Math.random()*.7,aimz=(Math.random()-.5)*6;
 s.SC=s.S;s.shoot(u,pw,aimz,false,false);
 let r='other',maxY=0,minWallX=1e9,yAtWall=null;
 const wx=tr.fk.x+cos(tr.fk.ang)*9.15;
 for(let i=0;i<60*6;i++){
  s.simStep(1/60);
  if(yAtWall===null&&b.x>=wx)yAtWall=b.y;
  if(g.state==='goal'){r='goal';break;}
  if(tr.wait>0){const o=b.owner;r=o?(o.role==='GK'?'gk':'wall'):'out';break;}
 }
 res[r]++;if(yAtWall!==null)hs.push(yAtWall);
}
console.log(res,'altura média na barreira',(hs.reduce((a,b)=>a+b,0)/hs.length).toFixed(2));
