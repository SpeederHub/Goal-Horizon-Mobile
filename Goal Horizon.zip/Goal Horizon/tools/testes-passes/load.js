// Carrega os scripts do jogo num sandbox sem DOM e devolve o escopo global (para testes headless)
const vm=require('vm'),fs=require('fs'),path=require('path');
module.exports=function load(dir,files){
 const mk=()=>{const f=function(){};return new Proxy(f,{get:(t,k)=>{if(k===Symbol.toPrimitive)return()=>0;if(k==='length')return 0;if(k==='style'||k==='classList'||k==='dataset')return mk();return mk();},set:()=>true,apply:()=>mk(),construct:()=>mk(),has:()=>true});};
 const store={};
 const sb={console,Math,Date,JSON,Object,Array,Number,String,Boolean,Map,Set,WeakMap,Float32Array,Float64Array,Uint8Array,Int32Array,Uint16Array,Uint32Array,Promise,Symbol,Error,RegExp,parseInt,parseFloat,isNaN,isFinite,
  setTimeout:()=>0,clearTimeout(){},setInterval:()=>0,clearInterval(){},requestAnimationFrame:()=>0,cancelAnimationFrame(){},performance:{now:()=>Date.now()},
  localStorage:{getItem:k=>store[k]||null,setItem:(k,v)=>{store[k]=v;},removeItem:k=>{delete store[k];}},
  navigator:{vibrate:null,userAgent:'node',maxTouchPoints:0,getGamepads:()=>[]},
  document:mk(),location:{href:'',search:'',hash:'',protocol:'http:',host:'x'},screen:{width:800,height:400},
  Image:function(){return mk();},Audio:function(){return mk();},AudioContext:function(){return mk();},WebSocket:function(){return mk();},fetch:()=>Promise.reject(new Error('x')),
  XMLHttpRequest:function(){return mk();},URL:{createObjectURL:()=>''},Blob:function(){},innerWidth:800,innerHeight:400,devicePixelRatio:1,matchMedia:()=>({matches:false,addEventListener(){}}),
  addEventListener(){},removeEventListener(){},};
 sb.window=sb;sb.self=sb;sb.globalThis=sb;
 const ctx=vm.createContext(sb);
 let src='';
 src+=fs.readFileSync(path.join(__dirname,'prelude.js'),'utf8')+'\n';
 for(const f of files){src+=fs.readFileSync(path.join(dir,f),'utf8')+'\n;\n';}
 // expõe consts/lets do escopo de topo
 src+=';globalThis.__scope={};'+['shoot','nearestOppDist','G', 'S', 'SC', 'clamp', 'hyp', 'PI', 'cos', 'sin', 'abs', 'groundPass', 'bestTarget', 'passTo', 'kickBall', 'stepBallSub', 'checkPickup', 'initMatch', 'simStep', 'ctlOf', 'CTL', 'LC', 'HL', 'HW', 'BR', 'PQ', 'setOwner', 'updatePlayer', 'aiPlayer', 'physCore', 'lobSpeed', 'laneRisk', 'computeRanks', 'separation', 'checkBounds', 'gkSaves', 'kickoff', 'PA', 'livePass', 'planPass', 'PP', 'ballPath', 'receiveTarget', 'BP', 'startTraining', 'trainPlace', 'trainUpdate', 'trainNext', 'In', 'TR_INFO', 'freeKick', 'setRestart', 'foul', 'spBegin', 'spStep', 'spKick', 'spAI', 'spBuildWall', 'penErr', 'PEN_DIFF', 'buildRoster', 'mkPlayer', 'FCS', 'T3x'].map(n=>'try{__scope.'+n+'='+(n==='G'||n==='S'||n==='SC'?'0':n)+';}catch(e){}').join('')+'Object.defineProperty(__scope,"G",{get(){return G;}});Object.defineProperty(__scope,"S",{get(){return S;}});Object.defineProperty(__scope,"SC",{get(){return SC;},set(v){SC=v;}});';
 vm.runInContext(src,ctx,{filename:'game-bundle.js'});
 return ctx;
};
