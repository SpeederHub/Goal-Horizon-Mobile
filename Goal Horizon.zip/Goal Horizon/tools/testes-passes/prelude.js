var PT=[];function snapCamera(){}function fxPuff(){}function fxBurst(){}function fxKick(){}function fxGhost(){}function fxGoal(){}function stepFX(){}
var C={gfx:0,gfz:-1,grx:1,grz:0};
var resize=function(){};var lastTsStub=0;
