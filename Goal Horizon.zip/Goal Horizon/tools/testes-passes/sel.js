const B=require('./bench.js');const s=B.s,{cos,sin,PI,hyp}=s;
function pick(o,stickDeg,type,held=true){
 const {P,T0}=B.setup(Object.assign({mode:'human',d:10,ang:0},o.base||{}));
 // companheiros: ângulos relativos ao passador (graus) e distâncias
 const ms=o.mates.map((m,i)=>{const q=T0[1+i];q.x=P.x+cos(m[0]*PI/180)*m[1];q.z=P.z+sin(m[0]*PI/180)*m[1];q.vx=q.vz=0;return q;});
 T0[9].x=-50;T0[9].z=30;  // afasta o receptor padrão
 (o.opps||[]).forEach((m,i)=>{const q=s.G.teamP[1][1+i];q.x=P.x+m[0];q.z=P.z+m[1];q.vx=q.vz=0;});
 if(s.PA)s.PA.held=held;s.SC=s.S;
 const a=stickDeg*PI/180,t=s.bestTarget(P,cos(a),sin(a),type,.7,false);
 return t?ms.indexOf(t):-1;
}
const M=[[0,12],[45,12],[-45,12],[90,12],[-90,12],[180,12],[135,12]];
console.log('stick → índice escolhido (0:0°,1:45°,2:-45°,3:90°,4:-90°,5:180°,6:135°), -1 = espaço');
for(const st of [0,20,45,70,90,135,180,-30,-90]){console.log('stick',String(st).padStart(4),'tipo0 →',pick({mates:M},st,0),' tipo1 →',pick({mates:M},st,1),' tipo2 →',pick({mates:M},st,2));}
console.log('--- marcado × livre (mesma direção ±10°)');
console.log('A marcado(0°,14m,adv 1m) B livre(10°,14m): escolhe',pick({mates:[[0,14],[10,14]],opps:[[14,.8]]},5,0)===1?'B (livre) OK':'A');
console.log('--- corredor bloqueado: adv no meio do passe A; B livre a 12°');
console.log('escolhe',pick({mates:[[0,16],[30,16]],opps:[[8,0]]},12,0)===1?'B OK':'A');
console.log('--- sem analógico (face 0°): escolhe quem está à frente?',pick({mates:[[0,12],[180,8]]},0,0,false));
