const B=require('./bench.js');const s=B.s,{hyp,cos,sin,PI}=s;
function trial(o){
 const {P,T1}=B.setup({mode:'ai',d:5,ang:0,px:s.HL-o.d,pz:o.z||0,pvx:o.sp||0,face:o.face||0,opps:o.opps});
 T1[0].out=true;const g=s.G,b=g.ball;g.ball.x=P.x;g.ball.z=P.z;
 s.SC=s.S;
 s.G.teamP[0].forEach(q=>{if(q!==P){q.x=-45;}});
 const gz=o.aimz??(rnd()-.5)*4;
 s.shoot(P,o.pw,gz,false,false);
 let v0=hyp(b.vx,b.vz,b.vy),res='miss';
 for(let i=0;i<60*3;i++){s.simStep(1/60);if(b.x>=s.HL){res=(Math.abs(b.z)<3.66&&b.y<2.44)?'goal':'wide';break;}if(b.x<P.x-1&&Math.abs(b.vx)<1)break;}
 return{res,v0,over:b.y>=2.44};
}
function rnd(){return Math.random();}
module.exports={trial};

if(require.main===module){
 const N=300;
 for(const [d,name] of [[12,'12m'],[18,'18m'],[26,'26m'],[34,'34m']])
 for(const pw of [.4,.65,.9,1.08]){
  for(const [lab,extra] of [['parado',{}],['correndo 7',{sp:7}],['marcado',{opps:[{x:-1,z:.5,abs:false}]}]]){
   let g=0,w=0,vs=0;for(let k=0;k<N;k++){const r=trial(Object.assign({d,pw,aimz:(Math.random()-.5)*4},extra));if(r.res==='goal')g++;else w++;vs+=r.v0;}
   console.log(name,'carga',pw,lab.padEnd(10),'no alvo',String(Math.round(100*g/N)).padStart(3)+'%','vel',(vs/N).toFixed(1));
  }}
}
