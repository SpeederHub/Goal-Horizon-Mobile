let seed=+process.argv[3]||7;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const load=require('./load.js');
const ctx=load((process.argv[2]||require('path').join(__dirname,'../..')),['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,G=()=>s.G;
s.initMatch();s.LC.active=false;s.CTL[1].active=false;
let pend=null;const st={n:0,ok:0,opp:0,loose:0,dist:0};
const op=ctx.passTo;ctx.passTo=function(p,t,...r){const b=G().ball;const x0=b.x,z0=b.z;op(p,t,...r);pend={team:p.team,t:G().t,x0,z0,own:p};};
let lastOwner=null,nan=0;const t0=process.hrtime.bigint();
const N=60*60*10; // 10 min simulados
for(let i=0;i<N;i++){
 s.simStep(1/60);const g=G(),b=g.ball;
 if(!isFinite(b.x+b.z+b.y))nan++;
 if(g.state==='goal'){g.stateT=0;}
 if(pend){
  if(b.owner&&b.owner!==pend.own){st.n++;st.dist+=Math.hypot(b.x-pend.x0,b.z-pend.z0);if(b.owner.team===pend.team)st.ok++;else st.opp++;pend=null;}
  else if(g.t-pend.t>6||g.restart){st.n++;st.loose++;pend=null;}
 }
}
const ms=Number(process.hrtime.bigint()-t0)/1e6;
console.log(`passes=${st.n} completos=${(100*st.ok/st.n).toFixed(0)}% interceptados=${(100*st.opp/st.n).toFixed(0)}% perdidos/fora=${(100*st.loose/st.n).toFixed(0)}% dist média=${(st.dist/st.n).toFixed(1)}m  placar=${G().score}  NaN=${nan}  cpu/passo=${(ms/N*1000).toFixed(1)}µs`);
