// Conta saltos de posição do jogador durante o Treino de chute. uso: node teleporte.js [pasta do jogo]
const load=require('./load.js');
let seed=11;Math.random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
const dir=process.argv[2]||require('path').join(__dirname,'../..');
const ctx=load(dir,['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope,{hyp}=s;s.LC.active=true;
s.startTraining('shoot');const g=s.G,u=g.user;let px=u.x,pz=u.z,placed=0,jumps=[];
const origPlace=s.trainPlace;
for(let shot=0;shot<12;shot++){
 // chuta e, durante a espera entre tentativas, o jogador tenta correr/chutar de novo
 s.SC=s.S;s.shoot(u,.6+Math.random()*.3,(Math.random()-.5)*5,false,false);
 for(let i=0;i<60*9;i++){
  const tr=g.train;
  if(tr.wait>0||g.state==='goal'){s.In.L.x=1;s.In.L.y=-1;s.In.held.RT=true;}else{s.In.L.x=0;s.In.L.y=0;}
  const wasWait=tr.wait>0,st=g.state,ax=u.x,az=u.z;
  s.simStep(1/60);
  const d=hyp(u.x-ax,u.z-az);
  if(d>1.0)jumps.push({d:+d.toFixed(1),antesWait:wasWait,estado:st,depoisWait:tr.wait>0,tentativa:shot});
 }
}
console.log('saltos >1 m em 1 frame:',jumps.length);console.log(JSON.stringify(jumps.slice(0,6)));
