// Fumaça: inicia cada treino e simula 25 s sem erros. uso: node tools/testes-passes/treinos.js
const load=require('./load.js');
const ctx=load(require('path').join(__dirname,'../..'),['clubs.js','players/bundle.js','squads.js','league.js','competitions.js','game.js','audio.js','input.js']);
const s=ctx.__scope;s.LC.active=true;
for(const t of ['shoot','foul','pass','poss']){
 s.startTraining(t);const g=s.G;let bad=0;
 for(let i=0;i<60*25;i++){s.simStep(1/60);for(const p of g.players){if(!p.out&&(!isFinite(p.x)||!isFinite(p.z)))bad++;}if(!isFinite(g.ball.x))bad++;}
 console.log(t,'ok | jogadores em campo:',g.players.filter(p=>!p.out).length,'| NaN:',bad,'| estado:',g.state);
}
// reinício repetido da falta
for(let i=0;i<30;i++)s.startTraining('foul');
console.log('30 reinícios da falta: ok');
